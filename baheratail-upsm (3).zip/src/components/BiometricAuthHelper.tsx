import React, { useState, useEffect } from 'react';
import {
  Fingerprint,
  ShieldCheck,
  Key,
  Smartphone,
  Laptop,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  RefreshCw,
  Trash2,
  Lock,
  Unlock,
  ShieldAlert,
  Clock,
  UserCheck,
  Check,
  Sliders,
  Cpu,
  Eye,
  Activity
} from 'lucide-react';
import {
  isWebAuthnSupported,
  isPlatformBiometricAvailable,
  getWebAuthnDiagnostics,
  getStoredPasskeys,
  savePasskeyToStorage,
  deletePasskeyFromStorage,
  registerWebAuthnPasskey,
  verifyWebAuthnPasskey,
  verifySecurityPin,
  getBiometricSessionElevation,
  setBiometricSessionElevation,
  clearBiometricSessionElevation,
  WebAuthnDiagnostics,
  BiometricSessionState
} from '../utils/webauthn';
import { WebAuthnPasskeyCredential, AdminUserRecord, UnionParishadConfig } from '../types';
import { addAuditLogToFirebase } from '../firebase';

interface BiometricAuthHelperProps {
  currentUserEmail?: string;
  currentUserName?: string;
  currentUserRole?: string;
  adminRecord?: AdminUserRecord | null;
  config: UnionParishadConfig;
  onElevationChange?: (elevated: boolean) => void;
}

export const BiometricAuthHelper: React.FC<BiometricAuthHelperProps> = ({
  currentUserEmail = 'admin@boheratoil.gov.bd',
  currentUserName = 'ইউপি কর্মকর্তা',
  currentUserRole = 'super_admin',
  adminRecord,
  config,
  onElevationChange
}) => {
  const [diagnostics, setDiagnostics] = useState<WebAuthnDiagnostics | null>(null);
  const [isLoadingDiagnostics, setIsLoadingDiagnostics] = useState<boolean>(true);
  const [passkeys, setPasskeys] = useState<WebAuthnPasskeyCredential[]>([]);
  const [sessionElevation, setSessionElevation] = useState<BiometricSessionState | null>(null);
  
  // Interactive challenge states
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [isRegistering, setIsRegistering] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [customDeviceName, setCustomDeviceName] = useState<string>('');
  const [isEnrollModalOpen, setIsEnrollModalOpen] = useState<boolean>(false);

  // Security PIN state
  const [pinInput, setPinInput] = useState<string>('');
  const [isPinSubmitting, setIsPinSubmitting] = useState<boolean>(false);

  const effectiveEmail = (adminRecord?.email || currentUserEmail).toLowerCase().trim();
  const effectiveName = adminRecord?.name || currentUserName;

  // Run diagnostics and load passkeys
  const refreshStatus = async () => {
    setIsLoadingDiagnostics(true);
    try {
      const diag = await getWebAuthnDiagnostics();
      setDiagnostics(diag);

      const stored = getStoredPasskeys(effectiveEmail);
      setPasskeys(stored);

      const currentElev = getBiometricSessionElevation();
      setSessionElevation(currentElev);
      if (onElevationChange) {
        onElevationChange(!!currentElev?.isElevated);
      }
    } catch (err) {
      console.warn('Error refreshing biometric status:', err);
    } finally {
      setIsLoadingDiagnostics(false);
    }
  };

  useEffect(() => {
    refreshStatus();
  }, [effectiveEmail]);

  // Handle Biometric Scan & Elevation Challenge
  const handleTestBiometricChallenge = async () => {
    setIsVerifying(true);
    setErrorMessage(null);
    setStatusMessage('আপনার ডিভাইসের বায়োমেট্রিক সেন্সর (Touch ID / Face ID / Windows Hello) স্পর্শ করুন...');

    try {
      const res = await verifyWebAuthnPasskey(effectiveEmail);
      if (res.success) {
        setStatusMessage(res.message);
        const elev = setBiometricSessionElevation(effectiveEmail, res.authType, res.credentialId);
        setSessionElevation(elev);
        if (onElevationChange) onElevationChange(true);

        // Audit Trail Log
        await addAuditLogToFirebase({
          action: 'ADMIN_LOGIN',
          actionTitle: 'WebAuthn বায়োমেট্রিক নিরাপত্তা যাচাই সম্পন্ন',
          details: `ইউপি কর্মকর্তা ${effectiveName} (${effectiveEmail}) [রোল: ${currentUserRole}] ডিভাইসের WebAuthn বায়োমেট্রিক ভেরিফিকেশন সফলভাবে সম্পন্ন করিয়াছেন।`,
          performedByEmail: effectiveEmail,
          performedByName: effectiveName,
          performedByRole: (adminRecord?.role || currentUserRole) as any
        }).catch(() => {});

        refreshStatus();
      } else {
        setErrorMessage(res.message);
      }
    } catch (err: any) {
      setErrorMessage(`বায়োমেট্রিক স্ক্যানকালে অপ্রত্যাশিত সমস্যা: ${err.message || 'অজানা ত্রুটি'}`);
    } finally {
      setIsVerifying(false);
    }
  };

  // Handle Enrollment / Registering a new passkey
  const handleEnrollPasskey = async () => {
    setIsRegistering(true);
    setErrorMessage(null);
    setStatusMessage('বায়োমেট্রিক প্যাসকি রেজিস্ট্রেশনের জন্য সেন্সরে স্পর্শ করুন...');

    try {
      const res = await registerWebAuthnPasskey(effectiveEmail, effectiveName);
      if (res.success && res.passkey) {
        if (customDeviceName.trim()) {
          res.passkey.deviceName = customDeviceName.trim();
          savePasskeyToStorage(effectiveEmail, res.passkey);
        }

        setStatusMessage(res.message);
        setIsEnrollModalOpen(false);
        setCustomDeviceName('');

        // Audit log
        await addAuditLogToFirebase({
          action: 'CONFIG_UPDATED',
          actionTitle: 'নতুন বায়োমেট্রিক ডিভাইস প্যাসকি এনরোলমেন্ট',
          details: `কর্মকর্তা ${effectiveName} (${effectiveEmail}) নতুন হার্ডওয়্যার ডিভাইস প্যাসকি [${res.passkey.deviceName}] সফলভাবে যুক্ত করিয়াছেন।`,
          performedByEmail: effectiveEmail,
          performedByName: effectiveName,
          performedByRole: (adminRecord?.role || currentUserRole) as any
        }).catch(() => {});

        refreshStatus();
      } else {
        setErrorMessage(res.message);
      }
    } catch (err: any) {
      setErrorMessage(`প্যাসকি নিবন্ধনে ত্রুটি: ${err.message || 'অজানা সমস্যা'}`);
    } finally {
      setIsRegistering(false);
    }
  };

  // Handle Revoking a passkey
  const handleRevokePasskey = async (pkId: string, deviceName: string) => {
    if (!window.confirm(`আপনি কি নিশ্চিত যে '${deviceName}' প্যাসকি ডিভাইসের অ্যাকসেস বাতিল করতে চান?`)) return;

    deletePasskeyFromStorage(effectiveEmail, pkId);
    
    await addAuditLogToFirebase({
      action: 'ADMIN_REMOVED',
      actionTitle: 'বায়োমেট্রিক প্যাসকি বাতিলকরণ',
      details: `কর্মকর্তা ${effectiveName} (${effectiveEmail}) তাহার ডিভাইস প্যাসকি [${deviceName}] বাতিল করিয়াছেন।`,
      performedByEmail: effectiveEmail,
      performedByName: effectiveName,
      performedByRole: (adminRecord?.role || currentUserRole) as any
    }).catch(() => {});

    setStatusMessage(`✓ '${deviceName}' প্যাসকি সফলভাবে মুছে ফেলা হয়েছে।`);
    refreshStatus();
  };

  // Handle PIN fallback elevation
  const handlePinElevation = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (verifySecurityPin(pinInput)) {
      const elev = setBiometricSessionElevation(effectiveEmail, 'Master Security PIN');
      setSessionElevation(elev);
      if (onElevationChange) onElevationChange(true);
      setStatusMessage('✓ অফিশিয়াল মাস্টার সিকিউরিটি পিন যাচাই সফল হয়েছে! সেশন সুরক্ষিত ও এলিভেটেড।');
      setPinInput('');
      refreshStatus();
    } else {
      setErrorMessage('⚠️ ভুল সিকিউরিটি পিন নম্বর প্রদান করা হয়েছে। দয়া করে সঠিক ৬-ডিজিটের মাস্টার পিন দিন।');
    }
  };

  // Clear / Revoke Session Elevation
  const handleRevokeElevation = () => {
    clearBiometricSessionElevation();
    setSessionElevation(null);
    if (onElevationChange) onElevationChange(false);
    setStatusMessage('বায়োমেট্রিক এলিভেটেড অ্যাকসেস নিরাপদভাবে লক করা হয়েছে।');
  };

  return (
    <div className="space-y-6">
      
      {/* 1. Main Header Strip */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 text-white p-6 md:p-8 rounded-3xl shadow-xl border border-emerald-800/80 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-amber-400/20 text-amber-300 border border-amber-400/40 rounded-full text-xs font-black uppercase tracking-wider">
              <Fingerprint className="w-4 h-4 text-amber-300" />
              <span>Web Authentication (WebAuthn / FIDO2) Local Security Core</span>
            </div>

            <h2 className="text-xl md:text-2xl font-black text-white tracking-tight">
              লোকাল বায়োমেট্রিক ও প্যাসকি সিকিউরিটি হেল্পার
            </h2>

            <p className="text-xs md:text-sm text-emerald-100/90 max-w-2xl leading-relaxed">
              ইউনিয়ন পরিষদ কর্মকর্তাদের উচ্চ-নিরাপত্তাযুক্ত ডিজিটাল অ্যাকসেস নিশ্চিত করতে ব্রাউজারের নেটিভ Web Authentication API এর মাধ্যমে Touch ID, Face ID, Windows Hello ও ফিঙ্গারপ্রিন্ট প্যাসকি ভেরিফিকেশন।
            </p>
          </div>

          {/* Quick Elevation Status Card */}
          <div className="bg-white/10 backdrop-blur-md p-4 md:p-5 rounded-2xl border border-white/20 shrink-0 min-w-[280px] space-y-3">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="text-xs font-extrabold text-amber-300 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-300" />
                <span>বায়োমেট্রিক সিকিউরিটি স্ট্যাটাস</span>
              </span>
              <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full border ${
                sessionElevation?.isElevated
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400 animate-pulse'
                  : 'bg-amber-500/20 text-amber-300 border-amber-400/50'
              }`}>
                {sessionElevation?.isElevated ? '🔒 সিকিউরলি এলিভেটেড' : 'স্ট্যান্ডার্ড অ্যাকসেস'}
              </span>
            </div>

            <div className="text-xs text-white/90 space-y-1">
              <p className="font-extrabold text-xs truncate flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>{effectiveName}</span>
              </p>
              <p className="text-[11px] text-emerald-200 truncate">{effectiveEmail}</p>
              {sessionElevation?.isElevated && (
                <p className="text-[10px] text-amber-300 font-mono">
                  ভেরিফায়েড: {sessionElevation.authType} ({new Date(sessionElevation.elevatedAt).toLocaleTimeString('bn-BD')})
                </p>
              )}
            </div>

            <div className="pt-1 flex gap-2">
              {sessionElevation?.isElevated ? (
                <button
                  type="button"
                  onClick={handleRevokeElevation}
                  className="w-full py-2 px-3 bg-rose-600/90 hover:bg-rose-600 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>লক করুন (Lock Elevation)</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleTestBiometricChallenge}
                  disabled={isVerifying}
                  className="w-full py-2.5 px-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Fingerprint className="w-4 h-4 text-slate-950" />
                  <span>{isVerifying ? 'স্ক্যান হচ্ছে...' : 'বায়োমেট্রিক আনলক করুন'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Status Toasts */}
      {statusMessage && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 p-4 rounded-2xl text-xs font-bold flex items-center justify-between gap-3 shadow-sm animate-fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{statusMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setStatusMessage(null)}
            className="text-slate-400 hover:text-slate-600 font-black text-sm"
          >
            ✕
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-2xl text-xs font-bold flex items-center justify-between gap-3 shadow-sm animate-fade-in">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setErrorMessage(null)}
            className="text-slate-400 hover:text-slate-600 font-black text-sm"
          >
            ✕
          </button>
        </div>
      )}

      {/* 2. Device Diagnostics & Readiness Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Card 1: WebAuthn API Support */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="p-2.5 bg-emerald-100 text-emerald-900 rounded-xl">
              <Cpu className="w-5 h-5" />
            </div>
            {diagnostics?.isSupported ? (
              <span className="px-2.5 py-1 bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-full text-[10px] font-black">
                ✓ সক্রিয় (Supported)
              </span>
            ) : (
              <span className="px-2.5 py-1 bg-rose-100 text-rose-800 border border-rose-300 rounded-full text-[10px] font-black">
                অসমর্থিত
              </span>
            )}
          </div>
          <div>
            <h3 className="font-extrabold text-slate-900 text-sm">Web Authentication API</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              ব্রাউজার: <span className="font-bold text-slate-700">{diagnostics?.browserType || 'সনাক্ত করা হচ্ছে'}</span>
            </p>
            <p className="text-[11px] text-slate-500">
              নিরাপত্তা মান: <span className="font-mono text-emerald-700">W3C WebAuthn Level 2/3</span>
            </p>
          </div>
        </div>

        {/* Card 2: Biometric Hardware Sensor */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="p-2.5 bg-amber-100 text-amber-900 rounded-xl">
              <Fingerprint className="w-5 h-5" />
            </div>
            {diagnostics?.isPlatformAvailable ? (
              <span className="px-2.5 py-1 bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-full text-[10px] font-black">
                ✓ সেন্সর প্রস্তুত
              </span>
            ) : (
              <span className="px-2.5 py-1 bg-amber-100 text-amber-900 border border-amber-300 rounded-full text-[10px] font-black">
                প্যাসকি / পিন সক্রিয়
              </span>
            )}
          </div>
          <div>
            <h3 className="font-extrabold text-slate-900 text-sm">হার্ডওয়্যার বায়োমেট্রিক সেন্সর</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              ডিভাইস: <span className="font-bold text-slate-700">{diagnostics?.hardwareDeviceName || 'ডিভাইস সেন্সর'}</span>
            </p>
            <p className="text-[11px] text-slate-500">
              ওএস: <span className="font-medium text-slate-700">{diagnostics?.osName}</span>
            </p>
          </div>
        </div>

        {/* Card 3: Enrolled Passkeys */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="p-2.5 bg-teal-100 text-teal-900 rounded-xl">
              <Smartphone className="w-5 h-5" />
            </div>
            <span className="px-2.5 py-1 bg-teal-100 text-teal-900 border border-teal-300 rounded-full text-[10px] font-black">
              {passkeys.length} টি প্যাসকি
            </span>
          </div>
          <div>
            <h3 className="font-extrabold text-slate-900 text-sm">নিবন্ধিত ডিভাইস প্যাসকি</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              প্রস্তাবিত মেথড: <span className="font-bold text-teal-800">{diagnostics?.recommendedMethod || 'Touch ID / Passkey'}</span>
            </p>
            <p className="text-[11px] text-slate-500">
              এনক্রিপশন: <span className="font-mono text-slate-700">ES256 / RS256 Public-Key</span>
            </p>
          </div>
        </div>

      </div>

      {/* 3. Interactive Biometric Operations Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Live Biometric Testing & Challenge (7 cols) */}
        <div className="lg:col-span-7 bg-white p-6 md:p-7 rounded-3xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-200 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-emerald-900 text-amber-300 rounded-xl font-black">
                <Fingerprint className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black text-slate-900 text-base">
                  লাইভ বায়োমেট্রিক চ্যালেঞ্জ ও সেশন এলিভেশন
                </h3>
                <p className="text-xs text-slate-500">
                  ডিভাইসের সেন্সর স্ক্যান করে উচ্চ-নিরাপত্তা প্রশাসনিক অ্যাকসেস নিশ্চিত করুন
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={refreshStatus}
              disabled={isLoadingDiagnostics}
              className="p-2 hover:bg-slate-100 text-slate-600 rounded-xl transition cursor-pointer"
              title="রিফ্রেশ স্ট্যাটাস"
            >
              <RefreshCw className={`w-4 h-4 ${isLoadingDiagnostics ? 'animate-spin text-emerald-700' : ''}`} />
            </button>
          </div>

          {/* Interactive Visual Fingerprint Scanner Box */}
          <div className="bg-gradient-to-b from-slate-50 to-emerald-50/50 p-6 rounded-2xl border border-slate-200/80 text-center space-y-4">
            <div className="relative inline-block">
              <div className={`w-28 h-28 rounded-full flex items-center justify-center mx-auto relative transition-all duration-300 ${
                sessionElevation?.isElevated
                  ? 'bg-emerald-100 border-4 border-emerald-500 text-emerald-700 shadow-lg shadow-emerald-500/20'
                  : isVerifying
                  ? 'bg-amber-100 border-4 border-amber-500 text-amber-600 shadow-lg shadow-amber-500/20 animate-pulse'
                  : 'bg-white border-2 border-slate-300 text-slate-700 hover:border-emerald-500 hover:text-emerald-700 shadow-md'
              }`}>
                {sessionElevation?.isElevated ? (
                  <ShieldCheck className="w-16 h-16 stroke-[2.5]" />
                ) : (
                  <Fingerprint className={`w-16 h-16 ${isVerifying ? 'animate-bounce' : ''}`} />
                )}
                {isVerifying && (
                  <div className="absolute inset-0 rounded-full bg-amber-400/20 animate-ping pointer-events-none" />
                )}
              </div>
            </div>

            <div className="space-y-1">
              <h4 className="font-extrabold text-slate-900 text-sm">
                {sessionElevation?.isElevated
                  ? '✓ আপনার সেশনটি বায়োমেট্রিক ও WebAuthn দ্বারা সুরক্ষিত!'
                  : 'ডিভাইস ফিঙ্গারপ্রিন্ট বা প্যাসকি ভেরিফিকেশন শুরু করুন'}
              </h4>
              <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                {sessionElevation?.isElevated
                  ? `বৈধতার মেয়াদ: ৩০ মিনিট (${new Date(sessionElevation.expiresAt).toLocaleTimeString('bn-BD')} পর্যন্ত)। সকল সংবেদনশীল প্রশাসনিক কমান্ড স্বয়ংক্রিয়ভাবে অনুমোদিত হবে।`
                  : 'চেয়ারম্যান, সচিব ও সিস্টেম সুপার এডমিনদের জন্য প্রত্যয়নপত্র অনুমোদন, ডাটা এক্সপোর্ট ও কনফিগ পরিবর্তনের পূর্বে বায়োমেট্রিক স্পর্শ আবশ্যক।'}
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={handleTestBiometricChallenge}
                disabled={isVerifying}
                className="px-6 py-3 bg-emerald-900 hover:bg-emerald-800 text-amber-300 font-extrabold text-xs rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 active:scale-95"
              >
                <Fingerprint className="w-4 h-4 text-amber-300" />
                <span>{isVerifying ? 'সেন্সরে স্পর্শ করুন...' : 'বায়োমেট্রিক স্ক্যান / অথেন্টিকেশন শুরু করুন'}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsEnrollModalOpen(true)}
                className="px-5 py-3 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-bold text-xs rounded-xl shadow-sm transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Smartphone className="w-4 h-4 text-amber-600" />
                <span>নতুন ডিভাইস প্যাসকি যুক্ত করুন</span>
              </button>
            </div>
          </div>

          {/* High-Security Protected Actions Matrix */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-slate-900 text-xs flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-600" />
              <span>বায়োমেট্রিক এলিভেশন দ্বারা সুরক্ষিত অফিশিয়াল অপারেশনসমূহ:</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-2.5">
                <Check className="w-4 h-4 text-emerald-700 shrink-0 font-black" />
                <span className="text-slate-700 font-medium">নাগরিক প্রত্যয়নপত্র চূড়ান্ত অনুমোদন ও ডিজিটাল স্বাক্ষর</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-2.5">
                <Check className="w-4 h-4 text-emerald-700 shrink-0 font-black" />
                <span className="text-slate-700 font-medium">নতুন ইউপি এডমিন তৈরি ও পদবীভিত্তিক পারমিশন রোল বদল</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-2.5">
                <Check className="w-4 h-4 text-emerald-700 shrink-0 font-black" />
                <span className="text-slate-700 font-medium">মাস্টার সেটআপ ও ক্লাউড ডাটাবেস এক্সপোর্ট/ব্যাকআপ</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-2.5">
                <Check className="w-4 h-4 text-emerald-700 shrink-0 font-black" />
                <span className="text-slate-700 font-medium">সিস্টেম সিকিউরিটি অডিট ট্রেইল মুছে ফেলা বা সংরক্ষণ</span>
              </div>
            </div>
          </div>

        </div>

        {/* Right Column: Passkey Vault & Master PIN (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Box 1: Enrolled Passkeys Vault */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <Laptop className="w-5 h-5 text-emerald-800" />
                <h3 className="font-extrabold text-slate-900 text-sm">
                  নিবন্ধিত প্যাসকি ভল্ট ({passkeys.length})
                </h3>
              </div>

              <button
                type="button"
                onClick={() => setIsEnrollModalOpen(true)}
                className="text-[11px] font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1 cursor-pointer"
              >
                + নতুন প্যাসকি
              </button>
            </div>

            {passkeys.length === 0 ? (
              <div className="p-5 bg-slate-50 border border-dashed border-slate-300 rounded-2xl text-center space-y-2">
                <p className="text-xs text-slate-500 font-medium">
                  এই অফিসিয়াল অ্যাকাউন্টের সাথে কোনো বায়োমেট্রিক প্যাসকি সংরক্ষিত নেই।
                </p>
                <button
                  type="button"
                  onClick={() => setIsEnrollModalOpen(true)}
                  className="px-4 py-2 bg-emerald-900 hover:bg-emerald-800 text-amber-300 font-bold text-xs rounded-xl shadow transition"
                >
                  প্রথম প্যাসকি রেজিস্টার করুন
                </button>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                {passkeys.map(pk => (
                  <div
                    key={pk.id}
                    className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="p-2 bg-white rounded-xl text-emerald-800 border border-slate-200 shrink-0">
                        <Fingerprint className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="font-extrabold text-slate-900 truncate text-xs">{pk.deviceName}</p>
                        <p className="text-[10px] text-slate-500">
                          যুক্ত: {new Date(pk.registeredAt).toLocaleDateString('bn-BD')}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleRevokePasskey(pk.id, pk.deviceName)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer shrink-0"
                      title="প্যাসকি মুছুন"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Box 2: Official Master PIN Fallback */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <Key className="w-5 h-5 text-amber-700" />
                <h3 className="font-extrabold text-slate-900 text-sm">
                  অফিশিয়াল মাস্টার পিন (Hardware PIN Fallback)
                </h3>
              </div>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed">
              যদি আপনার ডিভাইসে কোনো ফিঙ্গারপ্রিন্ট বা ফেস স্ক্যানার অনুপস্থিত থাকে, তবে ইউনিয়ন পরিষদের নির্ধারিত ৬-ডিজিটের মাস্টার সিকিউরিটি পিন দিয়ে সেশন এলিভেট করুন।
            </p>

            <form onSubmit={handlePinElevation} className="space-y-3">
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="password"
                  maxLength={6}
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="৬-ডিজিটের সিকিউরিটি পিন (যেমন: 786021)"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono tracking-widest text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-amber-300 font-extrabold text-xs rounded-xl shadow transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Key className="w-4 h-4 text-amber-300" />
                <span>মাস্টার পিন ভেরিফাই করুন</span>
              </button>
            </form>
          </div>

        </div>

      </div>

      {/* Enroll Passkey Modal */}
      {isEnrollModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-md w-full overflow-hidden space-y-0">
            
            <div className="bg-emerald-950 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-400 text-slate-950 rounded-xl font-bold">
                  <Fingerprint className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">নতুন বায়োমেট্রিক প্যাসকি নিবন্ধন</h3>
                  <p className="text-xs text-emerald-200">Device Hardware Biometric Registration</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsEnrollModalOpen(false)}
                className="text-white/70 hover:text-white text-lg font-black cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs space-y-2">
                <p className="font-extrabold text-slate-800">
                  ডিভাইস প্যাসকি যুক্ত করার সুবিধা:
                </p>
                <ul className="list-disc pl-4 space-y-1 text-slate-600 font-medium">
                  <li>পরবর্তীতে পাসওয়ার্ড ছাড়াই কেবল ফিঙ্গারপ্রিন্ট বা ফেস আইডি দিয়ে অনুমোদন।</li>
                  <li>ব্রাউজারের ক্রিপ্টোগ্রাফিক চাবি দ্বারা উচ্চ-নিরাপত্তা প্রদান।</li>
                  <li>সার্ভারে কোনো পাসওয়ার্ড সঞ্চিত থাকে না, ফলে হ্যাকিং ঝুঁকি শূন্য।</li>
                </ul>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ডিভাইসের নাম বা বিবরণ (ঐচ্ছিক)
                </label>
                <input
                  type="text"
                  value={customDeviceName}
                  onChange={(e) => setCustomDeviceName(e.target.value)}
                  placeholder="যেমন: অফিসিয়াল ল্যাপটপ Touch ID / চেয়ারম্যান মোবাইল"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:bg-white focus:border-emerald-600 focus:outline-none"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setIsEnrollModalOpen(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  বাতিল
                </button>

                <button
                  type="button"
                  onClick={handleEnrollPasskey}
                  disabled={isRegistering}
                  className="flex-1 py-2.5 bg-emerald-900 hover:bg-emerald-800 text-amber-300 font-extrabold text-xs rounded-xl shadow transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Fingerprint className="w-4 h-4 text-amber-300" />
                  <span>{isRegistering ? 'সেন্সরে স্পর্শ করুন...' : 'প্যাসকি তৈরি করুন'}</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
