import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, 
  Search, 
  UserPlus, 
  Building2, 
  Phone, 
  FileCheck2, 
  Check, 
  MapPin, 
  RefreshCw, 
  Sparkles, 
  Camera, 
  X, 
  Copy, 
  Home, 
  CreditCard, 
  UserCheck, 
  Briefcase, 
  Cake, 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown, 
  Grid, 
  List, 
  Download, 
  SlidersHorizontal, 
  User, 
  Eye 
} from 'lucide-react';
import { WARDS, KNOWN_VILLAGES, COMMON_OCCUPATIONS, AGE_GROUP_RANGES } from '../data/villages';
import { CitizenAccountRecord, UnionParishadConfig, NidScanResult } from '../types';
import { sanitizeObject } from '../utils/security';
import { validateNid, validateBirthNo, validatePhone } from '../utils/validation';
import { fetchCertificatesFromFirebase } from '../firebase';
import { sheetsSyncService } from '../services/sheetsSyncService';
import { NidScannerModal } from './NidScannerModal';

interface CitizenMasterRegisterProps {
  config: UnionParishadConfig;
  onApplyForCitizen: (citizen: CitizenAccountRecord) => void;
}

// Helper: Extract age from record or NID/birth number
export const extractAge = (c: Partial<CitizenAccountRecord>): number | undefined => {
  if (typeof c.age === 'number' && !isNaN(c.age) && c.age > 0) return c.age;
  
  if (c.dateOfBirth) {
    const yearMatch = c.dateOfBirth.match(/(\d{4})/);
    if (yearMatch) {
      const bYear = parseInt(yearMatch[1], 10);
      const currentYear = new Date().getFullYear();
      if (bYear > 1900 && bYear <= currentYear) return currentYear - bYear;
    }
  }

  if (c.birthNo && c.birthNo.length >= 4) {
    const bYear = parseInt(c.birthNo.substring(0, 4), 10);
    const currentYear = new Date().getFullYear();
    if (bYear > 1900 && bYear <= currentYear) return currentYear - bYear;
  }

  if (c.nid && (c.nid.length === 17 || (c.nid.length === 13 && (c.nid.startsWith('19') || c.nid.startsWith('20'))))) {
    const bYear = parseInt(c.nid.substring(0, 4), 10);
    const currentYear = new Date().getFullYear();
    if (bYear > 1900 && bYear <= currentYear) return currentYear - bYear;
  }

  return undefined;
};

// Helper: Get Age Group Information
export const getAgeGroupInfo = (age: number | undefined): { key: string; label: string; badgeColor: string } => {
  if (age === undefined) {
    return { key: 'unknown', label: 'বয়স অনির্ধারিত', badgeColor: 'bg-slate-100 text-slate-600 border-slate-200' };
  }
  if (age <= 17) {
    return { key: 'child', label: `শিশু/কিশোর (${age} বছর)`, badgeColor: 'bg-sky-100 text-sky-900 border-sky-300' };
  }
  if (age <= 35) {
    return { key: 'youth', label: `তরুণ/যুবক (${age} বছর)`, badgeColor: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
  }
  if (age <= 50) {
    return { key: 'middle', label: `মধ্যবয়সী (${age} বছর)`, badgeColor: 'bg-amber-100 text-amber-900 border-amber-300' };
  }
  return { key: 'senior', label: `প্রবীণ/জ্যেষ্ঠ (${age} বছর)`, badgeColor: 'bg-purple-100 text-purple-900 border-purple-300' };
};

export const CitizenMasterRegister: React.FC<CitizenMasterRegisterProps> = ({
  config,
  onApplyForCitizen,
}) => {
  const [citizens, setCitizens] = useState<CitizenAccountRecord[]>([]);
  const [loading, setLoading] = useState(true);

  // Search & Basic Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [searchCategory, setSearchCategory] = useState<'all' | 'nid' | 'holding' | 'name' | 'mobile' | 'village' | 'occupation'>('all');
  const [selectedWard, setSelectedWard] = useState('');
  const [selectedVillage, setSelectedVillage] = useState('');
  const [selectedGender, setSelectedGender] = useState('সব');
  
  // Advanced Filters: Age Group & Occupation
  const [selectedAgeGroup, setSelectedAgeGroup] = useState<string>('all');
  const [customMinAge, setCustomMinAge] = useState<string>('');
  const [customMaxAge, setCustomMaxAge] = useState<string>('');
  const [selectedOccupation, setSelectedOccupation] = useState<string>('');
  const [selectedCertStatus, setSelectedCertStatus] = useState<'all' | 'has_cert' | 'no_cert'>('all');
  
  // Sort State
  const [sortField, setSortField] = useState<'village' | 'age' | 'occupation' | 'name' | 'holding' | 'ward' | 'certificates' | 'date'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  
  // View Mode: Table vs Grid/Cards vs Village Grouped
  const [viewMode, setViewMode] = useState<'table' | 'grid' | 'village_group'>('table');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(true);

  // Modals & Active Citizen Previews
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isNidScannerOpen, setIsNidScannerOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [viewCitizenDetail, setViewCitizenDetail] = useState<CitizenAccountRecord | null>(null);

  // New Citizen Form State
  const [newCitizen, setNewCitizen] = useState<Partial<CitizenAccountRecord>>({
    name: '',
    nid: '',
    birthNo: '',
    holdingNo: '',
    father: '',
    mother: '',
    spouseName: '',
    gender: 'পুরুষ',
    age: undefined,
    dateOfBirth: '',
    occupation: 'কৃষি / কৃষক',
    mobile: '',
    village: 'বহেড়াতৈল',
    wardNo: '০১',
    postOffice: 'বহেড়াতৈল',
    postCode: '১৯৫০'
  });

  const handleCopyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(label + '_' + text);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleNidAutoFill = (result: NidScanResult) => {
    let calculatedAge: number | undefined = undefined;
    if (result.dob) {
      const yearMatch = result.dob.match(/(\d{4})/);
      if (yearMatch) {
        calculatedAge = new Date().getFullYear() - parseInt(yearMatch[1], 10);
      }
    }
    setNewCitizen((prev) => ({
      ...prev,
      nid: result.nidNo || prev.nid,
      name: result.name || prev.name,
      father: result.fatherName || prev.father,
      mother: result.motherName || prev.mother,
      spouseName: result.spouseName || prev.spouseName,
      dateOfBirth: result.dob || prev.dateOfBirth,
      age: calculatedAge !== undefined ? calculatedAge : prev.age,
      village: result.addressText ? (result.addressText.includes('বহেড়াতৈল') ? 'বহেড়াতৈল' : prev.village) : prev.village
    }));
    setIsAddModalOpen(true);
  };

  const loadCitizens = async () => {
    setLoading(true);
    try {
      // Build master list from server certificates and Firebase
      const res = await fetch('/api/admin/logs');
      const data = await res.json();
      const serverCerts = data.logs || [];
      const fbCerts = await fetchCertificatesFromFirebase();

      const combinedCerts = [...serverCerts, ...fbCerts];

      // Map unique citizens by NID or BirthNo or Name
      const map = new Map<string, CitizenAccountRecord>();

      // Pre-seed realistic citizen master records for 02নং বহেড়াতৈল ইউনিয়ন with villages, ages, and occupations
      const defaultCitizens: CitizenAccountRecord[] = [
        {
          id: 'cit_101',
          nid: '19859382011234567',
          holdingNo: 'এইচ-১০৪',
          name: 'মোঃ আতিকুর রহমান',
          father: 'হাজী আব্দুল গণি',
          mother: 'আয়েশা খাতুন',
          gender: 'পুরুষ',
          age: 41,
          dateOfBirth: '1985-04-12',
          occupation: 'কৃষি / কৃষক',
          mobile: '01712345678',
          village: 'বহেড়াতৈল',
          wardNo: '০৫',
          postOffice: 'বহেড়াতৈল',
          postCode: '১৯৫০',
          totalCertificates: 3,
          lastCertificateType: 'নাগরিকত্ব সনদপত্র',
          lastCertificateDate: '১৫/০৭/২০২৬',
          registeredAt: '2026-01-10'
        },
        {
          id: 'cit_102',
          nid: '19904281928374651',
          holdingNo: 'এইচ-০৭২',
          name: 'মোছাঃ পারভীন আক্তার',
          father: 'মৃত সোলাইমান মিয়া',
          mother: 'মোছাঃ রহিমা বেগম',
          gender: 'মহিলা',
          age: 36,
          dateOfBirth: '1990-08-25',
          occupation: 'গৃহিণী',
          mobile: '01819876543',
          village: 'ডাবাইল',
          wardNo: '০১',
          postOffice: 'নাগবাড়ী',
          postCode: '১৯৭২',
          totalCertificates: 2,
          lastCertificateType: 'ওয়ারিশান / উত্তরাধিকার সনদপত্র',
          lastCertificateDate: '২০/০৭/২০২৬',
          registeredAt: '2026-02-14'
        },
        {
          id: 'cit_103',
          nid: '19782910482918273',
          holdingNo: 'এইচ-১১৯',
          name: 'মোঃ খলিলুর রহমান',
          father: 'মৃত আকবর আলী',
          mother: 'খদেজা বেগম',
          gender: 'পুরুষ',
          age: 48,
          dateOfBirth: '1978-02-10',
          occupation: 'ব্যবসা / ব্যবসায়ী',
          mobile: '01911223344',
          village: 'গোহাইলবাড়ী',
          wardNo: '০৩',
          postOffice: 'বহেড়াতৈল',
          postCode: '১৯৫০',
          totalCertificates: 1,
          lastCertificateType: 'ভূমিহীন সনদপত্র',
          lastCertificateDate: '০৫/০৬/২০২৬',
          registeredAt: '2026-03-01'
        },
        {
          id: 'cit_104',
          birthNo: '20129381029381203',
          holdingNo: 'এইচ-০৮৫',
          name: 'সুমাইয়া তাসনিম',
          father: 'মোঃ রফিকুল ইসলাম',
          mother: 'মোছাঃ শারমিন সুলতানা',
          gender: 'মহিলা',
          age: 14,
          dateOfBirth: '2012-05-18',
          occupation: 'শিক্ষার্থী',
          mobile: '01755667788',
          village: 'যোগীরকোফা',
          wardNo: '০৪',
          postOffice: 'বেতুয়া',
          postCode: '১৯৫০',
          totalCertificates: 1,
          lastCertificateType: 'শিক্ষার্থী পরিচয় প্রত্যয়নপত্র',
          lastCertificateDate: '১২/০৭/২০২৬',
          registeredAt: '2026-04-20'
        },
        {
          id: 'cit_105',
          nid: '19985920194827163',
          holdingNo: 'এইচ-১৫৬',
          name: 'মোঃ শাকিল আহমেদ',
          father: 'নজরুল ইসলাম',
          mother: 'বিলকিস বেগম',
          gender: 'পুরুষ',
          age: 28,
          dateOfBirth: '1998-11-04',
          occupation: 'প্রবাসী / রেমিট্যান্স যোদ্ধা',
          mobile: '01799887766',
          village: 'কামারঙ্গ',
          wardNo: '০২',
          postOffice: 'বহেড়াতৈল',
          postCode: '১৯৫০',
          totalCertificates: 2,
          lastCertificateType: 'চারিত্রিক সনদপত্র',
          lastCertificateDate: '০২/০৮/২০২৬',
          registeredAt: '2026-05-02'
        },
        {
          id: 'cit_106',
          nid: '19623819283746182',
          holdingNo: 'এইচ-০৪৩',
          name: 'হাজী মোঃ ইসমাইল হোসেন',
          father: 'মৃত মকবুল হোসেন',
          mother: 'মৃত জোবেদা খাতুন',
          gender: 'পুরুষ',
          age: 64,
          dateOfBirth: '1962-01-15',
          occupation: 'অবসরপ্রাপ্ত',
          mobile: '01833445566',
          village: 'ঘাটেশ্বরী',
          wardNo: '০৫',
          postOffice: 'বহেড়াতৈল',
          postCode: '১৯৫০',
          totalCertificates: 4,
          lastCertificateType: 'নাগরিকত্ব সনদপত্র',
          lastCertificateDate: '০১/০৮/২০২৬',
          registeredAt: '2026-01-20'
        },
        {
          id: 'cit_107',
          nid: '20019283746152839',
          holdingNo: 'এইচ-২০১',
          name: 'তানজিলা মাহমুদ',
          father: 'মাহমুদুল হাসান',
          mother: 'সালমা বেগম',
          gender: 'মহিলা',
          age: 25,
          dateOfBirth: '2001-09-30',
          occupation: 'শিক্ষক / শিক্ষিকা',
          mobile: '01988776655',
          village: 'ভুগলীচালা',
          wardNo: '০৬',
          postOffice: 'ছিলিমপুর',
          postCode: '১৯৫০',
          totalCertificates: 1,
          lastCertificateType: 'অবিবাহিত সনদপত্র',
          lastCertificateDate: '১০/০৮/২০২৬',
          registeredAt: '2026-06-11'
        },
        {
          id: 'cit_108',
          nid: '19729384756182930',
          holdingNo: 'এইচ-০১৬',
          name: 'মোঃ জলিল শেখ',
          father: 'মৃত কাদির শেখ',
          mother: 'মৃত কুলসুম নেছা',
          gender: 'পুরুষ',
          age: 54,
          dateOfBirth: '1972-07-20',
          occupation: 'দিনমজুর / শ্রমিক',
          mobile: '01722334455',
          village: 'ধোপার চালা',
          wardNo: '০৭',
          postOffice: 'বহেড়াতৈল',
          postCode: '১৯৫০',
          totalCertificates: 1,
          lastCertificateType: 'বাৎসরিক আয়ের প্রত্যয়নপত্র',
          lastCertificateDate: '২৮/০৭/২০২৬',
          registeredAt: '2026-04-05'
        },
        {
          id: 'cit_109',
          nid: '19958374619283746',
          holdingNo: 'এইচ-০৯৯',
          name: 'মোঃ আল-আমিন হোসেন',
          father: 'মোস্তফা কামাল',
          mother: 'ফরিদা ইয়াসমিন',
          gender: 'পুরুষ',
          age: 31,
          dateOfBirth: '1995-03-14',
          occupation: 'চালক / পরিবহন শ্রমিক',
          mobile: '01866554433',
          village: 'আমতৈল',
          wardNo: '০৮',
          postOffice: 'বহেড়াতৈল',
          postCode: '১৯৫০',
          totalCertificates: 0,
          registeredAt: '2026-07-15'
        },
        {
          id: 'cit_110',
          nid: '19559382019482716',
          holdingNo: 'এইচ-৩১২',
          name: 'মোছাঃ ফাতেমা বেগম',
          father: 'মৃত রমজান আলী',
          spouseName: 'মৃত আফসার উদ্দিন',
          mother: 'মৃত মরিয়ম বেগম',
          gender: 'মহিলা',
          age: 71,
          dateOfBirth: '1955-12-05',
          occupation: 'গৃহিণী',
          mobile: '01977665544',
          village: 'শালগ্রামপুর',
          wardNo: '০৯',
          postOffice: 'নাগবাড়ী',
          postCode: '১৯৭২',
          totalCertificates: 2,
          lastCertificateType: 'বিধবা সনদপত্র',
          lastCertificateDate: '০৪/০৮/২০২৬',
          registeredAt: '2026-02-28'
        }
      ];

      defaultCitizens.forEach(c => {
        const key = c.nid || c.birthNo || c.holdingNo || c.name;
        map.set(key, c);
      });

      combinedCerts.forEach(cert => {
        if (!cert.citizen) return;
        const c = cert.citizen;
        const holding = c.holdingNo || (cert.extra && cert.extra.simpleFields ? cert.extra.simpleFields['holdingNo'] : '') || '';
        const key = c.nid || c.birthNo || holding || c.name;

        if (map.has(key)) {
          const existing = map.get(key)!;
          existing.totalCertificates += 1;
          existing.lastCertificateType = cert.typeLabel;
          existing.lastCertificateDate = cert.issueDate;
          if (!existing.holdingNo && holding) {
            existing.holdingNo = holding;
          }
          if (!existing.occupation && c.occupation) {
            existing.occupation = c.occupation;
          }
          if (existing.age === undefined && c.age !== undefined) {
            existing.age = c.age;
          }
        } else {
          const inferredAge = extractAge({
            age: c.age,
            dateOfBirth: c.dateOfBirth,
            birthNo: c.birthNo,
            nid: c.nid
          });

          map.set(key, {
            id: `cit_${Date.now()}_${Math.random()}`,
            nid: c.nid || '',
            birthNo: c.birthNo || '',
            holdingNo: holding,
            name: c.name,
            father: c.father || '',
            mother: c.mother || '',
            spouseName: c.spouseName || '',
            gender: c.gender || 'পুরুষ',
            age: inferredAge,
            dateOfBirth: c.dateOfBirth || '',
            occupation: c.occupation || 'অন্যান্য',
            mobile: c.mobile || '',
            village: c.village || 'বহেড়াতৈল',
            wardNo: c.wardNo || '০১',
            postOffice: c.postOffice || 'বহেড়াতৈল',
            postCode: c.postCode || '১৯৫০',
            totalCertificates: 1,
            lastCertificateType: cert.typeLabel,
            lastCertificateDate: cert.issueDate,
            registeredAt: cert.createdAt || new Date().toISOString()
          });
        }
      });

      setCitizens(Array.from(map.values()));
    } catch (e) {
      console.error('Error loading citizens:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCitizens();
  }, []);

  // Aggregated dynamic lists for dropdowns
  const allVillagesList = useMemo(() => {
    const set = new Set<string>(KNOWN_VILLAGES);
    citizens.forEach(c => {
      if (c.village) set.add(c.village.trim());
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'bn'));
  }, [citizens]);

  const allOccupationsList = useMemo(() => {
    const set = new Set<string>(COMMON_OCCUPATIONS);
    citizens.forEach(c => {
      if (c.occupation) set.add(c.occupation.trim());
    });
    return Array.from(set).filter(Boolean);
  }, [citizens]);

  // Real-time Advanced Filtering & Sorting Logic
  const filteredCitizens = useMemo(() => {
    return citizens.filter((c) => {
      // 1. Ward Filter
      if (selectedWard && c.wardNo !== selectedWard) return false;

      // 2. Village Filter
      if (selectedVillage && c.village !== selectedVillage) return false;

      // 3. Gender Filter
      if (selectedGender !== 'সব' && c.gender !== selectedGender) return false;

      // 4. Certificate Beneficiary Status Filter
      if (selectedCertStatus === 'has_cert' && c.totalCertificates <= 0) return false;
      if (selectedCertStatus === 'no_cert' && c.totalCertificates > 0) return false;

      // 5. Occupation Filter
      if (selectedOccupation) {
        if (!c.occupation || !c.occupation.includes(selectedOccupation)) return false;
      }

      // 6. Age Group & Custom Range Filter
      const calculatedAge = extractAge(c);
      
      if (selectedAgeGroup !== 'all') {
        const range = AGE_GROUP_RANGES.find(r => r.key === selectedAgeGroup);
        if (range) {
          if (calculatedAge === undefined) return false;
          if (calculatedAge < range.min || calculatedAge > range.max) return false;
        }
      }

      if (customMinAge) {
        const minA = parseInt(customMinAge, 10);
        if (!isNaN(minA) && (calculatedAge === undefined || calculatedAge < minA)) return false;
      }

      if (customMaxAge) {
        const maxA = parseInt(customMaxAge, 10);
        if (!isNaN(maxA) && (calculatedAge === undefined || calculatedAge > maxA)) return false;
      }

      // 7. Search Query Filter
      const q = searchQuery.trim().toLowerCase();
      if (!q) return true;

      const matchNid = Boolean(c.nid && c.nid.toLowerCase().includes(q)) || Boolean(c.birthNo && c.birthNo.toLowerCase().includes(q));
      const matchHolding = Boolean(c.holdingNo && c.holdingNo.toLowerCase().includes(q));
      const matchName = c.name.toLowerCase().includes(q) || 
                        Boolean(c.father && c.father.toLowerCase().includes(q)) || 
                        Boolean(c.spouseName && c.spouseName.toLowerCase().includes(q)) ||
                        Boolean(c.mother && c.mother.toLowerCase().includes(q));
      const matchMobile = Boolean(c.mobile && c.mobile.includes(q));
      const matchVillage = Boolean(c.village && c.village.toLowerCase().includes(q));
      const matchOccupation = Boolean(c.occupation && c.occupation.toLowerCase().includes(q));

      if (searchCategory === 'nid') return matchNid;
      if (searchCategory === 'holding') return matchHolding;
      if (searchCategory === 'name') return matchName;
      if (searchCategory === 'mobile') return matchMobile;
      if (searchCategory === 'village') return matchVillage;
      if (searchCategory === 'occupation') return matchOccupation;

      return matchNid || matchHolding || matchName || matchMobile || matchVillage || matchOccupation;
    }).sort((a, b) => {
      let comparison = 0;

      switch (sortField) {
        case 'village': {
          const vA = a.village || '';
          const vB = b.village || '';
          comparison = vA.localeCompare(vB, 'bn');
          break;
        }
        case 'age': {
          const ageA = extractAge(a) ?? -1;
          const ageB = extractAge(b) ?? -1;
          comparison = ageA - ageB;
          break;
        }
        case 'occupation': {
          const occA = a.occupation || '';
          const occB = b.occupation || '';
          comparison = occA.localeCompare(occB, 'bn');
          break;
        }
        case 'name': {
          comparison = (a.name || '').localeCompare(b.name || '', 'bn');
          break;
        }
        case 'holding': {
          comparison = (a.holdingNo || '').localeCompare(b.holdingNo || '', 'bn', { numeric: true });
          break;
        }
        case 'ward': {
          comparison = (a.wardNo || '').localeCompare(b.wardNo || '', 'bn');
          break;
        }
        case 'certificates': {
          comparison = (a.totalCertificates || 0) - (b.totalCertificates || 0);
          break;
        }
        case 'date': {
          const dateA = a.registeredAt || '';
          const dateB = b.registeredAt || '';
          comparison = dateA.localeCompare(dateB);
          break;
        }
        default:
          comparison = 0;
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });
  }, [
    citizens, 
    searchQuery, 
    searchCategory, 
    selectedWard, 
    selectedVillage, 
    selectedGender, 
    selectedCertStatus, 
    selectedOccupation, 
    selectedAgeGroup, 
    customMinAge, 
    customMaxAge,
    sortField,
    sortOrder
  ]);

  // Village-grouped citizens for Village Group View
  const villageGroupedData = useMemo(() => {
    const groupMap: Record<string, CitizenAccountRecord[]> = {};
    filteredCitizens.forEach((cit) => {
      const v = cit.village || 'অনির্দিষ্ট গ্রাম';
      if (!groupMap[v]) groupMap[v] = [];
      groupMap[v].push(cit);
    });
    return groupMap;
  }, [filteredCitizens]);

  // Active Filter Count Calculation
  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (searchQuery) count++;
    if (selectedWard) count++;
    if (selectedVillage) count++;
    if (selectedGender !== 'সব') count++;
    if (selectedAgeGroup !== 'all') count++;
    if (customMinAge || customMaxAge) count++;
    if (selectedOccupation) count++;
    if (selectedCertStatus !== 'all') count++;
    return count;
  }, [searchQuery, selectedWard, selectedVillage, selectedGender, selectedAgeGroup, customMinAge, customMaxAge, selectedOccupation, selectedCertStatus]);

  // Reset All Filters
  const handleResetFilters = () => {
    setSearchQuery('');
    setSearchCategory('all');
    setSelectedWard('');
    setSelectedVillage('');
    setSelectedGender('সব');
    setSelectedAgeGroup('all');
    setCustomMinAge('');
    setCustomMaxAge('');
    setSelectedOccupation('');
    setSelectedCertStatus('all');
    setSortField('name');
    setSortOrder('asc');
  };

  // Toggle Table Header Sort
  const handleHeaderSort = (field: 'village' | 'age' | 'occupation' | 'name' | 'holding' | 'ward' | 'certificates' | 'date') => {
    if (sortField === field) {
      setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  // Export Filtered Citizens to CSV
  const handleExportCsv = () => {
    if (filteredCitizens.length === 0) {
      alert('এক্সপোর্ট করার মতো কোনো নাগরিক ডাটা নেই!');
      return;
    }

    const headers = [
      'নাগরিকের নাম',
      'পিতা/স্বামী',
      'মাতা',
      'লিঙ্গ',
      'বয়স',
      'বয়সসীমা',
      'পেশা',
      'গ্রাম',
      'ওয়ার্ড নং',
      'হোল্ডিং নং',
      'NID নম্বর',
      'জন্ম নিবন্ধন নং',
      'মোবাইল নম্বর',
      'মোট ইস্যুকৃত সনদ',
      'সর্বশেষ সনদ',
      'সর্বশেষ সনদের তারিখ'
    ];

    const rows = filteredCitizens.map((c) => {
      const age = extractAge(c);
      const ageInfo = getAgeGroupInfo(age);
      return [
        `"${(c.name || '').replace(/"/g, '""')}"`,
        `"${(c.father || c.spouseName || '').replace(/"/g, '""')}"`,
        `"${(c.mother || '').replace(/"/g, '""')}"`,
        `"${c.gender || ''}"`,
        `"${age !== undefined ? age + ' বছর' : 'অনির্দিষ্ট'}"`,
        `"${ageInfo.label}"`,
        `"${(c.occupation || '').replace(/"/g, '""')}"`,
        `"${(c.village || '').replace(/"/g, '""')}"`,
        `"ওয়ার্ড ${c.wardNo || ''}"`,
        `"${(c.holdingNo || '').replace(/"/g, '""')}"`,
        `"${c.nid || ''}"`,
        `"${c.birthNo || ''}"`,
        `"${c.mobile || ''}"`,
        `"${c.totalCertificates || 0}"`,
        `"${(c.lastCertificateType || '').replace(/"/g, '""')}"`,
        `"${c.lastCertificateDate || ''}"`
      ];
    });

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Citizen_Master_Register_${config.upName}_${new Date().toISOString().substring(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCreateCitizen = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCitizen.name || !newCitizen.mother || !newCitizen.village) {
      alert('অনুগ্রহ করে নাগরিকের নাম, মাতার নাম এবং গ্রাম তথ্য প্রদান করুন।');
      return;
    }

    if (newCitizen.nid) {
      const nidVal = validateNid(newCitizen.nid);
      if (!nidVal.isValid) {
        alert(nidVal.message);
        return;
      }
    }

    if (newCitizen.birthNo) {
      const birthVal = validateBirthNo(newCitizen.birthNo);
      if (!birthVal.isValid) {
        alert(birthVal.message);
        return;
      }
    }

    if (newCitizen.mobile) {
      const phoneVal = validatePhone(newCitizen.mobile);
      if (!phoneVal.isValid) {
        alert(phoneVal.message);
        return;
      }
    }

    const calculatedAge = newCitizen.age || (newCitizen.dateOfBirth ? extractAge({ dateOfBirth: newCitizen.dateOfBirth }) : undefined);

    const createdRecord: CitizenAccountRecord = sanitizeObject({
      id: `cit_custom_${Date.now()}`,
      nid: newCitizen.nid || '',
      birthNo: newCitizen.birthNo || '',
      holdingNo: newCitizen.holdingNo || '',
      name: newCitizen.name || '',
      father: newCitizen.father || '',
      mother: newCitizen.mother || '',
      spouseName: newCitizen.spouseName || '',
      gender: newCitizen.gender || 'পুরুষ',
      age: calculatedAge,
      dateOfBirth: newCitizen.dateOfBirth || '',
      occupation: newCitizen.occupation || 'কৃষি / কৃষক',
      mobile: newCitizen.mobile || '',
      village: newCitizen.village || 'বহেড়াতৈল',
      wardNo: newCitizen.wardNo || '০১',
      postOffice: newCitizen.postOffice || 'বহেড়াতৈল',
      postCode: newCitizen.postCode || '১৯৫০',
      totalCertificates: 0,
      registeredAt: new Date().toISOString()
    });

    setCitizens([createdRecord, ...citizens]);
    
    // Enqueue to Google Sheets Real-time Background Sync Queue
    try {
      sheetsSyncService.enqueueCitizenSync(createdRecord, config);
    } catch (sErr) {
      console.warn('Google Sheets background citizen queue error:', sErr);
    }

    setIsAddModalOpen(false);
    alert('নাগরিক অ্যাকাউন্ট সফলভাবে মাস্টার রেজিস্টার ও গুগ্‌ল শিট সিঙ্ক কিউতে যোগ করা হয়েছে!');
  };

  return (
    <div className="space-y-5">
      {/* 1. Header Banner & Quick Action Buttons */}
      <div className="bg-white p-5 rounded-2xl shadow-md border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-900 text-amber-300 flex items-center justify-center shadow-md">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-black text-emerald-950 flex items-center gap-2">
                <span>নাগরিক মাস্টার রেজিস্টার ও স্মার্ট ফিল্টারিং হাব</span>
                <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-100 text-emerald-900 rounded-full border border-emerald-300">
                  স্মার্ট প্রত্যয়ন আবেদন
                </span>
              </h2>
              <p className="text-xs text-slate-500">
                {config.upName} এর সকল স্থায়ী নাগরিকের প্রোফাইল গ্রাম, বয়সসীমা ও পেশাভিত্তিক সহজে সাজিয়ে ১-ক্লিকে সনদ ইস্যু করুন।
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Refresh Button */}
          <button
            onClick={loadCitizens}
            className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition cursor-pointer active:scale-95 border border-slate-300"
            title="ডাটা রিফ্রেশ করুন"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          {/* Export CSV Button */}
          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-emerald-300 font-bold text-xs rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer active:scale-95 border border-slate-700"
            title="ফিল্টারকৃত ডাটা Excel / CSV হিসেবে ডাউনলোড করুন"
          >
            <Download className="w-4 h-4 text-amber-300" />
            <span>Excel / CSV</span>
          </button>

          {/* Gemini Vision AI NID Scanner */}
          <button
            onClick={() => setIsNidScannerOpen(true)}
            className="px-3.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-amber-300 font-bold text-xs rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer active:scale-95 border border-slate-800"
          >
            <Camera className="w-4 h-4 text-amber-400" />
            <span>Gemini NID স্ক্যানার</span>
          </button>

          {/* Add Citizen Button */}
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer active:scale-95 border border-emerald-700"
          >
            <UserPlus className="w-4 h-4 text-amber-300" />
            <span>+ নতুন নাগরিক নিবন্ধন</span>
          </button>
        </div>
      </div>

      {/* 2. Key Metrics Summary Statistics */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-emerald-950 text-white p-3.5 rounded-xl shadow-sm border border-emerald-900">
          <p className="text-[11px] text-emerald-200 font-bold flex items-center gap-1">
            <Users className="w-3.5 h-3.5 text-amber-300" />
            <span>মোট নাগরিক</span>
          </p>
          <p className="text-xl font-black text-amber-300 mt-0.5">{citizens.length} জন</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl shadow-sm border border-slate-200">
          <p className="text-[11px] text-slate-500 font-bold flex items-center gap-1">
            <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>ফিল্টার মিল</span>
          </p>
          <p className="text-xl font-black text-emerald-800 mt-0.5">
            {filteredCitizens.length} জন
          </p>
        </div>

        <div className="bg-white p-3.5 rounded-xl shadow-sm border border-slate-200">
          <p className="text-[11px] text-slate-500 font-bold flex items-center gap-1">
            <Building2 className="w-3.5 h-3.5 text-sky-600" />
            <span>মোট গ্রাম</span>
          </p>
          <p className="text-xl font-black text-slate-800 mt-0.5">
            {allVillagesList.length} টি
          </p>
        </div>

        <div className="bg-white p-3.5 rounded-xl shadow-sm border border-slate-200">
          <p className="text-[11px] text-slate-500 font-bold flex items-center gap-1">
            <Briefcase className="w-3.5 h-3.5 text-amber-600" />
            <span>পেশা তালিকা</span>
          </p>
          <p className="text-xl font-black text-slate-800 mt-0.5">
            {allOccupationsList.length} টি
          </p>
        </div>

        <div className="bg-white p-3.5 rounded-xl shadow-sm border border-slate-200 col-span-2 sm:col-span-1">
          <p className="text-[11px] text-slate-500 font-bold flex items-center gap-1">
            <FileCheck2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>সনদ সুবিধাভোগী</span>
          </p>
          <p className="text-xl font-black text-emerald-700 mt-0.5">
            {citizens.filter(c => c.totalCertificates > 0).length} জন
          </p>
        </div>
      </div>

      {/* 3. Comprehensive Filter & Search Control Center */}
      <div className="bg-white p-5 rounded-2xl border-2 border-emerald-600/30 shadow-md space-y-4">
        {/* Search Bar & Instant Filter Stats */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-800 text-amber-300 flex items-center justify-center font-bold shadow-xs">
              <Search className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                <span>লাইভ রিয়েল-টাইম নাগরিক এনকোয়ারি</span>
                {activeFiltersCount > 0 && (
                  <span className="px-2 py-0.5 bg-amber-100 text-amber-900 rounded-full font-bold text-[10px] border border-amber-300">
                    {activeFiltersCount}টি ফিল্টার সক্রিয়
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-slate-500">নাম, পিতা/মাতা, NID, হোল্ডিং, গ্রাম, বয়সসীমা বা পেশা দিয়ে তাৎক্ষণিক অনুসন্ধান করুন।</p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* View Mode Switcher */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-300 text-xs">
              <button
                onClick={() => setViewMode('table')}
                className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                  viewMode === 'table' ? 'bg-emerald-900 text-amber-300 shadow-xs' : 'text-slate-700 hover:text-slate-900'
                }`}
                title="তালিকা ভিউ"
              >
                <List className="w-3.5 h-3.5" />
                <span>তালিকা</span>
              </button>
              <button
                onClick={() => setViewMode('grid')}
                className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                  viewMode === 'grid' ? 'bg-emerald-900 text-amber-300 shadow-xs' : 'text-slate-700 hover:text-slate-900'
                }`}
                title="কার্ড ভিউ"
              >
                <Grid className="w-3.5 h-3.5" />
                <span>কার্ড</span>
              </button>
              <button
                onClick={() => setViewMode('village_group')}
                className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                  viewMode === 'village_group' ? 'bg-emerald-900 text-amber-300 shadow-xs' : 'text-slate-700 hover:text-slate-900'
                }`}
                title="গ্রামভিত্তিক গুচ্ছ ভিউ"
              >
                <Building2 className="w-3.5 h-3.5" />
                <span>গ্রাম গুচ্ছ</span>
              </button>
            </div>

            {/* Toggle Advanced Filters Button */}
            <button
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl border border-slate-300 transition flex items-center gap-1.5 cursor-pointer"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-emerald-700" />
              <span>{showAdvancedFilters ? 'ফিল্টার গুটিয়ে নিন' : 'ফিল্টার প্যানেল'}</span>
            </button>

            {/* Reset All Filters */}
            {activeFiltersCount > 0 && (
              <button
                onClick={handleResetFilters}
                className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs rounded-xl border border-rose-300 transition flex items-center gap-1 cursor-pointer"
                title="সকল ফিল্টার ও সার্চ মুছে ফেলুন"
              >
                <X className="w-3.5 h-3.5" />
                <span>রিসেট ({activeFiltersCount})</span>
              </button>
            )}
          </div>
        </div>

        {/* Real-time Search Input Box */}
        <div className="relative">
          <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-emerald-700 flex items-center gap-1">
            <Search className="w-5 h-5" />
          </div>

          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="NID নম্বর (যেমন: 1985938201), হোল্ডিং নম্বর (যেমন: এইচ-১০৪), গ্রাম (যেমন: বহেড়াতৈল), পেশা বা নাগরিকের নাম টাইপ করুন..."
            className="w-full pl-11 pr-10 py-3 bg-emerald-50/20 border-2 border-emerald-600/50 focus:border-emerald-700 rounded-xl text-sm font-semibold text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:ring-4 focus:ring-emerald-600/10 transition shadow-inner"
          />

          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 rounded-full bg-slate-100 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Search Field Scopes */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] font-bold text-slate-500 mr-1">সার্চ ফিল্ড:</span>
            
            <button
              onClick={() => setSearchCategory('all')}
              className={`px-2.5 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                searchCategory === 'all'
                  ? 'bg-emerald-800 text-amber-300 shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Search className="w-3 h-3" />
              <span>সকল ফিল্ড</span>
            </button>

            <button
              onClick={() => setSearchCategory('village')}
              className={`px-2.5 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                searchCategory === 'village'
                  ? 'bg-emerald-800 text-amber-300 shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <MapPin className="w-3 h-3 text-amber-400" />
              <span>গ্রামভিত্তিক</span>
            </button>

            <button
              onClick={() => setSearchCategory('occupation')}
              className={`px-2.5 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                searchCategory === 'occupation'
                  ? 'bg-emerald-800 text-amber-300 shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Briefcase className="w-3 h-3 text-emerald-400" />
              <span>পেশাভিত্তিক</span>
            </button>

            <button
              onClick={() => setSearchCategory('nid')}
              className={`px-2.5 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                searchCategory === 'nid'
                  ? 'bg-emerald-800 text-amber-300 shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <CreditCard className="w-3 h-3 text-cyan-400" />
              <span>NID / জন্ম সনদ</span>
            </button>

            <button
              onClick={() => setSearchCategory('holding')}
              className={`px-2.5 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                searchCategory === 'holding'
                  ? 'bg-emerald-800 text-amber-300 shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Home className="w-3 h-3 text-amber-400" />
              <span>হোল্ডিং নং</span>
            </button>

            <button
              onClick={() => setSearchCategory('name')}
              className={`px-2.5 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                searchCategory === 'name'
                  ? 'bg-emerald-800 text-amber-300 shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Users className="w-3 h-3" />
              <span>নাগরিকের নাম</span>
            </button>

            <button
              onClick={() => setSearchCategory('mobile')}
              className={`px-2.5 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                searchCategory === 'mobile'
                  ? 'bg-emerald-800 text-amber-300 shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Phone className="w-3 h-3" />
              <span>মোবাইল</span>
            </button>
          </div>

          {/* Result Count Badge */}
          <div className="flex items-center gap-1 text-[11px] font-bold text-slate-600">
            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-950 rounded-lg border border-emerald-200">
              ফলাফল: {filteredCitizens.length} / {citizens.length} জন
            </span>
          </div>
        </div>

        {/* 4. Advanced Filter Parameters: Village, Age Group, Occupation, Ward, Gender, Sort */}
        {showAdvancedFilters && (
          <div className="pt-3 border-t border-slate-200 space-y-3.5">
            {/* Primary Filter Grid: Village, Age Group, Occupation, Ward */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              {/* Village Filter */}
              <div className="space-y-1">
                <label className="block font-black text-slate-700 flex items-center justify-between">
                  <span className="flex items-center gap-1 text-emerald-900">
                    <MapPin className="w-3.5 h-3.5 text-emerald-700" />
                    <span>গ্রাম ফিল্টার (Village):</span>
                  </span>
                  {selectedVillage && (
                    <button
                      onClick={() => setSelectedVillage('')}
                      className="text-[10px] text-rose-600 hover:underline cursor-pointer"
                    >
                      রিসেট
                    </button>
                  )}
                </label>
                <select
                  value={selectedVillage}
                  onChange={(e) => setSelectedVillage(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:border-emerald-600 focus:bg-white focus:outline-none shadow-xs"
                >
                  <option value="">সকল গ্রাম ({allVillagesList.length}টি গ্রাম)</option>
                  {allVillagesList.map((v) => {
                    const count = citizens.filter(c => c.village === v).length;
                    return (
                      <option key={v} value={v}>
                        {v} ({count} জন)
                      </option>
                    );
                  })}
                </select>
              </div>

              {/* Age Group Filter */}
              <div className="space-y-1">
                <label className="block font-black text-slate-700 flex items-center justify-between">
                  <span className="flex items-center gap-1 text-emerald-900">
                    <Cake className="w-3.5 h-3.5 text-emerald-700" />
                    <span>বয়সসীমা (Age Group):</span>
                  </span>
                  {(selectedAgeGroup !== 'all' || customMinAge || customMaxAge) && (
                    <button
                      onClick={() => { setSelectedAgeGroup('all'); setCustomMinAge(''); setCustomMaxAge(''); }}
                      className="text-[10px] text-rose-600 hover:underline cursor-pointer"
                    >
                      রিসেট
                    </button>
                  )}
                </label>
                <select
                  value={selectedAgeGroup}
                  onChange={(e) => {
                    setSelectedAgeGroup(e.target.value);
                    setCustomMinAge('');
                    setCustomMaxAge('');
                  }}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:border-emerald-600 focus:bg-white focus:outline-none shadow-xs"
                >
                  {AGE_GROUP_RANGES.map((rg) => {
                    let count = 0;
                    if (rg.key === 'all') {
                      count = citizens.length;
                    } else {
                      count = citizens.filter(c => {
                        const a = extractAge(c);
                        return a !== undefined && a >= rg.min && a <= rg.max;
                      }).length;
                    }
                    return (
                      <option key={rg.key} value={rg.key}>
                        {rg.label} ({count} জন)
                      </option>
                    );
                  })}
                </select>
              </div>

              {/* Occupation Filter */}
              <div className="space-y-1">
                <label className="block font-black text-slate-700 flex items-center justify-between">
                  <span className="flex items-center gap-1 text-emerald-900">
                    <Briefcase className="w-3.5 h-3.5 text-emerald-700" />
                    <span>পেশা (Occupation):</span>
                  </span>
                  {selectedOccupation && (
                    <button
                      onClick={() => setSelectedOccupation('')}
                      className="text-[10px] text-rose-600 hover:underline cursor-pointer"
                    >
                      রিসেট
                    </button>
                  )}
                </label>
                <select
                  value={selectedOccupation}
                  onChange={(e) => setSelectedOccupation(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:border-emerald-600 focus:bg-white focus:outline-none shadow-xs"
                >
                  <option value="">সকল পেশা ({allOccupationsList.length}টি পেশা)</option>
                  {allOccupationsList.map((occ) => {
                    const count = citizens.filter(c => c.occupation && c.occupation.includes(occ)).length;
                    return (
                      <option key={occ} value={occ}>
                        {occ} ({count} জন)
                      </option>
                    );
                  })}
                </select>
              </div>

              {/* Ward Filter */}
              <div className="space-y-1">
                <label className="block font-black text-slate-700 flex items-center justify-between">
                  <span className="flex items-center gap-1 text-emerald-900">
                    <Building2 className="w-3.5 h-3.5 text-emerald-700" />
                    <span>ওয়ার্ড নং (Ward):</span>
                  </span>
                  {selectedWard && (
                    <button
                      onClick={() => setSelectedWard('')}
                      className="text-[10px] text-rose-600 hover:underline cursor-pointer"
                    >
                      রিসেট
                    </button>
                  )}
                </label>
                <select
                  value={selectedWard}
                  onChange={(e) => setSelectedWard(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:border-emerald-600 focus:bg-white focus:outline-none shadow-xs"
                >
                  <option value="">সকল ওয়ার্ড (০১ - ০৯)</option>
                  {WARDS.map((w) => {
                    const count = citizens.filter(c => c.wardNo === w).length;
                    return (
                      <option key={w} value={w}>
                        ওয়ার্ড নং {w} ({count} জন)
                      </option>
                    );
                  })}
                </select>
              </div>
            </div>

            {/* Secondary Controls: Gender, Certificate Status, Sort By Field, Sort Order */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs pt-1">
              {/* Gender Filter */}
              <div className="space-y-1">
                <label className="block font-bold text-slate-600">লিঙ্গ ফিল্টার:</label>
                <select
                  value={selectedGender}
                  onChange={(e) => setSelectedGender(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg font-semibold text-slate-800 focus:border-emerald-600 focus:outline-none"
                >
                  <option value="সব">সকল লিঙ্গ</option>
                  <option value="পুরুষ">পুরুষ ({citizens.filter(c => c.gender === 'পুরুষ').length})</option>
                  <option value="মহিলা">মহিলা ({citizens.filter(c => c.gender === 'মহিলা').length})</option>
                  <option value="হিজরা">হিজরা</option>
                </select>
              </div>

              {/* Certificate Beneficiary Filter */}
              <div className="space-y-1">
                <label className="block font-bold text-slate-600">সনদ গ্রহণের স্ট্যাটাস:</label>
                <select
                  value={selectedCertStatus}
                  onChange={(e) => setSelectedCertStatus(e.target.value as 'all' | 'has_cert' | 'no_cert')}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg font-semibold text-slate-800 focus:border-emerald-600 focus:outline-none"
                >
                  <option value="all">সকল নাগরিক</option>
                  <option value="has_cert">ইতিমধ্যে সনদ গ্রহণকারী (১+ টি)</option>
                  <option value="no_cert">নতুন নাগরিক (০ টি সনদ)</option>
                </select>
              </div>

              {/* Sorting Field */}
              <div className="space-y-1">
                <label className="block font-bold text-slate-600 flex items-center gap-1">
                  <ArrowUpDown className="w-3 h-3 text-emerald-700" />
                  <span>সর্টিং ক্রাইটেরিয়া (Sort By):</span>
                </label>
                <select
                  value={sortField}
                  onChange={(e) => setSortField(e.target.value as any)}
                  className="w-full px-3 py-1.5 bg-emerald-50/40 border border-emerald-300 rounded-lg font-bold text-emerald-950 focus:border-emerald-600 focus:outline-none"
                >
                  <option value="name">নাগরিকের নাম (Name)</option>
                  <option value="village">গ্রামের নাম (Village)</option>
                  <option value="age">বয়স (Age)</option>
                  <option value="occupation">পেশা (Occupation)</option>
                  <option value="ward">ওয়ার্ড নং (Ward)</option>
                  <option value="holding">হোল্ডিং নং (Holding)</option>
                  <option value="certificates">সনদ গ্রহণের সংখ্যা (Certificates)</option>
                  <option value="date">নিবন্ধনের তারিখ (Date)</option>
                </select>
              </div>

              {/* Sorting Order */}
              <div className="space-y-1">
                <label className="block font-bold text-slate-600">সর্ট ক্রম (Order):</label>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setSortOrder('asc')}
                    className={`flex-1 py-1.5 px-2 rounded-lg font-bold text-xs flex items-center justify-center gap-1 cursor-pointer transition ${
                      sortOrder === 'asc'
                        ? 'bg-emerald-800 text-amber-300 border border-emerald-900 shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-300'
                    }`}
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                    <span>উর্ধ্বক্রম (A-Z / ১-৯)</span>
                  </button>
                  <button
                    onClick={() => setSortOrder('desc')}
                    className={`flex-1 py-1.5 px-2 rounded-lg font-bold text-xs flex items-center justify-center gap-1 cursor-pointer transition ${
                      sortOrder === 'desc'
                        ? 'bg-emerald-800 text-amber-300 border border-emerald-900 shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-300'
                    }`}
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                    <span>নিম্নক্রম (Z-A / ৯-১)</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Age Group Segmented Buttons & Village Pills */}
            <div className="pt-2 border-t border-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-2 text-xs">
              {/* Age Group Quick Chips */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[11px] font-bold text-slate-500 flex items-center gap-1">
                  <Cake className="w-3 h-3 text-emerald-700" />
                  <span>বয়স গ্রুপ:</span>
                </span>
                {AGE_GROUP_RANGES.map((rg) => (
                  <button
                    key={rg.key}
                    onClick={() => {
                      setSelectedAgeGroup(rg.key);
                      setCustomMinAge('');
                      setCustomMaxAge('');
                    }}
                    className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition cursor-pointer border ${
                      selectedAgeGroup === rg.key
                        ? 'bg-emerald-900 text-amber-300 border-emerald-950 shadow-xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                    }`}
                  >
                    {rg.label.split(' ')[0]}
                  </button>
                ))}
              </div>

              {/* Quick Custom Age Range Inputs */}
              <div className="flex items-center gap-1.5 text-[11px] text-slate-600">
                <span className="font-bold">কাস্টম বয়স:</span>
                <input
                  type="number"
                  placeholder="মিন"
                  value={customMinAge}
                  onChange={(e) => {
                    setCustomMinAge(e.target.value);
                    setSelectedAgeGroup('all');
                  }}
                  className="w-12 px-1.5 py-0.5 bg-slate-50 border border-slate-300 rounded font-bold text-center text-xs focus:border-emerald-600 focus:outline-none"
                />
                <span>-</span>
                <input
                  type="number"
                  placeholder="ম্যাক্স"
                  value={customMaxAge}
                  onChange={(e) => {
                    setCustomMaxAge(e.target.value);
                    setSelectedAgeGroup('all');
                  }}
                  className="w-12 px-1.5 py-0.5 bg-slate-50 border border-slate-300 rounded font-bold text-center text-xs focus:border-emerald-600 focus:outline-none"
                />
                <span>বছর</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 5. Main Content: View Switcher (Table / Cards / Village Group) */}
      {loading ? (
        <div className="bg-white p-16 rounded-2xl shadow-md border border-slate-200 text-center text-slate-500 space-y-3">
          <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin mx-auto" />
          <p className="font-bold text-slate-800">নাগরিক মাস্টার ডাটাবেজ প্রস্তুত হইতেছে...</p>
          <p className="text-xs text-slate-400">অনুগ্রহ করে কয়েক সেকেন্ড অপেক্ষা করুন।</p>
        </div>
      ) : filteredCitizens.length === 0 ? (
        <div className="bg-white p-16 rounded-2xl shadow-md border border-slate-200 text-center text-slate-500 space-y-3">
          <Search className="w-12 h-12 text-slate-300 mx-auto" />
          <p className="text-base font-black text-slate-800">কোনো নাগরিক রেকর্ড পাওয়া যায় নাই!</p>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            আপনার নির্বাচিত ফিল্টার (গ্রাম: {selectedVillage || 'সব'}, বয়স: {selectedAgeGroup}, পেশা: {selectedOccupation || 'সব'}) বা সার্চ শব্দ অনুযায়ী কোনো নাগরিক পাওয়া যায়নি।
          </p>
          <button
            onClick={handleResetFilters}
            className="px-4 py-2 bg-emerald-800 hover:bg-emerald-700 text-amber-300 font-bold text-xs rounded-xl shadow transition cursor-pointer"
          >
            সকল ফিল্টার রিসেট করুন
          </button>
        </div>
      ) : viewMode === 'table' ? (
        /* TABLE VIEW */
        <div className="bg-white rounded-2xl shadow-md border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left text-slate-800">
              <thead className="bg-emerald-950 text-white font-bold select-none">
                <tr>
                  <th 
                    onClick={() => handleHeaderSort('name')}
                    className="p-3 border-r border-emerald-900 cursor-pointer hover:bg-emerald-900/80 transition"
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span>নাগরিকের নাম</span>
                      {sortField === 'name' ? (
                        sortOrder === 'asc' ? <ArrowUp className="w-3 h-3 text-amber-300" /> : <ArrowDown className="w-3 h-3 text-amber-300" />
                      ) : <ArrowUpDown className="w-3 h-3 text-emerald-500/70" />}
                    </div>
                  </th>

                  <th 
                    onClick={() => handleHeaderSort('village')}
                    className="p-3 border-r border-emerald-900 cursor-pointer hover:bg-emerald-900/80 transition"
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span>গ্রাম ও ওয়ার্ড</span>
                      {sortField === 'village' ? (
                        sortOrder === 'asc' ? <ArrowUp className="w-3 h-3 text-amber-300" /> : <ArrowDown className="w-3 h-3 text-amber-300" />
                      ) : <ArrowUpDown className="w-3 h-3 text-emerald-500/70" />}
                    </div>
                  </th>

                  <th 
                    onClick={() => handleHeaderSort('age')}
                    className="p-3 border-r border-emerald-900 cursor-pointer hover:bg-emerald-900/80 transition text-center"
                  >
                    <div className="flex items-center justify-center gap-1">
                      <span>বয়স ও বয়সসীমা</span>
                      {sortField === 'age' ? (
                        sortOrder === 'asc' ? <ArrowUp className="w-3 h-3 text-amber-300" /> : <ArrowDown className="w-3 h-3 text-amber-300" />
                      ) : <ArrowUpDown className="w-3 h-3 text-emerald-500/70" />}
                    </div>
                  </th>

                  <th 
                    onClick={() => handleHeaderSort('occupation')}
                    className="p-3 border-r border-emerald-900 cursor-pointer hover:bg-emerald-900/80 transition"
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span>পেশা</span>
                      {sortField === 'occupation' ? (
                        sortOrder === 'asc' ? <ArrowUp className="w-3 h-3 text-amber-300" /> : <ArrowDown className="w-3 h-3 text-amber-300" />
                      ) : <ArrowUpDown className="w-3 h-3 text-emerald-500/70" />}
                    </div>
                  </th>

                  <th className="p-3 border-r border-emerald-900">NID / জন্ম সনদ</th>

                  <th 
                    onClick={() => handleHeaderSort('holding')}
                    className="p-3 border-r border-emerald-900 cursor-pointer hover:bg-emerald-900/80 transition"
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span>হোল্ডিং নং</span>
                      {sortField === 'holding' ? (
                        sortOrder === 'asc' ? <ArrowUp className="w-3 h-3 text-amber-300" /> : <ArrowDown className="w-3 h-3 text-emerald-500/70" />
                      ) : <ArrowUpDown className="w-3 h-3 text-emerald-500/70" />}
                    </div>
                  </th>

                  <th className="p-3 border-r border-emerald-900">অভিভাবক ও মোবাইল</th>

                  <th 
                    onClick={() => handleHeaderSort('certificates')}
                    className="p-3 border-r border-emerald-900 text-center cursor-pointer hover:bg-emerald-900/80 transition"
                  >
                    <div className="flex items-center justify-center gap-1">
                      <span>ইস্যুকৃত সনদ</span>
                      {sortField === 'certificates' ? (
                        sortOrder === 'asc' ? <ArrowUp className="w-3 h-3 text-amber-300" /> : <ArrowDown className="w-3 h-3 text-amber-300" />
                      ) : <ArrowUpDown className="w-3 h-3 text-emerald-500/70" />}
                    </div>
                  </th>

                  <th className="p-3 text-center">প্রত্যয়ন অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredCitizens.map((cit) => {
                  const age = extractAge(cit);
                  const ageInfo = getAgeGroupInfo(age);

                  return (
                    <tr key={cit.id} className="hover:bg-emerald-50/60 transition">
                      {/* Name & Gender */}
                      <td className="p-3 font-bold text-slate-900">
                        <div className="text-sm font-extrabold text-emerald-950">{cit.name}</div>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded font-semibold">{cit.gender}</span>
                          {cit.registeredAt && (
                            <span className="text-[10px] text-slate-400">নিবন্ধন: {cit.registeredAt.substring(0, 10)}</span>
                          )}
                        </div>
                      </td>

                      {/* Village & Ward */}
                      <td className="p-3">
                        <div className="font-extrabold text-slate-900 flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-emerald-700 shrink-0" />
                          <span>{cit.village}</span>
                        </div>
                        <div className="mt-1">
                          <span className="text-[10px] bg-emerald-800 text-amber-300 px-1.5 py-0.5 rounded font-bold">
                            ওয়ার্ড নং {cit.wardNo}
                          </span>
                        </div>
                      </td>

                      {/* Age & Age Group */}
                      <td className="p-3 text-center">
                        {age !== undefined ? (
                          <div className="space-y-1">
                            <span className="text-xs font-black text-slate-900 block">
                              {age} বছর
                            </span>
                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border block whitespace-nowrap ${ageInfo.badgeColor}`}>
                              {ageInfo.label.split(' ')[0]}
                            </span>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic text-[11px]">অনির্দিষ্ট</span>
                        )}
                      </td>

                      {/* Occupation */}
                      <td className="p-3">
                        <div className="flex items-center gap-1.5">
                          <span className="p-1 rounded-md bg-amber-100 text-amber-800">
                            <Briefcase className="w-3 h-3" />
                          </span>
                          <span className="font-bold text-slate-800">
                            {cit.occupation || 'অন্যান্য'}
                          </span>
                        </div>
                      </td>

                      {/* NID / Birth Registration */}
                      <td className="p-3 font-mono font-bold text-slate-900">
                        {cit.nid ? (
                          <div className="flex items-center gap-1">
                            <span className="bg-emerald-100 text-emerald-950 border border-emerald-300 px-2 py-0.5 rounded text-xs font-bold">
                              {cit.nid}
                            </span>
                            <button
                              onClick={() => handleCopyText(cit.nid!, 'nid')}
                              className="p-1 hover:bg-slate-200 text-slate-500 rounded transition cursor-pointer"
                              title="NID কপি করুন"
                            >
                              {copiedId === 'nid_' + cit.nid ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-slate-500" />}
                            </button>
                          </div>
                        ) : cit.birthNo ? (
                          <div className="flex items-center gap-1">
                            <span className="bg-blue-100 text-blue-900 border border-blue-300 px-2 py-0.5 rounded text-[11px]">
                              {cit.birthNo}
                            </span>
                            <button
                              onClick={() => handleCopyText(cit.birthNo!, 'birth')}
                              className="p-1 hover:bg-slate-200 text-slate-500 rounded transition cursor-pointer"
                              title="জন্ম নিবন্ধন কপি করুন"
                            >
                              {copiedId === 'birth_' + cit.birthNo ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-slate-500" />}
                            </button>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">N/A</span>
                        )}
                      </td>

                      {/* Holding Number */}
                      <td className="p-3">
                        {cit.holdingNo ? (
                          <div className="flex items-center gap-1">
                            <span className="bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 rounded font-black text-xs flex items-center gap-1">
                              <Home className="w-3 h-3 text-amber-700 shrink-0" />
                              <span>{cit.holdingNo}</span>
                            </span>
                            <button
                              onClick={() => handleCopyText(cit.holdingNo!, 'holding')}
                              className="p-1 hover:bg-slate-200 text-slate-500 rounded transition cursor-pointer"
                              title="হোল্ডিং কপি করুন"
                            >
                              {copiedId === 'holding_' + cit.holdingNo ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-slate-500" />}
                            </button>
                          </div>
                        ) : (
                          <span className="text-slate-400 text-[11px] italic">নির্ধারিত নয়</span>
                        )}
                      </td>

                      {/* Guardian & Mobile */}
                      <td className="p-3 text-slate-700">
                        <div className="font-semibold text-slate-900 text-[11px]">
                          <span className="text-slate-400 text-[10px] font-normal mr-1">পিতা/স্বামী:</span>
                          {cit.father || cit.spouseName || 'N/A'}
                        </div>
                        {cit.mobile ? (
                          <a
                            href={`tel:${cit.mobile}`}
                            className="hover:underline text-emerald-800 font-bold flex items-center gap-1 text-[11px] mt-0.5 font-mono"
                          >
                            <Phone className="w-3 h-3 text-emerald-600" />
                            <span>{cit.mobile}</span>
                          </a>
                        ) : (
                          <span className="text-slate-400 text-[10px]">মোবাইল নেই</span>
                        )}
                      </td>

                      {/* Issued Certificates Count */}
                      <td className="p-3 text-center">
                        <span className="px-2.5 py-1 bg-amber-100 text-amber-900 text-xs font-black rounded-full border border-amber-300">
                          {cit.totalCertificates} টি
                        </span>
                      </td>

                      {/* Action */}
                      <td className="p-3 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => onApplyForCitizen(cit)}
                            className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs rounded-xl transition flex items-center gap-1 cursor-pointer shadow-sm active:scale-95 border border-emerald-700"
                            title="এই নাগরিকের জন্য সরাসরি সনদ আবেদন করুন"
                          >
                            <FileCheck2 className="w-3.5 h-3.5 text-amber-300" />
                            <span>সনদ আবেদন</span>
                          </button>
                          
                          <button
                            onClick={() => setViewCitizenDetail(cit)}
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition cursor-pointer border border-slate-300"
                            title="পূর্ণাঙ্গ নাগরিক বিবরণী দেখুন"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : viewMode === 'grid' ? (
        /* GRID / CARDS VIEW */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCitizens.map((cit) => {
            const age = extractAge(cit);
            const ageInfo = getAgeGroupInfo(age);

            return (
              <div
                key={cit.id}
                className="bg-white rounded-2xl p-5 shadow-md border border-slate-200 hover:border-emerald-500 hover:shadow-lg transition space-y-3 flex flex-col justify-between"
              >
                <div>
                  {/* Top Card Header */}
                  <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-3">
                    <div>
                      <h4 className="font-black text-sm text-emerald-950">{cit.name}</h4>
                      <p className="text-xs text-slate-500 font-semibold mt-0.5">
                        পিতা/স্বামী: {cit.father || cit.spouseName || 'N/A'}
                      </p>
                    </div>

                    <span className="px-2 py-0.5 bg-emerald-800 text-amber-300 text-[10px] font-bold rounded-lg shrink-0">
                      ওয়ার্ড {cit.wardNo}
                    </span>
                  </div>

                  {/* Badges: Village, Age, Occupation */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-3">
                    <span className="px-2.5 py-1 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-lg text-xs font-extrabold flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-emerald-700" />
                      <span>{cit.village}</span>
                    </span>

                    {age !== undefined && (
                      <span className={`px-2 py-0.5 rounded-lg text-xs font-bold border flex items-center gap-1 ${ageInfo.badgeColor}`}>
                        <Cake className="w-3 h-3" />
                        <span>{age} বছর</span>
                      </span>
                    )}

                    <span className="px-2 py-0.5 bg-amber-50 text-amber-900 border border-amber-200 rounded-lg text-xs font-bold flex items-center gap-1">
                      <Briefcase className="w-3 h-3 text-amber-700" />
                      <span>{cit.occupation || 'অন্যান্য'}</span>
                    </span>
                  </div>

                  {/* Details Grid */}
                  <div className="mt-3 bg-slate-50 p-2.5 rounded-xl text-xs space-y-1 font-semibold text-slate-700 border border-slate-200">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">NID / জন্ম সনদ:</span>
                      <span className="font-mono font-bold text-slate-900">{cit.nid || cit.birthNo || 'N/A'}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">হোল্ডিং নম্বর:</span>
                      <span className="font-bold text-amber-900">{cit.holdingNo || 'নির্ধারিত নয়'}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">মোবাইল:</span>
                      <span className="font-mono text-emerald-800 font-bold">{cit.mobile || 'N/A'}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">গৃহীত সনদ:</span>
                      <span className="font-bold text-emerald-700">{cit.totalCertificates} টি</span>
                    </div>
                  </div>
                </div>

                {/* Card Action Button */}
                <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                  <button
                    onClick={() => onApplyForCitizen(cit)}
                    className="flex-1 py-2 bg-emerald-800 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                  >
                    <FileCheck2 className="w-4 h-4 text-amber-300" />
                    <span>সনদ আবেদন করুন</span>
                  </button>

                  <button
                    onClick={() => setViewCitizenDetail(cit)}
                    className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition cursor-pointer border border-slate-300"
                    title="বিস্তারিত দেখুন"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* VILLAGE GROUPED VIEW */
        <div className="space-y-6">
          {(Object.entries(villageGroupedData) as [string, CitizenAccountRecord[]][]).map(([villageName, vCitizens]) => (
            <div key={villageName} className="bg-white rounded-2xl shadow-md border border-slate-200 overflow-hidden">
              {/* Group Header */}
              <div className="bg-emerald-950 text-white p-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-800 text-amber-300 flex items-center justify-center font-bold">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-black text-sm text-white">গ্রাম: {villageName}</h3>
                    <p className="text-xs text-emerald-300">
                      এই গ্রামের নিবন্ধিত নাগরিক: {vCitizens.length} জন
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 bg-emerald-800 text-amber-300 text-xs font-bold rounded-lg border border-emerald-700">
                    সনদ সুবিধাভোগী: {vCitizens.filter(c => c.totalCertificates > 0).length} জন
                  </span>
                </div>
              </div>

              {/* Group Citizens Cards Grid */}
              <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 bg-slate-50/50">
                {vCitizens.map((cit) => {
                  const age = extractAge(cit);
                  const ageInfo = getAgeGroupInfo(age);

                  return (
                    <div
                      key={cit.id}
                      className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs hover:border-emerald-500 transition flex flex-col justify-between space-y-2.5"
                    >
                      <div>
                        <div className="flex items-start justify-between">
                          <h4 className="font-black text-xs text-emerald-950">{cit.name}</h4>
                          <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded font-bold">
                            ওয়ার্ড {cit.wardNo}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                          {age !== undefined && (
                            <span className={`text-[10px] px-2 py-0.5 rounded-md font-bold border ${ageInfo.badgeColor}`}>
                              {age} বছর
                            </span>
                          )}
                          <span className="text-[10px] px-2 py-0.5 bg-amber-50 text-amber-900 border border-amber-200 rounded-md font-bold">
                            {cit.occupation || 'অন্যান্য'}
                          </span>
                          {cit.holdingNo && (
                            <span className="text-[10px] px-1.5 py-0.5 bg-slate-100 text-slate-700 font-bold rounded">
                              {cit.holdingNo}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                        <span className="text-[11px] font-mono text-slate-500 font-bold">
                          {cit.nid ? cit.nid.substring(0, 10) + '...' : (cit.birthNo ? cit.birthNo.substring(0, 10) + '...' : 'N/A')}
                        </span>

                        <button
                          onClick={() => onApplyForCitizen(cit)}
                          className="px-2.5 py-1 bg-emerald-800 hover:bg-emerald-700 text-amber-300 font-black text-[11px] rounded-lg transition flex items-center gap-1 cursor-pointer"
                        >
                          <FileCheck2 className="w-3 h-3 text-amber-300" />
                          <span>সনদ আবেদন</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 6. View Citizen Detail Modal */}
      {viewCitizenDetail && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-emerald-900 text-amber-300 flex items-center justify-center font-bold">
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-sm text-emerald-950">{viewCitizenDetail.name}</h3>
                  <p className="text-xs text-slate-500">নাগরিক পূর্ণাঙ্গ মাস্টার প্রোফাইল</p>
                </div>
              </div>

              <button
                onClick={() => setViewCitizenDetail(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition cursor-pointer font-bold"
              >
                ✕
              </button>
            </div>

            {/* Citizen Details List */}
            <div className="space-y-2 text-xs">
              <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-500 block">গ্রাম:</span>
                  <span className="font-extrabold text-emerald-950">{viewCitizenDetail.village}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">ওয়ার্ড নং:</span>
                  <span className="font-extrabold text-emerald-950">ওয়ার্ড নং {viewCitizenDetail.wardNo}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">বয়স:</span>
                  <span className="font-extrabold text-slate-900">
                    {extractAge(viewCitizenDetail) !== undefined ? `${extractAge(viewCitizenDetail)} বছর` : 'অনির্দিষ্ট'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">পেশা:</span>
                  <span className="font-extrabold text-amber-900">{viewCitizenDetail.occupation || 'অন্যান্য'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">হোল্ডিং নম্বর:</span>
                  <span className="font-bold text-slate-900">{viewCitizenDetail.holdingNo || 'নির্ধারিত নয়'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">লিঙ্গ:</span>
                  <span className="font-bold text-slate-900">{viewCitizenDetail.gender}</span>
                </div>
              </div>

              <div className="p-3 bg-emerald-50/40 rounded-xl border border-emerald-200 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-600">NID নম্বর:</span>
                  <span className="font-mono font-bold text-emerald-950">{viewCitizenDetail.nid || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">জন্ম নিবন্ধন নম্বর:</span>
                  <span className="font-mono font-bold text-blue-950">{viewCitizenDetail.birthNo || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">পিতার নাম:</span>
                  <span className="font-semibold text-slate-900">{viewCitizenDetail.father || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">মাতার নাম:</span>
                  <span className="font-semibold text-slate-900">{viewCitizenDetail.mother || 'N/A'}</span>
                </div>
                {viewCitizenDetail.spouseName && (
                  <div className="flex justify-between">
                    <span className="text-slate-600">স্বামী/স্ত্রীর নাম:</span>
                    <span className="font-semibold text-slate-900">{viewCitizenDetail.spouseName}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-600">মোবাইল নম্বর:</span>
                  <span className="font-mono font-bold text-slate-900">{viewCitizenDetail.mobile || 'N/A'}</span>
                </div>
              </div>

              {/* Certificate History Banner */}
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-center justify-between">
                <div>
                  <span className="text-amber-900 font-bold block">মোট ইস্যুকৃত সনদ: {viewCitizenDetail.totalCertificates} টি</span>
                  {viewCitizenDetail.lastCertificateType && (
                    <span className="text-[11px] text-amber-800">
                      সর্বশেষ: {viewCitizenDetail.lastCertificateType} ({viewCitizenDetail.lastCertificateDate})
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="pt-2 flex justify-end gap-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setViewCitizenDetail(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition cursor-pointer text-xs"
              >
                বন্ধ করুন
              </button>
              <button
                type="button"
                onClick={() => {
                  onApplyForCitizen(viewCitizenDetail);
                  setViewCitizenDetail(null);
                }}
                className="px-5 py-2 bg-emerald-800 hover:bg-emerald-700 text-amber-300 font-black rounded-xl transition shadow cursor-pointer text-xs flex items-center gap-1.5"
              >
                <FileCheck2 className="w-4 h-4 text-amber-300" />
                <span>এই নাগরিকের জন্য সনদ তৈরি করুন</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7. Add New Citizen Modal (With Age & Occupation) */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-lg w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h3 className="font-bold text-base text-emerald-950 flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-emerald-700" />
                <span>নতুন নাগরিক নিবন্ধন ও প্রোফাইল তৈরি</span>
              </h3>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsNidScannerOpen(true)}
                  className="px-2.5 py-1 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-lg transition flex items-center gap-1 cursor-pointer shadow-sm"
                >
                  <Sparkles className="w-3.5 h-3.5 text-slate-900" />
                  <span>AI NID স্ক্যান</span>
                </button>

                <button
                  onClick={() => setIsAddModalOpen(false)}
                  className="text-slate-400 hover:text-slate-600 font-bold text-lg px-1 cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>

            <form onSubmit={handleCreateCitizen} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">নাগরিকের নাম (বাংলায়) *</label>
                <input
                  type="text"
                  required
                  value={newCitizen.name}
                  onChange={(e) => setNewCitizen({ ...newCitizen, name: e.target.value })}
                  placeholder="যেমন: মোঃ কামরুল ইসলাম"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-emerald-600 focus:outline-none font-semibold text-xs"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">NID নম্বর</label>
                  <input
                    type="text"
                    value={newCitizen.nid}
                    onChange={(e) => setNewCitizen({ ...newCitizen, nid: e.target.value })}
                    placeholder="১০/১৭ ডিজিট"
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-emerald-600 focus:outline-none font-mono text-xs"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">জন্ম নিবন্ধন নম্বর</label>
                  <input
                    type="text"
                    value={newCitizen.birthNo}
                    onChange={(e) => setNewCitizen({ ...newCitizen, birthNo: e.target.value })}
                    placeholder="১৭ ডিজিট"
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-emerald-600 focus:outline-none font-mono text-xs"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">হোল্ডিং নম্বর</label>
                  <input
                    type="text"
                    value={newCitizen.holdingNo}
                    onChange={(e) => setNewCitizen({ ...newCitizen, holdingNo: e.target.value })}
                    placeholder="যেমন: এইচ-১০৪"
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-emerald-600 focus:outline-none font-bold text-xs"
                  />
                </div>
              </div>

              {/* Parents & Spouse */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">পিতার নাম</label>
                  <input
                    type="text"
                    value={newCitizen.father}
                    onChange={(e) => setNewCitizen({ ...newCitizen, father: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-emerald-600 focus:outline-none text-xs"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">মাতার নাম *</label>
                  <input
                    type="text"
                    required
                    value={newCitizen.mother}
                    onChange={(e) => setNewCitizen({ ...newCitizen, mother: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-emerald-600 focus:outline-none text-xs"
                  />
                </div>
              </div>

              {/* Age & Occupation Row */}
              <div className="grid grid-cols-3 gap-2 bg-emerald-50/50 p-2.5 rounded-xl border border-emerald-200">
                <div>
                  <label className="block font-black text-emerald-950 mb-1">বয়স (বছর)</label>
                  <input
                    type="number"
                    min="1"
                    max="120"
                    placeholder="যেমন: ৩৫"
                    value={newCitizen.age || ''}
                    onChange={(e) => setNewCitizen({ ...newCitizen, age: e.target.value ? parseInt(e.target.value, 10) : undefined })}
                    className="w-full px-2 py-2 bg-white border border-emerald-300 rounded-lg focus:border-emerald-600 focus:outline-none font-bold text-xs text-center"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block font-black text-emerald-950 mb-1">পেশা (Occupation)</label>
                  <select
                    value={newCitizen.occupation}
                    onChange={(e) => setNewCitizen({ ...newCitizen, occupation: e.target.value })}
                    className="w-full px-2 py-2 bg-white border border-emerald-300 rounded-lg focus:border-emerald-600 focus:outline-none font-bold text-xs"
                  >
                    {COMMON_OCCUPATIONS.map((occ) => (
                      <option key={occ} value={occ}>
                        {occ}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Gender, Ward & Village */}
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">লিঙ্গ</label>
                  <select
                    value={newCitizen.gender}
                    onChange={(e) => setNewCitizen({ ...newCitizen, gender: e.target.value as 'পুরুষ' | 'মহিলা' | 'হিজরা' })}
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:border-emerald-600 focus:outline-none font-semibold text-xs"
                  >
                    <option value="পুরুষ">পুরুষ</option>
                    <option value="মহিলা">মহিলা</option>
                    <option value="হিজরা">হিজরা</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">ওয়ার্ড নং</label>
                  <select
                    value={newCitizen.wardNo}
                    onChange={(e) => setNewCitizen({ ...newCitizen, wardNo: e.target.value })}
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:border-emerald-600 focus:outline-none font-bold text-xs"
                  >
                    {WARDS.map((w) => (
                      <option key={w} value={w}>
                        ওয়ার্ড {w}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">গ্রাম</label>
                  <select
                    value={newCitizen.village}
                    onChange={(e) => setNewCitizen({ ...newCitizen, village: e.target.value })}
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:border-emerald-600 focus:outline-none text-xs font-bold"
                  >
                    {KNOWN_VILLAGES.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">মোবাইল নম্বর</label>
                <input
                  type="text"
                  value={newCitizen.mobile}
                  onChange={(e) => setNewCitizen({ ...newCitizen, mobile: e.target.value })}
                  placeholder="017XXXXXXXX"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-emerald-600 focus:outline-none font-mono text-xs"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg transition text-xs"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-800 hover:bg-emerald-700 text-white font-bold rounded-lg transition shadow cursor-pointer text-xs"
                >
                  নাগরিক একাউন্ট সেভ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 8. Gemini Vision AI NID Scanner Modal */}
      <NidScannerModal
        isOpen={isNidScannerOpen}
        onClose={() => setIsNidScannerOpen(false)}
        onAutoFill={handleNidAutoFill}
      />
    </div>
  );
};
