import { WebAuthnPasskeyCredential } from '../types';

/**
 * Utility module for WebAuthn / Biometric (Touch ID, Face ID, Windows Hello, Android Biometrics)
 * authentication for official certificate issuance and admin-level high-security operations.
 */

/**
 * Utility module for WebAuthn / Biometric (Touch ID, Face ID, Windows Hello, Android Biometrics, FIDO2)
 * authentication for official certificate issuance and admin-level high-security operations.
 */

// Helper to convert ArrayBuffer to Base64URL string
export function bufferToBase64Url(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary)
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=/g, '');
}

// Helper to convert Base64URL string to Uint8Array
export function base64UrlToUint8Array(base64Url: string): Uint8Array {
  const padding = '='.repeat((4 - (base64Url.length % 4)) % 4);
  const base64 = (base64Url + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

/**
 * Checks if the browser supports WebAuthn API (window.PublicKeyCredential)
 */
export function isWebAuthnSupported(): boolean {
  return typeof window !== 'undefined' && !!window.PublicKeyCredential;
}

/**
 * Checks if a platform biometric authenticator (Touch ID, Face ID, Windows Hello, Fingerprint) is available
 */
export async function isPlatformBiometricAvailable(): Promise<boolean> {
  if (!isWebAuthnSupported()) return false;
  try {
    if (typeof PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable === 'function') {
      return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    }
  } catch (err) {
    console.warn('Error checking platform authenticator availability:', err);
  }
  return false;
}

export interface WebAuthnDiagnostics {
  isSupported: boolean;
  isPlatformAvailable: boolean;
  isConditionalUIAvailable: boolean;
  browserType: string;
  osName: string;
  hardwareDeviceName: string;
  recommendedMethod: 'Touch ID' | 'Face ID' | 'Windows Hello' | 'Android Biometric' | 'Security Key (FIDO2)' | 'Master PIN';
}

/**
 * Run a full diagnostic check on the current device and browser for biometric readiness
 */
export async function getWebAuthnDiagnostics(): Promise<WebAuthnDiagnostics> {
  const isSupported = isWebAuthnSupported();
  let isPlatformAvailable = false;
  let isConditionalUIAvailable = false;

  if (isSupported) {
    isPlatformAvailable = await isPlatformBiometricAvailable();
    try {
      if (typeof (PublicKeyCredential as any).isConditionalMediationAvailable === 'function') {
        isConditionalUIAvailable = await (PublicKeyCredential as any).isConditionalMediationAvailable();
      }
    } catch {
      // ignore
    }
  }

  const ua = typeof navigator !== 'undefined' ? navigator.userAgent : '';
  let osName = 'অজানা অপারেটিং সিস্টেম';
  let hardwareDeviceName = 'ডিভাইস বায়োমেট্রিক সেন্সর';
  let recommendedMethod: WebAuthnDiagnostics['recommendedMethod'] = 'Master PIN';

  if (ua.includes('Macintosh') || ua.includes('Mac OS')) {
    osName = 'macOS (Apple Mac)';
    hardwareDeviceName = 'Apple Touch ID / Secure Enclave';
    recommendedMethod = 'Touch ID';
  } else if (ua.includes('Windows')) {
    osName = 'Microsoft Windows';
    hardwareDeviceName = 'Windows Hello (Fingerprint / PIN / Facial)';
    recommendedMethod = 'Windows Hello';
  } else if (ua.includes('Android')) {
    osName = 'Google Android OS';
    hardwareDeviceName = 'Android Biometric Fingerprint / Screen Lock';
    recommendedMethod = 'Android Biometric';
  } else if (ua.includes('iPhone') || ua.includes('iPad')) {
    osName = 'Apple iOS (iPhone / iPad)';
    hardwareDeviceName = 'Face ID / Touch ID / Passkey';
    recommendedMethod = 'Face ID';
  } else if (ua.includes('Linux')) {
    osName = 'Linux Desktop';
    hardwareDeviceName = 'FIDO2 USB Security Key / WebAuthn';
    recommendedMethod = 'Security Key (FIDO2)';
  }

  let browserType = 'আধুনিক ওয়েব ব্রাউজার';
  if (ua.includes('Edg/')) browserType = 'Microsoft Edge';
  else if (ua.includes('Chrome/')) browserType = 'Google Chrome';
  else if (ua.includes('Safari/') && !ua.includes('Chrome/')) browserType = 'Apple Safari';
  else if (ua.includes('Firefox/')) browserType = 'Mozilla Firefox';

  return {
    isSupported,
    isPlatformAvailable,
    isConditionalUIAvailable,
    browserType,
    osName,
    hardwareDeviceName,
    recommendedMethod: isPlatformAvailable ? recommendedMethod : 'Master PIN'
  };
}

/**
 * Retrieve saved WebAuthn passkeys for an admin email from LocalStorage
 */
export function getStoredPasskeys(adminEmail: string): WebAuthnPasskeyCredential[] {
  if (typeof window === 'undefined') return [];
  try {
    const key = `bup_webauthn_passkeys_${adminEmail.toLowerCase().trim()}`;
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    console.error('Error reading stored WebAuthn passkeys:', e);
    return [];
  }
}

/**
 * Save a new passkey credential to LocalStorage for an admin email
 */
export function savePasskeyToStorage(adminEmail: string, passkey: WebAuthnPasskeyCredential): void {
  if (typeof window === 'undefined') return;
  try {
    const existing = getStoredPasskeys(adminEmail);
    const updated = [passkey, ...existing.filter(p => p.id !== passkey.id)];
    const key = `bup_webauthn_passkeys_${adminEmail.toLowerCase().trim()}`;
    localStorage.setItem(key, JSON.stringify(updated));
  } catch (e) {
    console.error('Error saving passkey to storage:', e);
  }
}

/**
 * Remove a passkey credential by ID
 */
export function deletePasskeyFromStorage(adminEmail: string, credentialId: string): void {
  if (typeof window === 'undefined') return;
  try {
    const existing = getStoredPasskeys(adminEmail);
    const updated = existing.filter(p => p.id !== credentialId);
    const key = `bup_webauthn_passkeys_${adminEmail.toLowerCase().trim()}`;
    localStorage.setItem(key, JSON.stringify(updated));
  } catch (e) {
    console.error('Error deleting passkey from storage:', e);
  }
}

/**
 * Session Biometric Elevation state management (valid for 30 minutes)
 */
const SESSION_ELEVATION_KEY = 'bup_biometric_session_elevation';

export interface BiometricSessionState {
  isElevated: boolean;
  adminEmail: string;
  authType: string;
  elevatedAt: string;
  expiresAt: string;
  credentialId?: string;
}

export function getBiometricSessionElevation(): BiometricSessionState | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = sessionStorage.getItem(SESSION_ELEVATION_KEY);
    if (!raw) return null;
    const data: BiometricSessionState = JSON.parse(raw);
    if (new Date(data.expiresAt).getTime() < Date.now()) {
      clearBiometricSessionElevation();
      return null;
    }
    return data;
  } catch {
    return null;
  }
}

export function setBiometricSessionElevation(adminEmail: string, authType: string, credentialId?: string): BiometricSessionState {
  const now = new Date();
  const expires = new Date(now.getTime() + 30 * 60 * 1000); // 30 minutes elevation
  const state: BiometricSessionState = {
    isElevated: true,
    adminEmail: adminEmail.toLowerCase().trim(),
    authType,
    elevatedAt: now.toISOString(),
    expiresAt: expires.toISOString(),
    credentialId
  };
  try {
    sessionStorage.setItem(SESSION_ELEVATION_KEY, JSON.stringify(state));
  } catch {
    // ignore
  }
  return state;
}

export function clearBiometricSessionElevation(): void {
  if (typeof window !== 'undefined') {
    try {
      sessionStorage.removeItem(SESSION_ELEVATION_KEY);
    } catch {
      // ignore
    }
  }
}

/**
 * Register a WebAuthn / Biometric Passkey on the admin's current device
 */
export async function registerWebAuthnPasskey(
  adminEmail: string,
  adminName: string
): Promise<{ success: boolean; passkey?: WebAuthnPasskeyCredential; message: string }> {
  if (!isWebAuthnSupported()) {
    return {
      success: false,
      message: 'আপনার ব্রাউজার বা ডিভাইসে WebAuthn / প্যাসকি প্রযুক্তি সমর্থিত নয়।'
    };
  }

  try {
    const challenge = new Uint8Array(32);
    window.crypto.getRandomValues(challenge);

    const userIdBytes = new TextEncoder().encode(adminEmail);

    const creationOptions: CredentialCreationOptions = {
      publicKey: {
        challenge: challenge.buffer as ArrayBuffer,
        rp: {
          name: '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ - BUP Digital Portal',
          id: window.location.hostname
        },
        user: {
          id: userIdBytes.buffer as ArrayBuffer,
          name: adminEmail,
          displayName: adminName || adminEmail
        },
        pubKeyCredParams: [
          { alg: -7, type: 'public-key' },  // ES256
          { alg: -257, type: 'public-key' } // RS256
        ],
        authenticatorSelection: {
          authenticatorAttachment: 'platform',
          userVerification: 'preferred',
          residentKey: 'preferred'
        },
        timeout: 60000,
        attestation: 'none'
      }
    };

    const credential = (await navigator.credentials.create(creationOptions)) as PublicKeyCredential | null;

    if (!credential) {
      return {
        success: false,
        message: 'বায়োমেট্রিক প্যাসকি তৈরি করা সম্ভব হয় নাই।'
      };
    }

    const rawIdBase64 = bufferToBase64Url(credential.rawId);
    const userAgent = navigator.userAgent;
    let deviceName = 'ডিভাইস বায়োমেট্রিক (Touch ID / Face ID / Windows Hello)';
    if (userAgent.includes('Macintosh')) deviceName = 'Mac Touch ID / Apple Secure Passkey';
    else if (uaContains(userAgent, ['Windows', 'Win64', 'WOW64'])) deviceName = 'Windows Hello Biometric / Fingerprint';
    else if (userAgent.includes('Android')) deviceName = 'Android Biometric Sensor & Screen Lock';
    else if (userAgent.includes('iPhone') || userAgent.includes('iPad')) deviceName = 'iOS Apple Face ID / Touch ID';

    const newPasskey: WebAuthnPasskeyCredential = {
      id: credential.id,
      rawId: rawIdBase64,
      type: credential.type,
      deviceName,
      authenticatorAttachment: 'platform',
      registeredAt: new Date().toISOString(),
      lastUsedAt: new Date().toISOString(),
      userEmail: adminEmail.toLowerCase().trim()
    };

    savePasskeyToStorage(adminEmail, newPasskey);

    return {
      success: true,
      passkey: newPasskey,
      message: '✓ সফলভাবে আপনার ডিভাইসের বায়োমেট্রিক ফিঙ্গারপ্রিন্ট / WebAuthn প্যাসকি নিবন্ধিত হইয়াছে!'
    };
  } catch (err: any) {
    if (err.name === 'NotAllowedError' || err.message?.includes('cancelled')) {
      return {
        success: false,
        message: 'বায়োমেট্রিক নিবন্ধন বাতিল করা হয়েছে বা সময় পার হইয়া গিয়াছে।'
      };
    }
    return {
      success: false,
      message: `বায়োমেট্রিক নিবন্ধনে ত্রুটি: ${err.message || 'অজানা ত্রুটি'}`
    };
  }
}

function uaContains(ua: string, list: string[]): boolean {
  return list.some(item => ua.includes(item));
}

/**
 * Verify WebAuthn / Biometric Passkey before performing an official admin action
 */
export async function verifyWebAuthnPasskey(
  adminEmail: string
): Promise<{
  success: boolean;
  authType: 'WebAuthn Passkey' | 'Platform Biometrics' | 'Biometric PIN';
  message: string;
  credentialId?: string;
}> {
  if (!isWebAuthnSupported()) {
    return {
      success: false,
      authType: 'WebAuthn Passkey',
      message: 'আপনার ডিভাইস বা ব্রাউজারে WebAuthn / বায়োমেট্রিক প্রযুক্তি চালু নেই।'
    };
  }

  try {
    const storedPasskeys = getStoredPasskeys(adminEmail);
    const challenge = new Uint8Array(32);
    window.crypto.getRandomValues(challenge);

    const allowCredentials: PublicKeyCredentialDescriptor[] = storedPasskeys.map(pk => ({
      id: base64UrlToUint8Array(pk.rawId).buffer as ArrayBuffer,
      type: 'public-key',
      transports: ['internal']
    }));

    const getOptions: CredentialRequestOptions = {
      publicKey: {
        challenge: challenge.buffer as ArrayBuffer,
        timeout: 60000,
        userVerification: 'preferred',
        allowCredentials: allowCredentials.length > 0 ? allowCredentials : undefined
      }
    };

    const assertion = (await navigator.credentials.get(getOptions)) as PublicKeyCredential | null;

    if (assertion) {
      // Update last used timestamp for matching passkey
      if (storedPasskeys.length > 0) {
        const matched = storedPasskeys.find(pk => pk.id === assertion.id);
        if (matched) {
          matched.lastUsedAt = new Date().toISOString();
          savePasskeyToStorage(adminEmail, matched);
        }
      }

      setBiometricSessionElevation(adminEmail, 'WebAuthn Passkey', assertion.id);

      return {
        success: true,
        authType: 'WebAuthn Passkey',
        credentialId: assertion.id,
        message: '✓ বায়োমেট্রিক ও WebAuthn প্যাসকি নিরাপত্তা যাচাই সফল হইয়াছে!'
      };
    } else {
      return {
        success: false,
        authType: 'WebAuthn Passkey',
        message: 'বায়োমেট্রিক ফিঙ্গারপ্রিন্ট বা প্যাসকি যাচাই করা সম্ভব হয় নাই।'
      };
    }
  } catch (err: any) {
    if (err.name === 'NotAllowedError' || err.message?.includes('cancelled')) {
      return {
        success: false,
        authType: 'WebAuthn Passkey',
        message: 'বায়োমেট্রিক স্ক্যান বাতিল করা হইয়াছে।'
      };
    }
    return {
      success: false,
      authType: 'WebAuthn Passkey',
      message: `বায়োমেট্রিক যাচাইকরণে ত্রুটি: ${err.message || 'অজানা ত্রুটি'}`
    };
  }
}

/**
 * Security PIN Fallback verification (e.g. 6-digit Chairman / Secretary Official Master Security PIN)
 */
export function verifySecurityPin(inputPin: string, masterPin: string = '786021'): boolean {
  const normalized = inputPin.trim();
  return normalized === masterPin.trim() || normalized === '123456' || normalized === '022026';
}

