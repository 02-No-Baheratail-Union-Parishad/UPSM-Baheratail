import React, { useState } from 'react';
import { 
  Sparkles, 
  Copy, 
  Check, 
  Download, 
  X, 
  FileText, 
  BookOpen, 
  Code2, 
  Layers, 
  ExternalLink, 
  Bot, 
  Workflow, 
  Send,
  HelpCircle,
  Database,
  ArrowRight
} from 'lucide-react';
import { UnionParishadConfig } from '../types';

interface GoogleGemWorkflowModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: UnionParishadConfig;
}

export const GoogleGemWorkflowModal: React.FC<GoogleGemWorkflowModalProps> = ({ isOpen, onClose, config }) => {
  const [activeTab, setActiveTab] = useState<'prompt' | 'knowledge' | 'actions' | 'guide' | 'test'>('prompt');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  
  // Test endpoint state
  const [testAction, setTestAction] = useState<'verify' | 'text'>('text');
  const [testName, setTestName] = useState('মোঃ আব্দুর রহিম');
  const [testType, setTestType] = useState('character');
  const [testMemo, setTestMemo] = useState('BUP-2026-04891');
  const [testLoading, setTestLoading] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);

  if (!isOpen) return null;

  const systemPromptContent = `# Google Gemini Custom Gem — Master System Prompt
## ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল সহকারী ও অটোমেশন এজেন্ট (UPSM Automation Agent)

### ১. এজেন্ট পরিচিতি ও ভূমিকা (Role & Persona)
তুমি "০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল সার্ভিস ও অটোমেশন এজেন্ট"। তুমি টাঙ্গাইল জেলার সখিপুর উপজেলাধীন ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের জন্য কাস্টমাইজড একটি সরকারি এআই সহকারী (Gemini Custom Gem / Workspace Agent)।

তোমার মূল দায়িত্ব:
1. ৪০+ ধরনের সরকারি প্রত্যয়নপত্র ও সনদ (চারিত্রিক, ওয়ারিশান, ট্রেড লাইসেন্স, ভূমিহীন, অবিবাহিত ইত্যাদি)-এর জন্য সরকারি মানসম্মত দাপ্তরিক বাংলা বিবরণী প্রস্তুত করা।
2. নাগরিকের প্রদত্ত তথ্যের যথার্থতা যাচাই (NID ১০/১৭ ডিজিট, জন্ম নিবন্ধন ১৭ ডিজিট, ওয়ার্ড নং ১-৯, গ্রামের নাম ২৬টি বৈধ গ্রামের সাথে মেলানো)।
3. ট্রেড লাইসেন্স ফি, সনদ ফি, ওয়ারিশ তালিকা ও অংশ হিসাব যাচাই করা।
4. ইউনিয়ন পরিষদের ডিজিটাল ট্র্যাকিং কোড (BUP-YYYY-XXXXX) ও অনলাইন কিউআর কোড ভেরিফিকেশন লিঙ্ক প্রদান করা।

### ২. দাপ্তরিক ভাষার মানদণ্ড (Bureaucratic Bengali)
- গঠন: "এই মর্মে প্রত্যয়ন করা যাইতেছে যে, ..." দিয়ে শুরু হবে।
- স্থায়ী ঠিকানা: "তিনি টাঙ্গাইল জেলার সখিপুর উপজেলার ০২নং বহেড়াতৈল ইউনিয়নের [ওয়ার্ড নং] নং ওয়ার্ডের [গ্রামের নাম] গ্রামের একজন স্থায়ী বাসিন্দা।"
- চরিত্র ও স্বীকৃতি: "তিনি আমার পূর্ব পরিচিত। তিনি রাষ্ট্র বা সমাজবিরোধী কোনো কার্যকলাপে লিপ্ত নহেন। তাঁহার নৈতিক চরিত্র উত্তম।"
- সমাপ্তি: "আমি তাহার সর্বাঙ্গীন মঙ্গল ও উত্তরোত্তর সাফল্য কামনা করি।"

ইউনিয়ন: ${config.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ'}
চেয়ারম্যান: ${config.chairmanName || 'মোশারফ হোসেন (হিরো মিয়া)'}
সচিব: ${config.secretaryName || 'মোঃ সাইদুজ্জামান'}
যোগাযোগ: ${config.upPhone || '০১৭xxxxxxxx'}, ${config.upEmail || 'baheratailunion@gmail.com'}`;

  const knowledgeBaseSnippet = `# ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল সিস্টেম — জ্ঞানভাণ্ডার (Knowledge Base)
**অধিক্ষেত্র:** ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, ডাকঘর: বহেড়াতৈল, উপজেলা: সখিপুর, জেলা: টাঙ্গাইল, বাংলাদেশ।

## ১. ভৌগোলিক ও প্রশাসনিক তথ্যাবলী
- ইউনিয়ন: ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ
- ওয়ার্ড: ৯টি, গ্রাম: ২৬টি (বহেড়াতৈল, বেতুয়া, ঘাটেশ্বরী, কালিয়াচালা, চাপড়াবাড়ি, বংশীনগর, গোবিন্দপুর, বাঘবেড়, কাকড়াজান পূর্ব, দেওবাড়ি, ডমুরিয়া ইত্যাদি)

## ২. ৪০+ প্রত্যয়নপত্রের বিভাগ
1. নাগরিকত্ব, পরিচয় ও চরিত্র (নাগরিকত্ব, চারিত্রিক, স্থায়ী বাসিন্দা, একই ব্যক্তি, NID সংশোধন)
2. পরিবার ও উত্তরাধিকার (ওয়ারিশান, অবিবাহিত, বিবাহিত, পুনর্বিবাহ না করা, এতিম)
3. শিক্ষা ও বয়স (ছাত্রত্ব, বয়স প্রাক্কলন, সনাতন ধর্মাবলম্বী, বার্ষিক আয়)
4. ব্যবসা ও বাণিজ্য (ট্রেড লাইসেন্স, বাণিজ্যিক অনাপত্তি, যানবাহন চলাচল অনুমতি)
5. কল্যাণ ও সাহায্য (প্রতিবন্ধী, নদীভাঙন, দরিদ্র ও আর্থিক অসচ্ছলতা, মুক্তিযোদ্ধা সন্তান)
6. ইউটিলিটি ও অনাপত্তি (বিদ্যুৎ সংযোগ অনাপত্তি, ভবন নির্মাণ অনাপত্তি, গ্যাস/পানি)

## ৩. কিউআর কোড ও অনলাইন ভেরিফিকেশন
- ফরম্যাট: BUP-YYYY-XXXXX
- ভেরিফিকেশন লিঙ্ক: https://upsm-baheratail.vercel.app/verify?memo=BUP-YYYY-XXXXX`;

  const openApiActionsSnippet = `{
  "openapi": "3.0.0",
  "info": {
    "title": "০২নং বহেড়াতৈল ইউনিয়ন পরিষদ অটোমেশন এপিআই (UPSM Agent Actions)",
    "version": "4.2.0"
  },
  "servers": [
    { "url": "https://upsm-baheratail.vercel.app", "description": "Production Server" }
  ],
  "paths": {
    "/api/certificates/generate-bengali-text": {
      "post": {
        "operationId": "generateCertificateText",
        "summary": "দাপ্তরিক বাংলা প্রত্যয়ন বিবরণী তৈরি করুন"
      }
    },
    "/api/certificates/verify/{trackingId}": {
      "get": {
        "operationId": "verifyCertificate",
        "summary": "সনদের কিউআর / ট্র্যাকিং আইডি যাচাই করুন"
      }
    },
    "/api/citizen/search": {
      "get": {
        "operationId": "searchCitizen",
        "summary": "নাগরিকের তথ্য ও পূর্বের সনদ অনুসন্ধান"
      }
    },
    "/api/public/config": {
      "get": {
        "operationId": "getPublicConfig",
        "summary": "ইউপি সাধারণ তথ্য ও ফি তালিকা"
      }
    }
  }
}`;

  const copyToClipboard = (text: string, sectionId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => setCopiedSection(null), 2500);
  };

  const downloadFile = (content: string, filename: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadAllBundle = () => {
    const bundle = {
      title: "০২নং বহেড়াতৈল ইউনিয়ন পরিষদ Google Gemini Gem Automation Bundle",
      version: "4.2.0",
      generatedAt: new Date().toISOString(),
      upDetails: {
        name: config.upName,
        chairman: config.chairmanName,
        secretary: config.secretaryName,
        email: config.upEmail,
        phone: config.upPhone
      },
      systemPrompt: systemPromptContent,
      knowledgeBase: knowledgeBaseSnippet,
      openApiActions: JSON.parse(openApiActionsSnippet)
    };

    downloadFile(JSON.stringify(bundle, null, 2), 'UPSM_Google_Gem_Bundle.json', 'application/json');
  };

  const handleRunApiTest = async () => {
    setTestLoading(true);
    setTestResult(null);
    try {
      if (testAction === 'text') {
        const res = await fetch('/api/certificates/generate-bengali-text', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            typeKey: testType,
            name: testName,
            fatherName: 'মোঃ আব্দুল করিম',
            motherName: 'মোছাঃ ফাতেমা বেগম',
            village: 'বহেড়াতৈল',
            wardNo: '০৫',
            nid: '19929315784000123'
          })
        });
        const data = await res.json();
        setTestResult(data);
      } else {
        const res = await fetch(`/api/certificates/verify/${encodeURIComponent(testMemo)}`);
        const data = await res.json();
        setTestResult(data);
      }
    } catch (err: any) {
      setTestResult({ error: true, message: err.message || 'API কল ব্যর্থ হয়েছে।' });
    } finally {
      setTestLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-5xl rounded-3xl shadow-2xl border border-slate-200 flex flex-col max-h-[92vh] overflow-hidden">
        
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-900 text-white p-5 flex items-center justify-between border-b border-emerald-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center shadow-lg font-black shrink-0">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold text-amber-300">
                  Google Gemini Gem & Automation Workflow Hub
                </h2>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold rounded-md border border-emerald-500/30">
                  v4.2
                </span>
              </div>
              <p className="text-xs text-slate-300">
                ইউনিয়ন পরিষদের এআই সহকারী হিসেবে Gemini Custom Gem সেটআপের জন্য প্রম্পট, নলেজ ফাইল ও অ্যাকশন এক্সপোর্ট
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadAllBundle}
              className="hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black rounded-xl shadow transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>সম্পূর্ণ বান্ডেল ডাউনলোড (.json)</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-xl text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar bg-slate-100 p-2 border-b border-slate-200 shrink-0">
          <button
            onClick={() => setActiveTab('prompt')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'prompt'
                ? 'bg-emerald-900 text-amber-300 shadow-sm'
                : 'text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>১. Gem সিস্টেম প্রম্পট (System Prompt)</span>
          </button>

          <button
            onClick={() => setActiveTab('knowledge')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'knowledge'
                ? 'bg-emerald-900 text-amber-300 shadow-sm'
                : 'text-slate-700 hover:bg-slate-200'
            }`}
          >
            <BookOpen className="w-4 h-4 text-emerald-400" />
            <span>২. নলেজ বেস ফাইল (Knowledge File)</span>
          </button>

          <button
            onClick={() => setActiveTab('actions')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'actions'
                ? 'bg-emerald-900 text-amber-300 shadow-sm'
                : 'text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Code2 className="w-4 h-4 text-blue-400" />
            <span>৩. OpenAPI অ্যাকশন স্পেক (Actions Schema)</span>
          </button>

          <button
            onClick={() => setActiveTab('guide')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'guide'
                ? 'bg-emerald-900 text-amber-300 shadow-sm'
                : 'text-slate-700 hover:bg-slate-200'
            }`}
          >
            <HelpCircle className="w-4 h-4 text-purple-400" />
            <span>৪. সেটআপ নির্দেশিকা (Setup Guide)</span>
          </button>

          <button
            onClick={() => setActiveTab('test')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'test'
                ? 'bg-emerald-900 text-amber-300 shadow-sm'
                : 'text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Workflow className="w-4 h-4 text-teal-400" />
            <span>৫. লাইভ এপিআই টেস্টার (Live API Test)</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">

          {/* TAB 1: SYSTEM PROMPT */}
          {activeTab === 'prompt' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-emerald-50 p-4 rounded-2xl border border-emerald-200">
                <div>
                  <h3 className="font-extrabold text-sm text-emerald-950 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-700" />
                    <span>Gemini Custom Gem Instructions (সিস্টেম প্রম্পট)</span>
                  </h3>
                  <p className="text-xs text-slate-600">
                    Google Gemini-এর <strong>"Gems"</strong> বা <strong>"Gem Manager"</strong>-এ নতুন Gem তৈরি করে এই নির্দেশনাগুলো "Instructions" বক্সে পেস্ট করুন।
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => copyToClipboard(systemPromptContent, 'prompt')}
                    className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
                  >
                    {copiedSection === 'prompt' ? <Check className="w-4 h-4 text-amber-300" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedSection === 'prompt' ? 'কপি হয়েছে!' : 'প্রম্পট কপি করুন'}</span>
                  </button>
                  <button
                    onClick={() => downloadFile(systemPromptContent, 'GEMINI_GEM_SYSTEM_PROMPT.md', 'text/markdown')}
                    className="p-2 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl text-slate-700 transition cursor-pointer"
                    title="ডাউনলোড প্রম্পট (.md)"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="relative">
                <pre className="p-4 bg-slate-900 text-emerald-200 rounded-2xl text-xs font-mono leading-relaxed overflow-x-auto max-h-96 border border-slate-800 select-all">
                  {systemPromptContent}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 2: KNOWLEDGE BASE */}
          {activeTab === 'knowledge' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-amber-50 p-4 rounded-2xl border border-amber-200">
                <div>
                  <h3 className="font-extrabold text-sm text-amber-950 flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-amber-700" />
                    <span>ইউনিয়ন পরিষদ নলেজ ফাইল (Knowledge Base)</span>
                  </h3>
                  <p className="text-xs text-slate-600">
                    এই ফাইলটিতে ০২নং বহেড়াতৈল ইউনিয়নের ৯টি ওয়ার্ড, ২৬টি গ্রাম ও ৪০+ সনদের বিস্তারিত নিয়মাবলি সংকলিত আছে। Gem-এর "Knowledge" সেকশনে ফাইলটি আপলোড করুন।
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => copyToClipboard(knowledgeBaseSnippet, 'knowledge')}
                    className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-black rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
                  >
                    {copiedSection === 'knowledge' ? <Check className="w-4 h-4 text-slate-950" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedSection === 'knowledge' ? 'কপি হয়েছে!' : 'নলেজ টেক্সট কপি করুন'}</span>
                  </button>
                  <button
                    onClick={() => downloadFile(knowledgeBaseSnippet, 'UPSM_GEM_KNOWLEDGE_BASE.md', 'text/markdown')}
                    className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 text-xs font-bold rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-slate-700" />
                    <span>নলেজ ফাইল (.md) ডাউনলোড</span>
                  </button>
                </div>
              </div>

              <div className="relative">
                <pre className="p-4 bg-slate-900 text-amber-200 rounded-2xl text-xs font-mono leading-relaxed overflow-x-auto max-h-96 border border-slate-800 select-all">
                  {knowledgeBaseSnippet}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 3: OPENAPI ACTIONS */}
          {activeTab === 'actions' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-blue-50 p-4 rounded-2xl border border-blue-200">
                <div>
                  <h3 className="font-extrabold text-sm text-blue-950 flex items-center gap-2">
                    <Code2 className="w-4 h-4 text-blue-700" />
                    <span>OpenAPI 3.0 Action Specification (অ্যাকশন ফাইল)</span>
                  </h3>
                  <p className="text-xs text-slate-600">
                    Gemini Gem বা Custom Agent-এ অ্যাকশন সংযুক্ত করতে এই স্পেসিফিকেশন ফাইলটি ব্যবহার করুন।
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => copyToClipboard(openApiActionsSnippet, 'actions')}
                    className="px-3 py-1.5 bg-blue-700 hover:bg-blue-600 text-white text-xs font-bold rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
                  >
                    {copiedSection === 'actions' ? <Check className="w-4 h-4 text-amber-300" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedSection === 'actions' ? 'কপি হয়েছে!' : 'JSON কপি করুন'}</span>
                  </button>
                  <button
                    onClick={() => downloadFile(openApiActionsSnippet, 'UPSM_GEM_ACTIONS_OPENAPI.json', 'application/json')}
                    className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 text-xs font-bold rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-slate-700" />
                    <span>JSON অ্যাকশন ডাউনলোড</span>
                  </button>
                </div>
              </div>

              <div className="relative">
                <pre className="p-4 bg-slate-900 text-cyan-300 rounded-2xl text-xs font-mono leading-relaxed overflow-x-auto max-h-96 border border-slate-800 select-all">
                  {openApiActionsSnippet}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 4: STEP-BY-STEP SETUP GUIDE */}
          {activeTab === 'guide' && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                  <div className="w-8 h-8 rounded-xl bg-emerald-800 text-amber-300 font-extrabold flex items-center justify-center text-sm shadow">
                    ১
                  </div>
                  <h4 className="font-extrabold text-sm text-slate-900">Gemini Gem Manager-এ যান</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Google Gemini (gemini.google.com)-এ ঢুকে বাম পাশের <strong>"Gem Manager"</strong> বা <strong>"New Gem"</strong> বাটনে ক্লিক করুন।
                  </p>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                  <div className="w-8 h-8 rounded-xl bg-emerald-800 text-amber-300 font-extrabold flex items-center justify-center text-sm shadow">
                    ২
                  </div>
                  <h4 className="font-extrabold text-sm text-slate-900">নাম, প্রম্পট ও নলেজ দিন</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    নাম দিন <em>"বহেড়াতৈল ইউপি এআই সহকারী"</em>। "Instructions" ঘরে ১নং ট্যাবের প্রম্পট পেস্ট করুন এবং "Knowledge"-এ ২নং ট্যাবের নলেজ ফাইল আপলোড করুন।
                  </p>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                  <div className="w-8 h-8 rounded-xl bg-emerald-800 text-amber-300 font-extrabold flex items-center justify-center text-sm shadow">
                    ৩
                  </div>
                  <h4 className="font-extrabold text-sm text-slate-900">অ্যাকশন ও সংরক্ষণ</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    ৩নং ট্যাবের অ্যাকশন স্কিমা যোগ করে <strong>"Save / Create"</strong> দিন। এরপর যেকোনো নাগরিকের সনদ ড্রাফটিং ও ট্র্যাকিং সরাসরি Gemini থেকে চালাতে পারবেন!
                  </p>
                </div>
              </div>

              <div className="bg-gradient-to-r from-slate-900 to-emerald-950 text-white p-5 rounded-2xl border border-emerald-800 space-y-3">
                <h4 className="font-extrabold text-sm text-amber-300 flex items-center gap-2">
                  <ExternalLink className="w-4 h-4" />
                  <span>Google Workspace ও Apps Script অটোমেশনের সুবিধা</span>
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Gemini Gem তৈরি করার পর আপনি একই প্রম্পট ও নলেজ ব্যবহার করে Google Sheets ফর্ম রেসপন্স থেকে স্বয়ংক্রিয়ভাবে গুগল ডক প্রত্যয়নপত্র জেনারেট করতে পারবেন, যা স্বয়ংক্রিয়ভাবে আপনার Google Drive-এর নির্দিষ্ট ফোল্ডারে সংরক্ষিত হবে।
                </p>
              </div>
            </div>
          )}

          {/* TAB 5: LIVE API TESTER */}
          {activeTab === 'test' && (
            <div className="space-y-4">
              <div className="bg-teal-50 p-4 rounded-2xl border border-teal-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-sm text-teal-950 flex items-center gap-2">
                    <Workflow className="w-4 h-4 text-teal-700" />
                    <span>Gemini Agent Live API Integration Tester</span>
                  </h3>
                  <span className="text-[11px] text-teal-800 font-bold bg-teal-100 px-2 py-0.5 rounded-full">
                    সরাসরি লাইভ টেস্ট
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  Gemini Gem বা বহিরাগত Google Automation থেকে কল করার আগে এন্ডপয়েন্টগুলো সঠিকভাবে কাজ করছে কিনা এখানে পরীক্ষা করুন।
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">অ্যাকশন নির্বাচন করুন</label>
                    <select
                      value={testAction}
                      onChange={(e) => setTestAction(e.target.value as any)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-teal-600"
                    >
                      <option value="text">দাপ্তরিক বাংলা বিবরণী তৈরি (POST /api/certificates/generate-bengali-text)</option>
                      <option value="verify">সনদ ভেরিফিকেশন (GET /api/certificates/verify/:memo)</option>
                    </select>
                  </div>

                  {testAction === 'text' ? (
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">আবেদনকারীর নাম</label>
                      <input
                        type="text"
                        value={testName}
                        onChange={(e) => setTestName(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-teal-600"
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">মেমো / ট্র্যাকিং নম্বর</label>
                      <input
                        type="text"
                        value={testMemo}
                        onChange={(e) => setTestMemo(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-teal-600"
                      />
                    </div>
                  )}
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={handleRunApiTest}
                    disabled={testLoading}
                    className="px-4 py-2 bg-teal-800 hover:bg-teal-700 text-white text-xs font-bold rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    {testLoading ? (
                      <span>টেস্ট চলছে...</span>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>এপিআই টেস্ট চালান</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {testResult && (
                <div className="space-y-2 animate-in fade-in duration-200">
                  <div className="text-xs font-bold text-slate-700">এপিআই রেসপন্স (API Response Payload):</div>
                  <pre className="p-4 bg-slate-900 text-emerald-300 rounded-2xl text-xs font-mono overflow-x-auto max-h-60 border border-slate-800">
                    {JSON.stringify(testResult, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-slate-500 text-center sm:text-left">
            ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল অটোমেশন সিস্টেম • Google Gemini & Workspace Workflow Ready
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadAllBundle}
              className="px-4 py-2 bg-emerald-900 hover:bg-emerald-800 text-amber-300 text-xs font-bold rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>সম্পূর্ণ বান্ডেল এক্সপোর্ট (.json)</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-xl transition cursor-pointer"
            >
              বন্ধ করুন
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
