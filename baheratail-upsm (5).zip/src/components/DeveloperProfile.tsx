import React, { useState, useEffect } from 'react';
import { 
  Code2, 
  User, 
  Github, 
  FolderGit2, 
  Cloud, 
  Mail, 
  Phone, 
  ExternalLink, 
  Terminal, 
  Cpu, 
  Upload, 
  CheckCircle2, 
  Sparkles, 
  ShieldAlert, 
  Layers, 
  Wrench, 
  RefreshCw,
  Copy,
  Check,
  Lock,
  Edit3,
  Globe,
  Share2,
  ShieldCheck,
  MessageSquare,
  Facebook,
  Linkedin,
  Instagram,
  Twitter,
  ArrowRight,
  Send,
  MessageCircle,
  Briefcase,
  GraduationCap,
  Award,
  BookOpen,
  MapPin,
  Calendar,
  Heart,
  FileText,
  Printer,
  Download,
  Users,
  Building2,
  CheckSquare,
  Flame,
  Search,
  KeyRound
} from 'lucide-react';
import { UnionParishadConfig } from '../types';
import { AdminAuthModal } from './AdminAuthModal';

interface DeveloperProfileProps {
  config: UnionParishadConfig;
  onUpdateConfig?: (newConfig: UnionParishadConfig) => void;
}

export const DeveloperProfile: React.FC<DeveloperProfileProps> = ({ config, onUpdateConfig }) => {
  // Tab View in Public Profile: 'cv' (Curriculum Vitae), 'tech' (System Specs & AI), 'channels' (Social & Connect)
  const [activeTab, setActiveTab] = useState<'cv' | 'tech' | 'channels'>('cv');

  // Developer Info State (initialized from CV details)
  const [developerName, setDeveloperName] = useState(config.developerName || 'MD. JUBAER HOSSEN');
  const [developerTitle, setDeveloperTitle] = useState(
    config.developerTitle || 'উদ্যোক্তা ও ডিজিটাল সিস্টেম আর্কিটেক্ট (Entrepreneur & Digital System Lead)'
  );
  const [developerBio, setDeveloperBio] = useState(
    config.developerBio || 
    'Recent MBA Graduate (Management, National University) & Entrepreneur at 02 No. Baheratail Union Parishad. Passionate about philanthropy, community automation, Google Workspace, Gemini AI and digital public service innovation.'
  );
  const [developerEmail, setDeveloperEmail] = useState(config.developerEmail || 'Inbox6090@gmail.com');
  const [developerPhone, setDeveloperPhone] = useState(config.developerPhone || '+8801834-333300');
  const [developerAddress, setDeveloperAddress] = useState(config.developerAddress || 'Gohail Bari, Nagbari-1972, Sakhipur, Tangail');
  const [developerNid, setDeveloperNid] = useState(config.developerNid || '19949318513000168');
  const [developerDob, setDeveloperDob] = useState(config.developerDob || '21 Oct 1994');
  const [developerBloodGroup, setDeveloperBloodGroup] = useState(config.developerBloodGroup || 'O (Positive)');
  const [developerFatherName, setDeveloperFatherName] = useState(config.developerFatherName || 'Sanowar Hossen');
  const [developerMotherName, setDeveloperMotherName] = useState(config.developerMotherName || 'Sahida');

  // Social & Messaging Handles
  const [developerWhatsapp, setDeveloperWhatsapp] = useState(config.developerWhatsappNumber || '01834-333300');
  const [developerWhatsappUsername, setDeveloperWhatsappUsername] = useState(config.developerWhatsappUsername || 'Xobaer6090');
  const [developerWhatsappUrl, setDeveloperWhatsappUrl] = useState(config.developerWhatsappUrl || 'https://wa.me/message/7PMRKZ6ZMPT2G1');
  const [developerFacebook, setDeveloperFacebook] = useState(config.developerFacebookUrl || 'https://facebook.com/xobaer6090');
  const [developerLinkedin, setDeveloperLinkedin] = useState(config.developerLinkedinUrl || 'https://linkedin.com/in/xobaer6090');
  const [developerTiktok, setDeveloperTiktok] = useState(config.developerTiktokUrl || 'https://www.tiktok.com/@xobaer6090?_r=1&_t=ZS-98qqxpnGbVA');
  const [developerInstagram, setDeveloperInstagram] = useState(config.developerInstagramUrl || 'https://www.instagram.com/xobaer6090?igsh=MWlua2h6YjQ2c2JmOA==');
  const [developerGithubProfile, setDeveloperGithubProfile] = useState(config.developerGithubProfileUrl || 'https://github.com/inbox6090');
  const [developerTwitter, setDeveloperTwitter] = useState(config.developerTwitterUrl || 'https://x.com/Xobaer6090');
  const [developerWordpress, setDeveloperWordpress] = useState(config.developerWordpressUrl || 'https://xobaer.wordpress.com');
  const [developerTelegramUrl, setDeveloperTelegramUrl] = useState(config.developerTelegramUrl || 'https://t.me/Xobaer6090');
  const [developerTelegramUsername, setDeveloperTelegramUsername] = useState(config.developerTelegramUsername || 'Xobaer6090');
  const [developerMessengerUrl, setDeveloperMessengerUrl] = useState(config.developerMessengerUrl || 'https://m.me/xobaer6090');
  const [developerMessengerUsername, setDeveloperMessengerUsername] = useState(config.developerMessengerUsername || 'xobaer6090');
  const [photoUrl, setPhotoUrl] = useState(config.developerPhotoUrl || '');

  // Tech / Backup State
  const [githubUrl, setGithubUrl] = useState(config.githubRepoUrl || 'https://github.com/inbox6090/UPSM-Baheratail');
  const [githubBranch, setGithubBranch] = useState(config.githubBranch || 'main');
  const [driveUrl, setDriveUrl] = useState(config.googleDriveBackupUrl || 'https://drive.google.com/drive/folders/16vXelYwApSFuFFru0Qkj1gaHCUwKZ-vz');
  const [mcpEndpoint, setMcpEndpoint] = useState(config.mcpEndpointUrl || 'https://api.baheratailup.gov.bd/v1/mcp');
  const [webhookUrl, setWebhookUrl] = useState(config.webhookUrl || 'https://api.baheratailup.gov.bd/v1/webhook');
  const [webhookSecret, setWebhookSecret] = useState(config.webhookSecret || 'whsec_up_baheratail_2026_secret_key');

  // Interactive Controls State
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [activeAdmin, setActiveAdmin] = useState<any>(null);

  const [copied, setCopied] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isSyncingBackup, setIsSyncingBackup] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [testLog, setTestLog] = useState<string | null>(null);

  // Sync props config when config updates
  useEffect(() => {
    if (config) {
      if (config.developerName) setDeveloperName(config.developerName);
      if (config.developerTitle) setDeveloperTitle(config.developerTitle);
      if (config.developerBio) setDeveloperBio(config.developerBio);
      if (config.developerEmail) setDeveloperEmail(config.developerEmail);
      if (config.developerPhone) setDeveloperPhone(config.developerPhone);
      if (config.developerAddress) setDeveloperAddress(config.developerAddress);
      if (config.developerNid) setDeveloperNid(config.developerNid);
      if (config.developerDob) setDeveloperDob(config.developerDob);
      if (config.developerBloodGroup) setDeveloperBloodGroup(config.developerBloodGroup);
      if (config.developerFatherName) setDeveloperFatherName(config.developerFatherName);
      if (config.developerMotherName) setDeveloperMotherName(config.developerMotherName);

      if (config.developerWhatsappNumber) setDeveloperWhatsapp(config.developerWhatsappNumber);
      if (config.developerWhatsappUsername) setDeveloperWhatsappUsername(config.developerWhatsappUsername);
      if (config.developerWhatsappUrl) setDeveloperWhatsappUrl(config.developerWhatsappUrl);
      if (config.developerFacebookUrl) setDeveloperFacebook(config.developerFacebookUrl);
      if (config.developerLinkedinUrl) setDeveloperLinkedin(config.developerLinkedinUrl);
      if (config.developerTiktokUrl) setDeveloperTiktok(config.developerTiktokUrl);
      if (config.developerInstagramUrl) setDeveloperInstagram(config.developerInstagramUrl);
      if (config.developerGithubProfileUrl) setDeveloperGithubProfile(config.developerGithubProfileUrl);
      if (config.developerTwitterUrl) setDeveloperTwitter(config.developerTwitterUrl);
      if (config.developerWordpressUrl) setDeveloperWordpress(config.developerWordpressUrl);
      if (config.developerTelegramUrl) setDeveloperTelegramUrl(config.developerTelegramUrl);
      if (config.developerTelegramUsername) setDeveloperTelegramUsername(config.developerTelegramUsername);
      if (config.developerMessengerUrl) setDeveloperMessengerUrl(config.developerMessengerUrl);
      if (config.developerMessengerUsername) setDeveloperMessengerUsername(config.developerMessengerUsername);
      if (config.developerPhotoUrl) setPhotoUrl(config.developerPhotoUrl);
      if (config.githubRepoUrl) setGithubUrl(config.githubRepoUrl);
      if (config.googleDriveBackupUrl) setDriveUrl(config.googleDriveBackupUrl);
    }
  }, [config]);

  // Check logged in Developer session
  useEffect(() => {
    const checkSession = () => {
      const saved = localStorage.getItem('bup_active_admin_session');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          setActiveAdmin(parsed);
        } catch (e) {
          setActiveAdmin(null);
        }
      } else {
        setActiveAdmin(null);
      }
    };

    checkSession();
    const handleAuthChange = (e: CustomEvent) => {
      setActiveAdmin(e.detail || null);
    };

    window.addEventListener('adminAuthChanged' as any, handleAuthChange);
    return () => {
      window.removeEventListener('adminAuthChanged' as any, handleAuthChange);
    };
  }, []);

  const isDeveloperOrAdmin = React.useMemo(() => {
    if (!activeAdmin) return false;
    return ['developer', 'super_admin', 'chairman', 'secretary'].includes(activeAdmin.role);
  }, [activeAdmin]);

  // Photo Upload Handler
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setPhotoUrl(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveDeveloperConfig = async () => {
    setIsSaving(true);
    setSavedSuccess(false);

    const updated: UnionParishadConfig = {
      ...config,
      developerName,
      developerTitle,
      developerBio,
      developerEmail,
      developerPhone,
      developerAddress,
      developerNid,
      developerDob,
      developerBloodGroup,
      developerFatherName,
      developerMotherName,
      developerWhatsappNumber: developerWhatsapp,
      developerWhatsappUsername,
      developerWhatsappUrl,
      developerFacebookUrl: developerFacebook,
      developerLinkedinUrl: developerLinkedin,
      developerTiktokUrl: developerTiktok,
      developerInstagramUrl: developerInstagram,
      developerGithubProfileUrl: developerGithubProfile,
      developerTwitterUrl: developerTwitter,
      developerWordpressUrl: developerWordpress,
      developerTelegramUrl,
      developerTelegramUsername,
      developerMessengerUrl,
      developerMessengerUsername,
      developerPhotoUrl: photoUrl,
      githubRepoUrl: githubUrl,
      githubBranch,
      googleDriveBackupUrl: driveUrl,
      mcpEndpointUrl: mcpEndpoint,
      webhookUrl,
      webhookSecret,
      lastBackupDate: new Date().toLocaleString('bn-BD')
    };

    try {
      const res = await fetch('/api/admin/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated)
      });
      const data = await res.json();
      if (data.success && onUpdateConfig) {
        onUpdateConfig(data.config);
        setSavedSuccess(true);
        setTimeout(() => setSavedSuccess(false), 3000);
      }
    } catch (e) {
      console.error('Error saving developer config:', e);
    } finally {
      setIsSaving(false);
    }
  };

  const handleGithubBackupSync = () => {
    setIsSyncingBackup(true);
    setTestLog(`[GITHUB BACKUP SYNC INITIATED]
Target Repo: ${githubUrl} (Branch: ${githubBranch})
Compressing codebase bundle & schemas...
Pushing commit to ${githubBranch}...`);

    setTimeout(() => {
      setIsSyncingBackup(false);
      setTestLog(`[SUCCESS] GitHub & Google Drive Sync Complete!
- Repository: ${githubUrl}
- Branch: ${githubBranch}
- Commit: "Auto-backup UP Automation System v2.5"
- Webhook Payload Sent to: ${webhookUrl}
- Status: 200 OK (${new Date().toLocaleTimeString('bn-BD')})`);
    }, 1200);
  };

  const handleRunMcpTest = () => {
    setTestLog('MCP Agent System Diagnostics: Connecting to ' + mcpEndpoint + '...');
    setTimeout(() => {
      setTestLog(`[SUCCESS] MCP Tool Server & Webhook Ready:
- Model Context Protocol v1.0
- Gemini 1.5 Flash Vision OCR Plugin: Active
- Webhook URL: ${webhookUrl}
- Google Workspace Apps Script Webhook: Connected
- Cloudflare R2 Storage Node: Synced
- Status: 200 OK (Ping: 42ms)`);
    }, 800);
  };

  const handleToggleEditMode = () => {
    if (isEditMode) {
      setIsEditMode(false);
      return;
    }

    if (isDeveloperOrAdmin) {
      setIsEditMode(true);
    } else {
      setIsAuthModalOpen(true);
    }
  };

  const copyCvText = () => {
    const cvText = `CURRICULUM VITAE
MD. JUBAER HOSSEN
Contact No: ${developerPhone}
E-mail: ${developerEmail}
Address: ${developerAddress}

CAREER OBJECTIVE:
To obtain a responsible career where I could optimally utilize my education. I am looking for an opportunity where I can apply my passion for philanthropy and use my professional experience to drive positive change in my community.

CAREER SUMMARY:
Recent graduate with a Masters of Business Administration (MBA) seeking an opportunity within an established management organization to utilize my organizational and quantitative abilities.
• By the grace of Allah, the Almighty I can learn anything very quickly.
• I enjoy challenges.
• I am never slack in doing my duties.
• I am punctual, truthful, motivator and friendly.

EXPERIENCE:
1. 2 No Baheratail Union Porishod
Position: Entrepreneur
Location: Sakhipur, Tangail
Duration: 1 year+
Achievement:
• Increased public services & automated certificate workflows.
• Satisfied citizen and customer wants.
• Work properly under pressure.

SPECIAL QUALIFICATION:
• Professional MS Excel, Word and PowerPoint.
• Database Management & Programming.
• Accounts payable, Invoicing, Cash Flow Management, Payroll, Report & Analytics.
• Quick learner & full-stack Google Workspace / AI systems builder.

EDUCATIONAL QUALIFICATION:
1. MBA | National University | Management | CGPA: 2.94 (Out of 4) | Passing Year: 2018
2. BBA | National University | Management | CGPA: 2.86 (Out of 4) | Passing Year: 2016
3. HSC | Dhaka Board | Business Studies | GPA: 3.60 (Out of 5) | Passing Year: 2012
4. SSC | Dhaka Board | Business Studies | GPA: 3.56 (Out of 5) | Passing Year: 2010

COMPUTER COURSE:
Course Name: Certificate in Computer Database Programing Course
Result: Grade "A+" | Year: 2018 | Duration: 6 months
Institution: Anika Computer & Technical Institute, Sakhipur, Tangail.

CAREER & APPLICATION INFORMATION:
Looking For: Professional IT / Enterprise / Government Automation Management
Available For: Full Time
Preferred Job Category: IT/Telecommunication, HR/Org. Development
Preferred District: Anywhere in Bangladesh

LANGUAGE SKILL:
• Bangla: Writing: High | Speaking: High
• English: Writing: Medium | Speaking: Medium

PERSONAL INFORMATION:
Father's Name: ${developerFatherName}
Mother's Name: ${developerMotherName}
Date of Birth: ${developerDob}
Gender: Male | Marital Status: Unmarried | Nationality: Bangladeshi | Religion: Islam
National ID No: ${developerNid}
Height: 5 feet 9 inch | Weight: 68 Kg | Blood Group: ${developerBloodGroup}
Permanent Address: ${developerAddress}

REFERENCES:
1. Amir Uddin | A.IGP, Bangladesh Police | Cell: 01719-187049 | Relation: Uncle
2. Akram Hossen Zishan | Deputy Manager, Petrobangla | Cell: 01747-161262 | Relation: Cousin`;

    navigator.clipboard.writeText(cvText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handlePrintCv = () => {
    window.print();
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-12">
      {/* Auth Modal for Developer Login */}
      <AdminAuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)}
        onAdminAuthenticated={(user) => {
          if (user && ['developer', 'super_admin', 'chairman', 'secretary'].includes(user.role)) {
            setIsEditMode(true);
          }
          setIsAuthModalOpen(false);
        }}
      />

      {/* Top Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-900 text-white p-6 rounded-2xl shadow-xl border border-emerald-800/80 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-amber-400/10 via-transparent to-transparent pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="px-3 py-1 bg-amber-400 text-emerald-950 text-[11px] font-black uppercase tracking-wider rounded-full inline-flex items-center gap-1 shadow-sm">
                <Sparkles className="w-3.5 h-3.5" />
                <span>System Developer & Entrepreneur Profile</span>
              </span>
              {isEditMode ? (
                <span className="px-2.5 py-0.5 bg-emerald-500 text-slate-950 text-[10px] font-bold rounded-full border border-emerald-300 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>কাস্টমাইজেশন মোড চালু (Developer Logged In)</span>
                </span>
              ) : (
                <span className="px-2.5 py-0.5 bg-slate-800 text-emerald-300 text-[10px] font-bold rounded-full border border-slate-700 flex items-center gap-1">
                  <Globe className="w-3 h-3" />
                  <span>অফিশিয়াল প্রোফাইল ও জীবনবৃত্তান্ত (Curriculum Vitae)</span>
                </span>
              )}
            </div>

            <h2 className="text-xl md:text-2xl font-black text-white flex items-center gap-2.5">
              <Code2 className="w-7 h-7 text-amber-300 shrink-0" />
              <span>MD. JUBAER HOSSEN (জোবায়ের) — সিস্টেম ডেভেলপার ও উদ্যোক্তা</span>
            </h2>
            <p className="text-xs text-emerald-200/90 mt-1 max-w-2xl leading-relaxed">
              ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল সেন্টার উদ্যোক্তা, কারিগরি রূপকার, ক্লাউড আর্কিটেক্ট ও কাস্টম জেমিনাই এআই প্রত্যয়নপত্র অটোমেশন ইঞ্জিনের প্রস্তুতকারক।
            </p>
          </div>

          <div className="shrink-0 flex items-center gap-2">
            {!isEditMode && (
              <>
                <button
                  type="button"
                  onClick={copyCvText}
                  className="px-3.5 py-2 rounded-xl font-bold text-xs bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 transition flex items-center gap-1.5 cursor-pointer shadow"
                  title="সম্পূর্ণ জীবনবৃত্তান্ত টেক্সট ফরম্যাটে কপি করুন"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? 'কপি হয়েছে' : 'CV কপি'}</span>
                </button>
                <button
                  type="button"
                  onClick={handlePrintCv}
                  className="px-3.5 py-2 rounded-xl font-bold text-xs bg-emerald-800 hover:bg-emerald-700 text-white border border-emerald-600 transition flex items-center gap-1.5 cursor-pointer shadow"
                  title="প্রিন্ট বা PDF হিসেবে সংরক্ষণ করুন"
                >
                  <Printer className="w-4 h-4 text-amber-300" />
                  <span>প্রিন্ট / PDF</span>
                </button>
              </>
            )}

            <button
              type="button"
              onClick={handleToggleEditMode}
              className={`px-4 py-2.5 rounded-xl font-black text-xs transition duration-200 flex items-center gap-2 shadow-lg cursor-pointer ${
                isEditMode
                  ? 'bg-amber-400 hover:bg-amber-300 text-emerald-950 border border-amber-300'
                  : 'bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 border border-amber-300'
              }`}
            >
              {isEditMode ? (
                <>
                  <Globe className="w-4 h-4 text-emerald-950" />
                  <span>পাবলিক প্রোফাইল ভিউতে ফিরে যান</span>
                </>
              ) : (
                <>
                  <Edit3 className="w-4 h-4 text-emerald-950" />
                  <span>{isDeveloperOrAdmin ? '✏️ প্রোফাইল কাস্টমাইজ করুন' : '🔒 এডিট মোড (Login)'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* View Switcher Tabs (Public Mode) */}
        {!isEditMode && (
          <div className="flex items-center gap-2 mt-6 pt-4 border-t border-emerald-800/60 overflow-x-auto pb-1">
            <button
              onClick={() => setActiveTab('cv')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer shrink-0 ${
                activeTab === 'cv'
                  ? 'bg-amber-400 text-emerald-950 shadow-md font-black'
                  : 'bg-emerald-900/60 text-emerald-200 hover:bg-emerald-800'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>১. পূর্ণাঙ্গ জীবনবৃত্তান্ত (Curriculum Vitae)</span>
            </button>

            <button
              onClick={() => setActiveTab('tech')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer shrink-0 ${
                activeTab === 'tech'
                  ? 'bg-amber-400 text-emerald-950 shadow-md font-black'
                  : 'bg-emerald-900/60 text-emerald-200 hover:bg-emerald-800'
              }`}
            >
              <Cpu className="w-4 h-4" />
              <span>২. সিস্টেম টেকনোলজি ও এআই স্পেক্স</span>
            </button>

            <button
              onClick={() => setActiveTab('channels')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer shrink-0 ${
                activeTab === 'channels'
                  ? 'bg-amber-400 text-emerald-950 shadow-md font-black'
                  : 'bg-emerald-900/60 text-emerald-200 hover:bg-emerald-800'
              }`}
            >
              <Share2 className="w-4 h-4" />
              <span>৩. সামাজিক যোগাযোগ ও সাপোর্ট চ্যানেল</span>
            </button>
          </div>
        )}
      </div>

      {/* ============================================================ */}
      {/* PUBLIC DEVELOPER SHOWCASE & CV CARDS                         */}
      {/* ============================================================ */}
      {!isEditMode && (
        <div className="space-y-6">
          {/* Main Persona Hero Card */}
          <div className="bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden relative">
            <div className="h-32 bg-gradient-to-r from-emerald-900 via-emerald-800 to-slate-900 p-6 flex items-end justify-between relative">
              <span className="text-[11px] font-bold text-amber-300 tracking-wider uppercase bg-black/40 backdrop-blur-md px-3 py-1 rounded-full border border-amber-400/20">
                02 No. Baheratail Union Parishad • Entrepreneur & Tech Lead
              </span>
              <span className="text-xs text-white/80 hidden sm:inline">
                National ID: <strong className="text-amber-300 font-mono">{developerNid}</strong>
              </span>
            </div>

            <div className="px-6 pb-6 pt-0 relative">
              <div className="flex flex-col md:flex-row items-center md:items-start gap-6 -mt-16 mb-6">
                {/* Photo Container */}
                <div className="w-36 h-36 md:w-44 md:h-44 rounded-2xl overflow-hidden border-4 border-white shadow-2xl bg-emerald-950 shrink-0 relative group">
                  {photoUrl ? (
                    <img 
                      src={photoUrl} 
                      alt={developerName} 
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-500" 
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-emerald-900 to-slate-900 flex flex-col items-center justify-center p-4 text-center text-white">
                      <User className="w-16 h-16 text-amber-300 mb-1" />
                      <span className="text-xs font-black text-amber-300 leading-tight">{developerName}</span>
                      <span className="text-[9px] text-emerald-200 mt-1">MBA (Management)</span>
                    </div>
                  )}
                  <div className="absolute inset-0 ring-1 ring-black/10 rounded-2xl pointer-events-none" />
                </div>

                {/* Developer Details Header */}
                <div className="text-center md:text-left flex-1 space-y-2 pt-2 md:pt-16">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                    <div>
                      <h3 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight flex items-center justify-center md:justify-start gap-2">
                        <span>{developerName}</span>
                        <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full border border-emerald-300">
                          (মো: জোবায়ের হোসেন)
                        </span>
                      </h3>
                      <p className="text-sm font-bold text-emerald-800 flex items-center justify-center md:justify-start gap-1.5 mt-0.5">
                        <Briefcase className="w-4 h-4 text-amber-600" />
                        <span>{developerTitle}</span>
                      </p>
                    </div>

                    <div className="flex items-center justify-center md:justify-end gap-2">
                      <span className="px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold text-xs rounded-full flex items-center gap-1.5 shadow-2xs">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>অনুমোদিত ডিজিটাল উদ্যোক্তা</span>
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed font-medium bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                    {developerBio}
                  </p>

                  <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-xs text-slate-600 pt-1">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-emerald-700" />
                      <span>{developerAddress}</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                      <span>DOB: <strong>{developerDob}</strong></span>
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className="w-3.5 h-3.5 text-rose-600" />
                      <span>Blood: <strong className="text-rose-700">{developerBloodGroup}</strong></span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Direct Helpline & Quick Action Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 pt-2">
                {/* Helpline Phone */}
                <a
                  href={`tel:${developerPhone.replace(/[^0-9+]/g, '')}`}
                  className="p-3 bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200 rounded-2xl transition flex items-center gap-2.5 group shadow-2xs"
                >
                  <div className="w-9 h-9 rounded-xl bg-emerald-800 text-amber-300 flex items-center justify-center shrink-0 shadow-sm group-hover:scale-110 transition">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-[9px] font-bold text-emerald-800 block uppercase tracking-tight">জরুরী কল</span>
                    <span className="text-xs font-black font-mono text-emerald-950 block truncate">{developerPhone}</span>
                  </div>
                </a>

                {/* WhatsApp Chat */}
                <a
                  href={developerWhatsappUrl || `https://wa.me/${developerWhatsapp.replace(/[^0-9]/g, '')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200 rounded-2xl transition flex items-center gap-2.5 group shadow-2xs"
                >
                  <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm group-hover:scale-110 transition">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-[9px] font-bold text-emerald-800 block uppercase tracking-tight">WhatsApp</span>
                    <span className="text-xs font-black font-mono text-emerald-950 block truncate">@{developerWhatsappUsername}</span>
                  </div>
                </a>

                {/* Telegram Chat */}
                {developerTelegramUrl && (
                  <a
                    href={developerTelegramUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-3 bg-sky-50 hover:bg-sky-100/80 border border-sky-200 rounded-2xl transition flex items-center gap-2.5 group shadow-2xs"
                  >
                    <div className="w-9 h-9 rounded-xl bg-sky-500 text-white flex items-center justify-center shrink-0 shadow-sm group-hover:scale-110 transition">
                      <Send className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className="text-[9px] font-bold text-sky-800 block uppercase tracking-tight">Telegram</span>
                      <span className="text-xs font-black font-mono text-sky-950 block truncate">@{developerTelegramUsername}</span>
                    </div>
                  </a>
                )}

                {/* Messenger Chat */}
                {developerMessengerUrl && (
                  <a
                    href={developerMessengerUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-3 bg-indigo-50 hover:bg-indigo-100/80 border border-indigo-200 rounded-2xl transition flex items-center gap-2.5 group shadow-2xs"
                  >
                    <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-sm group-hover:scale-110 transition">
                      <MessageCircle className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className="text-[9px] font-bold text-indigo-800 block uppercase tracking-tight">FB Messenger</span>
                      <span className="text-xs font-black font-mono text-indigo-950 block truncate">@{developerMessengerUsername}</span>
                    </div>
                  </a>
                )}

                {/* Email Support */}
                <a
                  href={`mailto:${developerEmail}`}
                  className="p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-2xl transition flex items-center gap-2.5 group shadow-2xs"
                >
                  <div className="w-9 h-9 rounded-xl bg-slate-800 text-amber-300 flex items-center justify-center shrink-0 shadow-sm group-hover:scale-110 transition">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-[9px] font-bold text-slate-500 block uppercase tracking-tight">ইমেইল</span>
                    <span className="text-xs font-bold font-mono text-slate-800 block truncate">{developerEmail}</span>
                  </div>
                </a>

                {/* WordPress Website */}
                {developerWordpress && (
                  <a
                    href={developerWordpress}
                    target="_blank"
                    rel="noreferrer"
                    className="p-3 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-2xl transition flex items-center gap-2.5 group shadow-2xs"
                  >
                    <div className="w-9 h-9 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-sm group-hover:scale-110 transition">
                      <Globe className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className="text-[9px] font-bold text-amber-800 block uppercase tracking-tight">ওয়েবসাইট</span>
                      <span className="text-xs font-bold font-mono text-amber-950 block truncate">xobaer.wordpress.com</span>
                    </div>
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* ============================================================ */}
          {/* TAB 1: CURRICULUM VITAE VIEW (AS PER OFFICIAL UPLOADED DOC)   */}
          {/* ============================================================ */}
          {activeTab === 'cv' && (
            <div className="space-y-6">
              {/* Objective & Career Summary */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-3xl shadow-md border border-slate-200 space-y-3">
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                    <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-wide">CAREER OBJECTIVE</h4>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed text-justify">
                    To obtain a responsible career where I could optimally utilize my education. I am looking for an opportunity where I can apply my passion for philanthropy and use my professional experience to drive positive change in my community.
                  </p>
                </div>

                <div className="bg-white p-6 rounded-3xl shadow-md border border-slate-200 space-y-3">
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                    <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center">
                      <Award className="w-4 h-4" />
                    </div>
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-wide">CAREER SUMMARY</h4>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    Recent graduate with a Masters of Business Administration (MBA) seeking an opportunity within an established management organization to utilize my organizational and quantitative abilities.
                  </p>
                  <ul className="space-y-1.5 text-xs text-slate-700 pt-1">
                    <li className="flex items-center gap-2 text-emerald-800 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>By the grace of Allah, the Almighty I can learn anything very quickly.</span>
                    </li>
                    <li className="flex items-center gap-2 text-emerald-800 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>I enjoy challenges.</span>
                    </li>
                    <li className="flex items-center gap-2 text-emerald-800 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>I am never slack in doing my duties.</span>
                    </li>
                    <li className="flex items-center gap-2 text-emerald-800 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>I am punctual, truthful, motivator and friendly.</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Experience Card */}
              <div className="bg-white p-6 rounded-3xl shadow-md border border-slate-200 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-emerald-800 text-amber-300 flex items-center justify-center">
                      <Building2 className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-slate-900 uppercase tracking-wide">PROFESSIONAL EXPERIENCE</h4>
                      <span className="text-[11px] text-slate-500">Local Government Administrative & Digital Automation</span>
                    </div>
                  </div>
                  <span className="px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full border border-emerald-300">
                    Duration: 1 year+
                  </span>
                </div>

                <div className="bg-emerald-50/50 p-4 rounded-2xl border border-emerald-200 space-y-2">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <h5 className="font-extrabold text-sm text-slate-900">
                      1. 2 No. Baheratail Union Porishod (০২নং বহেড়াতৈল ইউনিয়ন পরিষদ)
                    </h5>
                    <span className="text-xs font-bold text-emerald-800">
                      Location: Sakhipur, Tangail
                    </span>
                  </div>
                  <p className="text-xs font-bold text-slate-700">
                    Position: <span className="text-emerald-900 font-black">Entrepreneur (ডিজিটাল সেন্টার উদ্যোক্তা ও ডেটা অপারেটর)</span>
                  </p>
                  <div className="pt-2 border-t border-emerald-200/80">
                    <p className="text-xs font-bold text-slate-800 mb-1.5">Key Achievements:</p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <div className="p-2.5 bg-white rounded-xl border border-emerald-200 text-xs text-slate-700 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>Increased the public Services & turnaround speed.</span>
                      </div>
                      <div className="p-2.5 bg-white rounded-xl border border-emerald-200 text-xs text-slate-700 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>Satisfied customer & citizen needs accurately.</span>
                      </div>
                      <div className="p-2.5 bg-white rounded-xl border border-emerald-200 text-xs text-slate-700 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>Work properly under pressure and critical deadlines.</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Educational Qualifications Table */}
              <div className="bg-white p-6 rounded-3xl shadow-md border border-slate-200 space-y-4">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                  <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-900 flex items-center justify-center">
                    <GraduationCap className="w-4 h-4" />
                  </div>
                  <h4 className="text-sm font-black text-slate-900 uppercase tracking-wide">EDUCATIONAL QUALIFICATION</h4>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-100 text-slate-800 font-black border border-slate-200">
                        <th className="py-2.5 px-3 border border-slate-200">Examination</th>
                        <th className="py-2.5 px-3 border border-slate-200">Board / University</th>
                        <th className="py-2.5 px-3 border border-slate-200">Subject / Group</th>
                        <th className="py-2.5 px-3 border border-slate-200">GPA / CGPA</th>
                        <th className="py-2.5 px-3 border border-slate-200">Passing Year</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 font-medium text-slate-800">
                      <tr className="hover:bg-emerald-50/40 transition">
                        <td className="py-2.5 px-3 border border-slate-200 font-black text-emerald-950">MBA</td>
                        <td className="py-2.5 px-3 border border-slate-200">National University</td>
                        <td className="py-2.5 px-3 border border-slate-200 font-bold">Management</td>
                        <td className="py-2.5 px-3 border border-slate-200 font-black text-emerald-800">2.94 <span className="font-normal text-slate-500">(Out of 4)</span></td>
                        <td className="py-2.5 px-3 border border-slate-200 font-bold">2018</td>
                      </tr>
                      <tr className="hover:bg-emerald-50/40 transition">
                        <td className="py-2.5 px-3 border border-slate-200 font-black text-emerald-950">BBA</td>
                        <td className="py-2.5 px-3 border border-slate-200">National University</td>
                        <td className="py-2.5 px-3 border border-slate-200 font-bold">Management</td>
                        <td className="py-2.5 px-3 border border-slate-200 font-black text-emerald-800">2.86 <span className="font-normal text-slate-500">(Out of 4)</span></td>
                        <td className="py-2.5 px-3 border border-slate-200 font-bold">2016</td>
                      </tr>
                      <tr className="hover:bg-emerald-50/40 transition">
                        <td className="py-2.5 px-3 border border-slate-200 font-black text-emerald-950">HSC</td>
                        <td className="py-2.5 px-3 border border-slate-200">Dhaka Board</td>
                        <td className="py-2.5 px-3 border border-slate-200">Business Studies</td>
                        <td className="py-2.5 px-3 border border-slate-200 font-black text-emerald-800">3.60 <span className="font-normal text-slate-500">(Out of 5)</span></td>
                        <td className="py-2.5 px-3 border border-slate-200 font-bold">2012</td>
                      </tr>
                      <tr className="hover:bg-emerald-50/40 transition">
                        <td className="py-2.5 px-3 border border-slate-200 font-black text-emerald-950">SSC</td>
                        <td className="py-2.5 px-3 border border-slate-200">Dhaka Board</td>
                        <td className="py-2.5 px-3 border border-slate-200">Business Studies</td>
                        <td className="py-2.5 px-3 border border-slate-200 font-black text-emerald-800">3.56 <span className="font-normal text-slate-500">(Out of 5)</span></td>
                        <td className="py-2.5 px-3 border border-slate-200 font-bold">2010</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Computer Course & Special Qualifications Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Computer Certification */}
                <div className="bg-white p-6 rounded-3xl shadow-md border border-slate-200 space-y-3">
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                    <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-900 flex items-center justify-center">
                      <Award className="w-4 h-4" />
                    </div>
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-wide">PROFESSIONAL COMPUTER COURSE</h4>
                  </div>

                  <div className="p-4 bg-purple-50/60 rounded-2xl border border-purple-200 space-y-2 text-xs">
                    <p className="font-black text-purple-950 text-sm">
                      Certificate in Computer Database Programing Course
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-slate-700 pt-1">
                      <div>
                        <span className="text-slate-500 block text-[10px]">Result:</span>
                        <span className="font-black text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">Grade "A+"</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Passing Year:</span>
                        <span className="font-bold text-slate-900">2018</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Course Duration:</span>
                        <span className="font-bold text-slate-900">6 months</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Institution:</span>
                        <span className="font-bold text-slate-900">Anika Computer & Technical Institute</span>
                      </div>
                    </div>
                    <p className="text-[11px] text-purple-900 pt-1 font-medium">
                      Location: Sakhipur, Tangail.
                    </p>
                  </div>
                </div>

                {/* Special Qualifications */}
                <div className="bg-white p-6 rounded-3xl shadow-md border border-slate-200 space-y-3">
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                    <div className="w-8 h-8 rounded-xl bg-teal-100 text-teal-900 flex items-center justify-center">
                      <Wrench className="w-4 h-4" />
                    </div>
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-wide">SPECIAL QUALIFICATION & IT SKILLS</h4>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="p-2 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                      <span>Professional MS Excel, Word and PowerPoint</span>
                    </div>
                    <div className="p-2 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                      <span>Database Management & Information Systems</span>
                    </div>
                    <div className="p-2 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                      <span>Accounts Payable, Invoicing, Cash Flow, Payroll, Report & Analytics</span>
                    </div>
                    <div className="p-2 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                      <span>Google Workspace Automation, Apps Script & Gemini AI Systems</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Personal Information & References Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Personal Information */}
                <div className="bg-white p-6 rounded-3xl shadow-md border border-slate-200 space-y-4">
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                    <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center">
                      <User className="w-4 h-4" />
                    </div>
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-wide">PERSONAL INFORMATION</h4>
                  </div>

                  <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
                    <div>
                      <span className="text-slate-500 block text-[10px]">Father’s Name:</span>
                      <span className="font-bold text-slate-900">{developerFatherName}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Mother’s Name:</span>
                      <span className="font-bold text-slate-900">{developerMotherName}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Date of Birth:</span>
                      <span className="font-bold text-slate-900">{developerDob}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Gender & Status:</span>
                      <span className="font-bold text-slate-900">Male | Unmarried</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Nationality & Religion:</span>
                      <span className="font-bold text-slate-900">Bangladeshi | Islam</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">National ID No:</span>
                      <span className="font-black font-mono text-emerald-800">{developerNid}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Height & Weight:</span>
                      <span className="font-bold text-slate-900">5 feet 9 inch | 68 Kg</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Blood Group:</span>
                      <span className="font-black text-rose-700">{developerBloodGroup}</span>
                    </div>
                    <div className="col-span-2 pt-1 border-t border-slate-100">
                      <span className="text-slate-500 block text-[10px]">Permanent Address:</span>
                      <span className="font-bold text-slate-900">{developerAddress}</span>
                    </div>
                  </div>
                </div>

                {/* References */}
                <div className="bg-white p-6 rounded-3xl shadow-md border border-slate-200 space-y-4">
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                    <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-900 flex items-center justify-center">
                      <Users className="w-4 h-4" />
                    </div>
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-wide">REFERENCES</h4>
                  </div>

                  <div className="space-y-3 text-xs">
                    {/* Reference 1 */}
                    <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-black text-slate-900 text-sm">Amir Uddin</span>
                        <span className="text-[10px] bg-slate-200 px-2 py-0.5 rounded font-bold text-slate-700">Relation: Uncle</span>
                      </div>
                      <p className="text-slate-700 font-bold">A.IGP, Bangladesh Police</p>
                      <p className="text-emerald-800 font-mono font-bold">Cell: 01719-187049</p>
                    </div>

                    {/* Reference 2 */}
                    <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-black text-slate-900 text-sm">Akram Hossen Zishan</span>
                        <span className="text-[10px] bg-slate-200 px-2 py-0.5 rounded font-bold text-slate-700">Relation: Cousin</span>
                      </div>
                      <p className="text-slate-700 font-bold">Deputy Manager, Petrobangla (Bangladesh Oil, Gas & Mineral Co.)</p>
                      <p className="text-emerald-800 font-mono font-bold">Cell: 01747-161262</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Language & Hobbies */}
              <div className="bg-white p-6 rounded-3xl shadow-md border border-slate-200 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <h5 className="font-black text-slate-900 mb-2 flex items-center gap-1.5">
                      <Globe className="w-4 h-4 text-emerald-700" />
                      <span>LANGUAGE SKILLS:</span>
                    </h5>
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between p-2 bg-slate-50 rounded-lg border border-slate-200">
                        <span className="font-bold text-slate-800">Bangla (বাংলা)</span>
                        <span className="text-emerald-800 font-bold">Writing: High | Speaking: High</span>
                      </div>
                      <div className="flex items-center justify-between p-2 bg-slate-50 rounded-lg border border-slate-200">
                        <span className="font-bold text-slate-800">English (ইংরেজি)</span>
                        <span className="text-slate-700 font-bold">Writing: Medium | Speaking: Medium</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h5 className="font-black text-slate-900 mb-2 flex items-center gap-1.5">
                      <Heart className="w-4 h-4 text-rose-600" />
                      <span>HOBBIES & INTERESTS:</span>
                    </h5>
                    <div className="flex flex-wrap gap-2">
                      <span className="px-2.5 py-1 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-lg font-medium">✈️ Travelling</span>
                      <span className="px-2.5 py-1 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-lg font-medium">📖 Reading good books</span>
                      <span className="px-2.5 py-1 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-lg font-medium">✍️ Writing Blog & Social Media</span>
                      <span className="px-2.5 py-1 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-lg font-medium">🎵 Music & Movies</span>
                      <span className="px-2.5 py-1 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-lg font-medium">🌐 Internet Browsing & AI Research</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ============================================================ */}
          {/* TAB 2: SYSTEM ARCHITECTURE & AI CAPABILITIES                 */}
          {/* ============================================================ */}
          {activeTab === 'tech' && (
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-3xl shadow-md border border-slate-200 space-y-4">
                <h3 className="font-extrabold text-sm text-emerald-950 border-b border-slate-200 pb-3 flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-emerald-700" />
                  <span>কারিগরি আর্কিটেকচার ও সিস্টেম ফিচারসমুহ (System Engineering Specs)</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs">
                  <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200 space-y-1.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-800 text-amber-300 flex items-center justify-center font-bold mb-2">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <h4 className="font-black text-slate-900">Gemini 1.5 Flash Vision OCR</h4>
                    <p className="text-slate-600 leading-relaxed">
                      এনআইডি ও জন্ম নিবন্ধন কার্ডের ছবি থেকে বাংলায় নিখুঁত তথ্য এক্সট্র্যাক্ট এবং এআই চালিত ড্রাফট তৈরীর জন্য জেনারেটিভ মডেল।
                    </p>
                  </div>

                  <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200 space-y-1.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-800 text-amber-300 flex items-center justify-center font-bold mb-2">
                      <Layers className="w-4 h-4" />
                    </div>
                    <h4 className="font-black text-slate-900">Firebase Cloud Persistence</h4>
                    <p className="text-slate-600 leading-relaxed">
                      রিয়েলটাইম এনক্রিপ্টেড ফায়ারস্টোর ডেটাবেস, অডিট ট্রেইল সিকিউরিটি এবং রোল-বেসড পারমিশন অ্যাক্সেস রুলস।
                    </p>
                  </div>

                  <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200 space-y-1.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-800 text-amber-300 flex items-center justify-center font-bold mb-2">
                      <Cloud className="w-4 h-4" />
                    </div>
                    <h4 className="font-black text-slate-900">Cloudflare R2 & Drive Auto-Sync</h4>
                    <p className="text-slate-600 leading-relaxed">
                      ডিজিটাল কপি ক্লাউডে ব্যাকআপ এবং গুগল ড্রাইভ ও শিটসে স্বয়ংক্রিয় সিঙ্ক্রোনাইজেশন সিস্টেম।
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ============================================================ */}
          {/* TAB 3: SOCIAL MEDIA & CHANNELS HUB                           */}
          {/* ============================================================ */}
          {activeTab === 'channels' && (
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-3xl shadow-md border border-slate-200 space-y-4">
                <h3 className="font-extrabold text-sm text-slate-900 border-b border-slate-200 pb-3 flex items-center gap-2">
                  <Share2 className="w-5 h-5 text-emerald-700" />
                  <span>ডেভেলপার ও উদ্যোক্তা মো: জোবায়ের হোসেনের সকল চ্যানেল ও সোশ্যাল লিঙ্ক</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {developerFacebook && (
                    <a
                      href={developerFacebook}
                      target="_blank"
                      rel="noreferrer"
                      className="p-3.5 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-2xl transition flex items-center gap-3"
                    >
                      <Facebook className="w-5 h-5 text-blue-600 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-[10px] text-blue-800 font-bold block uppercase">Facebook Profile</span>
                        <span className="text-xs font-black text-slate-900 block truncate">/xobaer6090</span>
                      </div>
                    </a>
                  )}

                  {developerMessengerUrl && (
                    <a
                      href={developerMessengerUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="p-3.5 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-2xl transition flex items-center gap-3"
                    >
                      <MessageCircle className="w-5 h-5 text-indigo-600 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-[10px] text-indigo-800 font-bold block uppercase">FB Messenger</span>
                        <span className="text-xs font-black text-slate-900 block truncate">@{developerMessengerUsername}</span>
                      </div>
                    </a>
                  )}

                  {developerTelegramUrl && (
                    <a
                      href={developerTelegramUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="p-3.5 bg-sky-50 hover:bg-sky-100 border border-sky-200 rounded-2xl transition flex items-center gap-3"
                    >
                      <Send className="w-5 h-5 text-sky-500 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-[10px] text-sky-800 font-bold block uppercase">Telegram Chat</span>
                        <span className="text-xs font-black text-slate-900 block truncate">@{developerTelegramUsername}</span>
                      </div>
                    </a>
                  )}

                  {developerWhatsapp && (
                    <a
                      href={developerWhatsappUrl || `https://wa.me/${developerWhatsapp.replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noreferrer"
                      className="p-3.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-2xl transition flex items-center gap-3"
                    >
                      <MessageSquare className="w-5 h-5 text-emerald-600 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-[10px] text-emerald-800 font-bold block uppercase">WhatsApp Chat</span>
                        <span className="text-xs font-black text-slate-900 block truncate">@{developerWhatsappUsername}</span>
                      </div>
                    </a>
                  )}

                  {developerLinkedin && (
                    <a
                      href={developerLinkedin}
                      target="_blank"
                      rel="noreferrer"
                      className="p-3.5 bg-sky-50 hover:bg-sky-100 border border-sky-300 rounded-2xl transition flex items-center gap-3"
                    >
                      <Linkedin className="w-5 h-5 text-sky-700 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-[10px] text-sky-800 font-bold block uppercase">LinkedIn Profile</span>
                        <span className="text-xs font-black text-slate-900 block truncate">/in/xobaer6090</span>
                      </div>
                    </a>
                  )}

                  {developerGithubProfile && (
                    <a
                      href={developerGithubProfile}
                      target="_blank"
                      rel="noreferrer"
                      className="p-3.5 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-2xl transition flex items-center gap-3"
                    >
                      <Github className="w-5 h-5 text-slate-900 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-[10px] text-slate-600 font-bold block uppercase">GitHub Profile</span>
                        <span className="text-xs font-black text-slate-900 block truncate">github.com/inbox6090</span>
                      </div>
                    </a>
                  )}

                  {developerWordpress && (
                    <a
                      href={developerWordpress}
                      target="_blank"
                      rel="noreferrer"
                      className="p-3.5 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-2xl transition flex items-center gap-3"
                    >
                      <Globe className="w-5 h-5 text-amber-700 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-[10px] text-amber-800 font-bold block uppercase">WordPress Blog</span>
                        <span className="text-xs font-black text-slate-900 block truncate">xobaer.wordpress.com</span>
                      </div>
                    </a>
                  )}

                  {developerTiktok && (
                    <a
                      href={developerTiktok}
                      target="_blank"
                      rel="noreferrer"
                      className="p-3.5 bg-slate-900 hover:bg-black text-white rounded-2xl transition flex items-center gap-3"
                    >
                      <svg className="w-5 h-5 fill-current text-teal-400 shrink-0" viewBox="0 0 24 24">
                        <path d="M12.525.02c1.31-.02 2.61.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72v4.28c-.89-.26-1.87-.12-2.67.36-.88.52-1.48 1.48-1.58 2.49-.07.83.21 1.68.77 2.3.69.77 1.74 1.13 2.76 1.01 1.02-.08 1.96-.68 2.45-1.58.33-.58.48-1.26.47-1.94-.01-4.63-.01-9.25-.01-13.88z" />
                      </svg>
                      <div className="min-w-0">
                        <span className="text-[10px] text-teal-300 font-bold block uppercase">TikTok Channel</span>
                        <span className="text-xs font-black text-white block truncate">@xobaer6090</span>
                      </div>
                    </a>
                  )}

                  {developerInstagram && (
                    <a
                      href={developerInstagram}
                      target="_blank"
                      rel="noreferrer"
                      className="p-3.5 bg-pink-50 hover:bg-pink-100 border border-pink-200 rounded-2xl transition flex items-center gap-3"
                    >
                      <Instagram className="w-5 h-5 text-pink-600 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-[10px] text-pink-800 font-bold block uppercase">Instagram Profile</span>
                        <span className="text-xs font-black text-slate-900 block truncate">@xobaer6090</span>
                      </div>
                    </a>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ============================================================ */}
      {/* PROTECTED DEVELOPER EDITING FORM (ACCESSIBLE IN EDIT MODE)  */}
      {/* ============================================================ */}
      {isEditMode && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200 space-y-6">
            <h3 className="font-extrabold text-sm text-emerald-950 border-b border-slate-200 pb-2 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <User className="w-4 h-4 text-emerald-700" />
                <span>১. ডেভেলপার ব্যক্তিগত তথ্য ও জীবনবৃত্তান্ত (CV) কাস্টমাইজেশন</span>
              </span>
              <span className="text-xs font-normal text-slate-500">
                (এখানে পরিবর্তন করে নিচে সেভ বাটনে চাপ দিন)
              </span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Photo Column */}
              <div className="flex flex-col items-center text-center space-y-3 md:border-r border-slate-200 md:pr-6">
                <div className="relative group">
                  <div className="w-36 h-36 rounded-2xl overflow-hidden border-4 border-emerald-800 shadow-md bg-slate-100 flex items-center justify-center">
                    {photoUrl ? (
                      <img src={photoUrl} alt="Developer" className="w-full h-full object-cover" />
                    ) : (
                      <div className="text-slate-400 flex flex-col items-center">
                        <User className="w-12 h-12 text-slate-400" />
                        <span className="text-[10px] mt-1 font-bold">ছবি আপলোড করুন</span>
                      </div>
                    )}
                  </div>

                  <label className="absolute bottom-2 right-2 bg-emerald-800 hover:bg-emerald-700 text-amber-300 p-2 rounded-xl shadow cursor-pointer transition">
                    <Upload className="w-4 h-4" />
                    <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                  </label>
                </div>

                <div className="w-full text-left space-y-2 text-xs">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1">ছবি লিংক (Image URL):</label>
                    <input
                      type="text"
                      value={photoUrl}
                      onChange={(e) => setPhotoUrl(e.target.value)}
                      placeholder="https://..."
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded text-xs font-mono"
                    />
                  </div>

                  <div className="bg-emerald-50 p-2.5 rounded-xl border border-emerald-200 space-y-1">
                    <p className="text-[10px] font-bold text-emerald-900">অফিশিয়াল হেল্পলাইন:</p>
                    <p className="text-xs font-bold text-emerald-950 font-mono">
                      📞 কল: {developerPhone}
                    </p>
                    <p className="text-xs font-bold text-emerald-950 font-mono">
                      💬 WhatsApp: {developerWhatsapp}
                    </p>
                  </div>
                </div>
              </div>

              {/* Form Fields Column */}
              <div className="md:col-span-2 space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">নাম (Name):</label>
                    <input
                      type="text"
                      value={developerName}
                      onChange={(e) => setDeveloperName(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">পদবী/উপাধি (Title):</label>
                    <input
                      type="text"
                      value={developerTitle}
                      onChange={(e) => setDeveloperTitle(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">ফোন নম্বর (Contact No):</label>
                    <input
                      type="text"
                      value={developerPhone}
                      onChange={(e) => setDeveloperPhone(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono font-bold text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">ইমেইল ঠিকানা (E-mail):</label>
                    <input
                      type="email"
                      value={developerEmail}
                      onChange={(e) => setDeveloperEmail(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">জাতীয় পরিচয়পত্র নম্বর (NID No):</label>
                    <input
                      type="text"
                      value={developerNid}
                      onChange={(e) => setDeveloperNid(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">জন্ম তারিখ (Date of Birth):</label>
                    <input
                      type="text"
                      value={developerDob}
                      onChange={(e) => setDeveloperDob(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">ব্লাড গ্রুপ (Blood Group):</label>
                    <input
                      type="text"
                      value={developerBloodGroup}
                      onChange={(e) => setDeveloperBloodGroup(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">পিতার নাম (Father's Name):</label>
                    <input
                      type="text"
                      value={developerFatherName}
                      onChange={(e) => setDeveloperFatherName(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">মাতার নাম (Mother's Name):</label>
                    <input
                      type="text"
                      value={developerMotherName}
                      onChange={(e) => setDeveloperMotherName(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">স্থায়ী ঠিকানা (Address):</label>
                    <input
                      type="text"
                      value={developerAddress}
                      onChange={(e) => setDeveloperAddress(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">বায়ো / বিবরণী (Bio):</label>
                  <textarea
                    rows={2}
                    value={developerBio}
                    onChange={(e) => setDeveloperBio(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs leading-relaxed focus:bg-white focus:border-emerald-600 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Save Status Notification */}
          {savedSuccess && (
            <div className="p-3.5 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>ডেভেলপার তথ্য ও জীবনবৃত্তান্ত সফলভাবে সংরক্ষিত হয়েছে!</span>
            </div>
          )}

          {/* Save Action */}
          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsEditMode(false)}
              className="px-5 py-3.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
            >
              বাতিল (পাবলিক ভিউ)
            </button>
            <button
              type="button"
              onClick={handleSaveDeveloperConfig}
              disabled={isSaving}
              className="px-8 py-3.5 bg-emerald-800 hover:bg-emerald-700 text-white font-extrabold text-sm rounded-xl shadow-lg transition flex items-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-amber-300" />
                  <span>সেভ হইতেছে...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4 text-amber-300" />
                  <span>সমস্ত তথ্য ও ব্যাকআপ সেভ করুন</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
