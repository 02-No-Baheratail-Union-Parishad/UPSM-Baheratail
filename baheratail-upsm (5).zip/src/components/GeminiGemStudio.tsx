import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Copy,
  Check,
  Download,
  FileText,
  BookOpen,
  Code2,
  Layers,
  ExternalLink,
  Bot,
  Search,
  Edit3,
  RotateCcw,
  Save,
  ShieldCheck,
  Send,
  HelpCircle,
  FolderDown,
  Terminal,
  FileCode,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  Share2
} from 'lucide-react';
import { UnionParishadConfig } from '../types';
import { INITIAL_KNOWLEDGE_FILES, KnowledgeFile } from '../data/knowledgeBaseFiles';

interface GeminiGemStudioProps {
  config: UnionParishadConfig;
  onClose?: () => void;
}

export const GeminiGemStudio: React.FC<GeminiGemStudioProps> = ({ config }) => {
  // Load custom-edited knowledge files from localStorage or initial dataset
  const [knowledgeFiles, setKnowledgeFiles] = useState<KnowledgeFile[]>(() => {
    try {
      const saved = localStorage.getItem('upsm_custom_knowledge_files');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Failed to load customized knowledge base files:', e);
    }
    return INITIAL_KNOWLEDGE_FILES;
  });

  const [selectedFileId, setSelectedFileId] = useState<string>('07_gem_instructions');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editedContent, setEditedContent] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [saveToast, setSaveToast] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'files' | 'master_prompt' | 'guide' | 'simulator'>('files');

  // Simulator State
  const [simInput, setSimInput] = useState<string>('');
  const [simHistory, setSimHistory] = useState<Array<{ role: 'user' | 'gem'; text: string; mode?: string; time: string }>>([
    {
      role: 'gem',
      text: `আসসালামু আলাইকুম! আমি UPSM — ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল সহকারী ও অটোমেশন এজেন্ট।\n\nআমি Knowledge Base-এর সকল নিয়ম ও টেমপ্লেট অনুযায়ী প্রস্তুত। আপনি আমাকে বাংলাতে কমান্ড দিতে পারেন যেমন:\n• "এই NID থেকে তথ্য বের করো"\n• "তথ্যগুলো যাচাই করো"\n• "নাগরিক সনদ তৈরি করো"\n• "ওয়ার্ড ৪ এর গ্রামগুলো কী?"\n• "ট্রেড লাইসেন্স ফি কত?"\n• "Copy Ready দাও"`,
      mode: 'ASSIST',
      time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const currentFile = knowledgeFiles.find(f => f.id === selectedFileId) || knowledgeFiles[0];

  // Sync editedContent when selected file changes
  useEffect(() => {
    if (currentFile) {
      setEditedContent(currentFile.content);
      setIsEditing(false);
    }
  }, [selectedFileId, knowledgeFiles]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleSaveEdit = () => {
    const updated = knowledgeFiles.map(f => {
      if (f.id === selectedFileId) {
        return { ...f, content: editedContent };
      }
      return f;
    });
    setKnowledgeFiles(updated);
    localStorage.setItem('upsm_custom_knowledge_files', JSON.stringify(updated));
    setIsEditing(false);
    setSaveToast(`✅ "${currentFile.title}" ফাইলটি সফলভাবে সংরক্ষিত হয়েছে!`);
    setTimeout(() => setSaveToast(null), 3500);
  };

  const handleResetCurrentFile = () => {
    const original = INITIAL_KNOWLEDGE_FILES.find(f => f.id === selectedFileId);
    if (!original) return;
    if (window.confirm(`আপনি কি "${original.title}" এর সকল কাস্টম পরিবর্তন মুছে মূল ডিফল্ট কন্টেন্টে ফিরতে চান?`)) {
      const updated = knowledgeFiles.map(f => (f.id === selectedFileId ? original : f));
      setKnowledgeFiles(updated);
      setEditedContent(original.content);
      setIsEditing(false);
      localStorage.setItem('upsm_custom_knowledge_files', JSON.stringify(updated));
      setSaveToast(`🔄 "${original.title}" মূল ডিফল্ট মানে রিসেট করা হয়েছে।`);
      setTimeout(() => setSaveToast(null), 3000);
    }
  };

  const handleResetAllFiles = () => {
    if (window.confirm('আপনি কি সকল নলেজ ফাইলকে মূল ডিফল্ট সংস্করণে রিসেট করতে চান?')) {
      setKnowledgeFiles(INITIAL_KNOWLEDGE_FILES);
      localStorage.removeItem('upsm_custom_knowledge_files');
      setSaveToast('🔄 সকল Knowledge Base ফাইল মূল ডিফল্টে সফলভাবে রিসেট করা হয়েছে।');
      setTimeout(() => setSaveToast(null), 3000);
    }
  };

  const handleDownloadFile = (file: KnowledgeFile) => {
    const blob = new Blob([file.content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = file.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadAllBundled = () => {
    const bundleHeader = `# UPSM 2.0 — ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ সম্পূর্ণ নলেজ প্যাকেজ (All Knowledge Files Bundled)
ডাউনলোডের সময়: ${new Date().toLocaleString('bn-BD')}
অধিক্ষেত্র: ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল
================================================================================

`;
    const fullContent = bundleHeader + knowledgeFiles.map(f => `\n\n/* ==================== FILE: ${f.filename} ==================== */\n\n${f.content}`).join('\n\n');
    const blob = new Blob([fullContent], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `UPSM_Gem_Complete_Knowledge_Package_${new Date().toISOString().slice(0, 10)}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setSaveToast('📦 সম্পূর্ণ নলেজ প্যাকেজ .md ফাইল সফলভাবে ডাউনলোড হয়েছে!');
    setTimeout(() => setSaveToast(null), 3500);
  };

  // Filtered files
  const filteredFiles = knowledgeFiles.filter(f => {
    const matchesCategory = selectedCategory === 'all' || f.category === selectedCategory;
    const matchesSearch = searchQuery.trim() === '' || 
      f.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      f.filename.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.content.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Dynamic Master System Prompt
  const dynamicMasterPrompt = `# Google Gemini Custom Gem — Master System Prompt
## ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল সহকারী ও অটোমেশন এজেন্ট (UPSM Automation Agent)

### ১. এজেন্ট পরিচিতি ও ভূমিকা (Role & Persona)
তুমি "০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল সার্ভিস ও অটোমেশন এজেন্ট"। তুমি টাঙ্গাইল জেলার সখিপুর উপজেলাধীন ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের জন্য কাস্টমাইজড একটি সরকারি এআই সহকারী (Gemini Custom Gem / Workspace Agent)।

তোমার মূল দায়িত্ব:
1. ৪০+ ধরনের সরকারি প্রত্যয়নপত্র ও সনদ (নাগরিকত্ব, চারিত্রিক, ওয়ারিশান, ট্রেড লাইসেন্স, ভূমিহীন, অবিবাহিত ইত্যাদি)-এর জন্য সরকারি মানসম্মত দাপ্তরিক বাংলা বিবরণী প্রস্তুত করা।
2. নাগরিকের প্রদত্ত তথ্যের যথার্থতা যাচাই (NID ১০/১৩/১৭ ডিজিট, জন্ম নিবন্ধন ১৭ ডিজিট, ওয়ার্ড নং ০১-০৯, গ্রামের নাম ২০টি অনুমোদিত গ্রামের সাথে মেলানো)।
3. ট্রেড লাইসেন্স ফি, সনদ ফি, ওয়ারিশ তালিকা ও অংশ হিসাব স্বয়ংক্রিয়ভাবে যাচাই করা।
4. ইউনিয়ন পরিষদের ডিজিটাল ট্র্যাকিং কোড (BUP-YYYY-XXXXX) ও অনলাইন কিউআর কোড ভেরিফিকেশন লিঙ্ক প্রদান করা।

### ২. দাপ্তরিক ভাষার মানদণ্ড (Bureaucratic Bengali)
- বাক্য গঠন: "এই মর্মে প্রত্যয়ন করা যাইতেছে যে, ..." দিয়ে শুরু হবে।
- স্থায়ী ঠিকানা: "তিনি টাঙ্গাইল জেলার সখিপুর উপজেলার ০২নং বহেড়াতৈল ইউনিয়নের [ওয়ার্ড নং] নং ওয়ার্ডের [গ্রামের নাম] গ্রামের একজন স্থায়ী বাসিন্দা।"
- চরিত্র ও স্বীকৃতি: "তিনি আমার পূর্ব পরিচিত। তিনি রাষ্ট্র বা সমাজবিরোধী কোনো কার্যকলাপে লিপ্ত নহেন। তাঁহার নৈতিক চরিত্র উত্তম।"
- সমাপ্তি: "আমি তাঁহার সর্বাঙ্গীন মঙ্গল ও উত্তরোত্তর সাফল্য কামনা করি।"

### ৩. প্রশাসনিক ও ভৌগোলিক তথ্যাবলী (Administrative Jurisdiction)
- ইউনিয়ন: ${config.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ'} (ডাকঘর: বহেড়াতৈল, পোস্ট কোড: ১৯৫০)
- উপজেলা: ${config.upazila || 'সখিপুর'}, জেলা: ${config.district || 'টাঙ্গাইল'}
- ৯টি ওয়ার্ড, ৪টি ডাকঘর ও ২০টি অনুমোদিত গ্রাম:
  • ওয়ার্ড ০১: ডাবাইল, কামারঙ্গ, গোহাইলবাড়ী (ডাকঘর: নাগবাড়ী-১৯৭২)
  • ওয়ার্ড ০২: গোহাইলবাড়ী (ডাকঘর: নাগবাড়ী-১৯৭২), যোগীর কোফা (ডাকঘর: বহেড়াতৈল-১৯৫০)
  • ওয়ার্ড ০৩: ঘাটেশ্বরী (ডাকঘর: বহেড়াতৈল-১৯৫০)
  • ওয়ার্ড ০৪: বহেড়াতৈল, নয়াপড়া, ভুগলীচালা, নেরগীছ চালা, ধোপার চালা (ডাকঘর: বহেড়াতৈল-১৯৫০)
  • ওয়ার্ড ০৫: আমতৈল (ডাকঘর: বেতুয়া-১৯৫০), শালগ্রামপুর (ডাকঘর: ছিলিমপুর-১৯৫০)
  • ওয়ার্ড ০৬: বগাপ্রতিমা, ছাতিয়াচালা, আন্দি (ডাকঘর: বহেড়াতৈল-১৯৫০)
  • ওয়ার্ড ০৭: বেতুয়া (ডাকঘর: বেতুয়া-১৯৫০)
  • ওয়ার্ড ০৮: কালিয়ান, বেতুয়া (ডাকঘর: বেতুয়া-১৯৫০)
  • ওয়ার্ড ০৯: কালিয়ান (ডাকঘর: বেতুয়া-১৯৫০), হাতিবান্ধা

### ৪. কর্মকর্তা ও অফিস যোগাযোগ
- চেয়ারম্যান: ${config.chairmanName || 'মোশারফ হোসেন (হিরো মিয়া)'}
- সচিব: ${config.secretaryName || 'মোঃ সাইদুজ্জামান'}
- উদ্যোক্তা / কম্পিউটার অপারেটর: MD. JUBAER HOSSEN (XOBAER)
- যোগাযোগ: ${config.phone || '০১৮৩৪-৩৩৩৩৩০০'}, ${config.email || 'baheratailunion@gmail.com'}
- ভেরিফিকেশন পোর্টাল: https://upsm-baheratail.vercel.app/verify/BUP-YYYY-XXXXX

### ৫. ৫টি আউটপুট মোড (Output Modes)
1. **ASSIST MODE:** দাপ্তরিক কাজের নিয়ম ও প্রক্রিয়া বুঝিয়ে দেওয়া।
2. **DATA MODE:** NID/জন্মনিবন্ধন থেকে ফিল্ডভিত্তিক তথ্য বের করা।
3. **VERIFY MODE:** তথ্য ও গ্রাম-ওয়ার্ডের অসঙ্গতি বের করা।
4. **DRAFT MODE:** অনুমোদিত টেমপ্লেট অনুযায়ী সম্পূর্ণ খসড়া তৈরি।
5. **COPY-READY MODE:** যখন ব্যবহারকারী বলবে "Copy Ready দাও" বা "শুধু Body দাও" — তখন কোনো ভূমিকা বা কোডব্লক ছাড়া শুধুমাত্র প্রিন্ট-রেডি খাঁটি টেক্সট দেওয়া।`;

  // Simulator command runner
  const handleSimSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const prompt = simInput.trim();
    if (!prompt) return;

    const userMsg = {
      role: 'user' as const,
      text: prompt,
      time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
    };

    setSimHistory(prev => [...prev, userMsg]);
    setSimInput('');

    // Generate accurate contextual response from Knowledge Base
    setTimeout(() => {
      let reply = '';
      let mode = 'ASSIST';

      const lower = prompt.toLowerCase();
      if (lower.includes('nid') || lower.includes('তথ্য বের') || lower.includes('extract')) {
        mode = 'DATA';
        reply = `[DATA MODE — NID তথ্য নিষ্কাশন]\n• নাম: মোঃ আব্দুল করিম\n• English: Md Abdul Karim\n• পিতা: মোঃ হোসেন আলী\n• মাতা: মোসাঃ রহিমা বেগম\n• জন্ম তারিখ: ১৫-০৩-১৯৯৩\n• NID নং: ১৯৯৩২৬১৪৭৫৮০০০০১২ (১৭ ডিজিট — ফরম্যাট সঠিক)\n• গ্রাম: বহেড়াতৈল (ওয়ার্ড ০৪)\n• ডাকঘর: বহেড়াতৈল (পোস্ট কোড: ১৯৫০)\n\n⚠️ তথ্যটি অপারেটর দ্বারা চূড়ান্তভাবে যাচাই প্রয়োজন।`;
      } else if (lower.includes('যাচাই') || lower.includes('ভুল') || lower.includes('verify')) {
        mode = 'VERIFY';
        reply = `[VERIFY MODE — ভ্যালিডেশন ফলাফল]\n✅ NID ফরম্যাট: ১৭ ডিজিট (সঠিক)\n✅ ওয়ার্ড ও গ্রাম ম্যাপিং: ওয়ার্ড ০৪ ➔ বহেড়াতৈল (অনুমোদিত তালিকার সাথে মিল রয়েছে)\n✅ ডাকঘর: বহেড়াতৈল-১৯৫০ (সঠিক)\n✅ আবশ্যিক ফিল্ডসমূহ: নাম, পিতা, মাতা, ঠিকানা বিদ্যমান\n\n📌 স্ট্যাটাস: তথ্য সঠিক আছে, খসড়া তৈরিতে যেতে পারেন।`;
      } else if (lower.includes('নাগরিক') || lower.includes('জাতীয়তা') || lower.includes('সনদ তৈরি')) {
        mode = 'DRAFT';
        reply = `[DRAFT MODE — নাগরিক সনদপত্রের খসড়া]\nগণপ্রজাতন্ত্রী বাংলাদেশ সরকার\n০২নং বহেড়াতৈল ইউনিয়ন পরিষদ কার্যালয়\nসখিপুর, টাঙ্গাইল।\n\nস্মারক নং: BUP-2026-04891\nতারিখ: ${new Date().toLocaleDateString('bn-BD')}\n\nনাগরিক সনদপত্র\n\nএই মর্মে প্রত্যয়ন করা যাইতেছে যে, মোঃ আব্দুল করিম, পিতা: মোঃ হোসেন আলী, মাতা: মোসাঃ রহিমা বেগম, গ্রাম: বহেড়াতৈল, ওয়ার্ড নং: ০৪, ডাকঘর: বহেড়াতৈল-১৯৫০, উপজেলা: সখিপুর, জেলা: টাঙ্গাইল।\n\nতিনি অত্র ইউনিয়নের একজন স্থায়ী বাসিন্দা ও জন্মসূত্রে বাংলাদেশের নাগরিক। আমার জানামতে তিনি কোনো রাষ্ট্র বা সমাজবিরোধী কার্যকলাপে জড়িত নহেন।\n\nআমি তাঁহার সর্বাঙ্গীন মঙ্গল ও সাফল্য কামনা করি।\n\n(চেয়ারম্যান)\n০২নং বহেড়াতৈল ইউনিয়ন পরিষদ`;
      } else if (lower.includes('copy ready') || lower.includes('শুধু body') || lower.includes('word')) {
        mode = 'COPY-READY';
        reply = `এই মর্মে প্রত্যয়ন করা যাইতেছে যে, মোঃ আব্দুল করিম, পিতা: মোঃ হোসেন আলী, মাতা: মোসাঃ রহিমা বেগম, গ্রাম: বহেড়াতৈল, ওয়ার্ড নং: ০৪, ডাকঘর: বহেড়াতৈল-১৯৫০, উপজেলা: সখিপুর, জেলা: টাঙ্গাইল।\n\nতিনি অত্র ইউনিয়নের একজন স্থায়ী বাসিন্দা ও জন্মসূত্রে বাংলাদেশের নাগরিক। আমার জানামতে তিনি কোনো রাষ্ট্র বা সমাজবিরোধী কার্যকলাপে জড়িত নহেন।\n\nআমি তাঁহার সর্বাঙ্গীন মঙ্গল ও সাফল্য কামনা করি।`;
      } else if (lower.includes('গ্রাম') || lower.includes('ওয়ার্ড') || lower.includes('ডাকঘর')) {
        mode = 'ASSIST';
        reply = `[ASSIST MODE — ভৌগোলিক নলেজ]\n০২নং বহেড়াতৈল ইউনিয়ন পরিষদে মোট ৯টি ওয়ার্ড, ৪টি ডাকঘর ও ২০টি অনুমোদিত গ্রাম রয়েছে:\n• ওয়ার্ড ১: ডাবাইল, কামারঙ্গ, গোহাইলবাড়ী (ডাকঘর: নাগবাড়ী-১৯৭২)\n• ওয়ার্ড ২: গোহাইলবাড়ী, যোগীর কোফা\n• ওয়ার্ড ৩: ঘাটেশ্বরী\n• ওয়ার্ড ৪: বহেড়াতৈল, নয়াপড়া, ভুগলীচালা, নেরগীছ চালা, ধোপার চালা\n• ওয়ার্ড ৫: আমতৈল, শালগ্রামপুর\n• ওয়ার্ড ৬: বগাপ্রতিমা, ছাতিয়াচালা, আন্দি\n• ওয়ার্ড ৭: বেতুয়া\n• ওয়ার্ড ৮: কালিয়ান, বেতুয়া\n• ওয়ার্ড ৯: কালিয়ান, হাতিবান্ধা`;
      } else if (lower.includes('ফি') || lower.includes('ট্রেড')) {
        mode = 'ASSIST';
        reply = `[ASSIST MODE — ফি কাঠামো]\n• আদর্শ কর তফসিল ২০১৩ অনুযায়ী:\n  - নাগরিক/চারিত্রিক/আয় সনদ ফি: ৳ ৫০.০০\n  - ওয়ারিশান সনদ ফি: ৳ ১০০.০০\n  - নতুন ট্রেড লাইসেন্স ফি: ৳ ২০০.০০ + কর ৳ ১০০.০০ + ১৫% ভ্যাট ৳ ৩০.০০ = মোট ৳ ৩৩০.০০\n  - প্রতিবন্ধী সনদ: বিনামূল্যে (৳ ০.০০)`;
      } else {
        mode = 'ASSIST';
        reply = `[ASSIST MODE]\nআমি আপনার নির্দেশ পেয়েছি। আপনি বলতে পারেন:\n• "এই NID থেকে তথ্য বের করো"\n• "নাগরিক সনদ তৈরি করো"\n• "Copy Ready দাও" (ক্লিন টেক্সটের জন্য)\n• "ভুল যাচাই করো"`;
      }

      setSimHistory(prev => [
        ...prev,
        {
          role: 'gem',
          text: reply,
          mode,
          time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }, 400);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-teal-950 text-white rounded-3xl p-6 md:p-8 shadow-xl border border-emerald-800/40 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-400/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-400/20 text-amber-300 border border-amber-400/30 rounded-full text-xs font-bold tracking-wide">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Google Gemini Custom Gem & Knowledge Base Studio</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
              🏛️ গুগল জেম ও নলেজ ফাইল হাব — নিখুঁত ইনস্ট্রাকশন ও জ্ঞানভাণ্ডার
            </h1>
            <p className="text-sm text-emerald-100/90 leading-relaxed">
              সিস্টেমের সকল মাস্টার নলেজ ফাইলসমূহ (<code className="px-1.5 py-0.5 bg-black/30 rounded text-amber-300 font-mono text-xs">.md</code>) সরাসরি ব্রাউজারেই দেখুন, ১-ক্লিকে কপি করুন, কাস্টমাইজ বা আরো উন্নত করুন এবং <a href="https://gemini.google.com/gems" target="_blank" rel="noreferrer" className="underline font-bold text-amber-300 hover:text-amber-200 inline-flex items-center gap-1">Gemini Custom Gem <ExternalLink className="w-3 h-3" /></a>-এ আপলোড করে নিজস্ব এআই সহকারী হিসেবে চালান।
            </p>
          </div>

          <div className="flex flex-wrap gap-2.5 shrink-0">
            <button
              onClick={() => handleCopy(dynamicMasterPrompt, 'master_prompt_header')}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition flex items-center gap-2 cursor-pointer"
              title="সম্পূর্ণ জেম সিস্টেম প্রম্পট এক ক্লিকে কপি করুন"
            >
              {copiedId === 'master_prompt_header' ? (
                <>
                  <Check className="w-4 h-4 text-slate-950" />
                  <span>কপি সম্পন্ন!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>জেম সিস্টেম প্রম্পট কপি</span>
                </>
              )}
            </button>

            <button
              onClick={handleDownloadAllBundled}
              className="px-4 py-2.5 bg-white/15 hover:bg-white/25 text-white font-bold text-xs rounded-xl border border-white/20 shadow-md transition flex items-center gap-2 cursor-pointer"
              title="সকল নলেজ ফাইল একত্রিত প্যাকেজ হিসেবে ডাউনলোড করুন"
            >
              <FolderDown className="w-4 h-4 text-emerald-300" />
              <span>নলেজ প্যাকেজ ডাউনলোড (.md)</span>
            </button>

            <a
              href="https://gemini.google.com/gems"
              target="_blank"
              rel="noreferrer"
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-1.5 cursor-pointer"
            >
              <Bot className="w-4 h-4 text-amber-300" />
              <span>Gemini Gem খুলুন</span>
              <ExternalLink className="w-3 h-3 ml-0.5 opacity-80" />
            </a>
          </div>
        </div>

        {/* Studio Sub Tabs */}
        <div className="flex flex-wrap gap-2 pt-6 mt-4 border-t border-emerald-800/60">
          {[
            { id: 'files', label: `📚 নলেজ ফাইলসমূহ (${knowledgeFiles.length}টি)`, icon: BookOpen },
            { id: 'master_prompt', label: '🤖 মাস্টার জেম প্রম্পট', icon: Bot },
            { id: 'guide', label: '🪜 জেম সেটআপ গাইড (Step-by-Step)', icon: HelpCircle },
            { id: 'simulator', label: '🧪 লাইভ জেম সিমুলেটর', icon: Terminal }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer ${
                  isActive
                    ? 'bg-amber-400 text-slate-950 shadow-md'
                    : 'bg-emerald-900/60 hover:bg-emerald-800/80 text-emerald-100 border border-emerald-700/50'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Toast Notification */}
      {saveToast && (
        <div className="bg-emerald-900 text-amber-300 border border-emerald-600 px-4 py-3 rounded-2xl text-xs font-bold flex items-center justify-between shadow-lg animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{saveToast}</span>
          </div>
          <button onClick={() => setSaveToast(null)} className="text-white/60 hover:text-white text-xs">✕</button>
        </div>
      )}

      {/* TAB 1: KNOWLEDGE FILES EXPLORER & IN-BROWSER EDITOR */}
      {activeTab === 'files' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left Column: File Catalog & Filter */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
              {/* Search Box */}
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="নলেজ ফাইলে সার্চ করুন..."
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-600 dark:text-white"
                />
              </div>

              {/* Category Pills */}
              <div className="flex flex-wrap gap-1.5">
                {[
                  { id: 'all', label: 'সবগুলো' },
                  { id: 'core', label: 'মাস্টার ও রুল' },
                  { id: 'catalog', label: 'সনদ ও টেমপ্লেট' },
                  { id: 'instructions', label: 'জেম প্রম্পট' },
                  { id: 'automation', label: 'স্ক্রিপ্ট ও অটো' },
                  { id: 'security', label: 'নিরাপত্তা' }
                ].map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                      selectedCategory === cat.id
                        ? 'bg-emerald-800 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            {/* File List */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-2 shadow-sm space-y-1.5 max-h-[580px] overflow-y-auto">
              {filteredFiles.length === 0 ? (
                <div className="p-6 text-center text-slate-400 text-xs">
                  কোনো ফাইল পাওয়া যায়নি।
                </div>
              ) : (
                filteredFiles.map(file => {
                  const isSelected = file.id === selectedFileId;
                  return (
                    <button
                      key={file.id}
                      onClick={() => setSelectedFileId(file.id)}
                      className={`w-full text-left p-3 rounded-xl transition cursor-pointer flex items-start justify-between gap-3 border ${
                        isSelected
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-400 dark:border-emerald-700 text-emerald-950 dark:text-emerald-200 shadow-xs'
                          : 'border-transparent hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <div className="space-y-1 min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          {file.filename.endsWith('.js') ? (
                            <FileCode className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          ) : (
                            <FileText className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400 shrink-0" />
                          )}
                          <span className="font-bold text-xs truncate">{file.title}</span>
                        </div>
                        <div className="font-mono text-[10px] text-slate-500 dark:text-slate-400 truncate">
                          {file.filename}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                          {file.description}
                        </div>
                      </div>

                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold uppercase shrink-0 ${
                        isSelected ? 'bg-emerald-700 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                      }`}>
                        {file.category}
                      </span>
                    </button>
                  );
                })
              )}
            </div>

            {/* Reset All Button */}
            <div className="text-center pt-1">
              <button
                onClick={handleResetAllFiles}
                className="text-xs text-slate-500 hover:text-red-600 underline transition cursor-pointer"
              >
                সকল ফাইলকে মূল ডিফল্ট সংস্করণে রিসেট করুন
              </button>
            </div>
          </div>

          {/* Right Column: File Content Viewer & Editor */}
          <div className="lg:col-span-8 space-y-3">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden flex flex-col">
              {/* File Action Bar */}
              <div className="bg-slate-50 dark:bg-slate-800/80 px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="p-1.5 bg-emerald-100 dark:bg-emerald-900/60 rounded-lg text-emerald-800 dark:text-emerald-300">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-xs text-slate-900 dark:text-white truncate">
                      {currentFile.title}
                    </h3>
                    <div className="text-[10px] font-mono text-slate-500 dark:text-slate-400">
                      {currentFile.filename}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {/* Edit / Read Mode Toggle */}
                  <button
                    onClick={() => {
                      if (isEditing) {
                        setEditedContent(currentFile.content);
                        setIsEditing(false);
                      } else {
                        setIsEditing(true);
                      }
                    }}
                    className={`px-3 py-1.5 rounded-xl font-bold text-xs transition flex items-center gap-1.5 cursor-pointer ${
                      isEditing
                        ? 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <Edit3 className="w-3.5 h-3.5 text-amber-600" />
                    <span>{isEditing ? 'বাতিল' : 'সম্পাদনা ও উন্নয়ন'}</span>
                  </button>

                  {/* Save Button (when editing) */}
                  {isEditing && (
                    <button
                      onClick={handleSaveEdit}
                      className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5 text-amber-300" />
                      <span>পরিবর্তন সংরক্ষণ করুন</span>
                    </button>
                  )}

                  {/* Reset Single File */}
                  <button
                    onClick={handleResetCurrentFile}
                    className="p-1.5 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition cursor-pointer"
                    title="এই ফাইলের ডিফল্ট মান ফিরিয়ে আনুন"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>

                  {/* 1-Click Copy */}
                  <button
                    onClick={() => handleCopy(isEditing ? editedContent : currentFile.content, currentFile.id)}
                    className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-amber-300 font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                    title="সম্পূর্ণ ফাইলটি কপি করুন"
                  >
                    {copiedId === currentFile.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-amber-300" />
                        <span>কপি হয়েছে!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>কপি করুন</span>
                      </>
                    )}
                  </button>

                  {/* Download single file */}
                  <button
                    onClick={() => handleDownloadFile(currentFile)}
                    className="px-3 py-1.5 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                    title="এই ফাইলটি ডাউনলোড করুন"
                  >
                    <Download className="w-3.5 h-3.5 text-emerald-600" />
                    <span>ডাউনলোড</span>
                  </button>
                </div>
              </div>

              {/* Editor or Viewer Box */}
              <div className="p-4 flex-1">
                {isEditing ? (
                  <div className="space-y-2">
                    <div className="text-[11px] text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/30 p-2.5 rounded-xl border border-amber-200 dark:border-amber-900/50">
                      💡 <strong>উন্নয়ন সুবিধা:</strong> আপনি এখানে নিজস্ব গ্রাম, ফি, ওয়ার্ড বা দাপ্তরিক বয়ান লিখে "পরিবর্তন সংরক্ষণ করুন" চাপলে তা অ্যাপে সক্রিয় থাকবে।
                    </div>
                    <textarea
                      value={editedContent}
                      onChange={e => setEditedContent(e.target.value)}
                      rows={22}
                      className="w-full p-4 bg-slate-900 text-slate-100 font-mono text-xs leading-relaxed rounded-xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                ) : (
                  <pre className="p-4 bg-slate-900 text-emerald-300 font-mono text-xs leading-relaxed rounded-xl overflow-x-auto max-h-[580px] overflow-y-auto whitespace-pre-wrap selection:bg-emerald-700 selection:text-white">
                    {currentFile.content}
                  </pre>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MASTER SYSTEM PROMPT */}
      {activeTab === 'master_prompt' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                🤖 গুগল জেমিনাই কাস্টম জেম — মাস্টার সিস্টেম প্রম্পট (Master System Prompt)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                এটি সরাসরি <code className="text-emerald-700 dark:text-emerald-400 font-bold">gemini.google.com ➔ Gems ➔ Instructions</code> বক্সে পেস্ট করার জন্য তৈরি করা হয়েছে।
              </p>
            </div>

            <button
              onClick={() => handleCopy(dynamicMasterPrompt, 'master_prompt_tab')}
              className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-amber-300 font-bold text-xs rounded-xl shadow transition flex items-center gap-2 cursor-pointer"
            >
              {copiedId === 'master_prompt_tab' ? (
                <>
                  <Check className="w-4 h-4 text-amber-300" />
                  <span>সম্পূর্ণ কপি হয়েছে!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>সম্পূর্ণ প্রম্পট কপি করুন</span>
                </>
              )}
            </button>
          </div>

          <pre className="p-5 bg-slate-950 text-amber-300 font-mono text-xs leading-relaxed rounded-2xl overflow-x-auto max-h-[520px] overflow-y-auto whitespace-pre-wrap border border-slate-800 selection:bg-amber-500 selection:text-slate-950">
            {dynamicMasterPrompt}
          </pre>
        </div>
      )}

      {/* TAB 3: STEP-BY-STEP SETUP GUIDE */}
      {activeTab === 'guide' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 md:p-8 shadow-sm space-y-6">
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              🪜 গুগল জেমিনাই কাস্টম জেম (Gemini Custom Gem) সেটআপ নির্দেশিকা
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              নিচের ৪টি সহজ ধাপ অনুসরণ করে ৩ মিনিটের মধ্যেই আপনার ইউনিয়ন পরিষদের নিজস্ব সরকারি AI Gem চালু করুন।
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Step 1 */}
            <div className="p-5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50 space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-7 h-7 bg-emerald-800 text-white rounded-full flex items-center justify-center font-bold text-xs">১</span>
                <h3 className="font-bold text-sm text-emerald-950 dark:text-emerald-200">Gemini Gem পোর্টালে যান</h3>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                ব্রাউজারে <a href="https://gemini.google.com/gems" target="_blank" rel="noreferrer" className="font-bold text-emerald-700 dark:text-emerald-400 underline">gemini.google.com/gems</a> লিংকে যান এবং <strong>"+ New Gem"</strong> বা <strong>"+ কাস্টম জেম তৈরি করুন"</strong> বাটনে ক্লিক করুন।
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-7 h-7 bg-amber-700 text-white rounded-full flex items-center justify-center font-bold text-xs">২</span>
                <h3 className="font-bold text-sm text-amber-950 dark:text-amber-200">নাম ও ইনস্ট্রাকশন দিন</h3>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                <strong>Name:</strong> <code className="bg-white dark:bg-slate-800 px-1 py-0.5 rounded text-[11px]">UPSM — Union Parishad Smart Digital Assistant</code> দিন এবং <strong>Instructions:</strong> বক্সে আমাদের "মাস্টার সিস্টেম প্রম্পট" কপি করে পেস্ট করুন।
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-5 rounded-2xl bg-teal-50 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800/50 space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-7 h-7 bg-teal-800 text-white rounded-full flex items-center justify-center font-bold text-xs">৩</span>
                <h3 className="font-bold text-sm text-teal-950 dark:text-teal-200">Knowledge ফাইল আপলোড করুন</h3>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                উপরে থাকা <strong>"নলেজ প্যাকেজ ডাউনলোড"</strong> বাটনে ক্লিক করে .md ফাইলগুলো ডাউনলোড করুন এবং জেমের <strong>"Knowledge"</strong> সেকশনে আপলোড করুন।
              </p>
            </div>

            {/* Step 4 */}
            <div className="p-5 rounded-2xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/50 space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-7 h-7 bg-blue-800 text-white rounded-full flex items-center justify-center font-bold text-xs">৪</span>
                <h3 className="font-bold text-sm text-blue-950 dark:text-blue-200">Save করুন ও ব্যবহার শুরু করুন</h3>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                <strong>Save</strong> বাটনে ক্লিক করলেই আপনার নিজস্ব অফিসিয়াল সহকারী প্রস্তুত! এখন NID ছবি দিন বা বাংলায় নির্দেশ লিখুন।
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: INTERACTIVE GEM SIMULATOR */}
      {activeTab === 'simulator' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-600" />
                <span>🧪 লাইভ এআই জেম পরীক্ষাগার (Interactive Gem Simulator)</span>
              </h2>
              <p className="text-xs text-slate-500">
                Knowledge Base-এর নিয়ম ও আউটপুট মোডগুলো এখানে লাইভ পরীক্ষা করে দেখুন।
              </p>
            </div>
            <button
              onClick={() => setSimHistory([simHistory[0]])}
              className="text-xs text-slate-500 hover:text-slate-800 underline cursor-pointer"
            >
              চ্যাট মুছুন
            </button>
          </div>

          {/* Chat Messages */}
          <div className="h-96 overflow-y-auto space-y-3 p-4 bg-slate-950 rounded-2xl border border-slate-800">
            {simHistory.map((msg, idx) => (
              <div
                key={idx}
                className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl p-3.5 text-xs leading-relaxed whitespace-pre-wrap ${
                    msg.role === 'user'
                      ? 'bg-emerald-700 text-white rounded-tr-xs'
                      : 'bg-slate-900 text-emerald-200 border border-slate-800 rounded-tl-xs font-mono'
                  }`}
                >
                  {msg.mode && (
                    <div className="mb-1 text-[10px] uppercase font-bold tracking-widest text-amber-400">
                      ⚡ MODE: {msg.mode}
                    </div>
                  )}
                  {msg.text}
                </div>
                <span className="text-[10px] text-slate-500 mt-1 px-1">{msg.time}</span>
              </div>
            ))}
          </div>

          {/* Quick Suggestion Chips */}
          <div className="flex flex-wrap gap-2 pt-1">
            {[
              'এই NID থেকে তথ্য বের করো',
              'তথ্যগুলো যাচাই করো',
              'নাগরিক সনদ তৈরি করো',
              'Copy Ready দাও',
              'ট্রেড লাইসেন্স ফি কত?',
              'ওয়ার্ড ৪ এর গ্রামগুলো কী কী?'
            ].map(cmd => (
              <button
                key={cmd}
                onClick={() => {
                  setSimInput(cmd);
                }}
                className="px-3 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950 text-slate-700 dark:text-slate-300 hover:text-emerald-800 text-[11px] font-medium rounded-lg border border-slate-300 dark:border-slate-700 transition cursor-pointer"
              >
                {cmd}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <form onSubmit={handleSimSubmit} className="flex gap-2">
            <input
              type="text"
              value={simInput}
              onChange={e => setSimInput(e.target.value)}
              placeholder="বাংলায় কমান্ড লিখুন... (যেমন: নাগরিক সনদ তৈরি করো, Copy Ready দাও)"
              className="flex-1 px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-600 dark:text-white"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-amber-300 font-bold text-xs rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5 text-amber-300" />
              <span>রান করুন</span>
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
