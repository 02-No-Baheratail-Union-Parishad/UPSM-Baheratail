import { initializeApp, getApps, cert, App } from 'firebase-admin/app';
import { getFirestore, Firestore } from 'firebase-admin/firestore';
import fs from 'fs';
import path from 'path';

let adminApp: App | null = null;
let firestoreInstance: Firestore | null = null;
let firestoreCheckFailed = false;

function loadFirebaseConfig() {
  try {
    const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
    if (fs.existsSync(configPath)) {
      return JSON.parse(fs.readFileSync(configPath, 'utf8'));
    }
  } catch (_e) {
    // ignore
  }
  return {};
}

export function getFirebaseAdminApp(): App | null {
  if (adminApp) return adminApp;

  try {
    const existingApps = getApps();
    if (existingApps.length > 0 && existingApps[0]) {
      adminApp = existingApps[0];
      return adminApp;
    }

    const firebaseConfig = loadFirebaseConfig();
    const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;

    if (serviceAccountJson) {
      try {
        const credentials = JSON.parse(serviceAccountJson);
        adminApp = initializeApp({
          credential: cert(credentials),
          projectId: credentials.project_id || firebaseConfig.projectId
        });
        return adminApp;
      } catch (_err) {
        // service account JSON format issue
      }
    }

    if (firebaseConfig.projectId || process.env.GOOGLE_CLOUD_PROJECT) {
      const projectId = firebaseConfig.projectId || process.env.GOOGLE_CLOUD_PROJECT;
      adminApp = initializeApp({
        projectId
      });
      return adminApp;
    }

    return null;
  } catch (_error) {
    return null;
  }
}

export function getAdminFirestore(): Firestore | null {
  if (firestoreCheckFailed) return null;
  if (firestoreInstance) return firestoreInstance;

  const app = getFirebaseAdminApp();
  if (!app) {
    firestoreCheckFailed = true;
    return null;
  }

  try {
    const firebaseConfig = loadFirebaseConfig();
    const rawDbId = firebaseConfig.firestoreDatabaseId;
    const dbId = rawDbId && rawDbId !== '(default)' ? rawDbId : undefined;
    firestoreInstance = dbId ? getFirestore(app, dbId) : getFirestore(app);
    return firestoreInstance;
  } catch (_err) {
    firestoreCheckFailed = true;
    return null;
  }
}

export function markFirestoreUnavailable(): void {
  firestoreCheckFailed = true;
  firestoreInstance = null;
}
