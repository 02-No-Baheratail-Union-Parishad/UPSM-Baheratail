import React, { useState, useEffect } from 'react';
import {
  Brain,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  Lightbulb,
  Bug,
  Activity,
  FileText,
  RefreshCw,
  Sliders,
  Send,
  Lock,
  TrendingUp,
  Clock,
  Settings,
  Zap,
  Check,
  X,
  Filter,
  BarChart3,
  Bot,
  AlertCircle,
  HelpCircle,
  ArrowUpRight,
  Shield,
  Layers,
  ChevronRight,
  Eye,
  Bell,
  Cpu,
  Play,
  Pause,
  RotateCcw,
  Calendar,
  Mail,
  Globe,
  MessageSquare,
  Copy,
  ExternalLink,
  Search,
  CheckCheck,
  Trash2,
  ListChecks,
  CheckSquare,
  Database,
  FileSpreadsheet
} from 'lucide-react';
import {
  StructuredSupervisorEvent,
  CorrectionPatternRecord,
  BugCandidate,
  SupervisorIdea,
  DailyIntelligenceReport,
  SupervisorConfig,
  SupervisorAuditEntry,
  SupervisorSchedulerJob,
  SupervisorNotification
} from '../types';
import { AppsScriptModal } from './AppsScriptModal';
import { maskSensitiveData, syncSupervisorDatabase, createSupervisorGoogleSpreadsheet } from '../lib/googleSheets';

interface AiSupervisorDashboardProps {
  currentUserRole?: string;
  onNavigateToTab?: (tabId: string) => void;
}

export const AiSupervisorDashboard: React.FC<AiSupervisorDashboardProps> = ({
  currentUserRole = 'super_admin',
  onNavigateToTab
}) => {
  const [activeTab, setActiveTab] = useState<'briefing' | 'scheduler' | 'core_db' | 'patterns' | 'bugs' | 'ideas' | 'events' | 'chat' | 'settings'>('briefing');
  const [loading, setLoading] = useState<boolean>(true);
  const [scanning, setScanning] = useState<boolean>(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Core Database 6-Tab & Privacy Filter State
  const [isAppsScriptModalOpen, setIsAppsScriptModalOpen] = useState<boolean>(false);
  const [testPiiInput, setTestPiiInput] = useState<string>('আবেদনকারী মোঃ রহিম মিয়া, NID: 19909315784000555, ফোন: 01719876543, ইমেইল: rahim@gmail.com, গ্রাম: বহেড়াতৈল');
  const [maskedPiiOutput, setMaskedPiiOutput] = useState<string>(() => maskSensitiveData('আবেদনকারী মোঃ রহিম মিয়া, NID: 19909315784000555, ফোন: 01719876543, ইমেইল: rahim@gmail.com, গ্রাম: বহেড়াতৈল'));
  const [isSyncingSheets, setIsSyncingSheets] = useState<boolean>(false);
  const [createdSpreadsheetUrl, setCreatedSpreadsheetUrl] = useState<string | null>(null);

  // Dashboard Data
  const [config, setConfig] = useState<SupervisorConfig | null>(null);
  const [healthScore, setHealthScore] = useState<number>(95);
  const [stats, setStats] = useState<any>({
    totalCertificates: 0,
    approvedCertificates: 0,
    pendingCertificates: 0,
    correctionsToday: 0,
    validationFailures: 0,
    integrationErrors: 0,
    activeBugCandidates: 0,
    proposedIdeas: 0,
    approvedIdeas: 0
  });
  const [patterns, setPatterns] = useState<CorrectionPatternRecord[]>([]);
  const [bugs, setBugs] = useState<BugCandidate[]>([]);
  const [ideas, setIdeas] = useState<SupervisorIdea[]>([]);
  const [dailyReport, setDailyReport] = useState<DailyIntelligenceReport | null>(null);
  const [events, setEvents] = useState<StructuredSupervisorEvent[]>([]);
  const [auditLogs, setAuditLogs] = useState<SupervisorAuditEntry[]>([]);

  // Scheduler Data
  const [schedulerJobs, setSchedulerJobs] = useState<SupervisorSchedulerJob[]>([]);
  const [nextScheduledRun, setNextScheduledRun] = useState<string>('');
  const [isSchedulerRunning, setIsSchedulerRunning] = useState<boolean>(false);
  const [selectedJob, setSelectedJob] = useState<SupervisorSchedulerJob | null>(null);
  const [schedulerFilterType, setSchedulerFilterType] = useState<string>('all');
  const [schedulerFilterStatus, setSchedulerFilterStatus] = useState<string>('all');
  const [isTriggeringRunNow, setIsTriggeringRunNow] = useState<boolean>(false);
  const [isTestingNotification, setIsTestingNotification] = useState<boolean>(false);
  const [isTogglingPause, setIsTogglingPause] = useState<boolean>(false);
  const [copiedBriefing, setCopiedBriefing] = useState<boolean>(false);

  // Notifications Data
  const [notifications, setNotifications] = useState<SupervisorNotification[]>([]);
  const [unreadNotifsCount, setUnreadNotifsCount] = useState<number>(0);
  const [isNotifDropdownOpen, setIsNotifDropdownOpen] = useState<boolean>(false);

  // Event Filter
  const [eventFilterType, setEventFilterType] = useState<string>('all');
  const [eventFilterSeverity, setEventFilterSeverity] = useState<string>('all');

  // Interactive Chat
  const [chatInput, setChatInput] = useState<string>('');
  const [chatLoading, setChatLoading] = useState<boolean>(false);
  const [chatMessages, setChatMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string; time: string }>>([
    {
      role: 'assistant',
      text: 'আসসালামু আলাইকুম। আমি ইউপি সিস্টেমের ইন-বিল্ট এআই সুপারভাইজার। আমি সার্বক্ষণিক সিস্টেম কার্যক্রম, ডেটা ভ্যালিডেশন, ত্রুটির প্যাটার্ন ও দৈনিক শিডিউলার পর্যবেক্ষণ করছি। আপনি সিস্টেম স্বাস্থ্য, ত্রুটির সমাধান বা দৈনিক ব্রিফিং নিয়ে প্রশ্ন করতে পারেন।',
      time: '09:00 AM'
    }
  ]);

  // Load Dashboard Data
  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/ai-supervisor/dashboard');
      const data = await res.json();
      if (data.success) {
        setHealthScore(data.healthScore || 95);
        setStats(data.stats || {});
        setPatterns(data.correctionPatterns || []);
        setBugs(data.bugCandidates || []);
        setIdeas(data.ideas || []);
        setDailyReport(data.dailyReport || null);
        setEvents(data.recentEvents || []);
        setAuditLogs(data.auditLogs || []);
      }

      const confRes = await fetch('/api/ai-supervisor/config');
      const confData = await confRes.json();
      if (confData.success) {
        setConfig(confData.config);
      }

      // Fetch Scheduler Status & Notifications
      await fetchSchedulerStatus();
      await fetchNotifications();
    } catch (err: any) {
      console.error('Failed to load supervisor dashboard data:', err);
      setActionError('সুপারভাইজার ডেটা লোড করতে সমস্যা হইয়াছে।');
    } finally {
      setLoading(false);
    }
  };

  // Fetch Scheduler Status & Recent Jobs
  const fetchSchedulerStatus = async () => {
    try {
      const res = await fetch('/api/ai-supervisor/scheduler/status');
      const data = await res.json();
      if (data.success) {
        if (data.config) {
          setConfig(prev => ({ ...prev, ...data.config }));
        }
        setNextScheduledRun(data.nextScheduledRun || '');
        if (data.recentJobs) {
          setSchedulerJobs(data.recentJobs);
        }
        setUnreadNotifsCount(data.unreadNotificationsCount || 0);
      }
    } catch (err) {
      console.error('Failed to fetch scheduler status:', err);
    }
  };

  // Fetch In-App Notifications
  const fetchNotifications = async () => {
    try {
      const res = await fetch('/api/ai-supervisor/notifications');
      const data = await res.json();
      if (data.success) {
        setNotifications(data.notifications || []);
        setUnreadNotifsCount(data.unreadCount || 0);
      }
    } catch (err) {
      console.error('Failed to fetch supervisor notifications:', err);
    }
  };

  // Fetch All Scheduler Jobs
  const fetchSchedulerJobs = async () => {
    try {
      const res = await fetch('/api/ai-supervisor/scheduler/jobs?limit=50');
      const data = await res.json();
      if (data.success) {
        setSchedulerJobs(data.jobs || []);
      }
    } catch (err) {
      console.error('Failed to fetch jobs list:', err);
    }
  };

  useEffect(() => {
    fetchDashboardData();
    const timer = setInterval(() => {
      fetchSchedulerStatus();
      fetchNotifications();
    }, 30000); // 30s auto-refresh
    return () => clearInterval(timer);
  }, []);

  // Run AI Intelligence Scan
  const handleTriggerScan = async () => {
    try {
      setScanning(true);
      setActionSuccess(null);
      setActionError(null);
      const res = await fetch('/api/ai-supervisor/scan', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setActionSuccess(`এআই ইন্টেলিজেন্স স্ক্যান সফল (${data.scanDurationMs}ms)। নতুন রিপোর্ট তৈরি হইয়াছে।`);
        await fetchDashboardData();
      } else {
        setActionError(data.message || 'স্ক্যানে ত্রুটি ঘটিয়াছে।');
      }
    } catch (err: any) {
      setActionError(err.message || 'স্ক্যান রিকোয়েস্ট ব্যর্থ হইয়াছে।');
    } finally {
      setScanning(false);
    }
  };

  // Manual Trigger "RUN AI SUPERVISOR NOW"
  const handleRunNow = async () => {
    try {
      setIsTriggeringRunNow(true);
      setActionSuccess(null);
      setActionError(null);
      const res = await fetch('/api/ai-supervisor/scheduler/run-now', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setActionSuccess(`🚀 AI Supervisor সফলভাবে সম্পন্ন হয়েছে (${data.job?.durationMs || 0}ms)। হেলথ স্কোর: ${data.job?.healthScore || 96}%।`);
        await fetchDashboardData();
        await fetchSchedulerJobs();
      } else {
        setActionError(data.message || 'টাস্ক এক্সিকিউশন ব্যর্থ হয়েছে।');
      }
    } catch (err: any) {
      setActionError(err.message || 'টাস্ক রান রিকোয়েস্ট ব্যর্থ হয়েছে।');
    } finally {
      setIsTriggeringRunNow(false);
    }
  };

  // Toggle Pause/Resume Scheduler
  const handleTogglePause = async () => {
    try {
      setIsTogglingPause(true);
      const res = await fetch('/api/ai-supervisor/scheduler/toggle-pause', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setActionSuccess(data.message);
        if (config) {
          setConfig({ ...config, schedulerStatus: data.schedulerStatus });
        }
        await fetchSchedulerStatus();
      } else {
        setActionError(data.message || 'পজ পরিবর্তন ব্যর্থ হয়েছে।');
      }
    } catch (err: any) {
      setActionError(err.message);
    } finally {
      setIsTogglingPause(false);
    }
  };

  // Test Notification Broadcast
  const handleTestNotification = async () => {
    try {
      setIsTestingNotification(true);
      const res = await fetch('/api/ai-supervisor/scheduler/test-notification', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setActionSuccess(data.message);
        await fetchNotifications();
      } else {
        setActionError(data.message || 'টেস্ট নোটিফিকেশন পাঠাতে সমস্যা হয়েছে।');
      }
    } catch (err: any) {
      setActionError(err.message);
    } finally {
      setIsTestingNotification(false);
    }
  };

  // Mark single notification read
  const handleMarkNotifRead = async (notifId: string) => {
    try {
      await fetch(`/api/ai-supervisor/notifications/${notifId}/read`, { method: 'PATCH' });
      setNotifications(prev => prev.map(n => n.id === notifId ? { ...n, isRead: true } : n));
      setUnreadNotifsCount(prev => Math.max(0, prev - 1));
    } catch (e) {
      console.error(e);
    }
  };

  // Mark all notifications read
  const handleMarkAllNotifsRead = async () => {
    try {
      await fetch('/api/ai-supervisor/notifications/mark-all-read', { method: 'POST' });
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
      setUnreadNotifsCount(0);
      setActionSuccess('সকল নোটিফিকেশন পঠিত হিসেবে চিহ্নিত হয়েছে।');
    } catch (e) {
      console.error(e);
    }
  };

  // Save Scheduler Config
  const handleSaveSchedulerConfig = async (updatedFields: Partial<SupervisorConfig>) => {
    try {
      const res = await fetch('/api/ai-supervisor/scheduler/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedFields)
      });
      const data = await res.json();
      if (data.success) {
        setConfig(data.config);
        if (data.nextScheduledRun) {
          setNextScheduledRun(data.nextScheduledRun);
        }
        setActionSuccess('শিডিউলার সেটিংস সফলভাবে আপডেট হয়েছে।');
      } else {
        setActionError(data.message);
      }
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  // Update Bug Status
  const handleUpdateBugStatus = async (bugId: string, newStatus: string) => {
    try {
      const res = await fetch(`/api/ai-supervisor/bugs/${bugId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus, resolvedBy: currentUserRole })
      });
      const data = await res.json();
      if (data.success) {
        setActionSuccess(data.message);
        await fetchDashboardData();
      } else {
        setActionError(data.message);
      }
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  // Update Idea Status
  const handleUpdateIdeaStatus = async (ideaId: string, newStatus: string) => {
    try {
      const res = await fetch(`/api/ai-supervisor/ideas/${ideaId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus, reviewedBy: currentUserRole })
      });
      const data = await res.json();
      if (data.success) {
        setActionSuccess(data.message);
        await fetchDashboardData();
      } else {
        setActionError(data.message);
      }
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  // Send Chat Message
  const handleSendChat = async () => {
    if (!chatInput.trim() || chatLoading) return;
    const userText = chatInput.trim();
    setChatInput('');

    const newMsg = {
      role: 'user' as const,
      text: userText,
      time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, newMsg]);
    setChatLoading(true);

    try {
      const historyPayload = chatMessages.slice(-6).map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const res = await fetch('/api/ai-supervisor/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userText, history: historyPayload })
      });
      const data = await res.json();
      if (data.success) {
        setChatMessages(prev => [
          ...prev,
          {
            role: 'assistant',
            text: data.reply,
            time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      } else {
        setChatMessages(prev => [
          ...prev,
          {
            role: 'assistant',
            text: 'দুঃখিত, তথ্য প্রক্রিয়া করতে সমস্যা হইয়াছে। অনুগ্রহ করে আবার চেষ্টা করুন।',
            time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      }
    } catch (err) {
      setChatMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          text: 'সার্ভার সংযোগে ত্রুটি দেখা দিয়াছে।',
          time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  // Copy Executive Briefing to Clipboard
  const handleCopyBriefing = () => {
    if (!dailyReport) return;
    const text = `🏛️ ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ
🧠 এআই সুপারভাইজার দৈনিক নির্বাহী ব্রিফিং (${dailyReport.reportDate})
───────────────────────────────
📊 সিস্টেম স্বাস্থ্য স্কোর: ${dailyReport.health.healthScore}%
⏱️ গড় সনদ অনুমোদন সময়: ${dailyReport.health.avgApprovalMinutes} মিনিট

🔴 জরুরি বিষয়:
${dailyReport.briefing.urgentItems.map(i => `• ${i}`).join('\n')}

🟡 নজর রাখা প্রয়োজন:
${dailyReport.briefing.watchItems.map(i => `• ${i}`).join('\n')}

🟢 ভালো অগ্রগতি:
${dailyReport.briefing.goodProgress.map(i => `• ${i}`).join('\n')}

💡 আজকের এআই আইডিয়া:
${dailyReport.briefing.todaysIdea}

🛠️ প্রস্তাবিত পদক্ষেপ:
${dailyReport.briefing.recommendedActions.map((a, i) => `${i + 1}. ${a}`).join('\n')}
───────────────────────────────
স্বয়ংক্রিয়ভাবে প্রস্তুতকৃত এআই অডিট রিপোর্ট`;

    navigator.clipboard.writeText(text);
    setCopiedBriefing(true);
    setTimeout(() => setCopiedBriefing(false), 3000);
  };

  const filteredEvents = events.filter(e => {
    if (eventFilterType !== 'all' && e.eventType !== eventFilterType) return false;
    if (eventFilterSeverity !== 'all' && e.severity !== eventFilterSeverity) return false;
    return true;
  });

  const filteredJobs = schedulerJobs.filter(j => {
    if (schedulerFilterType !== 'all' && j.scheduleType !== schedulerFilterType) return false;
    if (schedulerFilterStatus !== 'all' && j.status !== schedulerFilterStatus) return false;
    return true;
  });

  // Calculate Dhaka time representation
  const formatDhakaDateTime = (isoString?: string) => {
    if (!isoString) return 'নির্ধারিত নেই';
    try {
      return new Date(isoString).toLocaleString('bn-BD', {
        timeZone: 'Asia/Dhaka',
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
    } catch {
      return isoString;
    }
  };

  const handleTestPiiChange = (val: string) => {
    setTestPiiInput(val);
    setMaskedPiiOutput(maskSensitiveData(val));
  };

  const handleSyncSupervisorGoogleSheets = async () => {
    try {
      setIsSyncingSheets(true);
      setActionError(null);
      setActionSuccess(null);

      const res = await syncSupervisorDatabase({
        applications: [
          {
            id: 'APP-26-001',
            createdAt: new Date().toISOString(),
            issueDate: new Date().toISOString().slice(0, 10),
            issueDateEn: new Date().toISOString().slice(0, 10),
            memoNo: 'BUP/2026/001',
            typeKey: 'citizenship',
            typeLabel: 'নাগরিক সনদ',
            category: 'নাগরিকত্ব ও পরিচয়',
            citizen: {
              name: 'মোঃ রহিম মিয়া',
              father: 'মৃত আলতাফ আলী',
              mother: 'আলেয়া বেগম',
              gender: 'পুরুষ',
              mobile: '01719876543',
              village: 'বহেড়াতৈল',
              postOffice: 'বহেড়াতৈল',
              wardNo: '১'
            },
            extra: { simpleFields: {}, tables: {} },
            bodyText: 'এই মর্মে প্রত্যয়ন করা যাইতেছে...',
            verificationUrl: 'https://boheratoil.gov.bd/verify/APP-26-001',
            issuedBy: 'Operator',
            status: 'approved'
          }
        ],
        eventLogs: events.map(e => ({
          id: e.id,
          timestamp: e.timestamp,
          category: e.eventType,
          module: e.module,
          actionBy: e.actor,
          description: e.details,
          status: e.severity === 'critical' ? 'Error' : 'Success'
        })),
        corrections: patterns.map(p => ({
          id: `COR-${p.field}`,
          timestamp: p.lastObserved,
          refAppId: 'APP-26-001',
          fieldName: p.field,
          oldValue: p.typicalError,
          newValue: p.suggestedRemedy,
          reason: p.rootCause,
          correctedBy: 'Operator'
        })),
        recommendations: ideas.map(i => ({
          id: i.id,
          dateGenerated: i.proposedAt,
          category: i.category,
          title: i.title,
          rootCause: i.problemSolved,
          proposedFix: i.solutionSummary,
          confidenceScore: i.expectedImpactScore,
          priority: i.priority,
          adminAction: i.status === 'approved' ? 'Approved' : i.status === 'rejected' ? 'Rejected' : 'Pending',
          actionDate: i.proposedAt
        })),
        knowledgePatterns: [
          {
            patternId: 'PAT-01',
            dateDiscovered: '2026-08-20',
            insight: 'নাগরিকের জন্মতারিখ OCR রিড করার সময় DD-MM-YYYY ফরম্যাট কনফিউশন ঘটে',
            impact: 'Medium',
            status: 'Active'
          },
          {
            patternId: 'PAT-02',
            dateDiscovered: '2026-08-21',
            insight: 'বহেড়াতৈল ইউনিয়নের ২০টি অনুমোদিত গ্রামের বানানের সাথে এনআইডি ঠিকানার গরমিল',
            impact: 'High',
            status: 'Active'
          }
        ],
        settings: [
          { settingName: 'AI_Run_Time', settingValue: config?.scheduledTime || '09:00 AM', status: config?.isEnabled ? 'ON' : 'OFF' },
          { settingName: 'Report_Frequency', settingValue: config?.frequency || 'Daily', status: 'ON' },
          { settingName: 'Timezone', settingValue: config?.timezone || 'Asia/Dhaka', status: 'ON' },
          { settingName: 'PII_Masking_Strictness', settingValue: 'Level_3_Full_Mask', status: 'ON' },
          { settingName: 'Admin_Notification_Email', settingValue: config?.emailRecipients?.join(', ') || 'admin@boheratoil.gov.bd', status: 'ON' }
        ]
      });

      if (res.success) {
        if (res.spreadsheetUrl) {
          setCreatedSpreadsheetUrl(res.spreadsheetUrl);
        }
        setActionSuccess(res.message || '৬টি মূল শিটের কোর ডাটাবেস সফলভাবে প্রস্তুত ও সিঙ্ক হয়েছে!');
      } else {
        setActionError(res.message || 'সিঙ্ক করতে সমস্যা হয়েছে।');
      }
    } catch (err: any) {
      setActionError(err.message || 'ডাটাবেস সিঙ্কে ত্রুটি ঘটেছে।');
    } finally {
      setIsSyncingSheets(false);
    }
  };

  return (
    <div id="ai-supervisor-dashboard-container" className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 1. Header & Live Intelligence Status Banner */}
      <div id="supervisor-header" className="bg-gradient-to-br from-emerald-900 via-slate-900 to-teal-950 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-emerald-500/30 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                <Brain className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
                SYSTEM INTELLIGENCE & SCHEDULER
              </span>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs bg-slate-800 text-slate-300 border border-slate-700">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                Strict PII Masked
              </span>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs bg-cyan-950/80 text-cyan-300 border border-cyan-700/50">
                <Cpu className="w-3 h-3 text-cyan-400" />
                Gemini 2.5 Flash Core
              </span>
              <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                config?.schedulerStatus === 'paused'
                  ? 'bg-amber-950 text-amber-300 border border-amber-600/60'
                  : config?.isEnabled
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-600/60'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}>
                <Clock className="w-3 h-3" />
                {config?.schedulerStatus === 'paused' ? 'শিডিউলার: পজড ⏸️' : config?.isEnabled ? `অটো-রান: ${config?.scheduledTime || '09:00 AM'} 🟢` : 'শিডিউলার নিষ্ক্রিয় ⚪'}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2">
              🧠 ইন-বিল্ট এআই সুপারভাইজার ও অটোমেশন শিডিউলার
            </h1>
            <p className="text-slate-300 text-sm max-w-3xl leading-relaxed">
              সার্বক্ষণিক সিস্টেম ইভেন্ট পর্যবেক্ষণ, দৈনিক স্বয়ংক্রিয় ইন্টেলিজেন্স স্ক্যান, ভুল ও সংশোধনের রুট কজ বিশ্লেষণ এবং স্বয়ংক্রিয় মাল্টি-চ্যানেল ব্রিফিং ডিসপ্যাচার।
            </p>
          </div>

          {/* Quick Action Buttons & Status */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Notification Center Trigger */}
            <div className="relative">
              <button
                id="btn-supervisor-notifications"
                onClick={() => setIsNotifDropdownOpen(!isNotifDropdownOpen)}
                className="relative p-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-600/60 transition cursor-pointer flex items-center justify-center"
                title="এআই সুপারভাইজার নোটিফিকেশন"
              >
                <Bell className="w-5 h-5 text-amber-400" />
                {unreadNotifsCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 px-1.5 py-0.5 rounded-full text-[10px] font-black bg-rose-500 text-white animate-bounce shadow-md">
                    {unreadNotifsCount}
                  </span>
                )}
              </button>

              {/* Notification Popover Drawer */}
              {isNotifDropdownOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl z-50 overflow-hidden text-slate-800 dark:text-slate-100">
                  <div className="p-3.5 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Bell className="w-4 h-4 text-amber-500" />
                      <span className="font-bold text-xs sm:text-sm">সুপারভাইজার নোটিফিকেশন</span>
                      {unreadNotifsCount > 0 && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                          {unreadNotifsCount}টি নতুন
                        </span>
                      )}
                    </div>
                    {unreadNotifsCount > 0 && (
                      <button
                        onClick={handleMarkAllNotifsRead}
                        className="text-[11px] font-semibold text-emerald-600 hover:text-emerald-500 cursor-pointer flex items-center gap-1"
                      >
                        <CheckCheck className="w-3.5 h-3.5" />
                        পঠিত করুন
                      </button>
                    )}
                  </div>

                  <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                    {notifications.length === 0 ? (
                      <div className="p-6 text-center text-xs text-slate-500">
                        কোনো নোটিফিকেশন পাওয়া যায়নি।
                      </div>
                    ) : (
                      notifications.map(notif => (
                        <div
                          key={notif.id}
                          className={`p-3.5 space-y-1.5 transition ${
                            notif.isRead ? 'bg-transparent' : 'bg-emerald-50/50 dark:bg-emerald-950/20'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-1.5">
                              <span className={`w-2 h-2 rounded-full ${notif.isRead ? 'bg-slate-300' : 'bg-emerald-500'}`} />
                              <h4 className="font-bold text-xs text-slate-800 dark:text-white">
                                {notif.title}
                              </h4>
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {new Date(notif.timestamp).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug">
                            {notif.message}
                          </p>
                          {notif.bulletPoints && notif.bulletPoints.length > 0 && (
                            <ul className="text-[10px] text-slate-500 dark:text-slate-400 space-y-0.5 pl-2 border-l border-emerald-500/30">
                              {notif.bulletPoints.slice(0, 3).map((bp, idx) => (
                                <li key={idx} className="line-clamp-1">{bp}</li>
                              ))}
                            </ul>
                          )}
                          {!notif.isRead && (
                            <div className="pt-1 flex justify-end">
                              <button
                                onClick={() => handleMarkNotifRead(notif.id)}
                                className="text-[10px] text-emerald-600 hover:text-emerald-500 font-medium cursor-pointer"
                              >
                                পঠিত হিসেবে চিহ্নিত করুন
                              </button>
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Run Now Button */}
            <button
              id="btn-trigger-ai-run-now"
              onClick={handleRunNow}
              disabled={isTriggeringRunNow || scanning}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-xs sm:text-sm text-white bg-emerald-600 hover:bg-emerald-500 active:scale-98 transition shadow-lg shadow-emerald-900/40 disabled:opacity-50 cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isTriggeringRunNow ? 'animate-spin' : ''}`} />
              {isTriggeringRunNow ? 'টাস্ক চলছে...' : 'এখনই রান করুন (Run Now)'}
            </button>

            {/* Scheduler Tab Shortcut */}
            <button
              id="btn-goto-scheduler-tab"
              onClick={() => setActiveTab('scheduler')}
              className="inline-flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl font-semibold text-xs sm:text-sm text-slate-200 bg-slate-800/90 hover:bg-slate-700 border border-slate-600/50 transition cursor-pointer"
            >
              <Clock className="w-4 h-4 text-teal-400" />
              শিডিউলার কন্ট্রোল
            </button>
          </div>
        </div>

        {/* Global Alert Banners */}
        {actionSuccess && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-900/60 border border-emerald-500/50 text-emerald-200 text-sm flex items-center justify-between animate-fadeIn">
            <span className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              {actionSuccess}
            </span>
            <button onClick={() => setActionSuccess(null)} className="text-emerald-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {actionError && (
          <div className="mt-4 p-3 rounded-xl bg-rose-900/60 border border-rose-500/50 text-rose-200 text-sm flex items-center justify-between animate-fadeIn">
            <span className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              {actionError}
            </span>
            <button onClick={() => setActionError(null)} className="text-rose-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* 2. Top Bento Health & Key Metrics Grid */}
      <div id="supervisor-metrics-grid" className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Health Score Gauge */}
        <div className="col-span-2 sm:col-span-1 bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>সিস্টেম হেলথ স্কোর</span>
            <Activity className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="my-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">{healthScore}%</span>
            <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">উৎকৃষ্ট</span>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
            <div className="bg-emerald-500 h-full rounded-full transition-all duration-500" style={{ width: `${healthScore}%` }}></div>
          </div>
        </div>

        {/* Certificates & Apps */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>বিশ্লেষিত সনদপত্র</span>
            <FileText className="w-4 h-4 text-blue-500" />
          </div>
          <div className="my-2">
            <span className="text-2xl font-bold text-slate-800 dark:text-white">{stats.totalCertificates || 42}</span>
          </div>
          <span className="text-xs text-slate-500">অনুমোদিত: {stats.approvedCertificates || 40}টি</span>
        </div>

        {/* Next Scheduled Scan */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>পরবর্তী স্ক্যান রান</span>
            <Clock className="w-4 h-4 text-teal-500" />
          </div>
          <div className="my-2">
            <span className="text-sm font-bold text-teal-600 dark:text-teal-400">
              {config?.scheduledTime || '09:00'} (ঢাকা)
            </span>
          </div>
          <span className="text-[11px] text-slate-500 line-clamp-1">
            {config?.schedulerStatus === 'paused' ? '⏸️ সাময়িক পজড' : '🟢 নিয়মিত অটো-শিডিউল'}
          </span>
        </div>

        {/* Bug Candidates */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>বাগ ক্যান্ডিডেট</span>
            <Bug className="w-4 h-4 text-rose-500" />
          </div>
          <div className="my-2">
            <span className="text-2xl font-bold text-rose-600 dark:text-rose-400">
              {bugs.filter(b => b.status === 'open' || b.status === 'in_review').length}টি
            </span>
          </div>
          <span className="text-xs text-slate-500">সমাধান হয়েছে: {bugs.filter(b => b.status === 'resolved').length}টি</span>
        </div>

        {/* Proposed Ideas */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>অটোমেশন আইডিয়া</span>
            <Lightbulb className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="my-2">
            <span className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">{ideas.length}টি</span>
          </div>
          <span className="text-xs text-slate-500">অনুমোদিত: {ideas.filter(i => i.status === 'approved' || i.status === 'in_progress').length}টি</span>
        </div>

        {/* Total Tasks Run */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>মোট শিডিউলার রান</span>
            <CheckSquare className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="my-2">
            <span className="text-2xl font-bold text-slate-800 dark:text-white">
              {schedulerJobs.length || 1}
            </span>
          </div>
          <span className="text-xs text-emerald-600 font-medium">১০০% সফল</span>
        </div>
      </div>

      {/* 3. Tab Navigation Bar */}
      <div id="supervisor-tabs-nav" className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-slate-200 dark:border-slate-800">
        {[
          { id: 'briefing', label: '📊 দৈনিক ইন্টেলিজেন্স রিপোর্ট', icon: BarChart3 },
          { id: 'scheduler', label: '⏰ শিডিউলার ও অটোমেশন হাব', icon: Clock, badge: unreadNotifsCount },
          { id: 'core_db', label: '🗄️ কোর ডাটাবেস (৬-ট্যাব)', icon: Database },
          { id: 'patterns', label: '🧠 লার্নিং ও কারেকশন প্যাটার্নস', icon: Brain, badge: patterns.length },
          { id: 'bugs', label: '🐛 বাগ ক্যান্ডিডেটস', icon: Bug, badge: bugs.filter(b => b.status === 'open').length },
          { id: 'ideas', label: '💡 সুপারভাইজার আইডিয়াবক্স', icon: Lightbulb, badge: ideas.filter(i => i.status === 'proposed').length },
          { id: 'events', label: '📡 লাইভ ইভেন্ট স্ট্রিম', icon: Activity, badge: events.length },
          { id: 'chat', label: '💬 সুপারভাইজার চ্যাট', icon: Bot },
          { id: 'settings', label: '⚙️ সুপারভাইজার পলিসি ও রুলস', icon: Sliders }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`tab-btn-${tab.id}`}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition cursor-pointer ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/20'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge !== undefined && tab.badge > 0 && (
                <span className={`px-1.5 py-0.2 rounded-full text-xs font-semibold ${
                  isActive ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* 4. Tab Contents */}

      {/* TAB 1: Daily Intelligence Briefing */}
      {activeTab === 'briefing' && (
        <div id="tab-content-briefing" className="space-y-6">
          {dailyReport ? (
            <>
              {/* Daily Report Executive Header */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
                  <div>
                    <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 tracking-wider uppercase">
                      DAILY AI INTELLIGENCE SCAN & EXECUTIVE BRIEFING
                    </span>
                    <h2 className="text-xl font-bold text-slate-800 dark:text-white mt-1">
                      তারিখ: {dailyReport.reportDate}
                    </h2>
                    <p className="text-xs text-slate-500">
                      জেনারেট সময়: {new Date(dailyReport.generatedAt).toLocaleString('bn-BD')} | সংস্করণ: {dailyReport.version}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={handleCopyBriefing}
                      className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                    >
                      {copiedBriefing ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      <span>{copiedBriefing ? 'কপি হয়েছে!' : 'হোয়াটসঅ্যাপ / টিম স্পেস কপি'}</span>
                    </button>
                    <span className="px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4" />
                      কোয়ালিটি স্কোর: {dailyReport.health.healthScore}%
                    </span>
                  </div>
                </div>

                {/* 5-Block Executive Briefing */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {/* 🔴 জরুরি (Urgent) */}
                  <div className="bg-rose-50/70 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 rounded-xl p-4 space-y-2">
                    <div className="flex items-center gap-2 text-rose-700 dark:text-rose-400 font-semibold text-sm">
                      <AlertTriangle className="w-4 h-4" />
                      <span>🔴 জরুরি নজর (Urgent Attention)</span>
                    </div>
                    <ul className="space-y-1.5 text-xs text-rose-900 dark:text-rose-200">
                      {dailyReport.briefing.urgentItems.map((item, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-rose-500">•</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* 🟡 নজর দেওয়া দরকার (Watch) */}
                  <div className="bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 rounded-xl p-4 space-y-2">
                    <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400 font-semibold text-sm">
                      <Eye className="w-4 h-4" />
                      <span>🟡 নজর রাখা প্রয়োজন (Watch Items)</span>
                    </div>
                    <ul className="space-y-1.5 text-xs text-amber-900 dark:text-amber-200">
                      {dailyReport.briefing.watchItems.map((item, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-amber-500">•</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* 🟢 ভালো হয়েছে (Good Progress) */}
                  <div className="bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 rounded-xl p-4 space-y-2">
                    <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 font-semibold text-sm">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>🟢 ভালো অগ্রগতি (Good Progress)</span>
                    </div>
                    <ul className="space-y-1.5 text-xs text-emerald-900 dark:text-emerald-200">
                      {dailyReport.briefing.goodProgress.map((item, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-emerald-500">•</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Today's Breakthrough Idea Banner */}
                <div className="bg-gradient-to-r from-indigo-50 via-purple-50 to-blue-50 dark:from-indigo-950/30 dark:via-purple-950/30 dark:to-blue-950/30 border border-indigo-200 dark:border-indigo-800/50 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-lg bg-indigo-600 text-white shrink-0">
                      <Lightbulb className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-indigo-900 dark:text-indigo-200">
                        💡 আজকের প্রস্তাবিত এআই আইডিয়া (Today's Breakthrough Idea)
                      </h4>
                      <p className="text-xs text-indigo-800 dark:text-indigo-300 mt-0.5">
                        {dailyReport.briefing.todaysIdea}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab('ideas')}
                    className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 text-white hover:bg-indigo-500 transition shrink-0 cursor-pointer"
                  >
                    আইডিয়া দেখুন ও অনুমোদন দিন →
                  </button>
                </div>

                {/* 🛠️ Recommended Action Checklist */}
                <div className="border-t border-slate-100 dark:border-slate-800 pt-4">
                  <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-200 mb-2 flex items-center gap-2">
                    <Zap className="w-4 h-4 text-emerald-500" />
                    প্রস্তাবিত পদক্ষেপ (Recommended Human Actions):
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {dailyReport.briefing.recommendedActions.map((act, i) => (
                      <div key={i} className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-xs text-slate-700 dark:text-slate-300 flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300 font-bold flex items-center justify-center text-[10px] shrink-0">
                          {i + 1}
                        </span>
                        <span>{act}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Data Quality & Top Corrected Fields Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Top Corrected Fields Bar Chart Visual */}
                <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-amber-500" />
                      সর্বাধিক সংশোধিত ফিল্ডসমূহ (Top Correction Patterns)
                    </h3>
                    <span className="text-xs text-slate-500">বিগত ৩০ দিন</span>
                  </div>
                  <div className="space-y-3">
                    {dailyReport.topCorrectedFields.map((f, i) => (
                      <div key={i} className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-medium text-slate-700 dark:text-slate-300">{f.field}</span>
                          <span className="text-slate-500">{f.count} বার ({f.percentage}%)</span>
                        </div>
                        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              i === 0 ? 'bg-amber-500' : i === 1 ? 'bg-blue-500' : i === 2 ? 'bg-teal-500' : 'bg-purple-500'
                            }`}
                            style={{ width: `${Math.min(100, f.percentage * 2)}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Risk Assessment Matrix */}
                <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-2">
                      <Shield className="w-4 h-4 text-indigo-500" />
                      সার্বিক ঝুঁকি মূল্যায়ন (Risk Assessment Matrix)
                    </h3>
                    <span className="text-xs text-emerald-500 font-semibold">নিরাপদ জোন</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                      <span className="text-xs text-slate-500">ডাটা কোয়ালিটি রিস্ক</span>
                      <div className="mt-1 flex items-center gap-1.5 text-sm font-bold text-emerald-600">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{dailyReport.risks.dataQualityRisk}</span>
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                      <span className="text-xs text-slate-500">সিকিউরিটি ও প্রাইভেসি রিস্ক</span>
                      <div className="mt-1 flex items-center gap-1.5 text-sm font-bold text-emerald-600">
                        <ShieldCheck className="w-4 h-4" />
                        <span>{dailyReport.risks.securityRisk}</span>
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                      <span className="text-xs text-slate-500">ইন্টিগ্রেশন ও API রিস্ক</span>
                      <div className="mt-1 flex items-center gap-1.5 text-sm font-bold text-amber-600">
                        <AlertTriangle className="w-4 h-4" />
                        <span>{dailyReport.risks.integrationRisk}</span>
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                      <span className="text-xs text-slate-500">ওয়ার্কফ্লো ও অনুমোদন রিস্ক</span>
                      <div className="mt-1 flex items-center gap-1.5 text-sm font-bold text-emerald-600">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{dailyReport.risks.workflowRisk}</span>
                      </div>
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs text-slate-600 dark:text-slate-400 space-y-1">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">🧠 এআই লার্নিং সামারি:</span>
                    <p>{dailyReport.aiLearnings[0] || 'পিতার নামের বানানে বাংলা টাইপিংয়ে সর্বাধিক সতর্কতা প্রয়োজন।'}</p>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-12 text-center border border-slate-200 dark:border-slate-800">
              <Brain className="w-12 h-12 text-slate-400 mx-auto mb-3 animate-pulse" />
              <h3 className="text-base font-semibold text-slate-700 dark:text-slate-300">কোনো দৈনিক রিপোর্ট তৈরি হয়নি</h3>
              <p className="text-xs text-slate-500 mt-1 mb-4">স্বয়ংক্রিয় এআই স্ক্যান চালিয়ে আজকের ইন্টেলিজেন্স রিপোর্ট তৈরি করুন।</p>
              <button
                onClick={handleTriggerScan}
                disabled={scanning}
                className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold cursor-pointer"
              >
                এখনই স্ক্যান চালান
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: DAILY AI SUPERVISOR SCHEDULER & AUTOMATION HUB */}
      {activeTab === 'scheduler' && (
        <div id="tab-content-scheduler" className="space-y-6 animate-fadeIn">
          {/* Top Live Scheduler Hero Card */}
          <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 rounded-2xl p-6 border border-emerald-500/30 text-white shadow-lg space-y-6">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" />
                    AUTONOMOUS SCHEDULER CONTROLLER
                  </span>
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                    config?.schedulerStatus === 'paused'
                      ? 'bg-amber-500 text-slate-950'
                      : config?.isEnabled
                      ? 'bg-emerald-500 text-slate-950 animate-pulse'
                      : 'bg-slate-600 text-slate-200'
                  }`}>
                    {config?.schedulerStatus === 'paused' ? '⏸️ PAUSED (স্থগিত)' : config?.isEnabled ? '🟢 ACTIVE (সচল)' : '⚪ DISABLED (নিষ্ক্রিয়)'}
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
                  দৈনিক স্বয়ংক্রিয় স্ক্যান ও ইন্টেলিজেন্স ডিসপ্যাচার
                </h2>
                <p className="text-slate-300 text-xs sm:text-sm max-w-2xl">
                  প্রতিদিন নির্ধারিত সময়ে (ডিফল্ট: সকাল ০৯:০০ AM) পূর্ববর্তী ২৪ ঘণ্টার সকল ইভেন্ট প্রাইভেসি ফিল্টারিং শেষে ডিপ এআই স্ক্যান পরিচালনা করে এবং অ্যাডমিনদের নোটিফিকেশন পাঠায়।
                </p>
              </div>

              {/* Action Controls */}
              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  onClick={handleRunNow}
                  disabled={isTriggeringRunNow}
                  className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold shadow-md flex items-center gap-2 transition disabled:opacity-50 cursor-pointer"
                >
                  <RefreshCw className={`w-4 h-4 ${isTriggeringRunNow ? 'animate-spin' : ''}`} />
                  {isTriggeringRunNow ? 'টাস্ক রান হচ্ছে...' : '🚀 এখনই রান করুন (Run Now)'}
                </button>

                <button
                  onClick={handleTogglePause}
                  disabled={isTogglingPause}
                  className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold border transition flex items-center gap-2 cursor-pointer ${
                    config?.schedulerStatus === 'paused'
                      ? 'bg-emerald-700/80 hover:bg-emerald-600 text-white border-emerald-500'
                      : 'bg-amber-600/80 hover:bg-amber-500 text-white border-amber-500'
                  }`}
                >
                  {config?.schedulerStatus === 'paused' ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                  <span>{config?.schedulerStatus === 'paused' ? 'পুনরায় চালু করুন' : 'সাময়িক স্থগিত (Pause)'}</span>
                </button>

                <button
                  onClick={handleTestNotification}
                  disabled={isTestingNotification}
                  className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-600 text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Bell className="w-4 h-4" />
                  <span>{isTestingNotification ? 'টেস্ট চলছে...' : 'নোটিফিকেশন টেস্ট'}</span>
                </button>
              </div>
            </div>

            {/* Execution Schedule & Status Ribbon */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-3 border-t border-slate-800">
              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-1">
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-teal-400" />
                  পরবর্তী নির্ধারিত রান (Dhaka Time)
                </span>
                <p className="text-xs sm:text-sm font-bold text-teal-300">
                  {formatDhakaDateTime(nextScheduledRun)}
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-1">
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  সর্বশেষ রানের স্ট্যাটাস
                </span>
                <p className="text-xs sm:text-sm font-bold text-emerald-300 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {config?.lastRunStatus || 'COMPLETED'}
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-1">
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                  মিসড টাস্ক রিকভারি
                </span>
                <p className="text-xs sm:text-sm font-bold text-amber-300">
                  স্বয়ংক্রিয় সক্রিয় (On Server Wake)
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-1">
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                  ম্যাক্স রিট্রাই লিমিট
                </span>
                <p className="text-xs sm:text-sm font-bold text-cyan-300">
                  ৩ বার (Exponential Backoff)
                </p>
              </div>
            </div>
          </div>

          {/* Scheduler & Multi-Channel Notification Policy Configuration */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Config Form (7 Cols) */}
            <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <h3 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-2">
                  <Sliders className="w-5 h-5 text-emerald-600" />
                  শিডিউলার ও নোটিফিকেশন পলিসি কনফিগারেশন
                </h3>
                <span className="text-xs text-slate-500">Asia/Dhaka UTC+6</span>
              </div>

              <div className="space-y-4 text-xs sm:text-sm">
                {/* Auto Enable Toggle & Time */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      স্বয়ংক্রিয় শিডিউলার স্ট্যাটাস
                    </label>
                    <button
                      type="button"
                      onClick={() => handleSaveSchedulerConfig({ isEnabled: !config?.isEnabled })}
                      className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer ${
                        config?.isEnabled
                          ? 'bg-emerald-600 text-white hover:bg-emerald-500 shadow'
                          : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {config?.isEnabled ? <CheckCircle2 className="w-4 h-4" /> : <X className="w-4 h-4" />}
                      <span>{config?.isEnabled ? 'শিডিউল সক্রিয় (Active)' : 'শিডিউল নিষ্ক্রিয় (Disabled)'}</span>
                    </button>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      দৈনিক স্ক্যান সময় (ঘন্টা:মিনিট)
                    </label>
                    <input
                      type="time"
                      value={config?.scheduledTime || '09:00'}
                      onChange={(e) => handleSaveSchedulerConfig({ scheduledTime: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-white font-mono text-xs focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                {/* Frequency & Timezone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      রান ফ্রিকোয়েন্সি
                    </label>
                    <select
                      value={config?.frequency || 'daily'}
                      onChange={(e) => handleSaveSchedulerConfig({ frequency: e.target.value as any })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-white text-xs focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="daily">প্রতিদিন ১ বার (Default 09:00 AM)</option>
                      <option value="twice_daily">দিনে ২ বার (সকাল ০৯:০০ ও বিকাল ০৫:০০)</option>
                      <option value="hourly">প্রতি ঘণ্টায় (Dense Audit Mode)</option>
                      <option value="manual">শুধুমাত্র ম্যানুয়াল রান</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      টাইমজোন
                    </label>
                    <input
                      type="text"
                      disabled
                      value={config?.timezone || 'Asia/Dhaka'}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/50 text-slate-500 text-xs font-mono"
                    />
                  </div>
                </div>

                {/* Email Recipient & Webhook URL */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      ইমেইল রিসিভার
                    </label>
                    <input
                      type="email"
                      placeholder="inbox600900@gmail.com"
                      value={config?.emailRecipient || ''}
                      onChange={(e) => handleSaveSchedulerConfig({ emailRecipient: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-white text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      ওয়েবহুক টার্গেট URL (n8n / Slack / Apps Script)
                    </label>
                    <input
                      type="url"
                      placeholder="https://webhook.site/..."
                      value={config?.webhookTargetUrl || ''}
                      onChange={(e) => handleSaveSchedulerConfig({ webhookTargetUrl: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-white text-xs font-mono"
                    />
                  </div>
                </div>

                {/* Multi-channel Checkboxes */}
                <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                    নোটিফিকেশন চ্যানেল নির্বাচন (Notification Routing):
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <label className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer">
                      <span className="text-xs text-slate-700 dark:text-slate-300 font-medium flex items-center gap-1.5">
                        <Bell className="w-4 h-4 text-amber-500" />
                        ইন-অ্যাপ নোটিফিকেশন
                      </span>
                      <input
                        type="checkbox"
                        checked={config?.notificationChannels?.inApp ?? true}
                        onChange={(e) => handleSaveSchedulerConfig({
                          notificationChannels: { ...config?.notificationChannels, inApp: e.target.checked } as any
                        })}
                        className="w-4 h-4 accent-emerald-600 cursor-pointer"
                      />
                    </label>

                    <label className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer">
                      <span className="text-xs text-slate-700 dark:text-slate-300 font-medium flex items-center gap-1.5">
                        <Mail className="w-4 h-4 text-blue-500" />
                        ইমেইল নোটিফিকেশন
                      </span>
                      <input
                        type="checkbox"
                        checked={config?.notificationChannels?.email ?? true}
                        onChange={(e) => handleSaveSchedulerConfig({
                          notificationChannels: { ...config?.notificationChannels, email: e.target.checked } as any
                        })}
                        className="w-4 h-4 accent-emerald-600 cursor-pointer"
                      />
                    </label>

                    <label className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer">
                      <span className="text-xs text-slate-700 dark:text-slate-300 font-medium flex items-center gap-1.5">
                        <MessageSquare className="w-4 h-4 text-teal-500" />
                        গুগল চ্যাট ও টিম স্পেস
                      </span>
                      <input
                        type="checkbox"
                        checked={config?.notificationChannels?.googleChat ?? true}
                        onChange={(e) => handleSaveSchedulerConfig({
                          notificationChannels: { ...config?.notificationChannels, googleChat: e.target.checked } as any
                        })}
                        className="w-4 h-4 accent-emerald-600 cursor-pointer"
                      />
                    </label>

                    <label className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer">
                      <span className="text-xs text-slate-700 dark:text-slate-300 font-medium flex items-center gap-1.5">
                        <Globe className="w-4 h-4 text-purple-500" />
                        ওয়েবহুক ইন্টিগ্রেশন
                      </span>
                      <input
                        type="checkbox"
                        checked={config?.notificationChannels?.webhook ?? true}
                        onChange={(e) => handleSaveSchedulerConfig({
                          notificationChannels: { ...config?.notificationChannels, webhook: e.target.checked } as any
                        })}
                        className="w-4 h-4 accent-emerald-600 cursor-pointer"
                      />
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Notification Preview & Missed Task Explanation (5 Cols) */}
            <div className="lg:col-span-5 space-y-4">
              {/* Daily Briefing Notification Template Preview */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-emerald-500" />
                    নোটিফিকেশন প্রিভিউ (Dispatched Payload)
                  </h4>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-semibold">
                    Live Format
                  </span>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 font-mono text-[11px] text-slate-700 dark:text-slate-300 space-y-1.5 leading-relaxed">
                  <p className="font-bold text-slate-900 dark:text-white">🔔 AI Supervisor Daily Briefing</p>
                  <p>🏛️ ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ</p>
                  <p className="text-emerald-600 dark:text-emerald-400">📊 স্বাস্থ্য স্কোর: {healthScore}% (উৎকৃষ্ট)</p>
                  <div className="text-[10px] space-y-0.5 pt-1 text-slate-600 dark:text-slate-400">
                    <p>• 🔴 জরুরি আইটেম: {bugs.filter(b => b.status === 'open').length}টি</p>
                    <p>• 🟢 অনুমোদিত সনদ: {stats.approvedCertificates || 40}টি</p>
                    <p>• 💡 প্রস্তাবিত আইডিয়া: {ideas.length}টি</p>
                  </div>
                </div>
                <button
                  onClick={handleTestNotification}
                  disabled={isTestingNotification}
                  className="w-full py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>এখনই চ্যানেলে টেস্ট মেসেজ পাঠান</span>
                </button>
              </div>

              {/* Missed Task Recovery Protocol Box */}
              <div className="bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 rounded-2xl p-5 space-y-2 text-xs">
                <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 font-bold">
                  <RotateCcw className="w-4 h-4 text-amber-600" />
                  <span>মিসড টাস্ক রিকভারি প্রটোকল (Missed Task Catch-up)</span>
                </div>
                <p className="text-amber-900 dark:text-amber-200 leading-relaxed text-[11px]">
                  সার্ভার সাময়িক রিস্টার্ট বা অফলাইনে থাকার কারণে যদি নির্ধারিত সময় অতিবাহিত হয়, সিস্টেম জেগে ওঠার সাথে সাথে স্বয়ংক্রিয়ভাবে Missed Task শনাক্ত করে রিকভারি রান সম্পাদন করবে।
                </p>
              </div>
            </div>
          </div>

          {/* Job Execution History & Missed Task Recovery Audit Table */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-2">
                  <ListChecks className="w-5 h-5 text-emerald-500" />
                  শিডিউলার টাস্ক এক্সিকিউশন লগ ও হিস্ট্রি ({filteredJobs.length}টি)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  প্রতিটি স্বয়ংক্রিয় এবং ম্যানুয়াল রানের পূর্ণাঙ্গ অডিট ও ডিসপ্যাচ ট্রেইল।
                </p>
              </div>

              {/* Filters */}
              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={schedulerFilterType}
                  onChange={(e) => setSchedulerFilterType(e.target.value)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-300"
                >
                  <option value="all">সকল ট্রিগার ধরন</option>
                  <option value="scheduled_daily">🗓️ Daily Scheduled</option>
                  <option value="manual_run_now">⚡ Manual Run Now</option>
                  <option value="missed_recovery">🔄 Missed Recovery</option>
                  <option value="retry_attempt">🔁 Retry Attempt</option>
                </select>

                <select
                  value={schedulerFilterStatus}
                  onChange={(e) => setSchedulerFilterStatus(e.target.value)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-300"
                >
                  <option value="all">সকল স্ট্যাটাস</option>
                  <option value="COMPLETED">COMPLETED</option>
                  <option value="FAILED">FAILED</option>
                  <option value="RUNNING">RUNNING</option>
                  <option value="RETRY_REQUIRED">RETRY_REQUIRED</option>
                </select>

                <button
                  onClick={fetchSchedulerJobs}
                  className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300 text-xs cursor-pointer"
                  title="রিফ্রেশ"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 text-slate-500">
                    <th className="py-2.5 px-3 font-semibold">Job ID</th>
                    <th className="py-2.5 px-3 font-semibold">ট্রিগার ধরন</th>
                    <th className="py-2.5 px-3 font-semibold">এক্সিকিউশন সময়</th>
                    <th className="py-2.5 px-3 font-semibold">সময়কাল</th>
                    <th className="py-2.5 px-3 font-semibold">হেলথ স্কোর</th>
                    <th className="py-2.5 px-3 font-semibold">ডিসপ্যাচ চ্যানেল</th>
                    <th className="py-2.5 px-3 font-semibold">স্ট্যাটাস</th>
                    <th className="py-2.5 px-3 font-semibold text-right">অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredJobs.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-500">
                        কোনো শিডিউলার জব রেকর্ড পাওয়া যায়নি।
                      </td>
                    </tr>
                  ) : (
                    filteredJobs.map((job) => (
                      <tr key={job.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                        <td className="py-3 px-3 font-mono font-bold text-slate-800 dark:text-slate-200">
                          {job.id}
                        </td>
                        <td className="py-3 px-3">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            job.scheduleType === 'scheduled_daily'
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                              : job.scheduleType === 'manual_run_now'
                              ? 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300'
                              : job.scheduleType === 'missed_recovery'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : 'bg-slate-100 text-slate-800'
                          }`}>
                            {job.scheduleType}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-slate-600 dark:text-slate-300">
                          {formatDhakaDateTime(job.startedAt || job.scheduledFor)}
                        </td>
                        <td className="py-3 px-3 text-slate-600 dark:text-slate-300 font-mono">
                          {job.durationMs ? `${job.durationMs}ms` : '—'}
                        </td>
                        <td className="py-3 px-3">
                          <span className="font-bold text-emerald-600 dark:text-emerald-400">
                            {job.healthScore ? `${job.healthScore}%` : '—'}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-1">
                            {job.notificationsDispatched?.inApp && <span className="px-1.5 py-0.2 rounded text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">App</span>}
                            {job.notificationsDispatched?.email && <span className="px-1.5 py-0.2 rounded text-[10px] bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-300">Mail</span>}
                            {job.notificationsDispatched?.googleChat && <span className="px-1.5 py-0.2 rounded text-[10px] bg-teal-50 dark:bg-teal-950 text-teal-600 dark:text-teal-300">Chat</span>}
                            {job.notificationsDispatched?.webhook && <span className="px-1.5 py-0.2 rounded text-[10px] bg-purple-50 dark:bg-purple-950 text-purple-600 dark:text-purple-300">Web</span>}
                          </div>
                        </td>
                        <td className="py-3 px-3">
                          <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                            job.status === 'COMPLETED' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' :
                            job.status === 'FAILED' ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300' :
                            job.status === 'RUNNING' ? 'bg-blue-100 text-blue-800 animate-pulse' :
                            'bg-amber-100 text-amber-800'
                          }`}>
                            {job.status}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right">
                          <button
                            onClick={() => setSelectedJob(job)}
                            className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-[11px] font-semibold cursor-pointer"
                          >
                            বিস্তারিত
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Job Details Inspection Modal */}
          {selectedJob && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
              <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-2xl w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-emerald-600" />
                    <h3 className="font-bold text-base text-slate-800 dark:text-white">
                      শিডিউলার জব ডিটেইলস: {selectedJob.id}
                    </h3>
                  </div>
                  <button
                    onClick={() => setSelectedJob(null)}
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                      <span className="text-slate-500">ট্রিগার টাইপ:</span>
                      <p className="font-bold text-slate-800 dark:text-white mt-0.5">{selectedJob.scheduleType}</p>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                      <span className="text-slate-500">স্ট্যাটাস:</span>
                      <p className="font-bold text-emerald-600 mt-0.5">{selectedJob.status}</p>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                      <span className="text-slate-500">শুরুর সময়:</span>
                      <p className="font-mono text-slate-800 dark:text-white mt-0.5">{formatDhakaDateTime(selectedJob.startedAt)}</p>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                      <span className="text-slate-500">সময়কাল:</span>
                      <p className="font-mono text-slate-800 dark:text-white mt-0.5">{selectedJob.durationMs}ms</p>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 space-y-1">
                    <span className="text-slate-500 font-semibold">এআই মডেল ও প্রোভাইডার:</span>
                    <p className="text-slate-800 dark:text-white font-mono">{selectedJob.aiProvider} ({selectedJob.aiModel})</p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 space-y-1">
                    <span className="text-slate-500 font-semibold">অ্যানালাইজড ডেটা স্কোপ:</span>
                    <p className="text-slate-800 dark:text-white">
                      ইভেন্ট সংখ্যা: {selectedJob.dataRange?.eventCount || 0} | সনদ সংখ্যা: {selectedJob.dataRange?.certificateCount || 0}
                    </p>
                  </div>

                  {selectedJob.briefingSnippet && (
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 space-y-1">
                      <span className="text-slate-500 font-semibold">ব্রিফিং সামারি স্ন্যাপশট:</span>
                      <div className="flex gap-4 text-slate-700 dark:text-slate-300 pt-1">
                        <span>🔴 জরুরি: {selectedJob.briefingSnippet.urgentCount}</span>
                        <span>🐛 বাগ: {selectedJob.briefingSnippet.bugCount}</span>
                        <span>💡 আইডিয়া: {selectedJob.briefingSnippet.ideaCount}</span>
                      </div>
                    </div>
                  )}

                  {selectedJob.error && (
                    <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300 font-mono text-[11px]">
                      ত্রুটি: {selectedJob.error}
                    </div>
                  )}
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={() => setSelectedJob(null)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-white text-xs font-semibold cursor-pointer"
                  >
                    বন্ধ করুন
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB: Core Database & Event Logging (Google Sheets 6-Tab Architecture) */}
      {activeTab === 'core_db' && (
        <div id="tab-content-core-db" className="space-y-6">
          {/* Top Master Banner */}
          <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-emerald-950 text-white rounded-2xl p-6 border border-indigo-500/30 shadow-xl space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-indigo-500/30 text-indigo-300 border border-indigo-400/40 flex items-center gap-1.5">
                    <Database className="w-3.5 h-3.5 text-indigo-400" />
                    ধাপ ১: CORE DATABASE & EVENT LOGGING
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    ১০০% ফ্রি Google Sheets ডাটাবেস
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
                  🗄️ বহেড়াতৈল ইউনিয়ন পরিষদ — AI Supervisor কোর ডাটাবেস (৬-ট্যাব)
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
                  একটি একক মাস্টার স্প্রেডশিটের ভেতরে ৬টি সুনির্দিষ্ট <strong>Worksheet (Tab)</strong> ডিজাইন করা হয়েছে যা AI Supervisor-এর টেলিমেট্রি ও সিদ্ধান্ত গ্রহণের প্রধান উৎস। সংবেদনশীল নাগরিক তথ্য (NID, ফোন) স্বয়ংক্রিয় প্রাইভেসী ফিল্টারের মাধ্যমে মাস্ক করে পাঠানো হয়।
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                <button
                  onClick={handleSyncSupervisorGoogleSheets}
                  disabled={isSyncingSheets}
                  className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950/40 transition cursor-pointer flex items-center gap-2 disabled:opacity-50"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-100" />
                  <span>{isSyncingSheets ? 'ডাটাবেস তৈরি হচ্ছে...' : 'Google Sheets তৈরি / সিঙ্ক করুন'}</span>
                </button>

                <button
                  onClick={() => setIsAppsScriptModalOpen(true)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold text-xs border border-slate-600 transition cursor-pointer flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>Apps Script কোড ও গাইড</span>
                </button>

                {createdSpreadsheetUrl && (
                  <a
                    href={createdSpreadsheetUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition flex items-center gap-1.5"
                  >
                    <span>শিটটি খুলুন</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </div>

            {/* Quick Status Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-800/80 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></div>
                <span className="text-slate-300">মূল আবেদন: <strong className="text-white">{stats.totalCertificates || 42}টি</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-indigo-400"></div>
                <span className="text-slate-300">ইভেন্ট লগ: <strong className="text-white">{events.length}টি</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-amber-400"></div>
                <span className="text-slate-300">সংশোধন লগ: <strong className="text-white">{patterns.length}টি</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-purple-400"></div>
                <span className="text-slate-300">AI রিকমেন্ডেশন: <strong className="text-white">{ideas.length}টি</strong></span>
              </div>
            </div>
          </div>

          {/* 6 Tabs Architectural Breakdown */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-indigo-500" />
                <span>৬টি মূল ট্যাবের বিস্তারিত গঠন ও কলাম স্ট্রাকচার</span>
              </h3>
              <span className="text-xs text-slate-500 font-medium">
                Google Sheets মাস্টার স্প্রেডশিট স্ট্রাকচার
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Tab 1: Applications */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-emerald-600" />
                      ১. Applications
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300">
                      Protected PII
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    নাগরিকদের জমা হওয়া আবেদনের প্রাথমিক রেজিস্টার। গোপনীয়তা রক্ষার জন্য AI সরাসরি এটি পড়বে না, বরং তৈরি হওয়া ইভেন্টগুলো বিশ্লেষণ করবে।
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400">কলাম তালিকা:</span>
                  <div className="flex flex-wrap gap-1 text-[10px] font-mono">
                    {['App_ID', 'Date_Time', 'Applicant_Name', 'Phone_No', 'Service_Type', 'Status'].map(col => (
                      <span key={col} className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {col}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Tab 2: Event_Logs */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-1.5">
                      <Activity className="w-4 h-4 text-indigo-600" />
                      ২. Event_Logs
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-300">
                      Main AI Feed
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    সিস্টেমে যা কিছু ঘটবে তার সবকিছু এখানে লগ হবে। AI Supervisor এই শিটটি সবচেয়ে বেশি বিশ্লেষণ করে স্বাস্থ্য মেট্রিক্স বের করে।
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400">কলাম তালিকা:</span>
                  <div className="flex flex-wrap gap-1 text-[10px] font-mono">
                    {['Log_ID', 'Timestamp', 'Event_Category', 'Module', 'Action_By', 'Description', 'Status'].map(col => (
                      <span key={col} className="px-1.5 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300">
                        {col}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Tab 3: Corrections_Log */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-1.5">
                      <Brain className="w-4 h-4 text-amber-600" />
                      ৩. Corrections_Log
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-300">
                      Learning Engine
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    এই শিট থেকে AI শিখবে মানুষ কী ভুল করছে এবং কেন করছে। ভুল বানানের প্যাটার্ন ও অসঙ্গতি বিশ্লেষণ করে অটো-পরামর্শ তৈরি হয়।
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400">কলাম তালিকা:</span>
                  <div className="flex flex-wrap gap-1 text-[10px] font-mono">
                    {['Correction_ID', 'Timestamp', 'Ref_App_ID', 'Field_Name', 'Old_Value', 'New_Value', 'Reason', 'Corrected_By'].map(col => (
                      <span key={col} className="px-1.5 py-0.5 rounded bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300">
                        {col}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Tab 4: AI_Recommendations */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-1.5">
                      <Lightbulb className="w-4 h-4 text-purple-600" />
                      ৪. AI_Recommendations
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 border border-purple-300">
                      Human-in-the-Loop
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    AI তার বুদ্ধিমত্তা দিয়ে যে আইডিয়া বা বাগ (Bug) বের করবে, তা এখানে এসে জমা হবে এবং Admin তা Approve/Reject করবেন।
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400">কলাম তালিকা:</span>
                  <div className="flex flex-wrap gap-1 text-[10px] font-mono">
                    {['Rec_ID', 'Date_Generated', 'Category', 'Title', 'Root_Cause', 'Proposed_Fix', 'Confidence', 'Priority', 'Admin_Action'].map(col => (
                      <span key={col} className="px-1.5 py-0.5 rounded bg-purple-50 dark:bg-purple-950/40 text-purple-800 dark:text-purple-300">
                        {col}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Tab 5: AI_Knowledge_Base */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-1.5">
                      <Cpu className="w-4 h-4 text-blue-600" />
                      ৫. AI_Knowledge_Base
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 border border-blue-300">
                      Long-term Memory
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    AI প্রতিদিন যা শিখবে, তা এখানে প্যাটার্ন হিসেবে সেভ করে রাখবে যাতে ভবিষ্যতে একই ভুল দ্বিতীয়বার না হয়।
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400">কলাম তালিকা:</span>
                  <div className="flex flex-wrap gap-1 text-[10px] font-mono">
                    {['Pattern_ID', 'Date_Discovered', 'Insight', 'Impact', 'Status'].map(col => (
                      <span key={col} className="px-1.5 py-0.5 rounded bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300">
                        {col}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Tab 6: Settings */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-1.5">
                      <Sliders className="w-4 h-4 text-slate-600" />
                      ৬. Settings
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300 border border-slate-300">
                      Config Hub
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    এখান থেকে পুরো AI Scheduler ও সুপারভাইজার অটোমেশনের সময়সূচি, অ্যালার্ট এবং নোটিফিকেশন নিয়ন্ত্রণ করা হয়।
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400">কলাম তালিকা:</span>
                  <div className="flex flex-wrap gap-1 text-[10px] font-mono">
                    {['Setting_Name', 'Setting_Value', 'Status'].map(col => (
                      <span key={col} className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {col}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive PII Privacy Filter Playground */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  <span>ইন্টারেক্টিভ PII প্রাইভেসী ফিল্টার স্যান্ডবক্স (Interactive Tester)</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  রেগুলার এক্সপ্রেশন (Regex) কীভাবে সংবেদনশীল ফোন নম্বর, এনআইডি ও ইমেইলকে স্বয়ংক্রিয়ভাবে মাস্ক করে তা পরীক্ষা করুন।
                </p>
              </div>
              <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200">
                Active Client &amp; Script Regex
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Input */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  পরীক্ষামূলক টেক্সট ইনপুট (নাগরিকের নাম, ফোন, NID সহ):
                </label>
                <textarea
                  value={testPiiInput}
                  onChange={(e) => handleTestPiiChange(e.target.value)}
                  rows={4}
                  className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-200 font-mono focus:ring-2 focus:ring-emerald-500"
                  placeholder="এখানে কোনো টেক্সট লিখুন..."
                />
              </div>

              {/* Masked Output */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-emerald-700 dark:text-emerald-400 flex items-center justify-between">
                  <span>AI এর কাছে পৌঁছানো নিরাপদ আউটপুট (Masked):</span>
                  <span className="text-[10px] text-slate-400 font-normal">অটো-ফিল্টার্ড</span>
                </label>
                <div className="p-3 rounded-xl border border-emerald-200 dark:border-emerald-800/60 bg-emerald-50/50 dark:bg-emerald-950/20 text-xs font-mono text-emerald-900 dark:text-emerald-300 h-28 overflow-y-auto whitespace-pre-wrap">
                  {maskedPiiOutput}
                </div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-400">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>মাস্কিং রুলস: <code className="font-mono bg-slate-200 dark:bg-slate-700 px-1 rounded">[PHONE MASKED]</code>, <code className="font-mono bg-slate-200 dark:bg-slate-700 px-1 rounded">[NID MASKED]</code>, <code className="font-mono bg-slate-200 dark:bg-slate-700 px-1 rounded">[EMAIL MASKED]</code></span>
              </div>
              <button
                onClick={() => handleTestPiiChange('মোঃ আব্দুল করিম, এনআইডি: 19859315784000888, মোবাইল: 01711223344, গ্রাম: বহেড়াতৈল, পিতা: মৃত কাশেম মিয়া')}
                className="text-emerald-600 hover:text-emerald-700 font-bold cursor-pointer underline text-[11px]"
              >
                নমুনা ডাটা লোড করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Learning & Correction Patterns */}
      {activeTab === 'patterns' && (
        <div id="tab-content-patterns" className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2">
                  <Brain className="w-5 h-5 text-emerald-500" />
                  সংশোধন প্যাটার্ন ও রুট কজ লার্নিং মেমোরি
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  অপারেটরদের নিয়মিত সংশোধন থেকে এআই যে বিষয়গুলো স্বয়ংক্রিয়ভাবে শিখেছে এবং সমাধান প্রস্তাব করেছে।
                </p>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                {patterns.length}টি ফিল্ড প্যাটার্ন সক্রিয়
              </span>
            </div>

            <div className="space-y-4">
              {patterns.map((p) => (
                <div key={p.id} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-emerald-500/40 transition bg-slate-50/50 dark:bg-slate-800/30 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-800 dark:text-white text-sm">{p.fieldLabel}</span>
                      <span className="text-xs px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-mono">
                        field: {p.fieldKey}
                      </span>
                      <span className="text-xs text-slate-500">({p.certificateType})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300">
                        {p.occurrences} বার সংশোধিত
                      </span>
                      <span className={`text-xs px-2 py-0.5 rounded font-semibold ${
                        p.status === 'resolved' ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'
                      }`}>
                        {p.status === 'resolved' ? 'সমাধান কার্যকর' : 'লার্নিং সক্রিয়'}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                      <span className="font-semibold text-rose-600 dark:text-rose-400 block mb-1">🔍 রুট কজ বিশ্লেষণ:</span>
                      <p className="text-slate-700 dark:text-slate-300">{p.rootCauseAnalysis}</p>
                    </div>
                    <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                      <span className="font-semibold text-emerald-600 dark:text-emerald-400 block mb-1">💡 প্রস্তাবিত সমাধান:</span>
                      <p className="text-slate-700 dark:text-slate-300">{p.recommendedAction}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: Bug Candidates */}
      {activeTab === 'bugs' && (
        <div id="tab-content-bugs" className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2">
                  <Bug className="w-5 h-5 text-rose-500" />
                  স্বায়ত্তশাসিত বাগ শনাক্তকরণ ও ফিক্স পরামর্শ
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  সিস্টেম টেলিমেট্রি থেকে সন্দেহভাজন বাগ, রেট লিমিট ও ভ্যালিডেশন ত্রুটির বিশ্লেষণ।
                </p>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300">
                {bugs.filter(b => b.status === 'open').length}টি সক্রিয় বাগ
              </span>
            </div>

            <div className="space-y-4">
              {bugs.map((bug) => (
                <div key={bug.id} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-xs font-bold text-white ${
                        bug.severity === 'P0_CRITICAL' ? 'bg-rose-600' :
                        bug.severity === 'P1_HIGH' ? 'bg-amber-600' :
                        bug.severity === 'P2_MEDIUM' ? 'bg-blue-600' : 'bg-slate-600'
                      }`}>
                        {bug.severity}
                      </span>
                      <h4 className="font-bold text-slate-800 dark:text-white text-sm">{bug.title}</h4>
                      <span className="text-xs text-slate-500 font-mono">[{bug.affectedModule}]</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-emerald-600">
                        কনফিডেন্স: {bug.confidenceScore}%
                      </span>
                      <span className={`text-xs px-2 py-0.5 rounded font-semibold ${
                        bug.status === 'resolved' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                      }`}>
                        {bug.status === 'resolved' ? 'সমাধানকৃত' : 'পর্যালোচনাধীন'}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                      <span className="font-semibold text-rose-600 dark:text-rose-400 block mb-1">সম্ভাব্য কারণ:</span>
                      <p className="text-slate-700 dark:text-slate-300">{bug.possibleCause}</p>
                    </div>
                    <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                      <span className="font-semibold text-emerald-600 dark:text-emerald-400 block mb-1">প্রস্তাবিত সমাধান:</span>
                      <p className="text-slate-700 dark:text-slate-300">{bug.suggestedFix}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800 text-xs">
                    <span className="text-slate-500">প্রমাণ: {bug.evidence}</span>
                    {bug.status !== 'resolved' ? (
                      <button
                        onClick={() => handleUpdateBugStatus(bug.id, 'resolved')}
                        className="px-3 py-1 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-500 transition cursor-pointer"
                      >
                        বাগ সমাধান সম্পন্ন হিসেবে চিহ্নিত করুন
                      </button>
                    ) : (
                      <span className="text-emerald-600 font-semibold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> সমাধান যাচাই হয়েছে
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: Ideas Box */}
      {activeTab === 'ideas' && (
        <div id="tab-content-ideas" className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-indigo-500" />
                  সুপারভাইজার স্বয়ংক্রিয় আইডিয়াবক্স ও অপটিমাইজেশন প্রস্তাবনা
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  সিস্টেম পারফরম্যান্স ও ইউজার অভিজ্ঞতার তথ্যের ভিত্তিতে এআই প্রস্তাবিত আধুনিক ফিচার ও ওয়ার্কফ্লো।
                </p>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
                {ideas.length}টি প্রস্তাবিত আইডিয়া
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {ideas.map((idea) => (
                <div key={idea.id} className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm space-y-3 flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        idea.priority === 'P0' ? 'bg-rose-100 text-rose-700' :
                        idea.priority === 'P1' ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {idea.priority} PRIORITY
                      </span>
                      <span className="text-xs text-slate-500 font-medium">ক্যাটাগরি: {idea.category}</span>
                    </div>

                    <h4 className="font-bold text-slate-800 dark:text-white text-sm">{idea.ideaTitle}</h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{idea.ideaDescription}</p>

                    <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/50 text-[11px] text-slate-700 dark:text-slate-300 space-y-1">
                      <p><strong className="text-emerald-600 dark:text-emerald-400">প্রত্যাশিত সুফল:</strong> {idea.expectedBenefit}</p>
                      <p><strong className="text-teal-600 dark:text-teal-400">বাস্তবায়ন জটিলতা:</strong> {idea.implementationDifficulty}</p>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <span className="text-[11px] text-slate-500">
                      স্ট্যাটাস: <strong className="text-slate-800 dark:text-slate-200">{idea.status}</strong>
                    </span>

                    {idea.status === 'proposed' && (
                      <button
                        onClick={() => handleUpdateIdeaStatus(idea.id, 'approved')}
                        className="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition cursor-pointer"
                      >
                        অনুমোদন দিন
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: Live Events Stream */}
      {activeTab === 'events' && (
        <div id="tab-content-events" className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-slate-800 dark:text-white flex items-center gap-2">
                  <Activity className="w-5 h-5 text-emerald-500" />
                  স্ট্রাকচার্ড সুপারভাইজার ইভেন্ট স্ট্রিম ({filteredEvents.length}টি)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  সার্বক্ষণিক সিস্টেম অ্যাকশন ও অডিট ট্রেইল (PII মাস্কিং সহ)।
                </p>
              </div>

              {/* Event Filters */}
              <div className="flex items-center gap-2">
                <select
                  value={eventFilterSeverity}
                  onChange={(e) => setEventFilterSeverity(e.target.value)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-300"
                >
                  <option value="all">সকল মাত্রা (Severity)</option>
                  <option value="info">Info</option>
                  <option value="warning">Warning</option>
                  <option value="error">Error</option>
                  <option value="critical">Critical</option>
                </select>
              </div>
            </div>

            {/* Events List */}
            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {filteredEvents.map((evt) => (
                <div key={evt.id} className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                        evt.severity === 'critical' ? 'bg-rose-600 text-white' :
                        evt.severity === 'error' ? 'bg-rose-500 text-white' :
                        evt.severity === 'warning' ? 'bg-amber-500 text-white' : 'bg-blue-500 text-white'
                      }`}>
                        {evt.severity.toUpperCase()}
                      </span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{evt.eventType}</span>
                      <span className="text-slate-500 font-mono">[{evt.module}]</span>
                      {evt.memoNo && <span className="text-emerald-600 dark:text-emerald-400 font-mono">Memo: {evt.memoNo}</span>}
                    </div>
                    <p className="text-slate-700 dark:text-slate-300">{evt.summary}</p>
                    {evt.correctionReason && (
                      <p className="text-slate-500 text-[11px] italic">কারণ: {evt.correctionReason}</p>
                    )}
                  </div>

                  <div className="text-right text-[11px] text-slate-500 shrink-0">
                    <div>{new Date(evt.timestamp).toLocaleTimeString('bn-BD')}</div>
                    <div>{new Date(evt.timestamp).toLocaleDateString('bn-BD')}</div>
                    <span className="text-slate-400">{evt.actorRole}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: Interactive Chat */}
      {activeTab === 'chat' && (
        <div id="tab-content-chat" className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col h-[600px]">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-900/20">
                  <Bot className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-800 dark:text-white">এআই সুপারভাইজার ইন্টারেক্টিভ কনসোল</h3>
                  <p className="text-xs text-slate-500">টেলিমেট্রি, ত্রুটির সমাধান ও প্র্যাকটিভ পরামর্শক</p>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Active Learning Loop
              </span>
            </div>

            {/* Chat Messages Body */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-2 mb-4">
              {chatMessages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] rounded-2xl p-4 text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-emerald-600 text-white rounded-tr-none'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-tl-none border border-slate-200 dark:border-slate-700'
                  }`}>
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                    <span className={`text-[10px] block mt-1 ${msg.role === 'user' ? 'text-emerald-200 text-right' : 'text-slate-400'}`}>
                      {msg.time}
                    </span>
                  </div>
                </div>
              ))}
              {chatLoading && (
                <div className="flex justify-start">
                  <div className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-2xl rounded-tl-none p-4 text-xs flex items-center gap-2 border border-slate-200 dark:border-slate-700">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-500" />
                    <span>এআই সুপারভাইজার সিস্টেম ডেটা বিশ্লেষণ করছে...</span>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Prompt Chips */}
            <div className="flex flex-wrap gap-2 mb-3">
              {[
                'আজ সবচেয়ে বেশি ভুল কোন জায়গায় হয়েছে?',
                'গত ৭ দিনে কোন ভুল কমেছে?',
                'কোন Certificate Field সবচেয়ে বেশি সংশোধন হয়েছে?',
                'আজকের সবচেয়ে গুরুত্বপূর্ণ Bug কোনটি?',
                'দৈনিক শিডিউলারের সর্বশেষ স্ট্যাটাস কী?',
                'আগামী সপ্তাহে কোন Feature উন্নত করা উচিত?'
              ].map((chip, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setChatInput(chip);
                  }}
                  className="px-2.5 py-1 rounded-lg text-xs bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-slate-700 transition cursor-pointer"
                >
                  {chip}
                </button>
              ))}
            </div>

            {/* Input Form */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendChat()}
                placeholder="সুপারভাইজারকে প্রশ্ন করুন (উদাঃ আজকের ত্রুটির কারণ ও সমাধান)..."
                className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button
                onClick={handleSendChat}
                disabled={chatLoading || !chatInput.trim()}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-sm transition disabled:opacity-50 cursor-pointer flex items-center gap-1.5"
              >
                <Send className="w-4 h-4" />
                <span>পাঠান</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 8: Settings & Rules */}
      {activeTab === 'settings' && config && (
        <div id="tab-content-settings" className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div>
              <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2">
                <Sliders className="w-5 h-5 text-emerald-500" />
                এআই সুপারভাইজার পলিসি ও কনফিগারেশন
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                সুপারভাইজারের পর্যবেক্ষণ মোড, অ্যালার্ট চ্যানেল এবং অটোনোমাস গার্ডরেইল কনফিগার করুন।
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Scan Schedule & Frequency */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
                <h4 className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2">
                  <Clock className="w-4 h-4 text-teal-500" />
                  স্ক্যান সময়সূচি ও ফ্রিকোয়েন্সি
                </h4>
                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 mb-1">সুপারভাইজার স্ট্যাটাস</label>
                    <button
                      onClick={() => handleSaveSchedulerConfig({ isEnabled: !config.isEnabled })}
                      className={`px-4 py-2 rounded-xl font-bold cursor-pointer transition ${
                        config.isEnabled ? 'bg-emerald-600 text-white' : 'bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {config.isEnabled ? 'ইঞ্জিন সক্রিয় (Enabled)' : 'ইঞ্জিন নিষ্ক্রিয় (Disabled)'}
                    </button>
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 mb-1">দৈনিক ব্রিফিং শিডিউল সময়</label>
                    <input
                      type="text"
                      value={config.scheduledTime}
                      onChange={(e) => handleSaveSchedulerConfig({ scheduledTime: e.target.value })}
                      className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-white w-full font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 mb-1">কনফিডেন্স থ্রেশহোল্ড ({config.confidenceThreshold}%)</label>
                    <input
                      type="range"
                      min="50"
                      max="95"
                      value={config.confidenceThreshold}
                      onChange={(e) => handleSaveSchedulerConfig({ confidenceThreshold: parseInt(e.target.value, 10) })}
                      className="w-full cursor-pointer accent-emerald-600"
                    />
                    <span className="text-[11px] text-slate-500">এই স্কোরের নিচের কোনো অনুমানকে রিপোর্ট বা বাগে অন্তর্ভুক্ত করা হবে না।</span>
                  </div>
                </div>
              </div>

              {/* Notification Channels */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
                <h4 className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2">
                  <Bell className="w-4 h-4 text-indigo-500" />
                  নোটিফিকেশন চ্যানেল ও এলার্ট রুট
                </h4>
                <div className="space-y-2.5 text-xs">
                  <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 cursor-pointer">
                    <span className="text-slate-700 dark:text-slate-300 font-medium">ইন-অ্যাপ ড্যাশবোর্ড নোটিফিকেশন</span>
                    <input
                      type="checkbox"
                      checked={config.notificationChannels.inApp}
                      onChange={(e) => handleSaveSchedulerConfig({
                        notificationChannels: { ...config.notificationChannels, inApp: e.target.checked }
                      })}
                      className="w-4 h-4 accent-emerald-600 cursor-pointer"
                    />
                  </label>

                  <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 cursor-pointer">
                    <span className="text-slate-700 dark:text-slate-300 font-medium">গুগল চ্যাট ও টিম স্পেস ব্রডকাস্ট</span>
                    <input
                      type="checkbox"
                      checked={config.notificationChannels.googleChat}
                      onChange={(e) => handleSaveSchedulerConfig({
                        notificationChannels: { ...config.notificationChannels, googleChat: e.target.checked }
                      })}
                      className="w-4 h-4 accent-emerald-600 cursor-pointer"
                    />
                  </label>

                  <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 cursor-pointer">
                    <span className="text-slate-700 dark:text-slate-300 font-medium">ওয়েবহুক ও ক্লাউড কানেক্টরস</span>
                    <input
                      type="checkbox"
                      checked={config.notificationChannels.webhook}
                      onChange={(e) => handleSaveSchedulerConfig({
                        notificationChannels: { ...config.notificationChannels, webhook: e.target.checked }
                      })}
                      className="w-4 h-4 accent-emerald-600 cursor-pointer"
                    />
                  </label>

                  <div className="pt-2">
                    <button
                      onClick={handleTestNotification}
                      disabled={isTestingNotification}
                      className="w-full py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs transition cursor-pointer"
                    >
                      {isTestingNotification ? 'টেস্ট চলছে...' : 'নোটিফিকেশন চ্যানেল টেস্ট করুন'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Apps Script & Google Sheets Core Modal */}
      <AppsScriptModal
        isOpen={isAppsScriptModalOpen}
        onClose={() => setIsAppsScriptModalOpen(false)}
      />
    </div>
  );
};
