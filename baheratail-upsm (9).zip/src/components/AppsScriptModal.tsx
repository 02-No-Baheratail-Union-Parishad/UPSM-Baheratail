import React, { useState } from 'react';
import { 
  Code, 
  Copy, 
  Check, 
  X, 
  FileCode, 
  ExternalLink, 
  FileText, 
  Table, 
  BookOpen, 
  Layers, 
  Database, 
  ShieldCheck, 
  Sparkles, 
  Cpu, 
  Sliders, 
  CheckCircle2, 
  AlertCircle,
  HelpCircle,
  Eye,
  FileSpreadsheet
} from 'lucide-react';
import { maskSensitiveData } from '../lib/googleSheets';

interface AppsScriptModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppsScriptModal: React.FC<AppsScriptModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'core_db' | 'placeholders' | 'code' | 'guide'>('core_db');
  const [copiedTag, setCopiedTag] = useState<string | null>(null);
  const [copiedFile, setCopiedFile] = useState<string | null>(null);
  
  // Privacy Filter Interactive Tester State
  const [testPiiInput, setTestPiiInput] = useState<string>('আবেদনকারী মোঃ করিম, NID: 19929315784000123, ফোন: 01712345678, ইমেইল: karim@gmail.com');
  const [maskedOutput, setMaskedOutput] = useState<string>(() => maskSensitiveData('আবেদনকারী মোঃ করিম, NID: 19929315784000123, ফোন: 01712345678, ইমেইল: karim@gmail.com'));

  if (!isOpen) return null;

  const handleTestPiiChange = (val: string) => {
    setTestPiiInput(val);
    setMaskedOutput(maskSensitiveData(val));
  };

  const coreDatabaseTabs = [
    {
      tabName: 'Applications',
      banglaTitle: '১. Applications (নাগরিকদের মূল আবেদন রেজিস্টার)',
      description: 'নাগরিকদের জমা হওয়া আবেদনের প্রাথমিক তথ্য। গোপনীয়তার জন্য AI সরাসরি এটি পড়বে না, বরং তৈরি হওয়া ইভেন্টগুলো বিশ্লেষণ করবে।',
      badge: 'Protected PII',
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
      columns: [
        { name: 'App_ID', desc: 'অনন্য আইডি (যেমন: APP-26-001)' },
        { name: 'Date_Time', desc: 'আবেদনের সময়' },
        { name: 'Applicant_Name', desc: 'আবেদনকারীর নাম' },
        { name: 'Phone_No', desc: 'PII — AI এর কাছ থেকে হাইড করা থাকবে' },
        { name: 'Service_Type', desc: 'সেবার ধরন (Trade License, Citizenship)' },
        { name: 'Status', desc: 'Pending, Processing, Approved, Rejected' }
      ]
    },
    {
      tabName: 'Event_Logs',
      banglaTitle: '২. Event_Logs (AI-এর বিশ্লেষণের মূল সোর্স)',
      description: 'সিস্টেমে যা কিছু ঘটবে তার সবকিছু এখানে রেকর্ড হবে। AI Supervisor এই শিটটি সবচেয়ে বেশি বিশ্লেষণ করে স্বাস্থ্য মেট্রিক্স বের করবে।',
      badge: 'Main AI Feed',
      badgeColor: 'bg-indigo-100 text-indigo-800 border-indigo-300',
      columns: [
        { name: 'Log_ID', desc: 'লগ আইডি (যেমন: LOG-105)' },
        { name: 'Timestamp', desc: 'কখন ঘটেছে (এশিয়া/ঢাকা সময়)' },
        { name: 'Event_Category', desc: 'App_Created, Status_Changed, Validation_Error' },
        { name: 'Module', desc: 'কোন সার্ভিসে হয়েছে (যেমন: Trade License)' },
        { name: 'Action_By', desc: 'System, User, বা Officer ID (নাম থাকবে না)' },
        { name: 'Description', desc: 'ইভেন্টের বিস্তারিত বর্ণনা (PII Masked)' },
        { name: 'Status', desc: 'Success, Warning, Error' }
      ]
    },
    {
      tabName: 'Corrections_Log',
      banglaTitle: '৩. Corrections_Log (AI-এর লার্নিং ইঞ্জিন)',
      description: 'এই শিট থেকে AI শিখবে মানুষ কী ভুল করছে এবং কেন করছে। ভুল বানানের প্যাটার্ন ও অসঙ্গতি বিশ্লেষণ করে অটো-পরামর্শ তৈরি হয়।',
      badge: 'Learning Engine',
      badgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
      columns: [
        { name: 'Correction_ID', desc: 'অনন্য সংশোধন আইডি (COR-101)' },
        { name: 'Timestamp', desc: 'সংশোধনের সময়' },
        { name: 'Ref_App_ID', desc: 'কোন আবেদনের ভুল' },
        { name: 'Field_Name', desc: 'কোন ফিল্ডে ভুল হয়েছে (Father Name, DOB)' },
        { name: 'Old_Value', desc: 'ভুল ডেটা কী ছিল (PII Masked)' },
        { name: 'New_Value', desc: 'সঠিক ডেটা কী দেওয়া হলো (PII Masked)' },
        { name: 'Correction_Reason', desc: 'Typo, Format Error, OCR Error' },
        { name: 'Corrected_By', desc: 'কে ঠিক করেছেন' }
      ]
    },
    {
      tabName: 'AI_Recommendations',
      banglaTitle: '৪. AI_Recommendations (Human + AI Collaboration)',
      description: 'AI তার বুদ্ধিমত্তা দিয়ে যে আইডিয়া বা বাগ (Bug) বের করবে, তা এখানে এসে জমা হবে এবং Admin তা Approve/Reject করবেন।',
      badge: 'Human-in-the-Loop',
      badgeColor: 'bg-purple-100 text-purple-800 border-purple-300',
      columns: [
        { name: 'Rec_ID', desc: 'অনন্য রিকমেন্ডেশন আইডি (REC-001)' },
        { name: 'Date_Generated', desc: 'পরামর্শ জেনারেট হওয়ার তারিখ' },
        { name: 'Category', desc: 'Bug, UX Idea, Automation, Security' },
        { name: 'Title', desc: 'পরামর্শের শিরোনাম (যেমন: Repeated NID Error)' },
        { name: 'Root_Cause', desc: 'সমস্যার মূল কারণ' },
        { name: 'Proposed_Fix', desc: 'AI-এর প্রস্তাবিত সমাধান' },
        { name: 'Confidence_Score', desc: 'কনফিডেন্স স্কোর (যেমন: 92%)' },
        { name: 'Priority', desc: 'P0, P1, P2, P3' },
        { name: 'Admin_Action', desc: 'Dropdown: Pending, Approved, Rejected' },
        { name: 'Action_Date', desc: 'অনুমোদনের তারিখ' }
      ]
    },
    {
      tabName: 'AI_Knowledge_Base',
      banglaTitle: '৫. AI_Knowledge_Base (AI-এর নিজস্ব মেমোরি)',
      description: 'AI প্রতিদিন যা শিখবে, তা এখানে প্যাটার্ন হিসেবে সেভ করে রাখবে যাতে ভবিষ্যতে একই ভুল পুনরাবৃত্তি না হয়।',
      badge: 'Long-term Memory',
      badgeColor: 'bg-blue-100 text-blue-800 border-blue-300',
      columns: [
        { name: 'Pattern_ID', desc: 'প্যাটার্ন আইডি (PAT-01)' },
        { name: 'Date_Discovered', desc: 'আবিষ্কারের তারিখ' },
        { name: 'Insight', desc: 'শিক্ষা বা ইনসাইট (যেমন: DD-MM-YYYY কনফিউশন)' },
        { name: 'Impact', desc: 'High, Medium, Low' },
        { name: 'Status', desc: 'Active, Resolved' }
      ]
    },
    {
      tabName: 'Settings',
      banglaTitle: '৬. Settings (Admin Control Panel)',
      description: 'এখান থেকে পুরো AI Scheduler ও সুপারভাইজার অটোমেশন নিয়ন্ত্রণ করা হবে।',
      badge: 'Config Hub',
      badgeColor: 'bg-slate-100 text-slate-800 border-slate-300',
      columns: [
        { name: 'Setting_Name', desc: 'যেমন: AI_Run_Time, Report_Frequency' },
        { name: 'Setting_Value', desc: 'যেমন: 11:30 PM, Daily, admin@boheratoil.gov.bd' },
        { name: 'Status', desc: 'ON / OFF' }
      ]
    }
  ];

  const placeholders = [
    { tag: '{{name}}', alias: '{{নাম}}', desc: 'আবেদনকারীর পূর্ণ নাম', example: 'মোঃ আব্দুর রহিম' },
    { tag: '{{memoNo}}', alias: '{{সনদ_নং}}', desc: 'ইউনিক মেমো / ট্র্যাকিং নম্বর', example: 'BUP-2026-4891' },
    { tag: '{{qrCodeUrl}}', alias: '{{QR_CODE}}', desc: 'অনলাইন সনাক্তকরণ QR কোড লিঙ্ক / ইমেজ', example: 'https://ais-dev-.../verify?memo=BUP-2026-4891' },
    { tag: '{{body_text}}', alias: '{{দাপ্তরিক_বিবরণী}}', desc: 'Gemini AI দ্বারা জেনারেটেড ৪-৬ লাইনের বাংলা দাপ্তরিক বিবরণী', example: 'এই মর্মে প্রত্যয়ন করা যাইতেছে যে...' },
    { tag: '{{fatherName}}', alias: '{{পিতার_নাম}}', desc: 'পিতা বা স্বামীর নাম', example: 'মোঃ আব্দুল করিম' },
    { tag: '{{motherName}}', alias: '{{মাতার_নাম}}', desc: 'মাতার নাম', example: 'মোছাঃ ফাতেমা বেগম' },
    { tag: '{{village}}', alias: '{{গ্রাম}}', desc: 'স্থায়ী বাসস্থান / গ্রাম', example: 'বহেড়াতৈল' },
    { tag: '{{wardNo}}', alias: '{{ওয়ার্ড_নং}}', desc: 'ইউনিয়ন পরিষদের ওয়ার্ড নম্বর', example: '০৫' },
    { tag: '{{nidNo}}', alias: '{{NID_Birth_No}}', desc: 'জাতীয় পরিচয়পত্র বা জন্ম নিবন্ধন নম্বর', example: '19929315784000123' },
    { tag: '{{issueDate}}', alias: '{{ইস্যুর_তারিখ}}', desc: 'সনদ ডাউনলোড বা ইস্যুর বাংলা তারিখ', example: '০৭ আগস্ট, ২০২৬' },
    { tag: '{{certType}}', alias: '{{প্রত্যয়নপত্রের_ধরন}}', desc: 'প্রত্যয়নপত্রের শিরোনাম বা ধরন', example: 'নাগরিকত্ব সনদপত্র' },
    { tag: '{{chairmanName}}', alias: '{{চেয়ারম্যান_নাম}}', desc: 'ইউপি চেয়ারম্যান / প্যানেল চেয়ারম্যানের নাম', example: 'মোশারফ হোসেন (হিরো মিয়া)' },
    { tag: '{{secretaryName}}', alias: '{{সচিব_নাম}}', desc: 'ইউনিয়ন পরিষদ প্রশাসনিক কর্মকর্তার নাম', example: 'মোঃ সাইদুজ্জামান' }
  ];

  const supervisorCoreGsContent = `/**
 * Project: UPSM 2.0 AI Supervisor Core Database Engine
 * File: Supervisor_Core.gs
 * Target: ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল
 */

const SUPERVISOR_CONFIG = {
  UP_NAME: "০২নং বহেড়াতৈল ইউনিয়ন পরিষদ",
  ADMIN_EMAIL: "admin@boheratoil.gov.bd",
  SCHEDULE_HOUR: 23, // 11 PM
  SCHEDULE_MINUTE: 30
};

// -------------------------------------------------------------
// ১. ৬টি ডেডিকেটেড ট্যাব অটো-ইনিশিয়ালাইজেশন
// -------------------------------------------------------------
function initializeSupervisorDatabase() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  const schema = {
    "Applications": ["App_ID", "Date_Time", "Applicant_Name", "Phone_No", "Service_Type", "Status"],
    "Event_Logs": ["Log_ID", "Timestamp", "Event_Category", "Module", "Action_By", "Description", "Status"],
    "Corrections_Log": ["Correction_ID", "Timestamp", "Ref_App_ID", "Field_Name", "Old_Value", "New_Value", "Correction_Reason", "Corrected_By"],
    "AI_Recommendations": ["Rec_ID", "Date_Generated", "Category", "Title", "Root_Cause", "Proposed_Fix", "Confidence_Score", "Priority", "Admin_Action", "Action_Date"],
    "AI_Knowledge_Base": ["Pattern_ID", "Date_Discovered", "Insight", "Impact", "Status"],
    "Settings": ["Setting_Name", "Setting_Value", "Status"]
  };
  
  for (let tabName in schema) {
    let sheet = ss.getSheetByName(tabName);
    if (!sheet) {
      sheet = ss.insertSheet(tabName);
      sheet.appendRow(schema[tabName]);
      sheet.getRange(1, 1, 1, schema[tabName].length).setFontWeight("bold").setBackground("#e2e8f0");
      sheet.setFrozenRows(1);
    }
  }
  
  // Settings ডিফল্ট রো যোগ
  const settingsSheet = ss.getSheetByName("Settings");
  if (settingsSheet.getLastRow() <= 1) {
    settingsSheet.appendRow(["AI_Run_Time", "11:30 PM (Asia/Dhaka)", "ON"]);
    settingsSheet.appendRow(["Report_Frequency", "Daily", "ON"]);
    settingsSheet.appendRow(["Admin_Email", SUPERVISOR_CONFIG.ADMIN_EMAIL, "ON"]);
    settingsSheet.appendRow(["Privacy_Filter", "Enabled (PII Regex Masking)", "ON"]);
  }
  
  Logger.log("✓ ৬টি স্প্রেডশিট ট্যাব সফলভাবে প্রস্তুত হয়েছে!");
}

// -------------------------------------------------------------
// ২. প্রাইভেসী ফিল্টার (PII Masking) ফাংশন
// -------------------------------------------------------------
function maskSensitivePII(text) {
  if (!text) return "";
  let str = String(text);
  // Phone Mask (+8801... / 01...)
  str = str.replace(/(?:(?:\\+8801|8801|01))[3-9]\\d{8}/g, "[PHONE_MASKED]");
  // NID Mask (10, 13, 17 digits)
  str = str.replace(/\\b(?:\\d{17}|\\d{13}|\\d{10})\\b/g, "[ID_MASKED]");
  // Email Mask
  str = str.replace(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}/g, "[EMAIL_MASKED]");
  return str;
}

// -------------------------------------------------------------
// ৩. WebApp POST রিসিভার (Web App থেকে ইভেন্ট ও লগ সিঙ্ক)
// -------------------------------------------------------------
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    
    if (data.action === "LOG_EVENT") {
      const sheet = ss.getSheetByName("Event_Logs") || ss.insertSheet("Event_Logs");
      sheet.appendRow([
        data.logId || ("LOG-" + new Date().getTime().toString().slice(-4)),
        new Date().toLocaleString("bn-BD", { timeZone: "Asia/Dhaka" }),
        data.category || "General",
        data.module || "System",
        data.actionBy || "Operator",
        maskSensitivePII(data.description),
        data.status || "Success"
      ]);
    } else if (data.action === "LOG_CORRECTION") {
      const sheet = ss.getSheetByName("Corrections_Log") || ss.insertSheet("Corrections_Log");
      sheet.appendRow([
        data.correctionId || ("COR-" + new Date().getTime().toString().slice(-4)),
        new Date().toLocaleString("bn-BD", { timeZone: "Asia/Dhaka" }),
        data.refAppId || "N/A",
        data.fieldName || "General",
        maskSensitivePII(data.oldValue),
        maskSensitivePII(data.newValue),
        data.reason || "Correction",
        data.correctedBy || "Operator"
      ]);
    }
    
    return ContentService.createTextOutput(JSON.stringify({ success: true, message: "লগ সফলভাবে সংরক্ষিত হয়েছে।" }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ success: false, error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}`;

  const codeGsContent = `/**
 * Project: Union Parishad Digital Automation System
 * File: Code.gs
 * Target: 02নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল
 */

const CONFIG = {
  TEMPLATE_DOC_ID: 'YOUR_GOOGLE_DOC_TEMPLATE_ID', 
  TARGET_FOLDER_ID: 'YOUR_TARGET_DRIVE_FOLDER_ID',
  GEMINI_MODEL: 'gemini-1.5-flash',
  
  UP_NAME: "০২নং বহেড়াতৈল ইউনিয়ন পরিষদ",
  LOCATION: "সখিপুর, টাঙ্গাইল",
  CHAIRMAN_NAME: "মোশারফ হোসেন (হিরো মিয়া)",
  SECRETARY_NAME: "মোঃ সাইদুজ্জামান"
};

function doGet(e) {
  const template = HtmlService.createTemplateFromFile('Index');
  return template.evaluate()
      .setTitle(CONFIG.UP_NAME + ' - ডিজিটাল প্রত্যয়ন সেবা')
      .addMetaTag('viewport', 'width=device-width, initial-scale=1')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function generateCertificate(citizenData) {
  try {
    const templateFile = DriveApp.getFileById(CONFIG.TEMPLATE_DOC_ID);
    const folder = DriveApp.getFolderById(CONFIG.TARGET_FOLDER_ID);
    
    const fileName = \`\${citizenData.type}_\${citizenData.name}_\${new Date().getTime()}\`;
    const newDocFile = templateFile.makeCopy(fileName, folder);
    const doc = DocumentApp.openById(newDocFile.getId());
    const body = doc.getBody();

    const aiDescription = callGeminiAI(citizenData);
    const memoNo = citizenData.memoNo || generateMemoNumber();
    const issueDate = convertToBengaliNum(new Date().toLocaleDateString('bn-BD'));

    // Google Doc Placeholder Mapping Table
    const replacements = {
      '{{name}}': citizenData.name,
      '{{নাম}}': citizenData.name,
      '{{memoNo}}': memoNo,
      '{{সনদ_নং}}': memoNo,
      '{{qrCodeUrl}}': citizenData.qrCodeUrl || '',
      '{{QR_CODE}}': citizenData.qrCodeUrl || '',
      '{{body_text}}': aiDescription,
      '{{fatherName}}': citizenData.father || '',
      '{{পিতার_নাম}}': citizenData.father || '',
      '{{motherName}}': citizenData.mother || '',
      '{{মাতার_নাম}}': citizenData.mother || '',
      '{{village}}': citizenData.village || '',
      '{{গ্রাম}}': citizenData.village || '',
      '{{wardNo}}': convertToBengaliNum(citizenData.ward || '০৫'),
      '{{ওয়ার্ড_নং}}': convertToBengaliNum(citizenData.ward || '০৫'),
      '{{nidNo}}': convertToBengaliNum(citizenData.nid || citizenData.birthNo || ''),
      '{{NID_Birth_No}}': convertToBengaliNum(citizenData.nid || citizenData.birthNo || ''),
      '{{issueDate}}': issueDate,
      '{{ইস্যুর_তারিখ}}': issueDate,
      '{{certType}}': citizenData.type || 'নাগরিকত্ব সনদপত্র',
      '{{চেয়ারম্যান_নাম}}': CONFIG.CHAIRMAN_NAME,
      '{{সচিব_নাম}}': CONFIG.SECRETARY_NAME
    };

    for (let key in replacements) {
      body.replaceText(key, replacements[key]);
    }

    doc.saveAndClose();
    const pdfBlob = newDocFile.getAs(MimeType.PDF);
    const pdfFile = folder.createFile(pdfBlob);
    
    return { success: true, url: pdfFile.getUrl(), memo: memoNo, pdfUrl: pdfFile.getDownloadUrl() };
  } catch (error) {
    return { success: false, error: error.toString() };
  }
}

function convertToBengaliNum(num) {
  if (!num) return '';
  const map = {'0':'০','1':'১','2':'২','3':'৩','4':'৪','5':'৫','6':'৬','7':'৭','8':'৮','9':'৯'};
  return num.toString().replace(/[0-9]/g, w => map[w]);
}

function generateMemoNumber() {
  const year = new Date().getFullYear();
  const random = Math.floor(1000 + Math.random() * 9000);
  return \`BUP-\${year}-\${random}\`;
}`;

  const geminiGsContent = `/**
 * File: Gemini.gs
 */
function callGeminiAI(data) {
  const scriptProperties = PropertiesService.getScriptProperties();
  const apiKey = scriptProperties.getProperty('GEMINI_API_KEY');
  
  if (!apiKey) return "ত্রুটি: Gemini API Key কনফিগার করা নেই।";

  const apiUrl = \`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=\${apiKey}\`;

  const prompt = \`
    তুমি একজন দক্ষ সরকারি দাপ্তরিক লেখক। নিচের তথ্যগুলো ব্যবহার করে একটি "\${data.type}" এর জন্য ৪-৫ লাইনের একটি অত্যন্ত মার্জিত এবং আনুষ্ঠানিক বিবরণী বাংলা ভাষায় লেখো।
    বিবরণীটি এমনভাবে শুরু করো যেন তা প্রত্যয়নপত্রের মূল অংশ হিসেবে সরাসরি ব্যবহার করা যায়।
    
    নাগরিকের তথ্য:
    নাম: \${data.name}
    পিতা/স্বামী: \${data.father}
    মাতা: \${data.mother}
    গ্রাম: \${data.village}, ডাকঘর: বহেড়াতৈল, ওয়ার্ড: \${data.ward || '০৫'}
    উপজেলা: সখিপুর, জেলা: টাঙ্গাইল।
    
    শর্তাবলী:
    ১. বাক্য শুরু করো এভাবে: "এই মর্মে প্রত্যয়ন করা যাইতেছে যে..."
    ২. কোনো ভূমিকা বা উপসংহার লিখবে না।
    ৩. দাপ্তরিক গাম্ভীর্য বজায় রাখো।
    ৪. সকল সংখ্যা বাংলা হরফে (০, ১, ২...) লেখো।
  \`;

  const payload = { contents: [{ parts: [{ text: prompt }] }] };
  const options = { method: 'post', contentType: 'application/json', payload: JSON.stringify(payload), muteHttpExceptions: true };

  try {
    const response = UrlFetchApp.fetch(apiUrl, options);
    const result = JSON.parse(response.getContentText());
    if (result.candidates && result.candidates[0].content) {
      return result.candidates[0].content.parts[0].text.trim();
    }
    return "এআই বিবরণী তৈরিতে ব্যর্থ হয়েছে।";
  } catch (e) {
    return "এআই সংযোগ ত্রুটি: " + e.toString();
  }
}`;

  const handleCopyTag = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTag(text);
    setTimeout(() => setCopiedTag(null), 1800);
  };

  const handleCopyCode = (text: string, fileName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedFile(fileName);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-emerald-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 text-white p-4 sm:p-5 flex items-center justify-between shrink-0 border-b border-emerald-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-400/20 text-amber-300 border border-amber-400/30 rounded-xl">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg text-white flex items-center gap-2">
                <span>Google Sheets Core Database & Apps Script অটোমেশন হাব</span>
                <span className="px-2 py-0.5 bg-amber-400 text-slate-950 text-[10px] font-black rounded">
                  ধাপ ১: Core Architecture
                </span>
              </h3>
              <p className="text-xs text-emerald-200 mt-0.5">
                ৬-ট্যাব ডাটাবেস ডিজাইন, ইভেন্ট লগিং স্কিমা, প্রাইভেসী ফিল্টার (PII Masking) ও Apps Script সংযোগ
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="text-emerald-200 hover:text-white p-2 rounded-full hover:bg-emerald-800/80 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="bg-slate-100 px-4 pt-3 pb-0 border-b border-slate-200 flex items-center gap-2 shrink-0 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('core_db')}
            className={`px-4 py-2.5 font-extrabold text-xs rounded-t-xl transition flex items-center gap-2 cursor-pointer border-t border-x ${
              activeTab === 'core_db'
                ? 'bg-white text-indigo-950 border-slate-200 shadow-sm'
                : 'bg-transparent text-slate-600 hover:text-slate-900 border-transparent'
            }`}
          >
            <Database className="w-4 h-4 text-indigo-600" />
            <span>🗄️ ধাপ ১: Core Database & Event Logging</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('placeholders')}
            className={`px-4 py-2.5 font-extrabold text-xs rounded-t-xl transition flex items-center gap-2 cursor-pointer border-t border-x ${
              activeTab === 'placeholders'
                ? 'bg-white text-emerald-950 border-slate-200 shadow-sm'
                : 'bg-transparent text-slate-600 hover:text-slate-900 border-transparent'
            }`}
          >
            <Table className="w-4 h-4 text-emerald-700" />
            <span>১. Google Doc প্লেসহোল্ডার ম্যাপিং</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('code')}
            className={`px-4 py-2.5 font-extrabold text-xs rounded-t-xl transition flex items-center gap-2 cursor-pointer border-t border-x ${
              activeTab === 'code'
                ? 'bg-white text-emerald-950 border-slate-200 shadow-sm'
                : 'bg-transparent text-slate-600 hover:text-slate-900 border-transparent'
            }`}
          >
            <Code className="w-4 h-4 text-emerald-700" />
            <span>২. Apps Script কোড ফাইলসমূহ (Supervisor_Core.gs)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('guide')}
            className={`px-4 py-2.5 font-extrabold text-xs rounded-t-xl transition flex items-center gap-2 cursor-pointer border-t border-x ${
              activeTab === 'guide'
                ? 'bg-white text-emerald-950 border-slate-200 shadow-sm'
                : 'bg-transparent text-slate-600 hover:text-slate-900 border-transparent'
            }`}
          >
            <BookOpen className="w-4 h-4 text-emerald-700" />
            <span>৩. ধাপভিত্তিক সেটআপ নির্দেশিকা</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-6 text-sm text-slate-700 bg-slate-50/50">
          
          {/* TAB 0: 6-TAB CORE DATABASE ARCHITECTURE */}
          {activeTab === 'core_db' && (
            <div className="space-y-6">
              
              {/* Introduction Banner */}
              <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-emerald-950 text-white p-5 rounded-2xl border border-indigo-700/50 shadow-md space-y-2">
                <div className="flex items-center gap-2 text-indigo-300 font-extrabold text-sm">
                  <Sparkles className="w-5 h-5 text-amber-300" />
                  <span>বহেড়াতৈল ইউনিয়ন পরিষদ — AI Supervisor সম্পূর্ণ ফ্রি Google Sheets ডাটাবেস</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  একটি একক মাস্টার স্প্রেডশিটের ভেতরে ৬টি সুনির্দিষ্ট <strong>Tab (Worksheet)</strong> তৈরি করা হয়েছে যা AI Supervisor-এর জন্য খাদ্য ও টেলিমেট্রি ডাটা সোর্স হিসেবে কাজ করে। প্রাইভেসী ফিল্টারের মাধ্যমে নাগরিকদের সব ব্যক্তিগত তথ্য (Phone, NID) সুরক্ষিত রেখে AI বিশ্লেষণ সম্পন্ন হয়।
                </p>
              </div>

              {/* 6 Tabs Grid */}
              <div className="space-y-3">
                <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                  <Layers className="w-4 h-4 text-indigo-700" />
                  <span>৬টি মূল শিটের স্ট্রাকচার ও কলাম তালিকা:</span>
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {coreDatabaseTabs.map((tab, idx) => (
                    <div key={idx} className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm space-y-3 hover:border-indigo-300 transition">
                      <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-2">
                        <div>
                          <span className="font-mono font-bold text-xs text-indigo-700 block">{tab.tabName}</span>
                          <h5 className="font-extrabold text-xs text-slate-900">{tab.banglaTitle}</h5>
                        </div>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${tab.badgeColor} shrink-0`}>
                          {tab.badge}
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        {tab.description}
                      </p>

                      <div className="bg-slate-50 rounded-lg p-2.5 border border-slate-200 space-y-1">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">কলামসমূহ:</span>
                        <div className="flex flex-wrap gap-1.5">
                          {tab.columns.map((col, cIdx) => (
                            <span key={cIdx} className="text-[10px] font-mono font-semibold px-2 py-0.5 bg-white border border-slate-300 rounded text-slate-800 shadow-2xs" title={col.desc}>
                              {col.name}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Privacy Filter Mechanism Interactive Tester */}
              <div className="bg-white p-5 rounded-2xl border border-emerald-200 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-600" />
                    <div>
                      <h4 className="font-extrabold text-sm text-slate-900">
                        🛡️ Privacy Filter Mechanism (লাইভ টেস্ট ও রেজাল্ট)
                      </h4>
                      <p className="text-xs text-slate-600">
                        Google Apps Script ও সিস্টেম শুধুমাত্র মাস্কড ডেটা AI-এর কাছে পাঠায়। নিচের ইনপুটে যেকোনো ফোন নম্বর, ১৭ ডিজিট NID বা ইমেইল টাইপ করে তাৎক্ষণিক মাস্কিং পরীক্ষা করুন।
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] font-black px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full border border-emerald-300">
                    Regex Masker Active
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      অপারেটর বা সিস্টেম ইনপুট (সংবেদনশীল ডাটা সহ):
                    </label>
                    <textarea
                      value={testPiiInput}
                      onChange={(e) => handleTestPiiChange(e.target.value)}
                      rows={3}
                      className="w-full text-xs p-3 rounded-xl border border-slate-300 bg-slate-50 focus:bg-white focus:border-emerald-600 font-mono"
                      placeholder="এখানে টেক্সট দিন..."
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      AI Supervisor-এর কাছে পৌঁছানো নিরাপদ আউটপুট:
                    </label>
                    <div className="w-full text-xs p-3 rounded-xl border border-emerald-300 bg-emerald-50/50 font-mono text-emerald-950 min-h-[74px] leading-relaxed break-all">
                      {maskedOutput || '<খালি>'}
                    </div>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* TAB 1: PLACEHOLDER MAPPING TABLE */}
          {activeTab === 'placeholders' && (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 space-y-1.5">
                <h4 className="font-bold text-emerald-950 text-xs sm:text-sm flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-700" />
                  <span>Google Doc টেমপ্লেটে এই প্লেসহোল্ডারগুলো ব্যবহার করুন:</span>
                </h4>
                <p className="text-xs text-emerald-800">
                  আপনার অফিসিয়াল Google Doc প্রত্যয়নপত্র ফরম্যাটে ডাবল কার্লি ব্র্যাকেটে <code className="bg-emerald-200 px-1.5 py-0.5 rounded font-mono font-bold text-emerald-950">{"{{name}}"}</code> বা বাংলা নাম বসিয়ে দিন। সিস্টেমে ক্লিক করার সাথে সাথে এই প্লেসহোল্ডারগুলো আসল ডাটা দিয়ে প্রতিস্থাপিত হয়ে যাবে।
                </p>
              </div>

              <div className="overflow-x-auto bg-white rounded-xl border border-slate-200 shadow-sm">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-extrabold border-b border-slate-200">
                      <th className="p-3">প্লেসহোল্ডার ট্যাগ</th>
                      <th className="p-3">বাংলা অল্টারনেটিভ ট্যাগ</th>
                      <th className="p-3">বিবরণ</th>
                      <th className="p-3">উদাহরণ ডাটা</th>
                      <th className="p-3 text-center">কপি করুন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 font-medium text-slate-800">
                    {placeholders.map((p, idx) => (
                      <tr key={idx} className="hover:bg-slate-50 transition">
                        <td className="p-3 font-mono font-black text-indigo-900">
                          <span className="px-2 py-1 bg-indigo-50 border border-indigo-200 rounded-md">
                            {p.tag}
                          </span>
                        </td>
                        <td className="p-3 font-mono font-bold text-emerald-900">
                          <span className="px-2 py-1 bg-emerald-50 border border-emerald-200 rounded-md">
                            {p.alias}
                          </span>
                        </td>
                        <td className="p-3 text-slate-700">{p.desc}</td>
                        <td className="p-3 font-mono text-slate-500 text-[11px]">{p.example}</td>
                        <td className="p-3 text-center whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => handleCopyTag(p.tag)}
                            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-[11px] rounded-lg transition inline-flex items-center gap-1 cursor-pointer border border-slate-300"
                          >
                            {copiedTag === p.tag ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-600" />
                                <span className="text-emerald-700 font-extrabold">কপি হয়েছে!</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5 text-slate-600" />
                                <span>কপি</span>
                              </>
                            )}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: APPS SCRIPT CODE FILES */}
          {activeTab === 'code' && (
            <div className="space-y-6">
              <div className="bg-slate-900 text-slate-100 p-4 rounded-xl text-xs space-y-1">
                <p className="font-bold text-amber-300 flex items-center gap-2">
                  <FileCode className="w-4 h-4" />
                  <span>Google Apps Script-এ কোড ফাইলসমূহ তৈরি করুন</span>
                </p>
                <p className="text-slate-300">
                  নিচের কোডগুলো আপনার গুগল শিটের <strong>Extensions &gt; Apps Script</strong> এডিটর-এ পেস্ট করে <strong>Deploy as Web App</strong> করুন।
                </p>
              </div>

              {/* Supervisor_Core.gs Box */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                    <Database className="w-4 h-4 text-indigo-700" /> Supervisor_Core.gs (৬-ট্যাব ডাটাবেস, PII মাস্কার ও ইভেন্ট রিসিভার)
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopyCode(supervisorCoreGsContent, 'Supervisor_Core.gs')}
                    className="flex items-center gap-1 px-3 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-900 text-xs font-bold rounded-lg border border-indigo-300 transition cursor-pointer"
                  >
                    {copiedFile === 'Supervisor_Core.gs' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedFile === 'Supervisor_Core.gs' ? 'কপি হয়েছে' : 'কপি Supervisor_Core.gs'}</span>
                  </button>
                </div>
                <pre className="bg-slate-900 text-indigo-300 p-4 rounded-xl text-xs font-mono overflow-x-auto max-h-56 leading-relaxed border border-slate-800">
                  {supervisorCoreGsContent}
                </pre>
              </div>

              {/* Code.gs Box */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                    <FileCode className="w-4 h-4 text-emerald-700" /> Code.gs (Google Doc সার্টিফিকেট জেনারেটর)
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopyCode(codeGsContent, 'Code.gs')}
                    className="flex items-center gap-1 px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg border border-slate-300 transition cursor-pointer"
                  >
                    {copiedFile === 'Code.gs' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedFile === 'Code.gs' ? 'কপি হয়েছে' : 'কপি Code.gs'}</span>
                  </button>
                </div>
                <pre className="bg-slate-900 text-emerald-400 p-4 rounded-xl text-xs font-mono overflow-x-auto max-h-56 leading-relaxed border border-slate-800">
                  {codeGsContent}
                </pre>
              </div>

              {/* Gemini.gs Box */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                    <FileCode className="w-4 h-4 text-amber-700" /> Gemini.gs (AI জেনারেশন স্ক্রিপ্ট)
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopyCode(geminiGsContent, 'Gemini.gs')}
                    className="flex items-center gap-1 px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg border border-slate-300 transition cursor-pointer"
                  >
                    {copiedFile === 'Gemini.gs' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedFile === 'Gemini.gs' ? 'কপি হয়েছে' : 'কপি Gemini.gs'}</span>
                  </button>
                </div>
                <pre className="bg-slate-900 text-amber-300 p-4 rounded-xl text-xs font-mono overflow-x-auto max-h-56 leading-relaxed border border-slate-800">
                  {geminiGsContent}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 3: STEP BY STEP SETUP GUIDE */}
          {activeTab === 'guide' && (
            <div className="space-y-4 text-xs sm:text-sm">
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-2 border-b border-slate-100 pb-2">
                  <Layers className="w-5 h-5 text-indigo-700" />
                  <span>ধাপ ১: Google Sheets-এ ৬-ট্যাব ডাটাবেস ইনিশিয়ালাইজেশন</span>
                </h4>
                <ol className="list-decimal list-inside space-y-1.5 text-slate-700 pl-1">
                  <li>Google Drive-এ একটি নতুন খালি Google Sheet তৈরি করুন।</li>
                  <li>মেনুবার হতে <b>Extensions &gt; Apps Script</b> চাপুন এবং <code className="bg-slate-100 px-1.5 py-0.5 rounded font-mono font-bold">Supervisor_Core.gs</code> ফাইলটি পেস্ট করুন।</li>
                  <li>উপরে <b>initializeSupervisorDatabase</b> ফাংশনটি সিলেক্ট করে <b>Run</b> চাপুন। এটি স্বয়ংক্রিয়ভাবে ৬টি ট্যাব ও কলাম হেডার তৈরি করে দেবে।</li>
                </ol>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-2 border-b border-slate-100 pb-2">
                  <Layers className="w-5 h-5 text-emerald-700" />
                  <span>ধাপ ২: Google Doc টেমপ্লেট প্রস্তুতকরণ</span>
                </h4>
                <ol className="list-decimal list-inside space-y-1.5 text-slate-700 pl-1">
                  <li>Google Drive-এ একটি নতুন Google Doc খুলুন এবং আপনার ইউনিয়নের লোগো, শিরোনাম ও প্যাড ডিজাইন করুন।</li>
                  <li>যেসব স্থানে গতিশীল ডাটা বসবে সেখানে <code className="bg-slate-100 px-1.5 py-0.5 rounded font-mono font-bold text-emerald-900">{"{{name}}"}</code>, <code className="bg-slate-100 px-1.5 py-0.5 rounded font-mono font-bold text-emerald-900">{"{{memoNo}}"}</code>, <code className="bg-slate-100 px-1.5 py-0.5 rounded font-mono font-bold text-emerald-900">{"{{qrCodeUrl}}"}</code> বসান।</li>
                  <li>Doc-এর URL থেকে ID অংশটি কপি করে রাখুন (যেমন: docs.google.com/document/d/<b>TEMPLATE_DOC_ID</b>/edit)।</li>
                </ol>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-2 border-b border-slate-100 pb-2">
                  <Layers className="w-5 h-5 text-emerald-700" />
                  <span>ধাপ ৩: Gemini API Key ও Web App প্রকাশকরণ</span>
                </h4>
                <ol className="list-decimal list-inside space-y-1.5 text-slate-700 pl-1">
                  <li>Apps Script এডিটরের ⚙️ <b>Project Settings &gt; Script Properties</b> অপশনে যান।</li>
                  <li>নতুন Property যোগ করুন: Name = <code className="bg-amber-100 px-1.5 py-0.5 rounded font-mono font-bold text-amber-950">GEMINI_API_KEY</code>, Value = আপনার Gemini API Key।</li>
                  <li>উপরে <b>Deploy &gt; New Deployment</b> চাপুন &rarr; Select type: <b>Web App</b> &rarr; Execute as: <b>Me</b> &rarr; Who has access: <b>Anyone</b> দিয়ে প্রকাশ করুন।</li>
                </ol>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-3 shrink-0">
          <a
            href="https://script.google.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-emerald-800 hover:text-emerald-950 font-bold flex items-center gap-1.5 transition"
          >
            <span>script.google.com এ যান (Google Apps Script)</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-black rounded-xl shadow transition cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>

      </div>
    </div>
  );
};

