import React, { useState } from 'react';
import { 
  Puzzle, 
  Download, 
  Code, 
  Chrome, 
  Globe, 
  CheckCircle2, 
  ShieldCheck, 
  Zap, 
  Terminal, 
  Copy, 
  Check, 
  FileCode, 
  Cpu, 
  RefreshCw,
  ExternalLink,
  Layers
} from 'lucide-react';
import { UnionParishadConfig } from '../types';

interface BrowserExtensionHubProps {
  config: UnionParishadConfig;
}

export const BrowserExtensionHub: React.FC<BrowserExtensionHubProps> = ({ config }) => {
  const [copiedScript, setCopiedScript] = useState<string | null>(null);
  const [selectedBrowser, setSelectedBrowser] = useState<'chrome' | 'firefox' | 'edge' | 'brave'>('chrome');
  const [extensionName, setExtensionName] = useState('UPSM Smart UDC Assistant Bridge');
  const [autoSyncEnabled, setAutoSyncEnabled] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'manifest' | 'content_script' | 'popup' | 'pipeline'>('overview');

  const appUrl = window.location.origin;

  const handleCopyCode = (code: string, key: string) => {
    navigator.clipboard.writeText(code);
    setCopiedScript(key);
    setTimeout(() => setCopiedScript(null), 2500);
  };

  // Manifest V3 code template
  const manifestCode = `{
  "manifest_version": 3,
  "name": "${extensionName}",
  "version": "2.5.0",
  "description": "02 No. Baheratail Union Parishad Smart Digital Certificate & NID Auto-Extractor Bridge for UDC Operators.",
  "permissions": [
    "activeTab",
    "storage",
    "scripting",
    "tabs"
  ],
  "host_permissions": [
    "https://services.nidw.gov.bd/*",
    "https://bris.gov.bd/*",
    "${appUrl}/*"
  ],
  "action": {
    "default_popup": "popup.html",
    "default_icon": {
      "16": "icon16.png",
      "48": "icon48.png",
      "128": "icon128.png"
    }
  },
  "background": {
    "service_worker": "background.js"
  },
  "content_scripts": [
    {
      "matches": [
        "https://services.nidw.gov.bd/*",
        "https://bris.gov.bd/*"
      ],
      "js": ["content.js"]
    }
  ]
}`;

  // Content script template
  const contentScriptCode = `// UPSM 2.0 Content Script for NID & Birth Registration Auto-Extraction
console.log("🏛️ UPSM UDC Assistant Bridge Active on Government Portal");

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  if (event.data && event.data.type === "UPSM_EXTRACT_REQUEST") {
    extractPortalData();
  }
});

function extractPortalData() {
  try {
    // Extract NID or Birth Registration Details from DOM
    const nameBn = document.querySelector('.name-bn, .citizen-name, h3')?.innerText || document.title;
    const nidNo = document.querySelector('.nid-number, .id-number')?.innerText || '';
    const dob = document.querySelector('.dob, .birth-date')?.innerText || '';
    const father = document.querySelector('.father-name')?.innerText || '';
    const mother = document.querySelector('.mother-name')?.innerText || '';

    const citizenData = {
      name: nameBn.trim(),
      nid: nidNo.replace(/\\D/g, ''),
      dob: dob.trim(),
      fatherName: father.trim(),
      motherName: mother.trim(),
      extractedAt: new Date().toISOString(),
      sourceUrl: window.location.href,
      unionParishad: "${config.upName}"
    };

    // Send to UPSM Web App Background / Window Bridge
    chrome.runtime.sendMessage({ action: "UPSM_SYNC_CITIZEN", data: citizenData }, (response) => {
      console.log("✅ UPSM Sync Response:", response);
    });

    // Also dispatch event to page
    window.postMessage({ type: "UPSM_DATA_READY", payload: citizenData }, "*");
  } catch (err) {
    console.error("UPSM Extraction Error:", err);
  }
}`;

  // Popup HTML template
  const popupHtmlCode = `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <title>UPSM UDC Extension</title>
  <style>
    body { width: 320px; font-family: 'Segoe UI', Tahoma, sans-serif; background: #064e3b; color: #fff; margin: 0; padding: 16px; }
    h2 { font-size: 16px; margin: 0 0 8px; color: #fde047; display: flex; align-items: center; gap: 8px; }
    p { font-size: 12px; color: #d1fae5; line-height: 1.4; }
    .card { background: #022c22; border: 1px solid #047857; border-radius: 8px; padding: 12px; margin-top: 12px; }
    button { width: 100%; background: #f59e0b; color: #111827; border: none; padding: 10px; border-radius: 6px; font-weight: bold; cursor: pointer; margin-top: 10px; transition: 0.2s; }
    button:hover { background: #fbbf24; }
    .status { font-size: 11px; color: #6ee7b7; margin-top: 6px; text-align: center; }
  </style>
</head>
<body>
  <h2>🏛️ UPSM Smart UDC Bridge</h2>
  <p>০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল সেন্টার</p>
  
  <div class="card">
    <strong>অটো-এক্সট্র্যাক্ট স্ট্যাটাস</strong>
    <p>পোর্টাল থেকে নাগরিক তথ্য শনাক্তকরণ সক্রিয়।</p>
    <button id="extractBtn">নিবন্ধিত NID তথ্য UPSM-এ পাঠান</button>
  </div>
  
  <div class="status" id="statusText">সিস্টেম কানেক্টেড: ${appUrl}</div>

  <script src="popup.js"></script>
</body>
</html>`;

  // Background worker script
  const backgroundJsCode = `// UPSM Background Service Worker
chrome.runtime.onInstalled.addListener(() => {
  console.log("UPSM Extension Installed Successfully.");
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "UPSM_SYNC_CITIZEN") {
    fetch("${appUrl}/api/citizens/sync", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request.data)
    })
    .then(res => res.json())
    .then(data => sendResponse({ success: true, data }))
    .catch(err => sendResponse({ success: false, error: err.message }));
    
    return true; // Keep channel open for async response
  }
});`;

  const handleDownloadPackage = () => {
    // Create zip or trigger download of text files representing the extension package
    const files = [
      { name: 'manifest.json', content: manifestCode },
      { name: 'content.js', content: contentScriptCode },
      { name: 'popup.html', content: popupHtmlCode },
      { name: 'background.js', content: backgroundJsCode }
    ];

    files.forEach(f => {
      const blob = new Blob([f.content], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = f.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });

    alert('✅ UPSM Extension package files (manifest.json, content.js, popup.html, background.js) downloaded successfully!\n\nলোড করার নিয়ম:\n১. Chrome ব্রাউজারে chrome://extensions/ এ যান।\n২. Developer mode চালু করুন।\n৩. Load unpacked এ ক্লিক করে ফোল্ডার সিলেক্ট করুন।');
  };

  return (
    <div className="space-y-6 animate-fade-in pb-12 max-w-7xl mx-auto px-4 sm:px-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-emerald-700 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-emerald-700/20 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold mb-3">
              <Puzzle className="w-4 h-4" />
              <span>Universal 3rd Party Extension & Pipeline Studio</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2">
              ইউপিএসএম ব্রাউজার এক্সটেনশন ও প্লাগইন হাব
            </h1>
            <p className="text-emerald-100 text-sm max-w-2xl leading-relaxed">
              অন্যান্য ব্রাউজার ও অফিসিয়াল পোর্টাল (NID, BRIS) থেকে সরাসরি নাগরিক তথ্য অটো-এক্সট্র্যাক্ট ও সিঙ্ক করার জন্য ম্যানিফেস্ট ভি৩ (Manifest V3) এক্সটেনশন প্যাকেজ তৈরি এবং প্লাগইন পাইপলাইন ম্যানেজ করুন।
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0 flex-wrap">
            <button
              onClick={handleDownloadPackage}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 px-5 py-3 rounded-2xl font-bold text-sm shadow-lg flex items-center gap-2 transition cursor-pointer"
            >
              <Download className="w-5 h-5" />
              <span>এক্সটেনশন প্যাকেজ ডাউনলোড (.zip)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Browser Selection & Tabs */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
              activeTab === 'overview' ? 'bg-emerald-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>ওভারভিউ ও ইনস্টলেশন</span>
          </button>
          <button
            onClick={() => setActiveTab('manifest')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
              activeTab === 'manifest' ? 'bg-emerald-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>manifest.json</span>
          </button>
          <button
            onClick={() => setActiveTab('content_script')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
              activeTab === 'content_script' ? 'bg-emerald-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>content.js (OCR Bridge)</span>
          </button>
          <button
            onClick={() => setActiveTab('popup')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
              activeTab === 'popup' ? 'bg-emerald-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Chrome className="w-4 h-4" />
            <span>popup.html / background.js</span>
          </button>
          <button
            onClick={() => setActiveTab('pipeline')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
              activeTab === 'pipeline' ? 'bg-emerald-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>মডুলার পাইপলাইন আর্কিটেকচার</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500">ব্রাউজার:</span>
          {(['chrome', 'firefox', 'edge', 'brave'] as const).map(b => (
            <button
              key={b}
              onClick={() => setSelectedBrowser(b)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition ${
                selectedBrowser === b ? 'bg-slate-900 text-white dark:bg-amber-400 dark:text-slate-950' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              {b}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold text-lg">
              1
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">এক্সটেনশন প্যাকেজ তৈরি</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              ডাউনলোড বাটনে ক্লিক করে `manifest.json`, `content.js`, `popup.html` এবং `background.js` ফাইলগুলো ডাউনলোড করুন। এগুলো মেনিফেস্ট ভি৩ (Manifest V3) স্ট্যান্ডার্ড অনুযায়ী তৈরি।
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="w-12 h-12 rounded-xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold text-lg">
              2
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">ব্রাউজারে ইনস্টল (Load Unpacked)</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              {selectedBrowser === 'firefox' ? 'ফায়ারফক্সে about:debugging এ গিয়ে Load Temporary Add-on সিলেক্ট করুন।' : 'ক্রোম বা এজ ব্রাউজারে chrome://extensions/ এ গিয়ে Developer mode অন করে Load unpacked ফোল্ডার সিলেক্ট করুন।'}
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="w-12 h-12 rounded-xl bg-teal-100 dark:bg-teal-950/80 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold text-lg">
              3
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">অটো-সিঙ্ক ও সার্টিফিকেট</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              সরকারি পোর্টালে এনআইডি বা জন্ম নিবন্ধন চেক করার সময় এক্সটেনশনটি স্বয়ংক্রিয়ভাবে তথ্য ক্যাচ করে UPSM সিস্টেমে পাঠিয়ে দেবে, ফলে আপনাকে ম্যানুয়ালি টাইপ করতে হবে না।
            </p>
          </div>
        </div>
      )}

      {activeTab === 'manifest' && (
        <div className="bg-slate-900 text-slate-100 rounded-2xl p-6 border border-slate-800 shadow-lg space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileCode className="w-5 h-5 text-amber-400" />
              <span className="font-mono text-sm font-bold">manifest.json (Manifest V3)</span>
            </div>
            <button
              onClick={() => handleCopyCode(manifestCode, 'manifest')}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-amber-300 flex items-center gap-1.5 transition cursor-pointer"
            >
              {copiedScript === 'manifest' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedScript === 'manifest' ? 'কপি হয়েছে!' : 'কপি কোড'}</span>
            </button>
          </div>
          <pre className="p-4 rounded-xl bg-slate-950 font-mono text-xs text-emerald-300 overflow-x-auto leading-relaxed border border-slate-800">
            {manifestCode}
          </pre>
        </div>
      )}

      {activeTab === 'content_script' && (
        <div className="bg-slate-900 text-slate-100 rounded-2xl p-6 border border-slate-800 shadow-lg space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="w-5 h-5 text-amber-400" />
              <span className="font-mono text-sm font-bold">content.js (DOM Scraper & Sync Bridge)</span>
            </div>
            <button
              onClick={() => handleCopyCode(contentScriptCode, 'content')}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-amber-300 flex items-center gap-1.5 transition cursor-pointer"
            >
              {copiedScript === 'content' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedScript === 'content' ? 'কপি হয়েছে!' : 'কপি কোড'}</span>
            </button>
          </div>
          <pre className="p-4 rounded-xl bg-slate-950 font-mono text-xs text-emerald-300 overflow-x-auto leading-relaxed border border-slate-800">
            {contentScriptCode}
          </pre>
        </div>
      )}

      {activeTab === 'popup' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-slate-900 text-slate-100 rounded-2xl p-6 border border-slate-800 shadow-lg space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-mono text-sm font-bold text-amber-400">popup.html</span>
              <button
                onClick={() => handleCopyCode(popupHtmlCode, 'popup')}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-amber-300 flex items-center gap-1.5 transition cursor-pointer"
              >
                {copiedScript === 'popup' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copiedScript === 'popup' ? 'কপি' : 'কপি কোড'}</span>
              </button>
            </div>
            <pre className="p-3 rounded-xl bg-slate-950 font-mono text-[11px] text-emerald-300 overflow-x-auto leading-relaxed border border-slate-800 max-h-64">
              {popupHtmlCode}
            </pre>
          </div>

          <div className="bg-slate-900 text-slate-100 rounded-2xl p-6 border border-slate-800 shadow-lg space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-mono text-sm font-bold text-amber-400">background.js</span>
              <button
                onClick={() => handleCopyCode(backgroundJsCode, 'bg')}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-amber-300 flex items-center gap-1.5 transition cursor-pointer"
              >
                {copiedScript === 'bg' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copiedScript === 'bg' ? 'কপি' : 'কপি কোড'}</span>
              </button>
            </div>
            <pre className="p-3 rounded-xl bg-slate-950 font-mono text-[11px] text-emerald-300 overflow-x-auto leading-relaxed border border-slate-800 max-h-64">
              {backgroundJsCode}
            </pre>
          </div>
        </div>
      )}

      {activeTab === 'pipeline' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">ভবিষ্যৎ সম্প্রসারণ ও প্লাগইন পাইপলাইন আর্কিটেকচার</h2>
              <p className="text-xs text-slate-500">ভবিষ্যতে নতুন কোনো সার্টিফিকেট বা মডিউল যুক্ত করার জন্য মডুলার রেজিস্ট্রি সিস্টেম</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-slate-900 dark:text-white">1. Plugin Registry (`src/plugins/`)</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200">সক্রিয়</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                নতুন যেকোনো প্রত্যয়ন বা সেবামূলক ফর্ম যুক্ত করতে কেবল একটি অবজেক্ট কনফিগারেশন যোগ করলেই সিস্টেম নিজে থেকেই ফর্ম, ফিল্ড ও প্রিন্ট লেআউট তৈরি করে নেয়।
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-slate-900 dark:text-white">2. Hook Middleware Pipeline</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">নিরাপদ</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                ডাটা এক্সট্রাকশন, ভ্যালিডেশন এবং প্রিন্টিংয়ের প্রতিটি ধাপে কাস্টম মিডেলওয়্যার হুক যুক্ত করা হয়েছে, যা বাগ ফিক্স ও আপডেটকে অত্যন্ত সহজ করে তোলে।
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-slate-900 dark:text-white">3. Offline-First IndexedDB Bridge</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-teal-100 text-teal-800 dark:bg-teal-900 dark:text-teal-200">রিয়েল-টাইম</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                ইন্টারনেট না থাকলেও সমস্ত ডাটা ব্রাউজারের নিজস্ব সুরক্ষিত স্টোরেজে সংরক্ষিত থাকে এবং সংযোগ পেলেই ক্লাউড ও ফায়ারবেসে সিঙ্ক হয়ে যায়।
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
