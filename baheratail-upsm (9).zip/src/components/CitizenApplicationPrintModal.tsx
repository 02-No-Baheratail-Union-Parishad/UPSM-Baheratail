import React, { useRef } from 'react';
import { 
  Printer, 
  X, 
  FileText, 
  CheckCircle2, 
  QrCode, 
  Building2, 
  MapPin, 
  Phone, 
  Calendar, 
  User, 
  Scissors, 
  Paperclip,
  ShieldCheck,
  Download
} from 'lucide-react';
import { UnionParishadConfig, CertificateRecord, CertificateAttachment } from '../types';
import { StyledQrCode } from './StyledQrCode';
import { formatBanglaDate, convertEnglishDateToBanglaFormatted, toBengaliNumeral } from '../lib/utils';

export interface ApplicationFormData {
  memoNo?: string;
  trackingNo?: string;
  typeKey: string;
  typeLabel: string;
  name: string;
  father: string;
  mother: string;
  spouseName?: string;
  gender: string;
  mobile: string;
  nid?: string;
  birthNo?: string;
  village: string;
  postOffice: string;
  postCode?: string;
  wardNo: string;
  holdingNo?: string;
  extra?: {
    simpleFields?: Record<string, string>;
    tables?: Record<string, any[]>;
  };
  attachments?: CertificateAttachment[];
  customNote?: string;
  feeAmount?: number;
  paymentMethod?: string;
  issueDate?: string;
}

interface CitizenApplicationPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: UnionParishadConfig;
  certificate?: CertificateRecord | null;
  formData?: ApplicationFormData | null;
}

export const CitizenApplicationPrintModal: React.FC<CitizenApplicationPrintModalProps> = ({
  isOpen,
  onClose,
  config,
  certificate,
  formData
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  // Normalize data from either certificate or direct formData
  const appData: ApplicationFormData = certificate ? {
    memoNo: certificate.memoNo,
    trackingNo: certificate.memoNo,
    typeKey: certificate.typeKey,
    typeLabel: certificate.typeLabel,
    name: certificate.citizen.name,
    father: certificate.citizen.father,
    mother: certificate.citizen.mother,
    spouseName: certificate.citizen.spouseName,
    gender: certificate.citizen.gender,
    mobile: certificate.citizen.mobile || '',
    nid: certificate.citizen.nid,
    birthNo: certificate.citizen.birthNo,
    village: certificate.citizen.village,
    postOffice: certificate.citizen.postOffice,
    postCode: certificate.citizen.postCode,
    wardNo: certificate.citizen.wardNo,
    holdingNo: certificate.citizen.holdingNo,
    extra: certificate.extra,
    attachments: certificate.attachments,
    feeAmount: certificate.feeAmount,
    paymentMethod: certificate.paymentMethod,
    issueDate: certificate.issueDate
  } : (formData || {
    typeKey: 'general',
    typeLabel: 'প্রত্যয়নপত্র / সনদ',
    name: '',
    father: '',
    mother: '',
    gender: 'পুরুষ',
    mobile: '',
    village: 'বহেড়াতৈল',
    postOffice: 'বহেড়াতৈল',
    wardNo: '০৫'
  });

  const currentDateBn = appData.issueDate || formatBanglaDate();
  const trackingNumber = appData.memoNo || appData.trackingNo || `APP-${Date.now().toString().slice(-6)}`;
  const publicTrackingUrl = `${window.location.origin}/?tab=track&memo=${encodeURIComponent(trackingNumber)}`;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static print:overflow-visible">
      {/* Container Dialog */}
      <div className="bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] print:max-h-none print:max-w-none print:w-full print:shadow-none print:border-none print:rounded-none">
        
        {/* Modal Top Action Toolbar (Hidden in Print) */}
        <div className="bg-slate-900 text-white px-5 py-3.5 flex items-center justify-between border-b border-slate-800 print:hidden shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-600/30 text-emerald-400 rounded-xl border border-emerald-500/30">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">নাগরিক আবেদনপত্র প্রিন্ট ও প্রিভিউ (Application Form)</h3>
              <p className="text-[11px] text-slate-300">
                স্মারক/ট্র্যাকিং: <span className="font-mono text-amber-300 font-bold">{trackingNumber}</span> | A4 একক পাতায় মুদ্রণযোগ্য
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4 text-amber-300" />
              <span>আবেদনপত্র প্রিন্ট করুন</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Printable Body */}
        <div className="p-4 sm:p-8 overflow-y-auto print:overflow-visible print:p-0 bg-slate-100/60 print:bg-white flex justify-center">
          
          {/* A4 Paper Sheet */}
          <div 
            ref={printRef}
            className="w-full max-w-[210mm] bg-white p-6 sm:p-8 shadow-sm border border-slate-200 print:border-none print:shadow-none text-slate-900 font-serif leading-relaxed text-[13px] print:text-[12px] space-y-4 print:space-y-3"
            style={{ minHeight: '297mm' }}
          >
            {/* 1. Official Header */}
            <div className="text-center border-b-2 border-emerald-900 pb-3 space-y-1 relative">
              <div className="flex items-center justify-between">
                {/* Govt Emblem */}
                <div className="w-16 h-16 flex items-center justify-center">
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/8/84/Government_Seal_of_Bangladesh.svg"
                    alt="Bangladesh Govt Seal"
                    className="w-14 h-14 object-contain"
                    crossOrigin="anonymous"
                  />
                </div>

                {/* Parishad Heading */}
                <div className="flex-1 px-2">
                  <p className="text-xs font-semibold text-slate-700">গণপ্রজাতন্ত্রী বাংলাদেশ সরকার</p>
                  <h1 className="text-xl sm:text-2xl font-black text-emerald-950 tracking-wide">
                    {config.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ কার্যালয়'}
                  </h1>
                  <p className="text-xs font-semibold text-slate-800">
                    {config.upazila || 'সখিপুর'}, {config.district || 'টাঙ্গাইল'}।
                  </p>
                  <p className="text-[11px] text-slate-600">
                    ওয়েবসাইট: {config.website || 'baheratailup.tangail.gov.bd'} | ইমেইল: {config.email || 'up.baheratail@gmail.com'}
                  </p>
                </div>

                {/* UP Custom Logo or Digital Emblem */}
                <div className="w-16 h-16 flex items-center justify-center">
                  {config.customLogoUrl ? (
                    <img
                      src={config.customLogoUrl}
                      alt="UP Logo"
                      className="w-14 h-14 object-contain rounded-full border border-emerald-300"
                    />
                  ) : (
                    <div className="w-14 h-14 rounded-full border border-emerald-700 bg-emerald-50 flex items-center justify-center p-1 text-center">
                      <span className="text-[9px] font-bold text-emerald-900">ইউনিয়ন পরিষদ সিল</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Form Title Banner */}
              <div className="pt-2">
                <span className="inline-block bg-emerald-900 text-white font-bold px-5 py-1 rounded-md text-sm sm:text-base tracking-wide uppercase shadow-2xs">
                  {appData.typeLabel} প্রাপ্তির আবেদনপত্র
                </span>
              </div>
            </div>

            {/* 2. Memo & Tracking Bar */}
            <div className="flex items-center justify-between text-xs font-bold text-slate-800 bg-slate-50 px-3 py-1.5 rounded border border-slate-200">
              <div>
                <span>আবেদন / ট্র্যাকিং নং: </span>
                <span className="font-mono text-emerald-950 text-sm font-black">{trackingNumber}</span>
              </div>
              <div>
                <span>আবেদনের তারিখ: </span>
                <span className="font-semibold">{currentDateBn}</span>
              </div>
            </div>

            {/* 3. Addressee */}
            <div className="text-xs space-y-0.5 pt-1">
              <p className="font-bold text-slate-900">বরাবর,</p>
              <p className="font-semibold text-slate-800">চেয়ারম্যান / প্রশাসক</p>
              <p className="text-slate-700">{config.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ'}, {config.upazila || 'সখিপুর'}, {config.district || 'টাঙ্গাইল'}।</p>
              <p className="font-bold text-slate-900 pt-1.5">
                বিষয়: <u>{appData.typeLabel} পাওয়ার জন্য আবেদন।</u>
              </p>
            </div>

            <p className="text-xs text-justify">
              জনাব,<br />
              বিনীত নিবেদন এই যে, আমি নিম্নস্বাক্ষরকারী অত্র ইউনিয়নের একজন স্থায়ী বাসিন্দা। আমার প্রয়োজনীয় দাপ্তরিক/ব্যক্তিগত কাজে ব্যবহারের নিমিত্তে <strong>"{appData.typeLabel}"</strong> প্রয়োজন। আমার সঠিক ব্যক্তিগত ও পারিবারিক বিবরণী নিচে উপস্থাপন করিলাম:
            </p>

            {/* 4. Applicant Details Table */}
            <div className="border border-slate-300 rounded overflow-hidden">
              <table className="w-full text-xs text-left border-collapse">
                <tbody>
                  <tr className="border-b border-slate-200 bg-slate-50/50">
                    <td className="p-2 font-bold w-1/4 border-r border-slate-200 bg-slate-100/70">১. আবেদনকারীর পূর্ণ নাম:</td>
                    <td className="p-2 font-black text-slate-900 text-sm">{appData.name || '—'}</td>
                    <td className="p-2 font-bold w-1/5 border-r border-l border-slate-200 bg-slate-100/70">লিঙ্গ ও বয়স:</td>
                    <td className="p-2">{appData.gender || 'পুরুষ'} {appData.extra?.simpleFields?.age ? `(${toBengaliNumeral(appData.extra.simpleFields.age)} বছর)` : ''}</td>
                  </tr>
                  <tr className="border-b border-slate-200">
                    <td className="p-2 font-bold border-r border-slate-200 bg-slate-100/70">২. পিতা / স্বামীর নাম:</td>
                    <td className="p-2 font-semibold">{appData.father || appData.spouseName || '—'} {appData.spouseName && appData.father ? `(স্বামী: ${appData.spouseName})` : ''}</td>
                    <td className="p-2 font-bold border-r border-l border-slate-200 bg-slate-100/70">৩. মাতার নাম:</td>
                    <td className="p-2 font-semibold">{appData.mother || '—'}</td>
                  </tr>
                  <tr className="border-b border-slate-200 bg-slate-50/50">
                    <td className="p-2 font-bold border-r border-slate-200 bg-slate-100/70">৪. NID / জন্ম নিবন্ধন নং:</td>
                    <td className="p-2 font-mono font-bold text-slate-900">{appData.nid || appData.birthNo || '—'}</td>
                    <td className="p-2 font-bold border-r border-l border-slate-200 bg-slate-100/70">৫. মোবাইল নম্বর:</td>
                    <td className="p-2 font-mono font-semibold">{appData.mobile || '—'}</td>
                  </tr>
                  <tr className="border-b border-slate-200">
                    <td className="p-2 font-bold border-r border-slate-200 bg-slate-100/70">৬. স্থায়ী ঠিকানা:</td>
                    <td colSpan={3} className="p-2">
                      গ্রাম: <strong>{appData.village}</strong>, ডাকঘর: <strong>{appData.postOffice}</strong> (পোস্ট কোড: {toBengaliNumeral(appData.postCode || '১৯৫০')}), 
                      ওয়ার্ড নং: <strong>{toBengaliNumeral(appData.wardNo)}</strong>, উপজেলা: {config.upazila || 'সখিপুর'}, জেলা: {config.district || 'টাঙ্গাইল'}।
                    </td>
                  </tr>
                  {appData.holdingNo && (
                    <tr className="border-b border-slate-200 bg-slate-50/50">
                      <td className="p-2 font-bold border-r border-slate-200 bg-slate-100/70">৭. হোল্ডিং / বাসা নম্বর:</td>
                      <td colSpan={3} className="p-2 font-mono font-bold">{appData.holdingNo}</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* 5. Custom Specific Extra Fields / Notes */}
            {appData.extra?.simpleFields && Object.keys(appData.extra.simpleFields).length > 0 && (
              <div className="border border-slate-200 rounded p-2 bg-slate-50 text-[11.5px] space-y-1">
                <span className="font-bold text-slate-800 block">সনদ সংশ্লিষ্ট অতিরিক্ত তথ্যাদি:</span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {Object.entries(appData.extra.simpleFields)
                    .filter(([k]) => k !== 'holdingNo' && k !== 'age')
                    .map(([key, val]) => (
                      <div key={key} className="bg-white p-1.5 rounded border border-slate-200">
                        <span className="text-slate-500 block text-[10px]">{key}:</span>
                        <span className="font-bold text-slate-900">{val || '—'}</span>
                      </div>
                    ))}
                </div>
              </div>
            )}

            {/* 6. Attached Documents Checklist */}
            <div className="border border-slate-200 rounded p-2.5 space-y-1 text-xs">
              <span className="font-bold text-slate-900 flex items-center gap-1.5">
                <Paperclip className="w-3.5 h-3.5 text-emerald-800" />
                <span>সংযুক্ত প্রমাণক দলিলাদির তালিকা (আবেদনের সাথে দাখিলকৃত):</span>
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-1 text-[11px] text-slate-700 pt-1">
                <label className="flex items-center gap-1.5">
                  <input type="checkbox" checked={!!(appData.nid || appData.birthNo)} readOnly className="rounded text-emerald-600" />
                  <span>জাতীয় পরিচয়পত্র / জন্ম সনদ কপি</span>
                </label>
                <label className="flex items-center gap-1.5">
                  <input type="checkbox" checked={true} readOnly className="rounded text-emerald-600" />
                  <span>ওয়ার্ড মেম্বারের সুপারিশ / প্রত্যয়ন</span>
                </label>
                <label className="flex items-center gap-1.5">
                  <input type="checkbox" checked={!!appData.holdingNo} readOnly className="rounded text-emerald-600" />
                  <span>হোল্ডিং ট্যাক্স পরিশোধের রশিদ</span>
                </label>
                <label className="flex items-center gap-1.5">
                  <input type="checkbox" checked={true} readOnly className="rounded text-emerald-600" />
                  <span>পাসপোর্ট সাইজ ছবি</span>
                </label>
                <label className="flex items-center gap-1.5">
                  <input type="checkbox" checked={!!(appData.attachments && appData.attachments.length > 0)} readOnly className="rounded text-emerald-600" />
                  <span>ডিজিটাল প্রমাণক ফাইল ({appData.attachments?.length || 0} টি)</span>
                </label>
                <label className="flex items-center gap-1.5">
                  <input type="checkbox" checked={false} readOnly className="rounded text-emerald-600" />
                  <span>অন্যান্য দলিলাদি / ওয়ারিশনামা</span>
                </label>
              </div>
            </div>

            {/* 7. Applicant Declaration */}
            <div className="border border-slate-300 rounded p-2.5 bg-slate-50/70 text-xs text-justify">
              <p className="font-bold text-slate-900 mb-0.5">আবেদনকারীর অঙ্গীকারনামা:</p>
              <p className="text-slate-700 leading-relaxed text-[11.5px]">
                আমি এই মর্মে অঙ্গীকার করিতেছি যে, উপরে বর্ণিত সকল তথ্য সম্পূর্ণ সত্য, সঠিক ও নির্ভুল। ভবিষ্যতে কোনো তথ্য ভুল বা মিথ্যা প্রমাণিত হইলে আমি আইনত দায়ী থাকিব এবং ইউনিয়ন পরিষদ কর্তৃপক্ষ কর্তৃক সনদটি বাতিল গণ্য হইবে।
              </p>
              <div className="flex justify-between items-end pt-5 text-xs">
                <span className="text-slate-600">তারিখ: {currentDateBn}</span>
                <div className="text-center">
                  <div className="w-40 border-b border-dashed border-slate-700 mb-1"></div>
                  <span className="font-bold text-slate-900">আবেদনকারীর স্বাক্ষর / টিপসহি</span>
                </div>
              </div>
            </div>

            {/* 8. Ward Member & Office Verification Section */}
            <div className="grid grid-cols-2 gap-3 pt-1 text-xs">
              {/* Member Recommendation Box */}
              <div className="border border-slate-300 rounded p-2.5 bg-white space-y-1 flex flex-col justify-between">
                <div>
                  <p className="font-bold text-emerald-950 border-b pb-1 mb-1">ওয়ার্ড সদস্য/সদস্যার সুপারিশ ও প্রত্যয়ন:</p>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    আমি আবেদনকারীকে ব্যক্তিগতভাবে চিনি। তিনি অত্র <strong>{toBengaliNumeral(appData.wardNo)} নং ওয়ার্ডের</strong> স্থায়ী বাসিন্দা এবং বর্ণিত সকল বিবরণী সত্য।
                  </p>
                </div>
                <div className="pt-6 text-center">
                  <div className="w-32 border-b border-dashed border-slate-700 mx-auto mb-1"></div>
                  <p className="font-bold text-slate-800 text-[11px]">মেম্বার / মহিলা মেম্বারের স্বাক্ষর ও সিল</p>
                </div>
              </div>

              {/* Office & Secretary Section */}
              <div className="border border-slate-300 rounded p-2.5 bg-white space-y-1 flex flex-col justify-between">
                <div>
                  <p className="font-bold text-emerald-950 border-b pb-1 mb-1">ইউনিয়ন পরিষদ দাপ্তরিক যাচাই ও মতামত:</p>
                  <div className="text-[11px] text-slate-700 space-y-0.5">
                    <p>ফি আদায়: ৳<strong>{toBengaliNumeral(appData.feeAmount || 50)}</strong> ({appData.paymentMethod || 'ক্যাশ'})</p>
                    <p>যাচাই অবস্থা: <strong>সঠিক পাওয়া গেছে</strong></p>
                  </div>
                </div>
                <div className="pt-6 text-center">
                  <div className="w-32 border-b border-dashed border-slate-700 mx-auto mb-1"></div>
                  <p className="font-bold text-slate-800 text-[11px]">সচিব / দায়িত্বপ্রাপ্ত কর্মকর্তার সিল ও স্বাক্ষর</p>
                </div>
              </div>
            </div>

            {/* 9. Perforated Receipt / Citizen Tracking Slip (Scissors Cut Line) */}
            <div className="pt-3 border-t-2 border-dashed border-slate-400 relative">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-white px-3 text-[11px] font-bold text-slate-500 flex items-center gap-1">
                <Scissors className="w-3.5 h-3.5" />
                <span>এখান থেকে কেটে নাগরিককে প্রাপ্তি স্বীকার স্লিপ প্রদান করুন</span>
              </div>

              {/* Citizen Slip Box */}
              <div className="border-2 border-emerald-900/60 rounded-xl p-3 bg-emerald-50/40 mt-1 flex items-center justify-between gap-3">
                <div className="space-y-1 flex-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-emerald-950 text-xs">
                      {config.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ'} — নাগরিক প্রাপ্তি স্বীকার ও ট্র্যাকিং স্লিপ
                    </span>
                    <span className="text-[10px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded font-bold">
                      গ্রাহক কপি
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-x-3 text-[11.5px] text-slate-800">
                    <p>আবেদনকারী: <strong>{appData.name}</strong></p>
                    <p>সনদের ধরন: <strong>{appData.typeLabel}</strong></p>
                    <p>গ্রাম: <strong>{appData.village}</strong> (ওয়ার্ড {toBengaliNumeral(appData.wardNo)})</p>
                    <p>আবেদনের তারিখ: <strong>{currentDateBn}</strong></p>
                    <p>স্মারক/ট্র্যাকিং নং: <strong className="font-mono text-emerald-900">{trackingNumber}</strong></p>
                    <p>সরকারি প্রত্যয়ন ফি: <strong>৳{toBengaliNumeral(appData.feeAmount || 50)}</strong> (পরিশোধিত)</p>
                  </div>

                  <p className="text-[10px] text-slate-600 italic pt-0.5">
                    * আপনার আবেদনের অগ্রগতি জানতে ডানপাশের কিউআর কোডটি মোবাইল ক্যামেরা দিয়ে স্ক্যান করুন।
                  </p>
                </div>

                {/* Tracking QR Code */}
                <div className="text-center shrink-0 p-1.5 bg-white rounded-lg border border-emerald-300 shadow-2xs">
                  <StyledQrCode
                    value={publicTrackingUrl}
                    size={64}
                    colorScheme="govt-emerald"
                    embedLogo={true}
                  />
                  <span className="text-[9px] font-bold text-emerald-900 block mt-0.5">অনলাইন ট্র্যাকিং</span>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Modal Footer Controls (Hidden in Print) */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-3 flex items-center justify-between text-xs text-slate-600 print:hidden shrink-0">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>বাংলাদেশ ইউনিয়ন পরিষদ বিধিমালা অনুযায়ী আবেদনপত্রটি ১ পাতায় প্রস্তুতকৃত।</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-5 py-2 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4 text-amber-300" />
              <span>প্রিন্ট করুন (Ctrl+P)</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl transition cursor-pointer"
            >
              বন্ধ করুন
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
