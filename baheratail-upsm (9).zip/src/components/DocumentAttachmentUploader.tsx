import React, { useState, useRef } from 'react';
import { 
  Paperclip, 
  UploadCloud, 
  FileText, 
  Image as ImageIcon, 
  Trash2, 
  Eye, 
  CheckCircle2, 
  AlertCircle, 
  FileCheck, 
  Camera, 
  HelpCircle,
  X,
  FileSpreadsheet,
  Tag
} from 'lucide-react';
import { CertificateAttachment } from '../types';

interface DocumentAttachmentUploaderProps {
  selectedTypeKey: string;
  selectedTypeLabel: string;
  categoryLabel?: string;
  attachments: CertificateAttachment[];
  onChangeAttachments: (attachments: CertificateAttachment[]) => void;
  onPreviewAttachment?: (attachment: CertificateAttachment) => void;
}

// Recommended document guidance based on certificate type
const RECOMMENDED_DOCUMENTS_MAP: Record<string, { title: string; docs: string[] }> = {
  citizenship: {
    title: 'নাগরিকত্ব ও জাতীয়তা সনদ',
    docs: ['জাতীয় পরিচয়পত্র (NID) অথবা অনলাইন জন্ম নিবন্ধন সনদ', 'পিতা বা মাতার জাতীয় পরিচয়পত্রের কপি', 'ওয়ার্ড মেম্বারের প্রত্যয়ন / সুপারিশ (যদি থাকে)']
  },
  character: {
    title: 'চারিত্রিক সনদপত্র',
    docs: ['জাতীয় পরিচয়পত্র (NID) / জন্ম সনদ', 'স্থানীয় গণ্যমান্য ব্যক্তি বা ওয়ার্ড প্রতিনিধির প্রত্যয়ন']
  },
  warish: {
    title: 'ওয়ারিশান / উত্তরাধিকার সনদপত্র',
    docs: [
      'মৃত ব্যক্তির অনলাইন মৃত্যু নিবন্ধন সনদপত্র (বাধ্যতামূলক প্রমাণক)',
      'সকল জীবিত ওয়ারিশগণের NID / ডিজিটাল জন্ম সনদের কপি',
      'পারিবারিক বণ্টননামা / ওয়ারিশ তালিকা / মেম্বার প্রত্যয়নপত্র'
    ]
  },
  trade_license: {
    title: 'ই-ট্রেড লাইসেন্স ও ব্যবসা সনদ',
    docs: [
      'দোকান বা ব্যবসা প্রতিষ্ঠানের ভাড়ার চুক্তিপত্র অথবা নিজস্ব জায়গার দলিল/পর্চা',
      'হোল্ডিং ট্যাক্স ও ট্রেড কর পরিশোধের হালনাগাদ রসিদ',
      'মালিকের জাতীয় পরিচয়পত্র (NID) ও পাসপোর্ট সাইজ ছবি'
    ]
  },
  income: {
    title: 'বাৎসরিক আয় ও আর্থিক সচ্ছলতা সনদ',
    docs: ['আয়ের সমর্থনে বেতন বিবরণী / ব্যাংক স্টেটমেন্ট / জমির খতিয়ান', 'ট্যাক্স রিটার্ন দাখিলের প্রমাণ (প্রযোজ্য ক্ষেত্রে)']
  },
  landless: {
    title: 'ভূমিহীন / নদীভাঙন প্রত্যয়নপত্র',
    docs: ['নদীভাঙন ও ভূমিহীনতার সমর্থনে স্থানীয় মেম্বারের সুপারিশ', 'জমির খতিয়ান বা পর্চা (যদি থাকে)']
  },
  unmarried: {
    title: 'অবিবাহিত সনদপত্র',
    docs: ['আবেদনকারীর NID / জন্ম সনদ', 'পিতা/মাতার প্রত্যয়ন বা মেম্বার প্রত্যয়নপত্র']
  },
  remarriage_permission: {
    title: 'পুনর্বিবাহ ও পারিবারিক অনুমতি সনদ',
    docs: ['পূর্ববর্তী স্ত্রীর সম্মতিপত্র / কোর্ট হলফনামা কপি', 'নিকাহনামা ও জাতীয় পরিচয়পত্র']
  },
  death_cert: {
    title: 'মৃত্যু সংক্রান্ত প্রত্যয়নপত্র',
    docs: ['চিকিৎসকের ডেথ সার্টিফিকেট / কবরস্থান বা শ্মশানের প্রত্যয়ন', 'মৃত ব্যক্তির NID বা জন্ম নিবন্ধন']
  }
};

const COMMON_DOC_CATEGORIES = [
  'জাতীয় পরিচয়পত্র (NID)',
  'জন্ম নিবন্ধন সনদ',
  'মৃত্যু নিবন্ধন সনদ',
  'ওয়ারিশ তালিকা / বণ্টননামা',
  'জমির দলিল / খতিয়ান',
  'ভাড়া চুক্তিপত্র',
  'হোল্ডিং ট্যাক্স রসিদ',
  'মেম্বার প্রত্যয়নপত্র',
  'অন্যান্য প্রমাণক'
];

export const DocumentAttachmentUploader: React.FC<DocumentAttachmentUploaderProps> = ({
  selectedTypeKey,
  selectedTypeLabel,
  categoryLabel,
  attachments,
  onChangeAttachments,
  onPreviewAttachment
}) => {
  const [selectedCategoryTag, setSelectedCategoryTag] = useState<string>(COMMON_DOC_CATEGORIES[0]);
  const [customDocTitle, setCustomDocTitle] = useState<string>('');
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [showDocGuidance, setShowDocGuidance] = useState<boolean>(true);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Determine guidance for current certificate
  const docGuidance = RECOMMENDED_DOCUMENTS_MAP[selectedTypeKey] || {
    title: selectedTypeLabel || 'প্রত্যয়নপত্র',
    docs: ['জাতীয় পরিচয়পত্র (NID) অথবা অনলাইন জন্ম সনদ', 'আবেদন সংশ্লিষ্ট প্রয়োজনীয় প্রমাণক দলিলাদি / মেম্বার সুপারিশ']
  };

  // Helper to compress image and convert to Base64
  const processImageFile = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (readerEvent) => {
        const image = new Image();
        image.onload = () => {
          // Resize if larger than 1280px to maintain crisp readability while keeping payload light
          const maxDim = 1280;
          let width = image.width;
          let height = image.height;

          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(image, 0, 0, width, height);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
            resolve(dataUrl);
          } else {
            resolve(readerEvent.target?.result as string);
          }
        };
        image.onerror = () => resolve(readerEvent.target?.result as string);
        image.src = readerEvent.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  // Process uploaded files
  const handleFiles = async (fileList: FileList | File[]) => {
    setUploadError(null);
    setIsProcessing(true);

    try {
      const newAttachments: CertificateAttachment[] = [];

      for (let i = 0; i < fileList.length; i++) {
        const file = fileList[i];

        // Max 10MB check
        if (file.size > 10 * 1024 * 1024) {
          setUploadError(`"${file.name}" ফাইলটি ১০ মেগাবাইটের বেশি। অনুগ্রহ করে ছোট সাইজের ফাইল নির্বাচন করুন।`);
          continue;
        }

        let dataUrl = '';
        if (file.type.startsWith('image/')) {
          dataUrl = await processImageFile(file);
        } else if (file.type === 'application/pdf' || file.name.endsWith('.pdf')) {
          dataUrl = await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });
        } else {
          setUploadError(`"${file.name}" ফাইল ফরম্যাট সমর্থিত নয়। শুধুমাত্র ছবি (JPG, PNG, WebP) অথবা PDF ফাইল আপলোড করুন।`);
          continue;
        }

        const docTitle = customDocTitle.trim() || selectedCategoryTag || file.name;

        newAttachments.push({
          id: `att_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          name: docTitle,
          type: file.type || (file.name.endsWith('.pdf') ? 'application/pdf' : 'image/jpeg'),
          size: file.size,
          dataUrl: dataUrl,
          uploadedAt: new Date().toISOString(),
          category: selectedCategoryTag
        });
      }

      if (newAttachments.length > 0) {
        onChangeAttachments([...attachments, ...newAttachments]);
        setCustomDocTitle('');
      }
    } catch (err: any) {
      console.error('File attachment processing error:', err);
      setUploadError('ফাইল প্রসেসিংয়ে ত্রুটি ঘটিয়াছে: ' + (err?.message || 'অনুগ্রহ করে পুনরায় চেষ্টা করুন'));
    } finally {
      setIsProcessing(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
      if (cameraInputRef.current) cameraInputRef.current.value = '';
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleRemoveAttachment = (id: string) => {
    onChangeAttachments(attachments.filter(a => a.id !== id));
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return '';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div id="section-attachments" className="bg-slate-50 dark:bg-slate-900/60 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
      {/* Header & Optional Indicator Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded-xl">
            <Paperclip className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                প্রমাণক দলিলাদি ও সংযুক্তিসমূহ (Attachments)
              </h3>
              <span className="px-2.5 py-0.5 bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-700 text-[11px] font-bold rounded-full">
                ঐচ্ছিক / বাধ্যতামূলক নয় (Optional)
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              আবেদনের ধরন অনুযায়ী প্রয়োজনীয় প্রমাণক ফাইল আপলোড করলে চেয়ারম্যান, সচিব ও ইউডিসি ভেরিফিকেশনে তা যাচাই করতে পারবেন।
            </p>
          </div>
        </div>

        {attachments.length > 0 && (
          <span className="self-start sm:self-auto px-3 py-1 bg-emerald-800 text-amber-300 text-xs font-black rounded-lg shadow-2xs">
            সংযুক্ত নথি: {attachments.length} টি
          </span>
        )}
      </div>

      {/* Suggested Guidance Box for this Certificate Type */}
      <div className="bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/80 rounded-xl p-3.5 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-900 dark:text-emerald-300">
            <HelpCircle className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
            <span>{docGuidance.title} এর জন্য প্রযোজ্য প্রমাণক সহায়িকা:</span>
          </div>
          <button
            type="button"
            onClick={() => setShowDocGuidance(!showDocGuidance)}
            className="text-[11px] text-emerald-700 dark:text-emerald-400 hover:underline font-semibold cursor-pointer"
          >
            {showDocGuidance ? 'লুকান' : 'দেখুন'}
          </button>
        </div>

        {showDocGuidance && (
          <ul className="text-xs text-emerald-950 dark:text-emerald-200 space-y-1 pl-5 list-disc">
            {docGuidance.docs.map((doc, idx) => (
              <li key={idx} className="leading-snug">
                {doc}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Category Tag Selector & Custom Title */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
          <Tag className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
          <span>ডকুমেন্টের ধরন / ক্যাটাগরি বাছাই করুন:</span>
        </label>
        
        <div className="flex flex-wrap gap-1.5">
          {COMMON_DOC_CATEGORIES.map(cat => (
            <button
              key={cat}
              type="button"
              onClick={() => {
                setSelectedCategoryTag(cat);
                if (!customDocTitle) setCustomDocTitle(cat);
              }}
              className={`px-2.5 py-1 text-xs rounded-lg border font-semibold transition cursor-pointer ${
                selectedCategoryTag === cat
                  ? 'bg-emerald-800 text-amber-300 border-emerald-800 shadow-2xs font-bold'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-emerald-600'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="pt-1">
          <input
            type="text"
            value={customDocTitle}
            onChange={(e) => setCustomDocTitle(e.target.value)}
            placeholder={`ডকুমেন্টের শিরোনাম লিখুন (যেমন: ${selectedCategoryTag})`}
            className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:border-emerald-600 focus:outline-none"
          />
        </div>
      </div>

      {/* Drag & Drop Upload Zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-xl p-5 text-center transition ${
          isDragging 
            ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/30 ring-2 ring-emerald-500/20' 
            : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/60 hover:border-emerald-500'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/jpeg,image/png,image/webp,application/pdf"
          onChange={(e) => e.target.files && handleFiles(e.target.files)}
          className="hidden"
        />

        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={(e) => e.target.files && handleFiles(e.target.files)}
          className="hidden"
        />

        <div className="flex flex-col items-center justify-center space-y-2">
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 rounded-full border border-emerald-200 dark:border-emerald-800">
            <UploadCloud className="w-6 h-6" />
          </div>

          <div className="space-y-0.5">
            <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
              ফাইল এখানে ড্র্যাগ করে ছাড়ুন অথবা ক্লিক করে আপলোড করুন
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              সমর্থিত ফরম্যাট: JPG, PNG, WebP, PDF (সর্বোচ্চ ১০MB)
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessing}
              className="px-4 py-2 bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Paperclip className="w-3.5 h-3.5 text-amber-300" />
              <span>ফাইল নির্বাচন করুন</span>
            </button>

            <button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              disabled={isProcessing}
              className="px-4 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-600 transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Camera className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>ক্যামেরা দিয়ে ছবি তুলুন</span>
            </button>
          </div>

          {isProcessing && (
            <p className="text-xs font-bold text-emerald-700 dark:text-emerald-400 animate-pulse pt-1">
              ডকুমেন্ট প্রস্তুত করা হচ্ছে...
            </p>
          )}
        </div>
      </div>

      {/* Error Message */}
      {uploadError && (
        <div className="p-3 bg-rose-50 dark:bg-rose-950/60 text-rose-800 dark:text-rose-200 border border-rose-300 dark:border-rose-800 rounded-xl text-xs flex items-center gap-2 font-semibold">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
          <span>{uploadError}</span>
        </div>
      )}

      {/* Uploaded Attachments List */}
      {attachments.length > 0 && (
        <div className="space-y-2 pt-1">
          <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
            <span>সংযুক্ত নথিপত্রসমূহ ({attachments.length} টি):</span>
            <span className="text-[11px] font-normal text-slate-500">অনুমোদনের সময় চেয়ারম্যান/সচিব এটি দেখতে পারবেন</span>
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {attachments.map((att, idx) => {
              const isPdf = att.type === 'application/pdf' || att.name.endsWith('.pdf');

              return (
                <div
                  key={att.id || idx}
                  className="bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700 shadow-2xs flex flex-col justify-between space-y-2 group hover:border-emerald-500 transition"
                >
                  <div className="flex items-start gap-2.5">
                    {/* Thumbnail preview */}
                    <div className="w-12 h-12 rounded-lg bg-slate-100 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 shrink-0 overflow-hidden flex items-center justify-center relative">
                      {!isPdf && att.dataUrl ? (
                        <img
                          src={att.dataUrl}
                          alt={att.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <FileText className="w-6 h-6 text-rose-600 dark:text-rose-400" />
                      )}
                      {isPdf && (
                        <span className="absolute bottom-0 inset-x-0 bg-rose-600 text-white text-[8px] font-black text-center py-0.5">
                          PDF
                        </span>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate" title={att.name}>
                        {att.name}
                      </p>
                      {att.category && (
                        <span className="inline-block bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-[10px] font-semibold px-1.5 py-0.2 rounded mt-0.5">
                          {att.category}
                        </span>
                      )}
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        {formatFileSize(att.size)}
                      </p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-700 text-xs">
                    <button
                      type="button"
                      onClick={() => onPreviewAttachment && onPreviewAttachment(att)}
                      className="text-emerald-700 dark:text-emerald-400 hover:text-emerald-900 font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>প্রিভিউ</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleRemoveAttachment(att.id)}
                      className="text-rose-600 hover:text-rose-800 dark:text-rose-400 font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>মুছুন</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
