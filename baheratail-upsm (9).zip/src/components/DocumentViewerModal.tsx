import React, { useState } from 'react';
import { 
  X, 
  Download, 
  ZoomIn, 
  ZoomOut, 
  RotateCw, 
  Maximize2, 
  FileText, 
  ChevronLeft, 
  ChevronRight, 
  Calendar, 
  Tag, 
  HardDrive,
  ExternalLink
} from 'lucide-react';
import { CertificateAttachment } from '../types';

interface DocumentViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  attachments: CertificateAttachment[];
  initialIndex?: number;
}

export const DocumentViewerModal: React.FC<DocumentViewerModalProps> = ({
  isOpen,
  onClose,
  attachments,
  initialIndex = 0
}) => {
  const [currentIndex, setCurrentIndex] = useState<number>(initialIndex);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [rotation, setRotation] = useState<number>(0);

  if (!isOpen || attachments.length === 0) return null;

  const currentDoc = attachments[currentIndex] || attachments[0];
  const isPdf = currentDoc.type === 'application/pdf' || currentDoc.name.endsWith('.pdf');

  const handleZoomIn = () => setZoomLevel(prev => Math.min(prev + 0.25, 3.0));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(prev - 0.25, 0.5));
  const handleResetZoom = () => {
    setZoomLevel(1);
    setRotation(0);
  };
  const handleRotate = () => setRotation(prev => (prev + 90) % 360);

  const handleNext = () => {
    if (currentIndex < attachments.length - 1) {
      setCurrentIndex(prev => prev + 1);
      handleResetZoom();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      handleResetZoom();
    }
  };

  const handleDownload = () => {
    if (!currentDoc.dataUrl) return;
    const a = document.createElement('a');
    a.href = currentDoc.dataUrl;
    a.download = currentDoc.name || 'document_attachment';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const formatSize = (bytes?: number) => {
    if (!bytes) return '';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Top Header Bar */}
        <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between gap-3 text-white">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-2 bg-emerald-950 text-emerald-400 rounded-xl border border-emerald-800 shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-bold text-slate-100 truncate" title={currentDoc.name}>
                {currentDoc.name}
              </h3>
              <div className="flex items-center gap-2 text-[11px] text-slate-400">
                {currentDoc.category && (
                  <span className="bg-emerald-900/60 text-emerald-300 px-2 py-0.5 rounded text-[10px] font-semibold border border-emerald-700/50">
                    {currentDoc.category}
                  </span>
                )}
                {currentDoc.size && <span>• {formatSize(currentDoc.size)}</span>}
                <span>• নথি {currentIndex + 1} / {attachments.length}</span>
              </div>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-1.5 shrink-0">
            {!isPdf && (
              <>
                <button
                  onClick={handleZoomIn}
                  className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition text-xs font-bold cursor-pointer"
                  title="জুম ইন"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
                <button
                  onClick={handleZoomOut}
                  className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition text-xs font-bold cursor-pointer"
                  title="জুম আউট"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
                <button
                  onClick={handleRotate}
                  className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition text-xs font-bold cursor-pointer"
                  title="ঘোরান (Rotate 90°)"
                >
                  <RotateCw className="w-4 h-4" />
                </button>
              </>
            )}

            <button
              onClick={handleDownload}
              className="p-2 bg-emerald-800 hover:bg-emerald-700 text-amber-300 rounded-lg transition text-xs font-bold flex items-center gap-1 cursor-pointer"
              title="ডাউনলোড করুন"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline text-xs">ডাউনলোড</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 bg-slate-800 hover:bg-rose-900 text-slate-400 hover:text-white rounded-lg transition cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Document Content View Area */}
        <div className="flex-1 bg-slate-950/60 p-4 overflow-auto flex items-center justify-center min-h-[360px] relative select-none">
          {/* Navigation Arrows for Multiple Documents */}
          {attachments.length > 1 && (
            <>
              <button
                onClick={handlePrev}
                disabled={currentIndex === 0}
                className="absolute left-4 top-1/2 -translate-y-1/2 p-2.5 bg-slate-900/90 hover:bg-slate-800 text-white rounded-full border border-slate-700 shadow-xl disabled:opacity-30 disabled:cursor-not-allowed transition z-10 cursor-pointer"
                title="পূর্ববর্তী নথি"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <button
                onClick={handleNext}
                disabled={currentIndex === attachments.length - 1}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-2.5 bg-slate-900/90 hover:bg-slate-800 text-white rounded-full border border-slate-700 shadow-xl disabled:opacity-30 disabled:cursor-not-allowed transition z-10 cursor-pointer"
                title="পরবর্তী নথি"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </>
          )}

          {/* Main Visual Render */}
          {isPdf ? (
            <div className="w-full h-full min-h-[500px] flex flex-col items-center justify-center">
              <iframe
                src={currentDoc.dataUrl}
                title={currentDoc.name}
                className="w-full h-[520px] rounded-xl border border-slate-800 bg-white"
              />
            </div>
          ) : currentDoc.dataUrl ? (
            <div className="overflow-auto max-h-[65vh] flex items-center justify-center">
              <img
                src={currentDoc.dataUrl}
                alt={currentDoc.name}
                style={{
                  transform: `scale(${zoomLevel}) rotate(${rotation}deg)`,
                  transition: 'transform 0.15s ease'
                }}
                className="max-h-[60vh] max-w-full object-contain rounded-lg shadow-2xl border border-slate-800"
                referrerPolicy="no-referrer"
              />
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400 space-y-2">
              <FileText className="w-12 h-12 mx-auto text-slate-600" />
              <p className="text-sm">নথির কোনো প্রিভিউ পাওয়া যায় নাই।</p>
            </div>
          )}
        </div>

        {/* Thumbnail Selector Bar (if multiple attachments) */}
        {attachments.length > 1 && (
          <div className="bg-slate-950 p-2.5 border-t border-slate-800 flex items-center gap-2 overflow-x-auto">
            {attachments.map((att, idx) => {
              const attIsPdf = att.type === 'application/pdf' || att.name.endsWith('.pdf');
              return (
                <button
                  key={att.id || idx}
                  onClick={() => {
                    setCurrentIndex(idx);
                    handleResetZoom();
                  }}
                  className={`flex items-center gap-2 p-1.5 rounded-lg border text-left shrink-0 transition cursor-pointer ${
                    currentIndex === idx
                      ? 'bg-emerald-950 border-emerald-500 ring-2 ring-emerald-500/50'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700 opacity-70 hover:opacity-100'
                  }`}
                >
                  <div className="w-8 h-8 rounded bg-slate-800 flex items-center justify-center overflow-hidden shrink-0">
                    {!attIsPdf && att.dataUrl ? (
                      <img src={att.dataUrl} alt={att.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <FileText className="w-4 h-4 text-rose-400" />
                    )}
                  </div>
                  <div className="text-[11px] text-slate-200 max-w-[120px] truncate">
                    <p className="font-bold truncate">{att.name}</p>
                    <p className="text-[9px] text-slate-400">{formatSize(att.size)}</p>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
