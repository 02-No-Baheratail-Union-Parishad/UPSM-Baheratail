import React, { useRef } from 'react';
import { 
  Printer, 
  X, 
  FileText, 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle2, 
  QrCode, 
  Edit3,
  Calendar,
  Building2
} from 'lucide-react';
import { UnionParishadConfig, CertificateRecord } from '../types';
import { StyledQrCode } from './StyledQrCode';
import { formatBanglaDate, convertEnglishDateToBanglaFormatted, toBengaliNumeral } from '../lib/utils';
import { ApplicationFormData } from './CitizenApplicationPrintModal';

interface DraftCertificatePrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: UnionParishadConfig;
  certificate?: CertificateRecord | null;
  formData?: ApplicationFormData | null;
  generatedDraftBody?: string;
  onEditRequested?: () => void;
}

export const DraftCertificatePrintModal: React.FC<DraftCertificatePrintModalProps> = ({
  isOpen,
  onClose,
  config,
  certificate,
  formData,
  generatedDraftBody,
  onEditRequested
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  // Normalize data from either certificate or form state
  const typeLabel = certificate?.typeLabel || formData?.typeLabel || 'নাগরিকত্ব ও চারিত্রিক সনদপত্র';
  const name = certificate?.citizen.name || formData?.name || '';
  const father = certificate?.citizen.father || formData?.father || '';
  const mother = certificate?.citizen.mother || formData?.mother || '';
  const spouseName = certificate?.citizen.spouseName || formData?.spouseName || '';
  const village = certificate?.citizen.village || formData?.village || 'বহেড়াতৈল';
  const postOffice = certificate?.citizen.postOffice || formData?.postOffice || 'বহেড়াতৈল';
  const wardNo = certificate?.citizen.wardNo || formData?.wardNo || '০৫';
  const nid = certificate?.citizen.nid || formData?.nid || '';
  const birthNo = certificate?.citizen.birthNo || formData?.birthNo || '';
  const memoNo = certificate?.memoNo || formData?.memoNo || `UP/BHT/DRAFT-${Date.now().toString().slice(-5)}`;
  const issueDate = certificate?.issueDate || formData?.issueDate || formatBanglaDate();

  // Fallback body text if not passed
  const bodyText = generatedDraftBody || certificate?.bodyText || `এই মর্মে প্রত্যয়ন করা যাইতেছে যে, ${name}, পিতা: ${father || spouseName}, মাতা: ${mother}, গ্রাম: ${village}, ডাকঘর: ${postOffice}, ওয়ার্ড নং: ${toBengaliNumeral(wardNo)}, উপজেলা: ${config.upazila || 'সখিপুর'}, জেলা: ${config.district || 'টাঙ্গাইল'}। তিনি অত্র ইউনিয়নের একজন স্থায়ী বাসিন্দা এবং বাংলাদেশ সরকারের একজন সুনাগরিক। আমার জানামতে তিনি কোনো রাষ্ট্র বা সমাজবিরোধী কাজে জড়িত নন। তাঁহার চারিত্রিক স্বভাব অত্যন্ত ভালো।\n\nআমি তাঁহার উজ্জ্বল ভবিষ্যৎ ও সার্বিক সাফল্য কামনা করি।`;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static print:overflow-visible">
      {/* Modal Container */}
      <div className="bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] print:max-h-none print:max-w-none print:w-full print:shadow-none print:border-none print:rounded-none">
        
        {/* Top Header Controls (Hidden in print) */}
        <div className="bg-amber-950 text-white px-5 py-3.5 flex items-center justify-between border-b border-amber-900 print:hidden shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/30">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-white">সনদের খসড়া কপি মুদ্রণ (Draft Certificate Review)</h3>
                <span className="bg-amber-500 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                  খসড়া সংস্করণ
                </span>
              </div>
              <p className="text-[11px] text-amber-200">
                সচিব ও চেয়ারম্যানের প্রাক-যাচাই ও ম্যানুয়াল স্বাক্ষরের জন্য DRAFT জলছাপযুক্ত কপি
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onEditRequested && (
              <button
                onClick={() => {
                  onClose();
                  onEditRequested();
                }}
                className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
              >
                <Edit3 className="w-4 h-4 text-amber-400" />
                <span>সংশোধন করুন</span>
              </button>
            )}
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4 text-slate-950" />
              <span>খসড়া প্রিন্ট করুন</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Certificate Sheet Container */}
        <div className="p-4 sm:p-8 overflow-y-auto print:overflow-visible print:p-0 bg-slate-100/60 print:bg-white flex justify-center">
          
          {/* A4 Sheet with DRAFT Styling & Watermark */}
          <div 
            ref={printRef}
            className="w-full max-w-[210mm] bg-white p-8 sm:p-10 shadow-sm border-2 border-dashed border-amber-600/60 print:border-none print:shadow-none text-slate-900 font-serif leading-relaxed text-[14px] print:text-[13px] space-y-6 relative overflow-hidden"
            style={{ minHeight: '297mm' }}
          >
            {/* Prominent Diagonal Watermark for DRAFT */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none z-0">
              <div className="transform -rotate-45 text-center opacity-10">
                <span className="text-6xl sm:text-8xl font-black text-red-900 tracking-widest block font-sans">
                  DRAFT COPY
                </span>
                <span className="text-2xl sm:text-3xl font-black text-red-950 tracking-wider block mt-2">
                  খসড়া কপি — অনুমোদনের জন্য নহে
                </span>
              </div>
            </div>

            {/* DRAFT Top Caution Strip */}
            <div className="relative z-10 bg-amber-50 border border-amber-300 rounded-lg p-2 text-center text-xs text-amber-900 font-bold flex items-center justify-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0" />
              <span>⚠️ খসড়া কপি (DRAFT REVIEW) — শুধুমাত্র সচিব/চেয়ারম্যান ও নাগরিকের তথ্য যাচাইয়ের জন্য প্রযোজ্য।</span>
            </div>

            {/* 1. Official Header */}
            <div className="relative z-10 text-center border-b-2 border-emerald-900 pb-4 space-y-1">
              <div className="flex items-center justify-between">
                {/* Govt Emblem */}
                <div className="w-16 h-16 flex items-center justify-center">
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/8/84/Government_Seal_of_Bangladesh.svg"
                    alt="Bangladesh Govt Seal"
                    className="w-14 h-14 object-contain"
                    crossOrigin="anonymous"
                  />
                </div>

                {/* Center Title */}
                <div className="flex-1 px-2">
                  <p className="text-xs font-semibold text-slate-700">গণপ্রজাতন্ত্রী বাংলাদেশ সরকার</p>
                  <h1 className="text-xl sm:text-2xl font-black text-emerald-950 tracking-wide">
                    {config.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ কার্যালয়'}
                  </h1>
                  <p className="text-xs font-semibold text-slate-800">
                    {config.upazila || 'সখিপুর'}, {config.district || 'টাঙ্গাইল'}।
                  </p>
                  <p className="text-[11px] text-slate-600">
                    ইমেইল: {config.email || 'up.baheratail@gmail.com'} | স্থাপিত: ১৯৭২ ইং
                  </p>
                </div>

                {/* UP Custom Logo or Digital Emblem */}
                <div className="w-16 h-16 flex items-center justify-center">
                  {config.customLogoUrl ? (
                    <img
                      src={config.customLogoUrl}
                      alt="UP Logo"
                      className="w-14 h-14 object-contain rounded-full border border-emerald-300"
                    />
                  ) : (
                    <div className="w-14 h-14 rounded-full border border-emerald-700 bg-emerald-50 flex items-center justify-center p-1 text-center">
                      <span className="text-[9px] font-bold text-emerald-900">ইউনিয়ন পরিষদ সিল</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Certificate Title Badge */}
              <div className="pt-3">
                <span className="inline-block bg-emerald-950 text-white font-black px-6 py-1.5 rounded-lg text-base sm:text-lg tracking-wide shadow-2xs">
                  {typeLabel} (খসড়া)
                </span>
              </div>
            </div>

            {/* 2. Memo & Issue Date Bar */}
            <div className="relative z-10 flex items-center justify-between text-xs font-bold text-slate-800 bg-slate-50 px-4 py-2 rounded-lg border border-slate-200">
              <div>
                <span>খসড়া স্মারক নং: </span>
                <span className="font-mono text-emerald-950 text-sm font-black">{memoNo}</span>
              </div>
              <div>
                <span>তারিখ: </span>
                <span className="font-semibold">{issueDate}</span>
              </div>
            </div>

            {/* 3. Certificate Generated Body Content */}
            <div className="relative z-10 pt-2 space-y-4 text-justify leading-relaxed text-slate-900 font-serif">
              {bodyText.split('\n\n').map((para, index) => (
                <p key={index} className="text-sm sm:text-base leading-loose indent-8">
                  {para}
                </p>
              ))}
            </div>

            {/* 4. Applicant Quick Key Information Box */}
            <div className="relative z-10 border border-slate-300 rounded-xl p-3 bg-slate-50/70 text-xs space-y-1.5">
              <span className="font-bold text-slate-800 block border-b pb-1">যাচাইযোগ্য তথ্যাদি:</span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-slate-700">
                <p>নাম: <strong className="text-slate-900">{name}</strong></p>
                <p>পিতা: <strong>{father || '—'}</strong></p>
                <p>মাতা: <strong>{mother || '—'}</strong></p>
                <p>NID/জন্ম নং: <strong className="font-mono">{nid || birthNo || '—'}</strong></p>
                <p>গ্রাম: <strong>{village}</strong></p>
                <p>ওয়ার্ড নং: <strong>{toBengaliNumeral(wardNo)}</strong></p>
              </div>
            </div>

            {/* 5. Pre-Approval Inspection Checklist (For Secretary & Chairman Manual Marking) */}
            <div className="relative z-10 border-2 border-amber-400 rounded-xl p-3 bg-amber-50/50 space-y-2 text-xs">
              <span className="font-bold text-amber-950 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-amber-700" />
                <span>সচিব ও চেয়ারম্যানের ম্যানুয়াল যাচাই চেকলিস্ট (অনুমোদনের পূর্বে যাচাই করুন):</span>
              </span>
              <div className="grid grid-cols-2 gap-2 text-[11.5px] text-slate-800 pt-1">
                <label className="flex items-center gap-2 cursor-pointer bg-white p-1.5 rounded border border-amber-200">
                  <input type="checkbox" className="rounded text-emerald-600" />
                  <span>জাতীয় পরিচয়পত্র (NID) / জন্ম সনদ ডাটাবেসে সঠিক</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer bg-white p-1.5 rounded border border-amber-200">
                  <input type="checkbox" className="rounded text-emerald-600" />
                  <span>ওয়ার্ড মেম্বার ও গ্রামবাসীর প্রত্যয়নের মিল আছে</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer bg-white p-1.5 rounded border border-amber-200">
                  <input type="checkbox" className="rounded text-emerald-600" />
                  <span>ইউনিয়ন পরিষদ হোল্ডিং ট্যাক্স পরিশোধিত</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer bg-white p-1.5 rounded border border-amber-200">
                  <input type="checkbox" className="rounded text-emerald-600" />
                  <span>চূড়ান্ত ডিজিটাল স্বাক্ষর ও সিল দেওয়ার উপযোগী</span>
                </label>
              </div>
            </div>

            {/* 6. Signature & Seal Area (Draft Review State) */}
            <div className="relative z-10 pt-8 grid grid-cols-3 gap-4 text-center text-xs">
              {/* Operator */}
              <div className="space-y-1">
                <div className="h-12 flex items-end justify-center">
                  <span className="text-[10px] text-slate-400 italic">ডাটা প্রস্তুতকারী (UDC)</span>
                </div>
                <div className="w-28 border-b border-dashed border-slate-700 mx-auto"></div>
                <p className="font-bold text-slate-800">কম্পিউটার অপারেটর</p>
                <p className="text-[10px] text-slate-500">ইউপি ডিজিটাল সেন্টার</p>
              </div>

              {/* Secretary Verification */}
              <div className="space-y-1">
                <div className="h-12 flex items-end justify-center">
                  <span className="text-[10px] text-amber-800 font-bold bg-amber-100 px-2 py-0.5 rounded">
                    সচিব সুপারিশ বক্স
                  </span>
                </div>
                <div className="w-28 border-b border-dashed border-slate-700 mx-auto"></div>
                <p className="font-bold text-slate-800">ইউপি সচিব</p>
                <p className="text-[10px] text-slate-500">{config.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ'}</p>
              </div>

              {/* Chairman Final Approval */}
              <div className="space-y-1">
                <div className="h-12 flex items-end justify-center">
                  <span className="text-[10px] text-emerald-800 font-bold bg-emerald-100 px-2 py-0.5 rounded">
                    চেয়ারম্যান অনুমোদন বক্স
                  </span>
                </div>
                <div className="w-32 border-b border-dashed border-slate-700 mx-auto"></div>
                <p className="font-bold text-emerald-950">চেয়ারম্যান / প্রশাসক</p>
                <p className="text-[10px] text-slate-500">{config.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ'}</p>
              </div>
            </div>

            {/* Bottom Footer Note */}
            <div className="relative z-10 pt-4 text-center text-[10px] text-slate-400 border-t border-slate-200">
              নোট: এই খসড়া কপিটি কোনো অফিস বা আদালতে দাপ্তরিক সনদ হিসেবে গ্রহণযোগ্য নহে। চূড়ান্ত ডিজিটাল স্বাক্ষর ও কিউআর সিল সম্পন্ন সনদই কেবল বৈধ।
            </div>

          </div>
        </div>

        {/* Modal Bottom Actions (Hidden in Print) */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-3 flex items-center justify-between text-xs text-slate-600 print:hidden shrink-0">
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-amber-600" />
            <span>খসড়া কপিতে তথ্যের নির্ভুলতা নিশ্চিত করে চূড়ান্ত অনুমোদনে প্রেরণ করুন।</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4 text-slate-950" />
              <span>খসড়া প্রিন্ট করুন (Ctrl+P)</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl transition cursor-pointer"
            >
              বন্ধ করুন
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
