import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Building2, 
  Home, 
  Store, 
  Factory, 
  Landmark, 
  CreditCard, 
  DollarSign, 
  Search, 
  Filter, 
  Plus, 
  Printer, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  TrendingUp, 
  Download, 
  Send, 
  ExternalLink, 
  Phone, 
  User, 
  FileText, 
  ChevronRight, 
  RefreshCw, 
  X, 
  Layers, 
  Check, 
  QrCode,
  ShieldCheck,
  MapPin,
  PieChart,
  BarChart3,
  Calendar,
  Eye,
  MessageSquare,
  Copy,
  Sparkles,
  AlertTriangle,
  FileSpreadsheet,
  Share2,
  CheckSquare,
  FileCheck2,
  Loader2,
  Calculator,
  Upload,
  Percent,
  Scissors,
  SlidersHorizontal,
  ImageIcon,
  Info
} from 'lucide-react';
import { 
  HoldingTaxRecord, 
  HoldingTaxWardSummary, 
  HoldingType, 
  TaxPaymentStatus, 
  UnionParishadConfig,
  HoldingTaxReceipt
} from '../types';
import { INITIAL_HOLDING_TAX_RECORDS, computeHoldingTaxWardSummaries } from '../data/holdingTaxData';
import { WARD_VILLAGE_MAPPINGS } from '../data/villages';
import { generateTaxReceiptQRCode, downloadReceiptAsPDF } from '../utils/taxReceiptPdf';
import { WardArrearsReportModal } from './holdingTax/WardArrearsReportModal';
import { TaxAssessmentCalculatorModal } from './holdingTax/TaxAssessmentCalculatorModal';

interface HoldingTaxDashboardProps {
  config: UnionParishadConfig;
}

export const HoldingTaxDashboard: React.FC<HoldingTaxDashboardProps> = ({ config }) => {
  // State
  const [records, setRecords] = useState<HoldingTaxRecord[]>(INITIAL_HOLDING_TAX_RECORDS);
  const [loading, setLoading] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedWard, setSelectedWard] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedFiscalYear, setSelectedFiscalYear] = useState<string>('২০২৫-২০২৬');
  const [onlyDefaulters, setOnlyDefaulters] = useState<boolean>(false);
  
  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [isCollectModalOpen, setIsCollectModalOpen] = useState<boolean>(false);
  const [selectedRecordForPayment, setSelectedRecordForPayment] = useState<HoldingTaxRecord | null>(null);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState<boolean>(false);
  const [activeReceipt, setActiveReceipt] = useState<HoldingTaxReceipt | null>(null);
  const [isReminderGeneratorOpen, setIsReminderGeneratorOpen] = useState<boolean>(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [isCalculatorModalOpen, setIsCalculatorModalOpen] = useState<boolean>(false);
  const [viewDetailsRecord, setViewDetailsRecord] = useState<HoldingTaxRecord | null>(null);
  const [isPrintWardNoticesOpen, setIsPrintWardNoticesOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isDownloadingPdf, setIsDownloadingPdf] = useState<boolean>(false);

  // Automated Reminder Generator State
  const [reminderWard, setReminderWard] = useState<string>('all');
  const [reminderTemplateType, setReminderTemplateType] = useState<'standard' | 'urgent' | 'rebate' | 'custom'>('standard');
  const [customReminderTemplate, setCustomReminderTemplate] = useState<string>(
    'সম্মানিত করদাতা {{মালিকের_নাম}},\n{{ইউপি_নাম}}-এর হোল্ডিং নং {{হোল্ডিং_নং}} (গ্রাম: {{গ্রাম}}, ওয়ার্ড: {{ওয়ার্ড_নং}})-এর {{অর্থবছর}} অর্থবছরের বকেয়া কর বাবদ ৳{{বকেয়া_টাকা}}/- আগামী {{শেষ_তারিখ}}-এর মধ্যে পরিশোধের জন্য অনুরোধ করা যাচ্ছে। - চেয়ারম্যান'
  );
  const [reminderDeadline, setReminderDeadline] = useState<string>('১৫ দিনের মধ্যে');
  const [selectedPreviewTaxpayerId, setSelectedPreviewTaxpayerId] = useState<string | null>(null);

  // New Holding Form State
  const [newHoldingForm, setNewHoldingForm] = useState({
    holdingNo: '',
    holdingType: 'residential' as HoldingType,
    structureType: 'semi_pucca',
    ownerName: '',
    guardianName: '',
    motherName: '',
    mobile: '',
    nid: '',
    wardNo: '০১',
    village: 'ডাবাইল',
    postOffice: 'নাগবাড়ী',
    annualValuation: '20000',
    currentTaxDemand: '1000',
    arrearsDue: '0',
    fiscalYear: '২০২৫-২০২৬',
    notes: ''
  });

  // Union Parishad Logo State (Defaults to system config logo, can be uploaded/customized)
  const [customLogoUrl, setCustomLogoUrl] = useState<string>(config.logoUrl || '/baheratail_seal.svg');

  useEffect(() => {
    if (config.logoUrl) {
      setCustomLogoUrl(config.logoUrl);
    }
  }, [config.logoUrl]);

  // Handle Logo Upload from System / Computer
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 3 * 1024 * 1024) {
        alert('অনুগ্রহ করে ৩ এমবি (3MB)-এর কম সাইজের ছবি নির্বাচন করুন।');
        return;
      }
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        if (result) {
          setCustomLogoUrl(result);
          config.logoUrl = result;
          if (activeReceipt) {
            setActiveReceipt({ ...activeReceipt, unionLogoUrl: result });
          }
          setToastMessage('✅ ইউনিয়ন পরিষদের অফিসিয়াল লগো সফলভাবে আপলোড ও আপডেট করা হয়েছে!');
          setTimeout(() => setToastMessage(null), 4000);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Payment Collection & Deduction Form State
  const [paymentForm, setPaymentForm] = useState({
    paymentAmount: '',
    customPaymentMode: 'full' as 'full' | 'half' | 'custom',
    paymentMethod: 'Cash' as 'bKash' | 'Nagad' | 'Cash' | 'Bank' | 'Rocket',
    trxId: '',
    collectedBy: 'ইউপি ট্যাক্স আদায়কারী',
    notes: '',
    isDiscountEnabled: false,
    discountAmount: '',
    deductionReason: 'দরিদ্রতা ও অসচ্ছলতা বিবেচনায় বিশেষ ছাড়',
    allowDemandOverride: false,
    overrideDemand: ''
  });

  // Fetch holding tax records from backend API
  const fetchHoldingTaxData = async () => {
    setLoading(true);
    try {
      const queryParams = new URLSearchParams();
      if (selectedWard !== 'all') queryParams.append('ward', selectedWard);
      if (selectedType !== 'all') queryParams.append('holdingType', selectedType);
      if (selectedStatus !== 'all') queryParams.append('paymentStatus', selectedStatus);
      if (selectedFiscalYear !== 'all') queryParams.append('fiscalYear', selectedFiscalYear);
      if (searchQuery.trim()) queryParams.append('search', searchQuery.trim());

      const res = await fetch(`/api/holding-tax?${queryParams.toString()}`);
      const data = await res.json();
      if (data.success && Array.isArray(data.records)) {
        setRecords(data.records);
      }
    } catch (err) {
      console.warn('API error, using local fallback:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHoldingTaxData();
  }, [selectedWard, selectedType, selectedStatus, selectedFiscalYear]);

  // Handle Search Trigger
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchHoldingTaxData();
  };

  // Filtered Records (accounting for onlyDefaulters flag)
  const displayedRecords = useMemo(() => {
    let list = records;
    if (onlyDefaulters) {
      list = list.filter(r => (r.currentDue || 0) > 0);
    }
    return list;
  }, [records, onlyDefaulters]);

  // Compute Overall KPI Metrics
  const metrics = useMemo(() => {
    const totalHoldings = records.length;
    const totalDemand = records.reduce((sum, r) => sum + (r.totalDemand || 0), 0);
    const totalCollected = records.reduce((sum, r) => sum + (r.paidAmount || 0), 0);
    const totalDue = records.reduce((sum, r) => sum + (r.currentDue || 0), 0);
    const collectionRate = totalDemand > 0 ? Math.round((totalCollected / totalDemand) * 100) : 0;

    const residentialRecords = records.filter(r => r.holdingType === 'residential');
    const commercialRecords = records.filter(r => r.holdingType === 'commercial');
    const industrialRecords = records.filter(r => r.holdingType === 'industrial');

    const residentialDemand = residentialRecords.reduce((sum, r) => sum + (r.totalDemand || 0), 0);
    const residentialCollected = residentialRecords.reduce((sum, r) => sum + (r.paidAmount || 0), 0);
    const residentialDue = residentialRecords.reduce((sum, r) => sum + (r.currentDue || 0), 0);

    const commercialDemand = commercialRecords.reduce((sum, r) => sum + (r.totalDemand || 0), 0);
    const commercialCollected = commercialRecords.reduce((sum, r) => sum + (r.paidAmount || 0), 0);
    const commercialDue = commercialRecords.reduce((sum, r) => sum + (r.currentDue || 0), 0);

    const paidCount = records.filter(r => r.paymentStatus === 'paid').length;
    const partialCount = records.filter(r => r.paymentStatus === 'partial').length;
    const unpaidCount = records.filter(r => r.paymentStatus === 'unpaid').length;

    return {
      totalHoldings,
      totalDemand,
      totalCollected,
      totalDue,
      collectionRate,
      paidCount,
      partialCount,
      unpaidCount,
      residential: {
        count: residentialRecords.length,
        demand: residentialDemand,
        collected: residentialCollected,
        due: residentialDue,
        rate: residentialDemand > 0 ? Math.round((residentialCollected / residentialDemand) * 100) : 0
      },
      commercial: {
        count: commercialRecords.length,
        demand: commercialDemand,
        collected: commercialCollected,
        due: commercialDue,
        rate: commercialDemand > 0 ? Math.round((commercialCollected / commercialDemand) * 100) : 0
      },
      industrial: {
        count: industrialRecords.length,
        demand: industrialRecords.reduce((sum, r) => sum + (r.totalDemand || 0), 0),
        collected: industrialRecords.reduce((sum, r) => sum + (r.paidAmount || 0), 0),
        due: industrialRecords.reduce((sum, r) => sum + (r.currentDue || 0), 0)
      }
    };
  }, [records]);

  // Compute Ward-Wise Summaries
  const wardSummaries = useMemo(() => {
    return computeHoldingTaxWardSummaries(records);
  }, [records]);

  // Active Ward Summary details if a ward is selected
  const activeWardSummary = useMemo(() => {
    if (selectedWard === 'all') return null;
    return wardSummaries.find(w => w.wardNo === selectedWard) || null;
  }, [wardSummaries, selectedWard]);

  // Defaulter list for Automated Reminders
  const reminderDefaulters = useMemo(() => {
    let list = records.filter(r => (r.currentDue || 0) > 0);
    if (reminderWard !== 'all') {
      list = list.filter(r => r.wardNo === reminderWard);
    }
    return list;
  }, [records, reminderWard]);

  // Active Preview Taxpayer for Reminder Modal
  const previewTaxpayer = useMemo(() => {
    if (reminderDefaulters.length === 0) return null;
    if (selectedPreviewTaxpayerId) {
      const found = reminderDefaulters.find(r => r.id === selectedPreviewTaxpayerId);
      if (found) return found;
    }
    return reminderDefaulters[0];
  }, [reminderDefaulters, selectedPreviewTaxpayerId]);

  // Compile Dynamic Reminder Message
  const generateReminderText = (record: HoldingTaxRecord | null) => {
    if (!record) return '';
    const upTitle = config.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ';
    const dueAmount = (record.currentDue || 0).toLocaleString('bn-BD');
    const fiscalYr = record.fiscalYear || '২০২৫-২০২৬';

    if (reminderTemplateType === 'urgent') {
      return `🚨 জরুরি চূড়ান্ত তাগিদপত্র: সম্মানিত ${record.ownerName}, ${upTitle}-এ আপনার হোল্ডিং নং: ${record.holdingNo} (গ্রাম: ${record.village}, ওয়ার্ড: ${record.wardNo})-এর সর্বমোট বকেয়া কর ৳${dueAmount}/- এখনও অনাদায়ী রয়েছে। আগামী ৭ কার্যদিবসের মধ্যে ইউপি ট্যাক্স বুথ বা আদায়কারীর নিকট কর পরিশোধ করে ডিজিটাল দাখিলা গ্রহণ করুন, অন্যথায় স্থানীয় সরকার বিধি অনুযায়ী সেবা সাময়িক স্থগিত হতে পারে।\n- চেয়ারম্যান, ${upTitle}।`;
    }
    
    if (reminderTemplateType === 'rebate') {
      return `🎁 বিশেষ ছাড়ের সুযোগ: সম্মানিত করদাতা ${record.ownerName}, ${upTitle}-এ চলতি ${fiscalYr} অর্থবছরের হোল্ডিং কর (বকেয়াসহ ৳${dueAmount}/-) আগামী ${reminderDeadline}-এর মধ্যে এককালীন পরিশোধে পাচ্ছেন বিশেষ ছাড় ও তাৎক্ষণিক ডিজিটাল রসিদ। হোল্ডিং নং: ${record.holdingNo}। আজই যোগাযোগ করুন।\n- চেয়ারম্যান, ${upTitle}।`;
    }

    if (reminderTemplateType === 'custom') {
      let txt = customReminderTemplate;
      txt = txt.replace(/{{মালিকের_নাম}}/g, record.ownerName || '');
      txt = txt.replace(/{{হোল্ডিং_নং}}/g, record.holdingNo || '');
      txt = txt.replace(/{{ওয়ার্ড_নং}}/g, record.wardNo || '');
      txt = txt.replace(/{{গ্রাম}}/g, record.village || '');
      txt = txt.replace(/{{বকেয়া_টাকা}}/g, dueAmount);
      txt = txt.replace(/{{অর্থবছর}}/g, fiscalYr);
      txt = txt.replace(/{{ইউপি_নাম}}/g, upTitle);
      txt = txt.replace(/{{শেষ_তারিখ}}/g, reminderDeadline);
      return txt;
    }

    // Standard Friendly Template
    return `সম্মানিত করদাতা ${record.ownerName},\n${upTitle}-এর হোল্ডিং নং: ${record.holdingNo} (গ্রাম: ${record.village}, ওয়ার্ড: ${record.wardNo})-এর ${fiscalYr} অর্থবছরের বাৎসরিক ও পূর্বের মোট বকেয়া কর ৳${dueAmount}/-। আগামী ${reminderDeadline} ইউনিয়ন পরিষদ কার্যালয়ে বা ইউপি উদ্যোক্তার নিকট কর পরিশোধ করে ডিজিটাল রসিদ সংগ্রহ করার জন্য বিনীত অনুরোধ করা হইল।\n- চেয়ারম্যান, ${upTitle}।`;
  };

  // Open Payment Modal for a record (with full override and deduction support)
  const handleOpenPaymentModal = (record: HoldingTaxRecord) => {
    setSelectedRecordForPayment(record);
    const dueAmount = record.currentDue > 0 ? record.currentDue : record.totalDemand;
    setPaymentForm({
      paymentAmount: String(dueAmount),
      customPaymentMode: 'full',
      paymentMethod: 'Cash',
      trxId: '',
      collectedBy: 'ইউপি ট্যাক্স আদায়কারী',
      notes: '',
      isDiscountEnabled: false,
      discountAmount: '',
      deductionReason: 'দরিদ্রতা ও অসচ্ছলতা বিবেচনায় বিশেষ ছাড়',
      allowDemandOverride: false,
      overrideDemand: String(record.totalDemand)
    });
    setIsCollectModalOpen(true);
  };

  // View / Re-issue Receipt for any paid or partial record
  const handleViewReceiptForRecord = async (record: HoldingTaxRecord) => {
    const receiptNo = record.lastReceiptNo || `HTR-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const qrUrl = await generateTaxReceiptQRCode(receiptNo, record.holdingNo, record.paidAmount || record.totalDemand);
    
    const receipt: HoldingTaxReceipt = {
      receiptNo,
      holdingId: record.id,
      holdingNo: record.holdingNo,
      ownerName: record.ownerName,
      guardianName: record.guardianName,
      wardNo: record.wardNo,
      village: record.village,
      holdingType: record.holdingType,
      paidAmount: record.paidAmount || record.totalDemand,
      remainingDue: record.currentDue,
      totalDemand: record.totalDemand,
      originalDemand: record.totalDemand + (record.discountAmount || 0),
      discountAmount: record.discountAmount,
      deductionReason: record.deductionReason,
      netDemand: record.totalDemand,
      paymentMethod: record.paymentMethod || 'Cash',
      trxId: 'TXN-' + Math.floor(100000 + Math.random() * 900000),
      collectedBy: record.collectedBy || 'ইউপি আদায়কারী',
      date: record.lastPaymentDate ? new Date(record.lastPaymentDate).toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' }) : new Date().toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' }),
      fiscalYear: record.fiscalYear || '২০২৫-২০২৬',
      qrCodeUrl: qrUrl,
      unionLogoUrl: customLogoUrl || config.logoUrl || '/baheratail_seal.svg'
    };

    setActiveReceipt(receipt);
    setIsReceiptModalOpen(true);
  };

  // Submit Payment Collection and Auto-Generate Digital Money Receipt
  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRecordForPayment) return;

    const amount = Number(paymentForm.paymentAmount) || 0;
    const discount = paymentForm.isDiscountEnabled ? (Number(paymentForm.discountAmount) || 0) : 0;
    const override = paymentForm.allowDemandOverride ? Number(paymentForm.overrideDemand) : undefined;

    if (amount < 0 || discount < 0) {
      alert('টাকার পরিমাণ বা কর্তন ঋণাত্মক হতে পারে না!');
      return;
    }

    if (amount === 0 && discount === 0) {
      alert('অনুগ্রহ করে পরিশোধিত কর অথবা কর্তনের পরিমাণ লিখুন!');
      return;
    }

    try {
      const res = await fetch('/api/holding-tax/collect-tax', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          holdingId: selectedRecordForPayment.id,
          paymentAmount: amount,
          discountAmount: discount,
          deductionReason: paymentForm.isDiscountEnabled ? paymentForm.deductionReason : undefined,
          overrideDemand: override,
          paymentMethod: paymentForm.paymentMethod,
          trxId: paymentForm.trxId,
          collectedBy: paymentForm.collectedBy,
          fiscalYear: selectedRecordForPayment.fiscalYear,
          notes: paymentForm.notes
        })
      });

      const data = await res.json();
      if (data.success && data.receipt) {
        let receiptData = data.receipt;
        
        // Ensure union logo is attached
        if (!receiptData.unionLogoUrl) {
          receiptData.unionLogoUrl = customLogoUrl || config.logoUrl || '/baheratail_seal.svg';
        }

        // Ensure QR code is generated
        if (!receiptData.qrCodeUrl) {
          receiptData.qrCodeUrl = await generateTaxReceiptQRCode(
            receiptData.receiptNo, 
            receiptData.holdingNo, 
            receiptData.paidAmount
          );
        }

        setActiveReceipt(receiptData);
        setIsCollectModalOpen(false);
        setIsReceiptModalOpen(true); // Autotriggers receipt modal
        setToastMessage(data.message || `🎉 কর সফলভাবে গৃহীত হইয়াছে! ডিজিটাল মানি রসিদ প্রস্তুত।`);
        setTimeout(() => setToastMessage(null), 6000);
        fetchHoldingTaxData();
      } else {
        alert(data.message || 'পেমেন্ট প্রক্রিয়াকরণে সমস্যা হইয়াছে');
      }
    } catch (err: any) {
      alert('সার্ভার কানেকশনে ত্রুটি: ' + err.message);
    }
  };

  // Handle Download Receipt as PDF
  const handleDownloadReceiptPDF = async () => {
    if (!activeReceipt) return;
    setIsDownloadingPdf(true);
    try {
      const fileName = `BUP_Tax_Receipt_${activeReceipt.receiptNo}_${activeReceipt.holdingNo}`;
      const success = await downloadReceiptAsPDF('digital-tax-money-receipt-sheet', fileName);
      if (success) {
        setToastMessage('✅ ডিজিটাল মানি রসিদ PDF সফলভাবে ডাউনলোড হইয়াছে!');
        setTimeout(() => setToastMessage(null), 4000);
      } else {
        alert('PDF জেনারেট করতে সমস্যা হয়েছে, অনুগ্রহ করে ব্রাউজার প্রিন্ট অপশনটি ব্যবহার করুন।');
      }
    } catch (err: any) {
      console.error(err);
      alert('PDF তৈরিতে ত্রুটি: ' + err.message);
    } finally {
      setIsDownloadingPdf(false);
    }
  };

  // Submit New Holding Registration
  const handleCreateHoldingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHoldingForm.ownerName || !newHoldingForm.wardNo || !newHoldingForm.village) {
      alert('অনুগ্রহ করে করদাতার নাম, ওয়ার্ড এবং গ্রামের নাম পূরণ করুন!');
      return;
    }

    try {
      const res = await fetch('/api/holding-tax', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newHoldingForm)
      });

      const data = await res.json();
      if (data.success) {
        setIsAddModalOpen(false);
        setToastMessage(`✅ নতুন হোল্ডিং নং ${data.record.holdingNo} সফলভাবে সিস্টেমে যুক্ত হইয়াছে!`);
        setTimeout(() => setToastMessage(null), 5000);
        fetchHoldingTaxData();
        // Reset form
        setNewHoldingForm({
          holdingNo: '',
          holdingType: 'residential',
          structureType: 'semi_pucca',
          ownerName: '',
          guardianName: '',
          motherName: '',
          mobile: '',
          nid: '',
          wardNo: '০১',
          village: 'ডাবাইল',
          postOffice: 'নাগবাড়ী',
          annualValuation: '20000',
          currentTaxDemand: '1000',
          arrearsDue: '0',
          fiscalYear: '২০২৫-২০২৬',
          notes: ''
        });
      } else {
        alert(data.message || 'হোল্ডিং যুক্ত করতে সমস্যা হইয়াছে');
      }
    } catch (err: any) {
      alert('সার্ভার কানেকশনে ত্রুটি: ' + err.message);
    }
  };

  // Villages for Selected Ward in New Holding Form
  const availableVillagesForNewHolding = useMemo(() => {
    const mapping = WARD_VILLAGE_MAPPINGS.find(m => m.wardNo === newHoldingForm.wardNo);
    return mapping ? mapping.villages : ['বহেড়াতৈল', 'ডাবাইল', 'আমতৈল', 'বেতুয়া', 'কালিয়ান'];
  }, [newHoldingForm.wardNo]);

  // Open Automated Reminder Generator with preset ward
  const handleOpenReminderGenerator = (ward: string = selectedWard) => {
    setReminderWard(ward);
    setIsReminderGeneratorOpen(true);
  };

  // Copy helper
  const handleCopyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  // Copy all phone numbers for SMS Gateway
  const handleCopyBulkPhoneNumbers = () => {
    const numbers = reminderDefaulters
      .map(r => r.mobile?.replace(/\D/g, ''))
      .filter(Boolean);
    const joined = Array.from(new Set(numbers)).join(',');
    handleCopyText(joined, 'bulk_numbers');
  };

  // Insert tag into custom template
  const handleInsertTag = (tag: string) => {
    setCustomReminderTemplate(prev => prev + tag);
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['হোল্ডিং নং,মালিকের নাম,অভিভাবক,মোবাইল,ওয়ার্ড,গ্রাম,ধরনের নাম,বাৎসরিক মূল্যায়ন,চলতি দাবি,পূর্বের বকেয়া,মোট দাবি,আদায়কৃত,অবশিষ্ট বকেয়া,অবস্থা,অর্থবছর'];
    const rows = displayedRecords.map(r => [
      `"${r.holdingNo}"`,
      `"${r.ownerName}"`,
      `"${r.guardianName}"`,
      `"${r.mobile}"`,
      `"ওয়ার্ড ${r.wardNo}"`,
      `"${r.village}"`,
      `"${r.holdingType === 'residential' ? 'বসতবাড়ি' : r.holdingType === 'commercial' ? 'ব্যবসা প্রতিষ্ঠান' : 'শিল্প ইউনিট'}"`,
      r.annualValuation,
      r.currentTaxDemand,
      r.arrearsDue,
      r.totalDemand,
      r.paidAmount,
      r.currentDue,
      `"${r.paymentStatus === 'paid' ? 'পরিশোধিত' : r.paymentStatus === 'partial' ? 'আংশিক পরিশোধিত' : 'বকেয়া'}"`,
      `"${r.fiscalYear}"`
    ].join(','));

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `bup_holding_tax_${selectedWard !== 'all' ? `ward_${selectedWard}_` : ''}${onlyDefaulters ? 'defaulters_' : ''}${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="holding-tax-dashboard-root" className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-20 font-sans text-slate-800 dark:text-slate-100">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-emerald-600 text-white px-5 py-3.5 rounded-2xl shadow-2xl flex items-center gap-3 animate-bounce border border-emerald-400/40">
          <CheckCircle2 className="w-6 h-6 shrink-0 text-emerald-200" />
          <span className="font-bold text-sm tracking-wide">{toastMessage}</span>
        </div>
      )}

      {/* Hero Header */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white pt-8 pb-14 px-4 sm:px-6 lg:px-8 border-b border-emerald-800/40">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-3 mb-2 flex-wrap">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold uppercase tracking-wider border border-emerald-400/30">
                  <Landmark className="w-3.5 h-3.5" />
                  রাজস্ব ও কর আদায় সেল
                </span>
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-medium border border-amber-400/30">
                  <Calendar className="w-3.5 h-3.5" />
                  অর্থবছর: {selectedFiscalYear}
                </span>
                {onlyDefaulters && (
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 text-xs font-bold border border-rose-400/30 animate-pulse">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    বকেয়া ফিল্টার সক্রিয়
                  </span>
                )}
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white flex items-center gap-3">
                <Building2 className="w-8 h-8 text-emerald-400" />
                {config.upName} — হোল্ডিং ট্যাক্স ও ডিজিটাল মানি রসিদ ব্যবস্থাপনা
              </h1>
              <p className="mt-1 text-slate-300 text-sm max-w-2xl">
                ওয়ার্ডভিত্তিক কর আদায়, স্বয়ংক্রিয় QR কোডযুক্ত ডিজিটাল মানি রসিদ জেনারেশন, PDF ডাউনলোড ও বকেয়া তাগিদ নোটিফিকেশন সিস্টেম।
              </p>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex flex-wrap items-center gap-3">
              <button
                id="btn-open-tax-assessment-calculator"
                onClick={() => setIsCalculatorModalOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-sm shadow-lg shadow-teal-900/30 transition active:scale-95 cursor-pointer"
              >
                <Calculator className="w-4 h-4 text-white" />
                ট্যাক্স ক্যালকুলেটর
              </button>

              <button
                id="btn-export-ward-arrears-report"
                onClick={() => setIsReportModalOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-bold text-sm shadow-lg shadow-rose-900/30 transition active:scale-95 cursor-pointer"
              >
                <FileText className="w-4 h-4 text-white" />
                Export Report (PDF)
              </button>

              <button
                id="btn-open-automated-reminders"
                onClick={() => handleOpenReminderGenerator(selectedWard !== 'all' ? selectedWard : 'all')}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm shadow-lg shadow-amber-900/30 transition active:scale-95 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4 text-slate-950" />
                অটোমেটেড রিমাইন্ডার টেম্পলেট
              </button>

              <button
                id="btn-add-new-holding"
                onClick={() => setIsAddModalOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-medium text-sm shadow-lg shadow-emerald-900/30 transition active:scale-95 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                নতুন হোল্ডিং এন্ট্রি
              </button>

              <button
                id="btn-export-holding-csv"
                onClick={handleExportCSV}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-sm border border-slate-700 transition active:scale-95 cursor-pointer"
              >
                <Download className="w-4 h-4 text-slate-300" />
                CSV এক্সপোর্ট
              </button>

              <button
                id="btn-refresh-holding-data"
                onClick={fetchHoldingTaxData}
                disabled={loading}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
                title="রিফ্রেশ"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 space-y-8">
        {/* ============================================================ */}
        {/* KPI CARDS (4 CARDS) */}
        {/* ============================================================ */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Total Holdings */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">মোট হোল্ডিং সংখ্যা</span>
              <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
                <Building2 className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-4">
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white">
                {metrics.totalHoldings} <span className="text-sm font-medium text-slate-500">টি</span>
              </div>
              <div className="mt-2 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 flex-wrap">
                <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                  <Home className="w-3.5 h-3.5" /> বসতবাড়ি: {metrics.residential.count}
                </span>
                <span>•</span>
                <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400">
                  <Store className="w-3.5 h-3.5" /> ব্যবসা: {metrics.commercial.count}
                </span>
              </div>
            </div>
          </div>

          {/* Card 2: Total Demand */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">সর্বমোট করের দাবি</span>
              <div className="p-2.5 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400">
                <DollarSign className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-4">
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white">
                ৳{metrics.totalDemand.toLocaleString('bn-BD')}
              </div>
              <div className="mt-2 text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
                <span>চলতি + পূর্বের বকেয়া ধার্য</span>
                <span className="font-semibold text-purple-600 dark:text-purple-400">১০০% ধার্যকৃত</span>
              </div>
            </div>
          </div>

          {/* Card 3: Collected Tax */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">আদায়কৃত কর</span>
              <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
                <TrendingUp className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-4">
              <div className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">
                ৳{metrics.totalCollected.toLocaleString('bn-BD')}
              </div>
              <div className="mt-2 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span>আদায়ের শতকরা হার:</span>
                <span className="font-bold px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                  {metrics.collectionRate}%
                </span>
              </div>
            </div>
          </div>

          {/* Card 4: Total Due / Arrears */}
          <div 
            onClick={() => setOnlyDefaulters(!onlyDefaulters)}
            className={`rounded-2xl p-5 border shadow-sm flex flex-col justify-between cursor-pointer transition-all ${
              onlyDefaulters 
                ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-400 ring-2 ring-rose-500/40' 
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-rose-300'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-rose-600 dark:text-rose-400 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" /> অবশিষ্ট মোট বকেয়া
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 dark:bg-rose-900/60 dark:text-rose-300">
                {onlyDefaulters ? 'ফিল্টার সক্রিয়' : 'ফিল্টার করতে ক্লিক করুন'}
              </span>
            </div>
            <div className="mt-4">
              <div className="text-3xl font-extrabold text-rose-600 dark:text-rose-400">
                ৳{metrics.totalDue.toLocaleString('bn-BD')}
              </div>
              <div className="mt-2 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span>মোট বকেয়া করদাতা:</span>
                <span className="font-bold text-rose-600 dark:text-rose-400">
                  {metrics.unpaidCount + metrics.partialCount} জন
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* ============================================================ */}
        {/* WARD ARREARS SPOTLIGHT & QUICK REMINDER BANNER */}
        {/* ============================================================ */}
        {(selectedWard !== 'all' || onlyDefaulters) && (
          <div className="bg-gradient-to-r from-rose-950 via-slate-900 to-amber-950 text-white rounded-2xl p-5 border border-rose-500/40 shadow-xl space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-rose-500 text-white">
                    <AlertTriangle className="w-5 h-5" />
                  </span>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <span>{selectedWard !== 'all' ? `ওয়ার্ড নং ${selectedWard} — বকেয়া ও অনাদায়ী কর তালিকা` : 'সকল ওয়ার্ডের বকেয়া ও অনাদায়ী কর তালিকা'}</span>
                    {activeWardSummary && (
                      <span className="text-xs font-normal text-amber-300">
                        (গ্রাম: {activeWardSummary.villages.join(', ')})
                      </span>
                    )}
                  </h3>
                </div>
                <p className="text-xs text-slate-300">
                  {selectedWard !== 'all' && activeWardSummary ? (
                    <>এই ওয়ার্ডে মোট <span className="text-amber-300 font-bold">{activeWardSummary.totalHoldings}টি</span> হোল্ডিংয়ের মধ্যে অনাদায়ী মোট বকেয়া <span className="text-rose-400 font-black text-sm">৳{activeWardSummary.totalDue.toLocaleString('bn-BD')}/-</span> (আদায় অগ্রগতি: {activeWardSummary.collectionRate}%)।</>
                  ) : (
                    <>সকল ওয়ার্ড মিলিয়ে মোট <span className="text-rose-400 font-black text-sm">{metrics.unpaidCount + metrics.partialCount} জন</span> করদাতার নিকট <span className="text-amber-300 font-black text-sm">৳{metrics.totalDue.toLocaleString('bn-BD')}/-</span> বকেয়া রয়েছে।</>
                  )}
                </p>
              </div>

              {/* Action Buttons for this specific Ward */}
              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  id="btn-ward-export-report"
                  onClick={() => setIsReportModalOpen(true)}
                  className="px-3.5 py-2 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white rounded-xl text-xs font-bold shadow transition flex items-center gap-1.5 cursor-pointer"
                >
                  <FileText className="w-4 h-4" />
                  Export Report (PDF)
                </button>

                <button
                  id="btn-ward-automated-reminders"
                  onClick={() => handleOpenReminderGenerator(selectedWard !== 'all' ? selectedWard : 'all')}
                  className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl text-xs font-black shadow-md flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4 text-slate-950" />
                  এই ওয়ার্ডের জন্য রিমাইন্ডার মেসেজ বানান
                </button>

                <button
                  id="btn-print-ward-official-notices"
                  onClick={() => setIsPrintWardNoticesOpen(true)}
                  className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  ওয়ার্ড তাগিদপত্র প্রিন্ট
                </button>

                <button
                  onClick={() => {
                    setSelectedWard('all');
                    setOnlyDefaulters(false);
                  }}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium border border-slate-700 transition cursor-pointer"
                >
                  ফিল্টার বন্ধ করুন
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* WARD-WISE BREAKDOWN & HEATMAP (WARDS 01 TO 09) */}
        {/* ============================================================ */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <MapPin className="w-5 h-5 text-emerald-600" />
                ওয়ার্ডভিত্তিক বকেয়া ও আদায় অগ্রগতি চিত্র (ওয়ার্ড ০১ হতে ০৯)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                বহেড়াতৈল ইউনিয়নের প্রতিটি ওয়ার্ডের বাড়ি ও ব্যবসা প্রতিষ্ঠানের বকেয়া ও আদায় স্থিতি
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="font-semibold text-slate-500">বকেয়া মোড:</span>
              <button
                onClick={() => setOnlyDefaulters(!onlyDefaulters)}
                className={`px-3 py-1 rounded-full font-bold transition flex items-center gap-1 cursor-pointer ${
                  onlyDefaulters 
                    ? 'bg-rose-600 text-white shadow-sm' 
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                {onlyDefaulters ? 'শুধুমাত্র বকেয়া প্রদর্শন চালু' : 'সকল হোল্ডিং প্রদর্শন'}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-4 pt-2">
            {wardSummaries.map(ward => {
              const isSelected = selectedWard === ward.wardNo;
              return (
                <div
                  key={ward.wardNo}
                  onClick={() => setSelectedWard(isSelected ? 'all' : ward.wardNo)}
                  className={`cursor-pointer rounded-xl p-4 border transition-all ${
                    isSelected 
                      ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/40 ring-2 ring-emerald-500/30' 
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/60 dark:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
                      {ward.wardLabel}
                    </span>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                      ward.collectionRate >= 70 
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300' 
                        : 'bg-rose-100 text-rose-800 dark:bg-rose-900/60 dark:text-rose-300'
                    }`}>
                      {ward.collectionRate}% আদায়
                    </span>
                  </div>

                  <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-slate-500 block">বসতবাড়ি:</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{ward.residentialCount} টি</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">ব্যবসা/দোকান:</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{ward.commercialCount} টি</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">মোট দাবি:</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">৳{ward.totalDemand.toLocaleString('bn-BD')}</span>
                    </div>
                    <div>
                      <span className="text-rose-600 dark:text-rose-400 font-medium block">মোট বকেয়া:</span>
                      <span className="font-bold text-rose-600 dark:text-rose-400">৳{ward.totalDue.toLocaleString('bn-BD')}</span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mt-3 w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-300 ${
                        ward.collectionRate >= 75 ? 'bg-emerald-500' : ward.collectionRate >= 40 ? 'bg-amber-500' : 'bg-rose-500'
                      }`}
                      style={{ width: `${ward.collectionRate}%` }}
                    />
                  </div>

                  {/* Quick Ward Action Bar on Hover/Select */}
                  <div className="mt-3 pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-[11px]">
                    <span className="text-slate-500">বকেয়া নোটিশ পাঠাতে:</span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenReminderGenerator(ward.wardNo);
                      }}
                      className="text-amber-600 dark:text-amber-400 hover:underline font-bold flex items-center gap-0.5 cursor-pointer"
                    >
                      <MessageSquare className="w-3 h-3" /> রিমাইন্ডার
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* ============================================================ */}
        {/* INTERACTIVE REGISTER & TAXPAYER TABLE */}
        {/* ============================================================ */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          {/* Table Header Controls */}
          <div className="p-5 border-b border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <FileText className="w-5 h-5 text-emerald-600" />
                    হোল্ডিং ট্যাক্স রেজিস্টার ও অ্যাসেসমেন্ট তালিকা
                  </h3>
                  {onlyDefaulters && (
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border border-rose-300">
                      🚨 শুধুমাত্র বকেয়া তালিকা ({displayedRecords.length} জন)
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {selectedWard !== 'all' ? `ওয়ার্ড নং ${selectedWard}-এর ` : 'সকল ওয়ার্ডের '}
                  মোট {displayedRecords.length} জন করদাতার তথ্য প্রদর্শিত হচ্ছে
                </p>
              </div>

              {/* Search Bar */}
              <form onSubmit={handleSearchSubmit} className="flex items-center gap-2 w-full lg:w-96">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    id="input-holding-search"
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="হোল্ডিং নং, নাম, মোবাইল বা গ্রাম খুঁজুন..."
                    className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-100"
                  />
                </div>
                <button
                  type="submit"
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-medium transition cursor-pointer"
                >
                  খুঁজুন
                </button>
              </form>
            </div>

            {/* Filter Pills & Ward Selector */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              {/* Ward Filter */}
              <div className="flex items-center gap-1.5 text-xs">
                <span className="font-semibold text-slate-500">ওয়ার্ড:</span>
                <select
                  id="select-holding-ward-filter"
                  value={selectedWard}
                  onChange={(e) => setSelectedWard(e.target.value)}
                  className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="all">সকল ওয়ার্ড (১-৯)</option>
                  {['০১', '০২', '০৩', '০৪', '০৫', '০৬', '০৭', '০৮', '০৯'].map(w => (
                    <option key={w} value={w}>ওয়ার্ড নং {w}</option>
                  ))}
                </select>
              </div>

              {/* Holding Type Filter */}
              <div className="flex items-center gap-1.5 text-xs">
                <span className="font-semibold text-slate-500">ধরন:</span>
                <select
                  id="select-holding-type-filter"
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="all">সকল ধরন</option>
                  <option value="residential">বসতবাড়ি (Residential)</option>
                  <option value="commercial">ব্যবসা প্রতিষ্ঠান (Commercial)</option>
                  <option value="industrial">শিল্প / রাইস মিল (Industrial)</option>
                  <option value="institutional">প্রতিষ্ঠান (Institutional)</option>
                </select>
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-1.5 text-xs">
                <span className="font-semibold text-slate-500">অবস্থা:</span>
                <select
                  id="select-holding-status-filter"
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="all">সকল অবস্থা</option>
                  <option value="paid">পরিশোধিত (Paid)</option>
                  <option value="partial">আংশিক বকেয়া (Partial)</option>
                  <option value="unpaid">সম্পূর্ণ বকেয়া (Unpaid)</option>
                </select>
              </div>

              {/* Defaulter Toggle Button */}
              <button
                type="button"
                onClick={() => setOnlyDefaulters(!onlyDefaulters)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  onlyDefaulters 
                    ? 'bg-rose-600 text-white shadow-sm ring-2 ring-rose-400/40' 
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                <span>শুধুমাত্র বকেয়া ({records.filter(r => (r.currentDue || 0) > 0).length})</span>
              </button>

              {/* Reminder Action Button inside filter bar */}
              <button
                type="button"
                onClick={() => handleOpenReminderGenerator(selectedWard !== 'all' ? selectedWard : 'all')}
                className="px-3 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/30 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span>অটোমেটেড রিমাইন্ডার বানান</span>
              </button>

              {(selectedWard !== 'all' || selectedType !== 'all' || selectedStatus !== 'all' || searchQuery || onlyDefaulters) && (
                <button
                  onClick={() => {
                    setSelectedWard('all');
                    setSelectedType('all');
                    setSelectedStatus('all');
                    setSearchQuery('');
                    setOnlyDefaulters(false);
                  }}
                  className="text-xs text-rose-600 hover:text-rose-700 underline font-medium ml-auto cursor-pointer"
                >
                  ফিল্টার রিসেট
                </button>
              )}
            </div>
          </div>

          {/* Table Body */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 text-xs uppercase font-semibold border-b border-slate-200 dark:border-slate-700">
                  <th className="py-3.5 px-4">হোল্ডিং নং</th>
                  <th className="py-3.5 px-4">করদাতার নাম ও বিবরণ</th>
                  <th className="py-3.5 px-4">ওয়ার্ড ও গ্রাম</th>
                  <th className="py-3.5 px-4">ধরন ও কাঠামো</th>
                  <th className="py-3.5 px-4 text-right">মোট দাবি</th>
                  <th className="py-3.5 px-4 text-right">আদায়কৃত</th>
                  <th className="py-3.5 px-4 text-right">বকেয়া</th>
                  <th className="py-3.5 px-4 text-center">স্ট্যাটাস</th>
                  <th className="py-3.5 px-4 text-right">অ্যাকশন ও রসিদ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {displayedRecords.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-slate-500">
                      কোনো হোল্ডিং তথ্য পাওয়া যায় নাই।
                    </td>
                  </tr>
                ) : (
                  displayedRecords.map((r) => {
                    const cleanPhone = r.mobile ? r.mobile.replace(/\D/g, '') : '';
                    const phoneWithCountry = cleanPhone.startsWith('880') ? cleanPhone : `88${cleanPhone.replace(/^0/, '')}`;
                    const waNoticeText = generateReminderText(r);
                    const waUrl = `https://wa.me/${phoneWithCountry}?text=${encodeURIComponent(waNoticeText)}`;
                    const hasPaid = (r.paidAmount || 0) > 0;

                    return (
                      <tr 
                        key={r.id}
                        className={`hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors ${
                          (r.currentDue || 0) > 0 ? 'bg-rose-50/20 dark:bg-rose-950/10' : ''
                        }`}
                      >
                        <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white whitespace-nowrap">
                          {r.holdingNo}
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-slate-900 dark:text-white">{r.ownerName}</div>
                          <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                            <span>পিতা/স্বামী: {r.guardianName}</span>
                            {r.mobile && (
                              <span className="inline-flex items-center gap-0.5 text-slate-600 dark:text-slate-400">
                                <Phone className="w-3 h-3 text-emerald-600" /> {r.mobile}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span className="font-medium text-slate-800 dark:text-slate-200">ওয়ার্ড {r.wardNo}</span>
                          <div className="text-xs text-slate-500">{r.village}</div>
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
                            r.holdingType === 'residential' 
                              ? 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300' 
                              : r.holdingType === 'commercial'
                              ? 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                              : 'bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300'
                          }`}>
                            {r.holdingType === 'residential' ? <Home className="w-3 h-3" /> : <Store className="w-3 h-3" />}
                            {r.holdingType === 'residential' ? 'বসতবাড়ি' : r.holdingType === 'commercial' ? 'ব্যবসা প্রতিষ্ঠান' : 'শিল্প প্রতিষ্ঠান'}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right font-medium text-slate-900 dark:text-white whitespace-nowrap">
                          ৳{r.totalDemand.toLocaleString('bn-BD')}
                        </td>
                        <td className="py-3.5 px-4 text-right font-semibold text-emerald-600 dark:text-emerald-400 whitespace-nowrap">
                          ৳{r.paidAmount.toLocaleString('bn-BD')}
                        </td>
                        <td className="py-3.5 px-4 text-right font-bold text-rose-600 dark:text-rose-400 whitespace-nowrap">
                          ৳{r.currentDue.toLocaleString('bn-BD')}
                        </td>
                        <td className="py-3.5 px-4 text-center whitespace-nowrap">
                          {r.paymentStatus === 'paid' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                              <Check className="w-3 h-3" /> পরিশোধিত
                            </span>
                          ) : r.paymentStatus === 'partial' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                              <Clock className="w-3 h-3" /> আংশিক বকেয়া
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300">
                              <AlertCircle className="w-3 h-3" /> সম্পূর্ণ বকেয়া
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Pay Tax Button */}
                            <button
                              onClick={() => handleOpenPaymentModal(r)}
                              className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition flex items-center gap-1 shadow-sm cursor-pointer"
                              title="কর গ্রহণ ও রসিদ তৈরি"
                            >
                              <CreditCard className="w-3.5 h-3.5" /> কর আদায়
                            </button>

                            {/* View / Print Existing Receipt */}
                            {hasPaid && (
                              <button
                                onClick={() => handleViewReceiptForRecord(r)}
                                className="px-2.5 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-800 dark:bg-teal-950/60 dark:hover:bg-teal-900 dark:text-teal-300 border border-teal-200 dark:border-teal-800 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                                title="ডিজিটাল মানি রসিদ দেখুন ও প্রিন্ট করুন"
                              >
                                <FileCheck2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                                <span>রসিদ</span>
                              </button>
                            )}

                            {/* WhatsApp Due Notice Button */}
                            {r.currentDue > 0 && r.mobile && (
                              <a
                                href={waUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-1.5 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-800 dark:bg-emerald-950 dark:hover:bg-emerald-900 dark:text-emerald-300 transition"
                                title="হোয়াটসঅ্যাপে বকেয়া রিমাইন্ডার পাঠান"
                              >
                                <Send className="w-3.5 h-3.5" />
                              </a>
                            )}

                            {/* View Details */}
                            <button
                              onClick={() => setViewDetailsRecord(r)}
                              className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 transition cursor-pointer"
                              title="বিস্তারিত বিবরণ"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* MODAL 1: AUTOMATED REMINDER MESSAGE TEMPLATE GENERATOR & DISPATCHER */}
      {/* ============================================================ */}
      {isReminderGeneratorOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fadeIn overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-4xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-6 my-8">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-600 dark:text-amber-400">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    অটোমেটেড বকেয়া রিমাইন্ডার ও মেসেজ টেম্পলেট জেনারেটর
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    নির্দিষ্ট ওয়ার্ডের বকেয়া করদাতাদের জন্য স্বয়ংক্রিয় তাগাদা বার্তা ও হোয়াটসঅ্যাপ/এসএমএস নোটিফিকেশন সিস্টেম
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setIsReminderGeneratorOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scope & Template Controls */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Ward Scope Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  নির্দিষ্ট ওয়ার্ড নির্বাচন করুন *
                </label>
                <select
                  value={reminderWard}
                  onChange={(e) => setReminderWard(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-emerald-600 dark:text-emerald-400 focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">সকল ওয়ার্ড (১-৯) — মোট বকেয়া: {records.filter(r => (r.currentDue || 0) > 0).length} জন</option>
                  {['০১', '০২', '০৩', '০৪', '০৫', '০৬', '০৭', '০৮', '০৯'].map(w => {
                    const count = records.filter(r => r.wardNo === w && (r.currentDue || 0) > 0).length;
                    return (
                      <option key={w} value={w}>ওয়ার্ড নং {w} (বকেয়া: {count} জন)</option>
                    );
                  })}
                </select>
              </div>

              {/* Template Preset Type */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  রিমাইন্ডার টেম্পলেট নির্বাচন করুন *
                </label>
                <select
                  value={reminderTemplateType}
                  onChange={(e: any) => setReminderTemplateType(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="standard">১. সাধারণ বকেয়া তাগাদা (Standard Friendly Notice)</option>
                  <option value="urgent">২. জরুরি চূড়ান্ত তাগাদা ও আইনি নোটিশ (Final Warning)</option>
                  <option value="rebate">৩. ৫% বিশেষ ছাড় ও রিবেট নোটিশ (Discount Deadline)</option>
                  <option value="custom">৪. কাস্টম বার্তা (Custom Dynamic Template)</option>
                </select>
              </div>

              {/* Deadline / Timeframe */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  পরিশোধের সময়সীমা / শেষ তারিখ
                </label>
                <input
                  type="text"
                  value={reminderDeadline}
                  onChange={(e) => setReminderDeadline(e.target.value)}
                  placeholder="উদা: ১৫ দিনের মধ্যে / ৩০শে সেপ্টেম্বর"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* Custom Template Editor & Dynamic Tags (Only if Custom Template selected) */}
            {reminderTemplateType === 'custom' && (
              <div className="p-4 bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-900 dark:text-amber-300 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4" /> কাস্টম টেম্পলেট টেক্সট ও ডায়নামিক প্লেসহোল্ডার
                  </span>
                  <span className="text-[11px] text-slate-500">নিচের ট্যাগে ক্লিক করে যোগ করুন</span>
                </div>

                <textarea
                  rows={3}
                  value={customReminderTemplate}
                  onChange={(e) => setCustomReminderTemplate(e.target.value)}
                  className="w-full p-3 bg-white dark:bg-slate-800 border border-amber-300 dark:border-slate-700 rounded-xl text-xs font-mono text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-emerald-500"
                />

                {/* Clickable Tag Chips */}
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  <span className="text-slate-500 text-[11px]">ট্যাগসমূহ:</span>
                  {[
                    '{{মালিকের_নাম}}',
                    '{{হোল্ডিং_নং}}',
                    '{{ওয়ার্ড_নং}}',
                    '{{গ্রাম}}',
                    '{{বকেয়া_টাকা}}',
                    '{{অর্থবছর}}',
                    '{{ইউপি_নাম}}',
                    '{{শেষ_তারিখ}}'
                  ].map(tag => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => handleInsertTag(tag)}
                      className="px-2 py-0.5 bg-white dark:bg-slate-800 hover:bg-amber-100 dark:hover:bg-slate-700 text-amber-800 dark:text-amber-300 rounded-md border border-amber-300 dark:border-slate-700 font-mono text-[10px] transition cursor-pointer"
                    >
                      + {tag}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Live Message Preview Card */}
            <div className="p-4 bg-slate-900 text-white rounded-2xl border border-slate-800 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                    লাইভ মেসেজ প্রিভিউ (Live Generated Template Preview)
                  </span>
                </div>

                {/* Taxpayer Preview Switcher */}
                {reminderDefaulters.length > 0 && (
                  <div className="flex items-center gap-1.5 text-xs">
                    <span className="text-slate-400">করদাতা নমুনা:</span>
                    <select
                      value={selectedPreviewTaxpayerId || previewTaxpayer?.id || ''}
                      onChange={(e) => setSelectedPreviewTaxpayerId(e.target.value)}
                      className="px-2 py-1 bg-slate-800 border border-slate-700 rounded-lg text-xs text-amber-300 font-semibold focus:outline-none"
                    >
                      {reminderDefaulters.slice(0, 15).map(r => (
                        <option key={r.id} value={r.id}>
                          {r.ownerName} (হোল্ডিং: {r.holdingNo} - ৳{r.currentDue})
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              {previewTaxpayer ? (
                <div className="p-4 bg-slate-950/80 rounded-xl border border-emerald-500/20 space-y-2">
                  <div className="text-xs text-slate-400 flex items-center justify-between">
                    <span>প্রাপক: <strong className="text-white">{previewTaxpayer.ownerName}</strong> ({previewTaxpayer.mobile || 'মোবাইল যুক্ত নাই'})</span>
                    <span className="font-bold text-amber-400">বকেয়া: ৳{previewTaxpayer.currentDue}/-</span>
                  </div>
                  <pre className="text-xs text-emerald-200 whitespace-pre-wrap font-sans leading-relaxed">
                    {generateReminderText(previewTaxpayer)}
                  </pre>
                </div>
              ) : (
                <div className="py-6 text-center text-xs text-slate-400">
                  এই ফিল্টারে কোনো বকেয়া করদাতা পাওয়া যায় নাই।
                </div>
              )}
            </div>

            {/* Target Defaulters Dispatch List */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <User className="w-4 h-4 text-emerald-600" />
                  বকেয়া করদাতাদের তালিকা ({reminderDefaulters.length} জন)
                </h4>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyBulkPhoneNumbers}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    {copiedKey === 'bulk_numbers' ? 'নম্বরসমূহ কপি হয়েছে!' : 'সকল মোবাইল নম্বর কপি'}
                  </button>

                  <button
                    onClick={() => handleCopyText(generateReminderText(previewTaxpayer), 'template_text')}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    {copiedKey === 'template_text' ? 'টেক্সট কপি হয়েছে!' : 'মেসেজ টেক্সট কপি'}
                  </button>
                </div>
              </div>

              <div className="max-h-60 overflow-y-auto space-y-2 border border-slate-200 dark:border-slate-800 rounded-2xl p-2 bg-slate-50/50 dark:bg-slate-950/50 divide-y divide-slate-100 dark:divide-slate-800">
                {reminderDefaulters.length === 0 ? (
                  <div className="py-8 text-center text-xs text-slate-500">
                    কোনো বকেয়া করদাতা নাই।
                  </div>
                ) : (
                  reminderDefaulters.map((r) => {
                    const cleanPhone = r.mobile ? r.mobile.replace(/\D/g, '') : '';
                    const phoneWithCountry = cleanPhone.startsWith('880') ? cleanPhone : `88${cleanPhone.replace(/^0/, '')}`;
                    const msg = generateReminderText(r);
                    const waLink = r.mobile ? `https://wa.me/${phoneWithCountry}?text=${encodeURIComponent(msg)}` : '';

                    return (
                      <div key={r.id} className="p-2.5 flex items-center justify-between gap-3 text-xs">
                        <div>
                          <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                            <span>{r.ownerName}</span>
                            <span className="font-mono text-[11px] text-slate-500">({r.holdingNo})</span>
                          </div>
                          <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                            <span>ওয়ার্ড: {r.wardNo}, {r.village}</span>
                            <span>•</span>
                            <span className="text-rose-600 font-bold">বকেয়া: ৳{r.currentDue}</span>
                            {r.mobile && <span className="font-mono text-slate-600 dark:text-slate-400">({r.mobile})</span>}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {r.mobile ? (
                            <a
                              href={waLink}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs flex items-center gap-1.5 shadow-sm transition"
                            >
                              <Send className="w-3.5 h-3.5" /> WhatsApp পাঠান
                            </a>
                          ) : (
                            <span className="text-[11px] text-slate-400 italic">মোবাইল নম্বর নাই</span>
                          )}

                          <button
                            onClick={() => handleCopyText(msg, `msg_${r.id}`)}
                            className="p-1.5 rounded-lg bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 text-slate-700 dark:text-slate-300 transition cursor-pointer"
                            title="এই ব্যক্তির মেসেজ কপি"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Modal Bottom Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
              <div className="text-xs text-slate-500">
                *মেসেজ প্রেরণের পূর্বে মোবাইল নম্বর ও বকেয়া টাকার পরিমাণ মিলিয়ে নিন
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsPrintWardNoticesOpen(true)}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow transition cursor-pointer"
                >
                  <Printer className="w-4 h-4" /> অফিশিয়াল তাগিদপত্র প্রিন্ট করুন
                </button>

                <button
                  type="button"
                  onClick={() => setIsReminderGeneratorOpen(false)}
                  className="px-5 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  সম্পন্ন
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL 2: PRINTABLE OFFICIAL WARD-WISE DEMAND NOTICE LETTERS */}
      {/* ============================================================ */}
      {isPrintWardNoticesOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fadeIn overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-3xl max-w-4xl w-full p-6 sm:p-8 shadow-2xl space-y-6 my-8 border-4 border-double border-emerald-800">
            {/* Header / Action */}
            <div className="flex items-center justify-between border-b pb-4 print:hidden">
              <div>
                <h3 className="text-lg font-black text-emerald-900">
                  {selectedWard !== 'all' ? `ওয়ার্ড নং ${selectedWard}-এর ` : 'সকল ওয়ার্ডের '}
                  বকেয়া হোল্ডিং ট্যাক্স তাগিদ নোটিশ লেটার
                </h3>
                <p className="text-xs text-slate-600">
                  মোট {reminderDefaulters.length}টি তাগিদপত্র প্রস্তুত হয়েছে
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow cursor-pointer"
                >
                  <Printer className="w-4 h-4" /> প্রিন্ট করুন (A4)
                </button>
                <button
                  onClick={() => setIsPrintWardNoticesOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  বন্ধ করুন
                </button>
              </div>
            </div>

            {/* Printable Notice Sheets */}
            <div className="space-y-8 max-h-[70vh] overflow-y-auto print:max-h-none print:overflow-visible pr-2">
              {reminderDefaulters.length === 0 ? (
                <div className="py-12 text-center text-slate-500">
                  কোনো বকেয়া করদাতা পাওয়া যায় নাই।
                </div>
              ) : (
                reminderDefaulters.map((r, idx) => (
                  <div 
                    key={r.id}
                    className="p-6 border-2 border-emerald-700 rounded-2xl space-y-4 bg-slate-50/40 page-break-after"
                  >
                    {/* Notice Letter Header */}
                    <div className="text-center space-y-1 border-b border-emerald-700 pb-3">
                      <div className="text-[11px] font-bold uppercase tracking-widest text-emerald-800">
                        গণপ্রজাতন্ত্রী বাংলাদেশ সরকার
                      </div>
                      <h2 className="text-xl font-black text-emerald-900">{config.upName}</h2>
                      <div className="text-xs text-slate-600">
                        উপজেলা: {config.upazila}, জেলা: {config.district}
                      </div>
                      <div className="inline-block mt-1 px-4 py-0.5 rounded-full bg-rose-700 text-white font-bold text-xs">
                        হোল্ডিং ট্যাক্স ও কর পরিশোধের তাগিদপত্র
                      </div>
                    </div>

                    {/* Memo & Date */}
                    <div className="flex justify-between text-xs font-semibold text-slate-700">
                      <div>স্মারক নং: বইউপি/কর/২০২৬/{idx + 101}</div>
                      <div>তারিখ: {new Date().toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' })}</div>
                    </div>

                    {/* Recipient Box */}
                    <div className="p-3 bg-white border border-slate-300 rounded-xl text-xs space-y-1">
                      <div><strong>প্রাপক:</strong> {r.ownerName} (পিতা/স্বামী: {r.guardianName})</div>
                      <div><strong>হোল্ডিং নং:</strong> <span className="font-mono font-bold text-emerald-800">{r.holdingNo}</span> | <strong>ওয়ার্ড নং:</strong> {r.wardNo} | <strong>গ্রাম:</strong> {r.village}</div>
                      <div><strong>মোবাইল:</strong> {r.mobile || 'রেকর্ডভুক্ত নয়'}</div>
                    </div>

                    {/* Body Text */}
                    <div className="text-xs text-slate-800 leading-relaxed space-y-2">
                      <p>
                        <strong>বিষয়: {r.fiscalYear} অর্থবছরের বাৎসরিক ও পূর্বের অনাদায়ী বকেয়া হোল্ডিং ট্যাক্স পরিশোধের নোটিশ।</strong>
                      </p>
                      <p>
                        যথাবিহিত সম্মান প্রদর্শনপূর্বক জানানো যাচ্ছে যে, {config.upName}-এর আওতাধীন আপনার বর্ণিত হোল্ডিংয়ের বিপরীতে ধার্যকৃত কর বাবদ সর্বমোট <strong className="text-rose-700 font-bold">৳{(r.currentDue || 0).toLocaleString('bn-BD')}/- (কথায়: {r.currentDue} টাকা)</strong> অনাদায়ী রয়েছে।
                      </p>
                      <p>
                        অতএব, অত্র নোটিশ জারির আগামী <strong className="text-emerald-800">{reminderDeadline}</strong> ইউনিয়ন পরিষদ ট্যাক্স বুথে অথবা দায়িত্বপ্রাপ্ত কর আদায়কারীর নিকট বকেয়া অর্থ পরিশোধ করে ডিজিটাল মানি রসিদ গ্রহণ করার জন্য অনুরোধ করা হইল।
                      </p>
                    </div>

                    {/* Bottom Signature Area */}
                    <div className="flex items-end justify-between pt-6 border-t border-slate-300 text-xs">
                      <div className="text-[10px] text-slate-500 space-y-0.5">
                        <div>*অনলাইনে কর পরিশোধ ও রসিদ যাচাই: bup-gov.bd</div>
                        <div>*অনুলিপি: সংশ্লিষ্ট ওয়ার্ড মেম্বার ও আদায়কারী কর্মকর্তা।</div>
                      </div>

                      <div className="text-center space-y-1">
                        <div className="w-36 border-b border-slate-500 mx-auto" />
                        <div className="font-bold text-slate-900">{config.chairmanName}</div>
                        <div className="text-[10px] text-slate-600">চেয়ারম্যান, {config.upName}</div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL 3: COLLECT TAX PAYMENT (WITH MANUAL OVERRIDE & DEDUCTION) */}
      {/* ============================================================ */}
      {isCollectModalOpen && selectedRecordForPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fadeIn overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-xl w-full p-6 sm:p-7 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-5 my-6">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    হোল্ডিং ট্যাক্স আদায় ও কর কর্তন / সমন্বয়
                  </h3>
                  <p className="text-xs text-slate-500">
                    কর আদায় কর্মকর্তা প্রয়োজনমাফিক করের পরিমাণ নির্ধারণ বা কর্তন করতে পারবেন
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setIsCollectModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Target Holding Summary Banner */}
            <div className="p-3.5 bg-emerald-50/70 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800/50 text-xs space-y-1.5">
              <div className="flex justify-between font-bold text-slate-900 dark:text-white">
                <span className="flex items-center gap-1.5">
                  <Home className="w-3.5 h-3.5 text-emerald-600" />
                  হোল্ডিং নং: {selectedRecordForPayment.holdingNo}
                </span>
                <span>ওয়ার্ড নং: {selectedRecordForPayment.wardNo} ({selectedRecordForPayment.village})</span>
              </div>
              <div className="text-slate-600 dark:text-slate-300">
                করদাতার নাম: <strong className="text-slate-800 dark:text-slate-200">{selectedRecordForPayment.ownerName}</strong> | পিতা/স্বামী: {selectedRecordForPayment.guardianName}
              </div>
              <div className="flex justify-between font-semibold pt-1.5 border-t border-emerald-200/60 dark:border-emerald-800/40 text-[11px]">
                <span>মোট ধার্যকৃত দাবি: ৳{selectedRecordForPayment.totalDemand.toLocaleString('bn-BD')}</span>
                <span>পূর্বে পরিশোধিত: ৳{(selectedRecordForPayment.paidAmount || 0).toLocaleString('bn-BD')}</span>
                <span className="text-rose-600 dark:text-rose-400 font-bold">বর্তমান বকেয়া: ৳{selectedRecordForPayment.currentDue.toLocaleString('bn-BD')}</span>
              </div>
            </div>

            <form onSubmit={handlePaymentSubmit} className="space-y-4 text-sm">
              {/* Payment Mode Selection Buttons */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  আদায়কৃত করের পরিমাণ নির্ধারণ *
                </label>
                <div className="grid grid-cols-3 gap-2 mb-2">
                  <button
                    type="button"
                    onClick={() => {
                      setPaymentForm({
                        ...paymentForm,
                        customPaymentMode: 'full',
                        paymentAmount: String(selectedRecordForPayment.currentDue)
                      });
                    }}
                    className={`px-3 py-2 rounded-xl text-xs font-bold border transition text-center cursor-pointer ${
                      paymentForm.customPaymentMode === 'full'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-emerald-400'
                    }`}
                  >
                    সম্পূর্ণ কর (৳{selectedRecordForPayment.currentDue})
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const half = Math.ceil(selectedRecordForPayment.currentDue / 2);
                      setPaymentForm({
                        ...paymentForm,
                        customPaymentMode: 'half',
                        paymentAmount: String(half)
                      });
                    }}
                    className={`px-3 py-2 rounded-xl text-xs font-bold border transition text-center cursor-pointer ${
                      paymentForm.customPaymentMode === 'half'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-emerald-400'
                    }`}
                  >
                    ৫০% কিস্তি (৳{Math.ceil(selectedRecordForPayment.currentDue / 2)})
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setPaymentForm({
                        ...paymentForm,
                        customPaymentMode: 'custom'
                      });
                    }}
                    className={`px-3 py-2 rounded-xl text-xs font-bold border transition text-center cursor-pointer ${
                      paymentForm.customPaymentMode === 'custom'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-emerald-400'
                    }`}
                  >
                    কাস্টম পরিমাণ
                  </button>
                </div>

                {/* Editable Payment Input */}
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 font-bold text-slate-400 text-sm">৳</span>
                  <input
                    type="number"
                    required
                    min="0"
                    value={paymentForm.paymentAmount}
                    onChange={(e) => {
                      setPaymentForm({ 
                        ...paymentForm, 
                        paymentAmount: e.target.value,
                        customPaymentMode: 'custom'
                      });
                    }}
                    placeholder="কর পরিশোধের পরিমাণ (টাকা)"
                    className="w-full pl-8 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-black text-lg text-emerald-600 dark:text-emerald-400 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                  <Info className="w-3 h-3 text-emerald-600" />
                  কর্মকর্তা নিজের ইচ্ছামত যেকোনো অঙ্কের কর আদায় ইনপুট দিতে পারবেন।
                </p>
              </div>

              {/* TAX DEDUCTION / WAIVER / EXEMPTION SECTION */}
              <div className="p-3.5 bg-amber-50/70 dark:bg-amber-950/30 rounded-2xl border border-amber-200 dark:border-amber-800/50 space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-amber-900 dark:text-amber-300">
                    <input
                      type="checkbox"
                      checked={paymentForm.isDiscountEnabled}
                      onChange={(e) => {
                        setPaymentForm({
                          ...paymentForm,
                          isDiscountEnabled: e.target.checked
                        });
                      }}
                      className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4"
                    />
                    <Scissors className="w-3.5 h-3.5 text-amber-600" />
                    কর কর্তন / বিশেষ ছাড় / মওকুফ প্রযোজ্য
                  </label>
                  <span className="text-[10px] text-amber-700 dark:text-amber-400 font-semibold">
                    (ইউপি চেয়ারম্যান/কর্তৃপক্ষের অনুমোদন সাপেক্ষে)
                  </span>
                </div>

                {paymentForm.isDiscountEnabled && (
                  <div className="space-y-2.5 pt-2 border-t border-amber-200/80 dark:border-amber-800/40 animate-fadeIn">
                    <div>
                      <label className="block text-xs font-semibold text-amber-900 dark:text-amber-200 mb-1">
                        কর্তন / মওকুফকৃত অর্থের পরিমাণ (টাকা) *
                      </label>
                      <input
                        type="number"
                        min="1"
                        max={selectedRecordForPayment.currentDue}
                        value={paymentForm.discountAmount}
                        onChange={(e) => {
                          const disc = Number(e.target.value) || 0;
                          const netRemaining = Math.max(0, selectedRecordForPayment.currentDue - disc);
                          setPaymentForm({
                            ...paymentForm,
                            discountAmount: e.target.value,
                            paymentAmount: String(netRemaining)
                          });
                        }}
                        placeholder="উদা: ২০০"
                        className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded-xl text-xs font-bold text-amber-700 dark:text-amber-300"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-amber-900 dark:text-amber-200 mb-1">
                        কর্তন / মওকুফের কারণ *
                      </label>
                      <div className="flex flex-wrap gap-1.5 mb-1.5">
                        {[
                          'দরিদ্রতা ও অসচ্ছলতা বিবেচনায় বিশেষ ছাড়',
                          'বীর মুক্তিযোদ্ধা / প্রবীণ সুবিধা',
                          'গৃহ মেরামত ও ক্ষতিপূরণজনিত ছাড়',
                          'চেয়ারম্যানের বিশেষ বিবেচনা'
                        ].map((reason) => (
                          <button
                            key={reason}
                            type="button"
                            onClick={() => setPaymentForm({ ...paymentForm, deductionReason: reason })}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-medium border transition cursor-pointer ${
                              paymentForm.deductionReason === reason
                                ? 'bg-amber-600 text-white border-amber-600'
                                : 'bg-white dark:bg-slate-800 text-amber-900 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                            }`}
                          >
                            {reason}
                          </button>
                        ))}
                      </div>
                      <input
                        type="text"
                        value={paymentForm.deductionReason}
                        onChange={(e) => setPaymentForm({ ...paymentForm, deductionReason: e.target.value })}
                        placeholder="কর্তনের সুনির্দিষ্ট কারণ লিখুন"
                        className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded-xl text-xs"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* LIVE FINANCIAL BREAKDOWN CARD */}
              <div className="p-3 bg-slate-100 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 text-xs space-y-1 font-medium">
                <div className="flex justify-between text-slate-600 dark:text-slate-300">
                  <span>মোট কর দাবি:</span>
                  <span>৳{selectedRecordForPayment.totalDemand.toLocaleString('bn-BD')}/-</span>
                </div>
                {paymentForm.isDiscountEnabled && Number(paymentForm.discountAmount) > 0 && (
                  <div className="flex justify-between text-amber-700 dark:text-amber-400 font-bold">
                    <span>(-) অনুমোদিত কর কর্তন/ছাড়:</span>
                    <span>৳{(Number(paymentForm.discountAmount) || 0).toLocaleString('bn-BD')}/-</span>
                  </div>
                )}
                <div className="flex justify-between text-emerald-700 dark:text-emerald-400 font-bold">
                  <span>(-) বর্তমান আদায়কৃত অর্থ:</span>
                  <span>৳{(Number(paymentForm.paymentAmount) || 0).toLocaleString('bn-BD')}/-</span>
                </div>
                <div className="flex justify-between text-slate-900 dark:text-white font-black pt-1 border-t border-slate-300 dark:border-slate-600">
                  <span>পরিশোধ পরবর্তী অবশিষ্ট বকেয়া:</span>
                  <span className="text-rose-600 dark:text-rose-400">
                    ৳{Math.max(
                      0, 
                      selectedRecordForPayment.currentDue - 
                      (paymentForm.isDiscountEnabled ? (Number(paymentForm.discountAmount) || 0) : 0) - 
                      (Number(paymentForm.paymentAmount) || 0)
                    ).toLocaleString('bn-BD')}/-
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    পরিশোধের মাধ্যম *
                  </label>
                  <select
                    value={paymentForm.paymentMethod}
                    onChange={(e: any) => setPaymentForm({ ...paymentForm, paymentMethod: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  >
                    <option value="Cash">ক্যাশ / নগদ টাকা</option>
                    <option value="bKash">বিকাশ (bKash)</option>
                    <option value="Nagad">নগদ (Nagad)</option>
                    <option value="Rocket">রকেট (Rocket)</option>
                    <option value="Bank">ব্যাংক জমা</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    ট্রানজেকশন / রশিদ নং (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    value={paymentForm.trxId}
                    onChange={(e) => setPaymentForm({ ...paymentForm, trxId: e.target.value })}
                    placeholder="উদা: TRX-92817"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  ট্যাক্স আদায়কারী কর্মকর্তা / উদ্যোক্তা
                </label>
                <input
                  type="text"
                  value={paymentForm.collectedBy}
                  onChange={(e) => setPaymentForm({ ...paymentForm, collectedBy: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCollectModalOpen(false)}
                  className="px-4 py-2 text-slate-600 dark:text-slate-400 text-xs font-semibold hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-900/20 flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-4 h-4" /> কর গ্রহণ ও ডিজিটাল রসিদ ইস্যু
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL 4: AUTOMATIC DIGITAL MONEY RECEIPT (WITH UP LOGO, QR & PDF EXPORT) */}
      {/* ============================================================ */}
      {isReceiptModalOpen && activeReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fadeIn overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-6 my-8 border border-slate-200 dark:border-slate-800">
            {/* Modal Actions Top Bar (hidden on print) */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4 print:hidden">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                  <FileCheck2 className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-base">ডিজিটাল মানি রসিদ প্রস্তুত হইয়াছে</h3>
                  <p className="text-xs text-slate-500">ইউপি লোগো ও অনলাইন সত্যতা যাচাই QR কোড সংযুক্ত</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Upload / Change UP Logo Button */}
                <label 
                  title="ইউনিয়ন পরিষদ লোগো আপলোড বা পরিবর্তন করুন"
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-slate-300 dark:border-slate-600 cursor-pointer transition active:scale-95"
                >
                  <Upload className="w-3.5 h-3.5 text-emerald-600" />
                  <span>লোগো আপলোড</span>
                  <input 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={handleLogoUpload} 
                  />
                </label>

                {/* Download PDF Button */}
                <button
                  id="btn-download-receipt-pdf"
                  onClick={handleDownloadReceiptPDF}
                  disabled={isDownloadingPdf}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow flex items-center gap-1.5 transition active:scale-95 cursor-pointer disabled:opacity-50"
                >
                  {isDownloadingPdf ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>PDF তৈরি হচ্ছে...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5" />
                      <span>PDF ডাউনলোড</span>
                    </>
                  )}
                </button>

                {/* Print Receipt Button */}
                <button
                  id="btn-print-money-receipt"
                  onClick={() => window.print()}
                  className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold shadow flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>প্রিন্ট</span>
                </button>

                <button 
                  onClick={() => setIsReceiptModalOpen(false)}
                  className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Digital Money Receipt Sheet */}
            <div 
              id="digital-tax-money-receipt-sheet" 
              className="bg-white text-slate-900 p-6 sm:p-8 rounded-2xl border-4 border-double border-emerald-800 space-y-5 shadow-sm relative overflow-hidden"
            >
              {/* Background Watermark */}
              <div className="absolute inset-0 flex items-center justify-center opacity-[0.04] pointer-events-none select-none">
                <Landmark className="w-96 h-96 text-emerald-900" />
              </div>

              {/* Receipt Header with System Uploaded Union Parishad Logo */}
              <div className="flex items-center justify-between border-b-2 border-emerald-800 pb-3 gap-3">
                <div className="flex-shrink-0">
                  <img 
                    src={activeReceipt.unionLogoUrl || customLogoUrl || config.logoUrl || '/baheratail_seal.svg'} 
                    alt="Union Parishad Logo" 
                    className="w-16 h-16 sm:w-20 sm:h-20 object-contain rounded-full border border-emerald-800/30 p-1 bg-white shadow-xs"
                    crossOrigin="anonymous"
                  />
                </div>
                <div className="text-center flex-1 space-y-0.5">
                  <div className="text-[11px] font-bold uppercase tracking-widest text-emerald-800">
                    গণপ্রজাতন্ত্রী বাংলাদেশ সরকার
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black text-emerald-900 leading-tight">
                    {config.upName}
                  </h2>
                  <div className="text-xs text-slate-600 font-medium">
                    উপজেলা: {config.upazila}, জেলা: {config.district} | ই-মেইল: {config.email}
                  </div>
                  <div className="inline-block mt-1 px-5 py-0.5 rounded-full bg-emerald-800 text-white font-bold text-xs tracking-wider shadow-sm">
                    হোল্ডিং ট্যাক্স আদায় দাখিলা ও ডিজিটাল মানি রসিদ
                  </div>
                </div>
                <div className="hidden sm:flex flex-col items-center justify-center p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-center w-20">
                  <ShieldCheck className="w-6 h-6 text-emerald-700" />
                  <span className="text-[9px] font-bold text-emerald-900 uppercase mt-0.5">অফিশিয়াল রসিদ</span>
                </div>
              </div>

              {/* Meta Banner */}
              <div className="grid grid-cols-2 text-xs gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div>
                  <span className="font-bold text-slate-700">রসিদ নম্বর:</span>{' '}
                  <span className="font-mono font-black text-emerald-800 text-sm">{activeReceipt.receiptNo}</span>
                </div>
                <div className="text-right">
                  <span className="font-bold text-slate-700">পরিশোধের তারিখ:</span>{' '}
                  <span className="font-semibold text-slate-900">{activeReceipt.date}</span>
                </div>
                <div>
                  <span className="font-bold text-slate-700">অর্থবছর:</span>{' '}
                  <span className="font-bold text-slate-900">{activeReceipt.fiscalYear}</span>
                </div>
                <div className="text-right">
                  <span className="font-bold text-slate-700">পদ্ধতি:</span>{' '}
                  <span className="font-semibold text-slate-900">{activeReceipt.paymentMethod} {activeReceipt.trxId ? `(${activeReceipt.trxId})` : ''}</span>
                </div>
              </div>

              {/* Information Table */}
              <div className="border border-slate-300 rounded-xl overflow-hidden text-xs">
                <table className="w-full text-left">
                  <tbody>
                    <tr className="border-b border-slate-200 bg-slate-50/60">
                      <td className="p-2.5 font-bold text-slate-700 w-1/3">হোল্ডিং নম্বর:</td>
                      <td className="p-2.5 font-mono font-black text-emerald-900 text-sm">{activeReceipt.holdingNo}</td>
                    </tr>
                    <tr className="border-b border-slate-200">
                      <td className="p-2.5 font-bold text-slate-700">করদাতার নাম:</td>
                      <td className="p-2.5 font-bold text-slate-900 text-sm">{activeReceipt.ownerName}</td>
                    </tr>
                    <tr className="border-b border-slate-200 bg-slate-50/60">
                      <td className="p-2.5 font-bold text-slate-700">পিতা/স্বামীর নাম:</td>
                      <td className="p-2.5 font-medium text-slate-800">{activeReceipt.guardianName}</td>
                    </tr>
                    <tr className="border-b border-slate-200">
                      <td className="p-2.5 font-bold text-slate-700">ঠিকানা ও এলাকা:</td>
                      <td className="p-2.5 text-slate-800">গ্রাম: {activeReceipt.village}, ওয়ার্ড নং: {activeReceipt.wardNo}</td>
                    </tr>
                    <tr className="border-b border-slate-200 bg-slate-50/60">
                      <td className="p-2.5 font-bold text-slate-700">হোল্ডিংয়ের ধরন:</td>
                      <td className="p-2.5 font-semibold text-slate-800">
                        {activeReceipt.holdingType === 'residential' ? 'বসতবাড়ি (Residential)' : 'ব্যবসা প্রতিষ্ঠান / মার্কেট'}
                      </td>
                    </tr>
                    <tr className="border-b border-slate-200">
                      <td className="p-2.5 font-bold text-slate-700">সর্বমোট করের দাবি:</td>
                      <td className="p-2.5 font-bold text-slate-900">
                        ৳{(activeReceipt.originalDemand || activeReceipt.totalDemand).toLocaleString('bn-BD')}/-
                      </td>
                    </tr>
                    {activeReceipt.discountAmount && activeReceipt.discountAmount > 0 ? (
                      <>
                        <tr className="border-b border-slate-200 bg-amber-50/60 text-amber-950 font-semibold">
                          <td className="p-2.5">অনুমোদিত কর কর্তন / মওকুফ:</td>
                          <td className="p-2.5 text-amber-800">
                            (-) ৳{activeReceipt.discountAmount.toLocaleString('bn-BD')}/- 
                            <span className="text-[11px] text-amber-900 font-normal ml-1">
                              ({activeReceipt.deductionReason || 'ইউপি অনুমোদন'})
                            </span>
                          </td>
                        </tr>
                        <tr className="border-b border-slate-200 bg-slate-50/70 font-bold">
                          <td className="p-2.5">কর্তন পরবর্তী নিট দাবি:</td>
                          <td className="p-2.5 text-slate-900">
                            ৳{(activeReceipt.netDemand || activeReceipt.totalDemand).toLocaleString('bn-BD')}/-
                          </td>
                        </tr>
                      </>
                    ) : null}
                    <tr className="border-b border-slate-200 bg-emerald-50 text-emerald-950 font-black text-sm">
                      <td className="p-2.5">গৃহীত করের পরিমাণ:</td>
                      <td className="p-2.5 text-emerald-800">৳{activeReceipt.paidAmount.toLocaleString('bn-BD')}/- (পরিশোধিত)</td>
                    </tr>
                    <tr className="bg-rose-50/80 text-rose-900 text-xs">
                      <td className="p-2.5 font-bold">অবশিষ্ট বকেয়া:</td>
                      <td className="p-2.5 font-bold">
                        {activeReceipt.remainingDue > 0 ? `৳${activeReceipt.remainingDue.toLocaleString('bn-BD')}/-` : 'কোনো বকেয়া নাই (পরিশোধিত)'}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Bottom QR Verification & Signatures */}
              <div className="flex items-end justify-between pt-4 border-t border-slate-300 text-xs">
                {/* QR Section */}
                <div className="flex items-center gap-3">
                  {activeReceipt.qrCodeUrl ? (
                    <img 
                      src={activeReceipt.qrCodeUrl} 
                      alt="QR Verification" 
                      className="w-20 h-20 border-2 border-emerald-700 p-1 rounded-xl bg-white shadow-sm"
                    />
                  ) : (
                    <div className="w-20 h-20 border border-slate-300 rounded-xl flex items-center justify-center bg-slate-100">
                      <QrCode className="w-8 h-8 text-slate-400" />
                    </div>
                  )}
                  <div className="space-y-0.5">
                    <div className="font-bold text-emerald-900 flex items-center gap-1">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" /> ডিজিটাল ভেরিফিকেশন QR
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      যাচাই লিংক: bup-gov.bd/tax/verify
                    </div>
                    <div className="text-[10px] text-slate-400">
                      *স্মার্টফোনে স্ক্যান করে দাখিলার সত্যতা যাচাই করুন
                    </div>
                  </div>
                </div>

                {/* Signatures */}
                <div className="flex items-center gap-8">
                  <div className="text-center space-y-1">
                    <div className="w-28 border-b border-slate-400 mx-auto" />
                    <div className="font-bold text-slate-800 text-[11px]">{activeReceipt.collectedBy}</div>
                    <div className="text-[9px] text-slate-500">ট্যাক্স আদায়কারী</div>
                  </div>

                  <div className="text-center space-y-1">
                    <div className="w-28 border-b border-slate-400 mx-auto" />
                    <div className="font-bold text-slate-800 text-[11px]">{config.chairmanName}</div>
                    <div className="text-[9px] text-slate-500">চেয়ারম্যান, {config.upName}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Modal Actions (Hidden on Print) */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-200 dark:border-slate-800 print:hidden text-xs">
              <div className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                রসিদটি সিস্টেমে ডিজিটাল ডাটাবেজে স্থায়ীভাবে সংরক্ষিত হয়েছে।
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleDownloadReceiptPDF}
                  disabled={isDownloadingPdf}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  PDF ডাউনলোড করুন
                </button>

                <button
                  type="button"
                  onClick={() => setIsReceiptModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-semibold cursor-pointer"
                >
                  বন্ধ করুন
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL 5: ADD NEW HOLDING REGISTRATION */}
      {/* ============================================================ */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-5 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-600" />
                নতুন হোল্ডিং নিবন্ধন ও কর নির্ধারণ
              </h3>
              <button 
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateHoldingSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    ওয়ার্ড নম্বর *
                  </label>
                  <select
                    value={newHoldingForm.wardNo}
                    onChange={(e) => {
                      const ward = e.target.value;
                      const mapping = WARD_VILLAGE_MAPPINGS.find(m => m.wardNo === ward);
                      const defaultVillage = mapping ? mapping.villages[0] : 'বহেড়াতৈল';
                      setNewHoldingForm({ ...newHoldingForm, wardNo: ward, village: defaultVillage });
                    }}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  >
                    {['০১', '০২', '০৩', '০৪', '০৫', '০৬', '০৭', '০৮', '০৯'].map(w => (
                      <option key={w} value={w}>ওয়ার্ড নং {w}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    গ্রামের নাম *
                  </label>
                  <select
                    value={newHoldingForm.village}
                    onChange={(e) => setNewHoldingForm({ ...newHoldingForm, village: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  >
                    {availableVillagesForNewHolding.map(v => (
                      <option key={v} value={v}>{v}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    হোল্ডিং নং (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    value={newHoldingForm.holdingNo}
                    onChange={(e) => setNewHoldingForm({ ...newHoldingForm, holdingNo: e.target.value })}
                    placeholder="ফাঁকা রাখলে অটো জেনারেট"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    হোল্ডিংয়ের ধরন *
                  </label>
                  <select
                    value={newHoldingForm.holdingType}
                    onChange={(e: any) => setNewHoldingForm({ ...newHoldingForm, holdingType: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  >
                    <option value="residential">বসতবাড়ি (Residential)</option>
                    <option value="commercial">ব্যবসা প্রতিষ্ঠান / মার্কেট (Commercial)</option>
                    <option value="industrial">শিল্প কারখানা / রাইস মিল (Industrial)</option>
                    <option value="institutional">প্রতিষ্ঠান (Institutional)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    কাঠামো / ভবনের ধরন
                  </label>
                  <select
                    value={newHoldingForm.structureType}
                    onChange={(e: any) => setNewHoldingForm({ ...newHoldingForm, structureType: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  >
                    <option value="pucca">পাকা দালান (Pucca)</option>
                    <option value="semi_pucca">আধাপাকা টিনশেড (Semi-pucca)</option>
                    <option value="kacha">কাঁচা ঘর (Kacha)</option>
                    <option value="multi_storied">বহুতল বাণিজ্যিক ভবন (Multi-storied)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    করদাতার নাম / প্রতিষ্ঠানের নাম *
                  </label>
                  <input
                    type="text"
                    required
                    value={newHoldingForm.ownerName}
                    onChange={(e) => setNewHoldingForm({ ...newHoldingForm, ownerName: e.target.value })}
                    placeholder="উদা: মোঃ শাহ আলম"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    পিতা / স্বামীর নাম
                  </label>
                  <input
                    type="text"
                    value={newHoldingForm.guardianName}
                    onChange={(e) => setNewHoldingForm({ ...newHoldingForm, guardianName: e.target.value })}
                    placeholder="উদা: মৃত মজিবুর রহমান"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    মোবাইল নম্বর
                  </label>
                  <input
                    type="tel"
                    value={newHoldingForm.mobile}
                    onChange={(e) => setNewHoldingForm({ ...newHoldingForm, mobile: e.target.value })}
                    placeholder="017XXXXXXXX"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    জাতীয় পরিচয়পত্র (NID) নম্বর
                  </label>
                  <input
                    type="text"
                    value={newHoldingForm.nid}
                    onChange={(e) => setNewHoldingForm({ ...newHoldingForm, nid: e.target.value })}
                    placeholder="১০ বা ১৭ ডিজিট"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              {/* Assessment Values */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-center justify-between font-bold text-slate-800 dark:text-slate-200">
                  <span>কর মূল্যায়ন ও ধার্যকৃত অর্থ</span>
                  <button
                    type="button"
                    onClick={() => setIsCalculatorModalOpen(true)}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer transition shadow-sm"
                  >
                    <Calculator className="w-3.5 h-3.5" />
                    জমির ধরন ও আয়তন দিয়ে অটো হিসাব করুন
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      বাৎসরিক মূল্যায়ন (টাকা)
                    </label>
                    <input
                      type="number"
                      value={newHoldingForm.annualValuation}
                      onChange={(e) => {
                        const val = Number(e.target.value) || 0;
                        const defaultDemand = Math.round(val * 0.05);
                        setNewHoldingForm({ 
                          ...newHoldingForm, 
                          annualValuation: e.target.value,
                          currentTaxDemand: String(defaultDemand)
                        });
                      }}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      চলতি বাৎসরিক কর (টাকা)
                    </label>
                    <input
                      type="number"
                      value={newHoldingForm.currentTaxDemand}
                      onChange={(e) => setNewHoldingForm({ ...newHoldingForm, currentTaxDemand: e.target.value })}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      পূর্বের বকেয়া কর (যদি থাকে)
                    </label>
                    <input
                      type="number"
                      value={newHoldingForm.arrearsDue}
                      onChange={(e) => setNewHoldingForm({ ...newHoldingForm, arrearsDue: e.target.value })}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-rose-600"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  মন্তব্য / বিবরণ
                </label>
                <input
                  type="text"
                  value={newHoldingForm.notes}
                  onChange={(e) => setNewHoldingForm({ ...newHoldingForm, notes: e.target.value })}
                  placeholder="উদা: পাকা একতলা বাড়ি, ৩ রুম"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-slate-600 dark:text-slate-400 font-semibold hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-4 h-4" /> সিস্টেমে সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL 6: RECORD DETAILS MODAL */}
      {/* ============================================================ */}
      {viewDetailsRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-600" />
                হোল্ডিং বিস্তারিত — {viewDetailsRecord.holdingNo}
              </h3>
              <button 
                onClick={() => setViewDetailsRecord(null)}
                className="p-1 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">মালিকের নাম:</span>
                <span className="font-bold text-slate-900 dark:text-white">{viewDetailsRecord.ownerName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">পিতা/স্বামীর নাম:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{viewDetailsRecord.guardianName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">ঠিকানা:</span>
                <span className="text-slate-800 dark:text-slate-200">গ্রাম: {viewDetailsRecord.village}, ওয়ার্ড: {viewDetailsRecord.wardNo}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">মোবাইল:</span>
                <span className="font-mono text-slate-800 dark:text-slate-200">{viewDetailsRecord.mobile || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">এনআইডি:</span>
                <span className="font-mono text-slate-800 dark:text-slate-200">{viewDetailsRecord.nid || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">বাৎসরিক মূল্যায়ন:</span>
                <span className="font-bold text-slate-900 dark:text-white">৳{viewDetailsRecord.annualValuation}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">চলতি ধার্য কর:</span>
                <span className="font-semibold text-emerald-600">৳{viewDetailsRecord.currentTaxDemand}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">পূর্বের বকেয়া:</span>
                <span className="font-semibold text-rose-600">৳{viewDetailsRecord.arrearsDue}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 font-bold">মোট দাবি:</span>
                <span className="font-bold text-slate-900 dark:text-white">৳{viewDetailsRecord.totalDemand}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 font-bold">আদায়কৃত:</span>
                <span className="font-bold text-emerald-600">৳{viewDetailsRecord.paidAmount}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 font-bold">বর্তমান বকেয়া:</span>
                <span className="font-bold text-rose-600">৳{viewDetailsRecord.currentDue}</span>
              </div>
              {viewDetailsRecord.notes && (
                <div className="py-1">
                  <span className="text-slate-500 block mb-0.5">মন্তব্য:</span>
                  <p className="text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800 p-2 rounded-lg">{viewDetailsRecord.notes}</p>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setViewDetailsRecord(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL 7: WARD-WISE ARREARS SUMMARY PDF EXPORT REPORT */}
      {/* ============================================================ */}
      <WardArrearsReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        wardNo={selectedWard}
        onWardChange={(w) => setSelectedWard(w)}
        records={records}
        wardSummaries={wardSummaries}
        config={config}
        fiscalYear={selectedFiscalYear}
      />

      {/* ============================================================ */}
      {/* MODAL 8: HOLDING TAX & LAND ASSESSMENT CALCULATOR */}
      {/* ============================================================ */}
      <TaxAssessmentCalculatorModal
        isOpen={isCalculatorModalOpen}
        onClose={() => setIsCalculatorModalOpen(false)}
        config={config}
        onApplyToNewHolding={(assessmentData) => {
          setNewHoldingForm(prev => ({
            ...prev,
            holdingType: assessmentData.holdingType,
            structureType: assessmentData.structureType,
            annualValuation: String(assessmentData.annualValuation),
            currentTaxDemand: String(assessmentData.currentTaxDemand),
            arrearsDue: String(assessmentData.arrearsDue),
            notes: assessmentData.notes
          }));
          setIsAddModalOpen(true);
          setToastMessage('✅ ক্যালকুলেটরের হিসাব নতুন হোল্ডিং ফর্মে সফলভাবে বসেছে!');
          setTimeout(() => setToastMessage(null), 4000);
        }}
        existingRecords={records}
      />
    </div>
  );
};
