import React, { useState } from 'react';
import { 
  Home, 
  ShieldCheck, 
  UserCheck, 
  QrCode, 
  Landmark, 
  FileText, 
  Printer, 
  Users, 
  Layers, 
  MapPin, 
  Megaphone, 
  MessageSquare, 
  Sparkles, 
  Cpu, 
  Zap, 
  Puzzle, 
  Activity, 
  Settings, 
  Lock, 
  Code2, 
  ArrowRight, 
  BarChart2, 
  Layers3,
  CheckCircle2,
  ShieldAlert,
  Globe,
  Database,
  Brain
} from 'lucide-react';
import { UnionParishadConfig } from '../types';

interface MasterControlHubProps {
  config: UnionParishadConfig;
  setActiveTab: (tab: string) => void;
  pendingCount?: number;
}

export const MasterControlHub: React.FC<MasterControlHubProps> = ({ config, setActiveTab, pendingCount = 0 }) => {
  const [searchTerm, setSearchTerm] = useState('');

  // Grouped Navigation Categories with gorgeous cards
  const categories = [
    {
      id: 'services',
      title: '🏛️ নাগরিক সেবা ও সার্টিফিকেট ম্যানেজমেন্ট',
      subtitle: 'নাগরিক আবেদন, টেমপ্লেট জেনারেশন, হোল্ডিং ট্যাক্স এবং অনলাইন যাচাইকরণ',
      color: 'from-emerald-500/10 via-emerald-600/5 to-transparent border-emerald-500/30',
      badgeColor: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300',
      items: [
        {
          id: 'home',
          title: '১. ড্যাশবোর্ড ও ট্র্যাকিং',
          desc: 'সার্বিক পরিসংখ্যান, ৩০ দিনের ট্রেন্ড ও রিয়েল-টাইম সামারি।',
          icon: Home,
          badge: 'মেইন পেজ',
          subItems: ['📊 ৩০ দিনের ট্রেন্ড এনালাইটিক্স', 'সক্রিয় আবেদন স্ট্যাটাস']
        },
        {
          id: 'pending',
          title: '২. চেয়ারম্যান অনুমোদন সমূহ',
          desc: 'অপেক্ষমাণ প্রত্যয়নপত্র পর্যালোচনা ও ডিজিটাল স্বাক্ষর অনুমোদন।',
          icon: ShieldCheck,
          badge: pendingCount > 0 ? `${pendingCount} টি অপেক্ষমাণ` : 'সব অনুমোদিত',
          subItems: ['হিউম্যান-ইন-দ্য-লুপ গেট', 'তাৎক্ষণিক অনুমোদন']
        },
        {
          id: 'citizens',
          title: '৩. নাগরিক একাউন্ট ও ডাটাবেজ',
          desc: 'ওয়ার্ড ভিত্তিক নাগরিক তালিকা, NID ও জন্ম নিবন্ধন রেজিস্ট্রি।',
          icon: UserCheck,
          badge: 'ওয়ার্ড ১-৯',
          subItems: ['ওয়ার্ড ফিল্টার', 'নাগরিক প্রোফাইল']
        },
        {
          id: 'citizen_profile',
          title: '৩.১ সিটিজেন প্রোফাইল জেনারেটর',
          desc: 'নাগরিকের ব্যক্তিগত ড্যাশবোর্ড ও কিউআর আইডি কার্ড।',
          icon: QrCode,
          badge: 'পাবলিক লিংক',
          subItems: ['QR জেনারেটর', 'আইডি কার্ড প্রিন্ট']
        },
        {
          id: 'holding_tax',
          title: '৩.২ হোল্ডিং ট্যাক্স ও বকেয়া',
          desc: 'গ্রাম ও ওয়ার্ড ভিত্তিক হোল্ডিং ট্যাক্স আদায় ও বকেয়া খতিয়ান।',
          icon: Landmark,
          badge: 'আর্থিক রেজিস্ট্রি',
          subItems: ['ট্যাক্স লেজার', 'রসিদ প্রিন্ট']
        },
        {
          id: 'create',
          title: '৪. নতুন প্রত্যয়নপত্র আবেদন',
          desc: '৮০+ ক্যাটাগরির সনদ (নাগরিক, ওয়ারিশ, চারিত্রিক ইত্যাদি) প্রস্তুতকরণ।',
          icon: FileText,
          badge: '৮০+ ফরম্যাট',
          subItems: ['NID অটো স্ক্যান', 'AI ডেটা ভ্যালিডেশন']
        },
        {
          id: 'logs',
          title: '৫. সনদ পেজ ও রেকর্ড (সকল)',
          desc: 'অতীতে ইস্যুকৃত সমস্ত সার্টিফিকেটের সুরক্ষিত আর্কাইভ।',
          icon: FileText,
          badge: 'আর্কাইভ',
          subItems: ['স্মারক নম্বর ট্র্যাকিং', 'ইতিহাস']
        },
        {
          id: 'search_reprint',
          title: '৫.১ সনদ সার্চ ও রি-প্রিন্ট',
          desc: 'NID নম্বর বা নাগরিকের নাম দিয়ে তাৎক্ষণিক সনদ খুঁজে বের করা।',
          icon: Printer,
          badge: 'দ্রুত অনুসন্ধান',
          subItems: ['NID সার্চ', 'রি-প্রিন্ট মোড']
        },
        {
          id: 'verify',
          title: '৬. সনদ অনলাইন যাচাই',
          desc: 'QR কোড বা সার্টিফিকেট আইডি দিয়ে অনলাইন সত্যতা যাচাইকরণ।',
          icon: ShieldCheck,
          badge: 'পাবলিক সিকিউরিটি',
          subItems: ['QR স্ক্যানার', 'ভ্যালিডেশন রেজাল্ট']
        }
      ]
    },
    {
      id: 'ai_hub',
      title: '🤖 এআই ও স্মার্ট অ্যাসিস্ট্যান্ট হাব',
      subtitle: 'গুগল জেমিনি এআই, কাস্টম জেম, চ্যাট স্পেস এবং ওমনি কন্ট্রোল',
      color: 'from-blue-500/10 via-indigo-600/5 to-transparent border-blue-500/30',
      badgeColor: 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300',
      items: [
        {
          id: 'google_chat',
          title: '১১. গুগল চ্যাট ও টিম স্পেস',
          desc: 'ইউনিয়ন পরিষদ কর্মকর্তাদের অভ্যন্তরীণ রিয়েল-টাইম যোগাযোগ।',
          icon: MessageSquare,
          badge: 'ওয়ার্কস্পেস',
          subItems: ['টিম মেসেজিং', 'অফিসিয়াল চ্যাট']
        },
        {
          id: 'gem_studio',
          title: '১২. গুগল জেম ও নলেজ ফাইল হাব',
          desc: '১১টি মাস্টার নলেজ ফাইল এবং জেমিনি কাস্টম জেম প্রম্পট।',
          icon: Sparkles,
          badge: 'এআই ব্রেইন',
          subItems: ['নলেজ বেস ফাইল', 'জেম প্রম্পট']
        },
        {
          id: 'omnicontrol',
          title: '১৩.২ ওমনি কন্ট্রোল (API, MCP & AI Hub)',
          desc: 'মাস্টার API ম্যানেজার, ওয়েবহুক, MCP টুলস ও এআই মডেল রাউটার।',
          icon: Cpu,
          badge: 'মাস্টার হাব',
          subItems: ['API Keys', 'MCP Protocols', 'Multi-Model Router']
        }
      ]
    },
    {
      id: 'integrations',
      title: '🔗 ক্লাউড কানেক্টরস ও অটোমেশন সেন্টার',
      subtitle: 'n8n, মেক, ব্রাউজার এক্সটেনশন এবং রিয়েল-টাইম ক্লাউড সিঙ্ক',
      color: 'from-amber-500/10 via-orange-600/5 to-transparent border-amber-500/30',
      badgeColor: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300',
      items: [
        {
          id: 'cloud_connectors',
          title: '১৩. ক্লাউড কানেক্টরস ও অটোমেশন',
          desc: 'n8n, Make.com ও ১৪টি প্ল্যাটফর্মের সাথে সংযোগ ও অটোমেশন।',
          icon: Zap,
          badge: '১৪ প্ল্যাটফর্ম',
          subItems: ['n8n Webhooks', 'API Sync']
        },
        {
          id: 'browser_extension',
          title: '১৩.১ ব্রাউজার এক্সটেনশন ও প্লাগইন হাব',
          desc: 'Chrome/Firefox-এর জন্য Manifest V3 এক্সটেনশন ও টুলবার।',
          icon: Puzzle,
          badge: 'মেনিফেস্ট ভি৩',
          subItems: ['ডাউনলোড এক্সটেনশন', 'পপআপ স্ক্রিপ্ট']
        }
      ]
    },
    {
      id: 'council',
      title: '🗺️ পরিষদ ও উন্নয়ন ব্যবস্থাপনা',
      subtitle: 'কর্মকর্তা তালিকা, হিটম্যাপ, জিআইএস ওয়ার্ড ম্যাপ এবং নোটিশ বোর্ড',
      color: 'from-purple-500/10 via-pink-600/5 to-transparent border-purple-500/30',
      badgeColor: 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300',
      items: [
        {
          id: 'members',
          title: '৭. পরিষদ সদস্য ও কর্মকর্তা',
          desc: 'চেয়ারম্যান, সচিব, ইউপি সদস্য ও উদ্যোক্তাদের তথ্য ও যোগাযোগ।',
          icon: Users,
          badge: '২৭ জন কর্মকর্তা',
          subItems: ['যোগাযোগ তালিকা', 'পদবি রেজিস্ট্রি']
        },
        {
          id: 'heatmap',
          title: '৮. উন্নয়ন হিটম্যাপ',
          desc: 'D3 জেনারেটেড ভিজ্যুয়াল ডেটা ও বাজেট বরাদ্দ পরিসংখ্যান।',
          icon: Layers,
          badge: 'D3 এনালাইটিক্স',
          subItems: ['উন্নয়ন বাজেট', 'ওয়ার্ড বরাদ্দ']
        },
        {
          id: 'map',
          title: '৯. জিআইএস ওয়ার্ড ম্যাপ',
          desc: 'বহেড়াতৈল ইউনিয়নের ৯টি ওয়ার্ড ও ২০টি গ্রামের ভৌগোলিক মানচিত্র।',
          icon: MapPin,
          badge: 'ওয়ার্ড ১-৯',
          subItems: ['গ্রামের সীমানা', 'জিও-লোকেশন']
        },
        {
          id: 'notice',
          title: '১০. ডিজিটাল নোটিশ বোর্ড',
          desc: 'ইউনিয়ন পরিষদের গুরুত্বপূর্ণ ঘোষণা, আদেশ ও টেন্ডার নোটিশ।',
          icon: Megaphone,
          badge: 'লাইভ',
          subItems: ['সার্কুলার', 'জরুরি ঘোষণা']
        }
      ]
    },
    {
      id: 'security_admin',
      title: '🛡️ সিকিউরিটি, এডমিন ও ডেভেলপার কন্ট্রোল',
      subtitle: 'অ্যাক্টিভিটি অডিট ট্রেইল, ইউজার রোল, মাস্টার সেটআপ ও সিকিউরিটি',
      color: 'from-rose-500/10 via-red-600/5 to-transparent border-rose-500/30',
      badgeColor: 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300',
      items: [
        {
          id: 'audit_trail',
          title: '১৪. অ্যাক্টিভিটি অডিট ট্রেইল',
          desc: 'সিস্টেমের সমস্ত অপারেশনের ইমিউটেবল লগ ও সিকিউরিটি ট্র্যাকিং।',
          icon: Activity,
          badge: 'সুপার এডমিন',
          subItems: ['অ্যাক্টর লগ', 'টাইমস্ট্যাম্প']
        },
        {
          id: 'admin_dashboard',
          title: '১৫. ইউজার ও পারমিশন রোল',
          desc: 'RBAC (Role-Based Access Control) ও ইউজার পারমিশন ম্যানেজমেন্ট।',
          icon: ShieldCheck,
          badge: 'সুরক্ষা',
          subItems: ['রোল অ্যাসাইন', 'সিকিউরিটি পলিসি']
        },
        {
          id: 'admin',
          title: '১৬. মাস্টার সেটআপ',
          desc: 'ইউনিয়ন পরিষদের নাম, ঠিকানা, সিল, স্বাক্ষর ও কনফিগারেশন।',
          icon: Settings,
          badge: 'কনফিগ',
          subItems: ['অফিস তথ্য', 'স্মারক ফরম্যাট']
        },
        {
          id: 'developer_control',
          title: '১৭. ডেভেলপার সিকিউরিটি অ্যান্ড কন্ট্রোল',
          desc: 'এনভায়রনমেন্ট সিক্রেট, ফায়ারস্টোর সিকিউরিটি রুলস ও API গেটওয়ে।',
          icon: Lock,
          badge: 'এডমিন সিক্রেট',
          subItems: ['সিকিউরিটি রুলস', 'টোকেন ম্যানেজমেন্ট']
        },
        {
          id: 'developer',
          title: '১৮. ডেভেলপার প্রোফাইল',
          desc: 'সিস্টেম আর্কিটেক্ট ও টেকনিক্যাল টিমের তথ্য ও ডকুমেন্টেশন।',
          icon: Code2,
          badge: 'ক্রেডিট',
          subItems: ['আর্কিটেকচার ইনফো', 'ভার্সন ২.০']
        },
        {
          id: 'ai_supervisor',
          title: '১৯. ইন-বিল্ট এআই সুপারভাইজার (AI Intelligence)',
          desc: 'সিস্টেম অটোনোমাস কোয়ালিটি লার্নিং, এরর রুট কজ বিশ্লেষণ ও এক্সিকিউটিভ রিপোর্ট।',
          icon: Brain,
          badge: 'এআই ইন্টেলিজেন্স',
          subItems: ['লার্নিং মেমোরি', 'বাগ ক্যান্ডিডেটস', 'দৈনিক রিপোর্ট']
        }
      ]
    }
  ];

  const [filterMode, setFilterMode] = useState<'all' | 'master_11_18' | 'standard_1_10'>('all');

  // Fast Sub-Bar Items (১১ হতে ১৯ সাব-বার)
  const masterSubBarItems = [
    { id: 'google_chat', num: '১১', label: 'গুগল চ্যাট', icon: MessageSquare, badge: 'টিম স্পেস' },
    { id: 'gem_studio', num: '১২', label: 'জেম ও নলেজ ফাইল', icon: Sparkles, badge: 'Gem Studio' },
    { id: 'cloud_connectors', num: '১৩', label: 'ক্লাউড অটোমেশন', icon: Zap, badge: 'n8n/Make' },
    { id: 'browser_extension', num: '১৩.১', label: 'ব্রাউজার এক্সটেনশন', icon: Puzzle, badge: 'V3' },
    { id: 'omnicontrol', num: '১৩.২', label: 'ওমনি কন্ট্রোল', icon: Cpu, badge: 'AI Router' },
    { id: 'audit_trail', num: '১৪', label: 'অডিট ট্রেইল', icon: Activity, badge: 'লগ' },
    { id: 'admin_dashboard', num: '১৫', label: 'ইউজার ও রোল', icon: ShieldCheck, badge: 'RBAC' },
    { id: 'admin', num: '১৬', label: 'মাস্টার সেটআপ', icon: Settings, badge: 'কনফিগ' },
    { id: 'developer_control', num: '১৭', label: 'ডেভেলপার সিকিউরিটি', icon: Lock, badge: 'রুলস' },
    { id: 'developer', num: '১৮', label: 'ডেভেলপার প্রোফাইল', icon: Code2, badge: 'প্রোফাইল' },
    { id: 'ai_supervisor', num: '১৯', label: 'এআই সুপারভাইজার', icon: Brain, badge: 'AI Engine' }
  ];

  const filteredCategories = categories.map(cat => {
    let items = cat.items.filter(item => 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      item.desc.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (filterMode === 'master_11_18') {
      const master11to18Ids = ['google_chat', 'gem_studio', 'cloud_connectors', 'browser_extension', 'omnicontrol', 'audit_trail', 'admin_dashboard', 'admin', 'developer_control', 'developer', 'ai_supervisor'];
      items = items.filter(item => master11to18Ids.includes(item.id));
    } else if (filterMode === 'standard_1_10') {
      const standard1to10Ids = ['home', 'pending', 'citizens', 'citizen_profile', 'holding_tax', 'create', 'logs', 'search_reprint', 'verify', 'members', 'heatmap', 'map', 'notice'];
      items = items.filter(item => standard1to10Ids.includes(item.id));
    }

    return {
      ...cat,
      items
    };
  }).filter(cat => cat.items.length > 0);

  return (
    <div className="space-y-8 animate-fade-in pb-16 max-w-7xl mx-auto px-4 sm:px-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white rounded-3xl p-6 sm:p-10 shadow-2xl border border-emerald-500/30 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold">
              <Sparkles className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span>UPSM 2.0 Master Control & Navigation Hub</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white">
              ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ — মাস্টার নেভিগেশন ও কার্ড হাব
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              বহেড়াতৈল ইউনিয়ন পরিষদের সমস্ত সেবা, এআই হাব, অটোমেশন কানেক্টর এবং এডমিন মডিউলগুলো এখন এক ছাদের নিচে সুন্দর ক্যাটাগরি কার্ড আকারে বিন্যস্ত। যেকোনো মডিউলে সরাসরি প্রবেশ করতে কার্ডে ক্লিক করুন।
            </p>
          </div>

          <div className="w-full md:w-auto">
            <div className="relative">
              <input
                type="text"
                placeholder="সেবা বা মডিউল খুঁজুন..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full md:w-72 px-4 py-3 rounded-2xl bg-slate-800/90 border border-slate-700 text-white placeholder-slate-400 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-inner"
              />
            </div>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* MASTER HUB SUB-NAV BAR (১১ হতে ১৮ সাব-বার / Quick Sub-Bar) */}
      {/* ======================================================== */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border-2 border-amber-400/50 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-400 text-emerald-950 font-black shadow-sm">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <span>মাস্টার হাব সাব-বার (১১ হতে ১৮ দ্রুত অ্যাক্সেস)</span>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-300 font-bold border border-amber-300 dark:border-amber-700">১১-১৮</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                এডমিন, এআই হাব, অটোমেশন কানেক্টর ও সিকিউরিটি মডিউলসমূহে তাৎক্ষণিক প্রবেশ
              </p>
            </div>
          </div>

          {/* Filter Segmented Controls */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-bold shrink-0 self-start sm:self-auto">
            <button
              onClick={() => setFilterMode('all')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                filterMode === 'all'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs font-black'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              সকল মডিউল
            </button>
            <button
              onClick={() => setFilterMode('master_11_18')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                filterMode === 'master_11_18'
                  ? 'bg-amber-400 text-emerald-950 shadow-xs font-black'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              ১১-১৮ মাস্টার হাব
            </button>
            <button
              onClick={() => setFilterMode('standard_1_10')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                filterMode === 'standard_1_10'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs font-black'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              ১-১০ সাধারণ সেবা
            </button>
          </div>
        </div>

        {/* Horizontal Quick Sub-bar Pill List (১১ হতে ১৮) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
          {masterSubBarItems.map((subItem) => {
            const SubIcon = subItem.icon;
            return (
              <button
                key={subItem.id}
                onClick={() => setActiveTab(subItem.id)}
                className="group flex flex-col p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/70 hover:bg-gradient-to-br hover:from-emerald-900 hover:to-slate-900 text-slate-800 dark:text-slate-200 hover:text-white border border-slate-200 dark:border-slate-700/80 hover:border-amber-400 transition-all duration-200 shadow-xs hover:shadow-md cursor-pointer text-left relative overflow-hidden"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="p-1.5 rounded-lg bg-emerald-100 dark:bg-emerald-950/80 group-hover:bg-amber-400 text-emerald-700 dark:text-emerald-300 group-hover:text-emerald-950 transition-colors">
                    <SubIcon className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-black px-1.5 py-0.5 rounded-md bg-amber-400 text-emerald-950 group-hover:bg-white group-hover:text-slate-900">
                    {subItem.num}
                  </span>
                </div>
                <span className="text-xs font-extrabold truncate group-hover:text-amber-300">
                  {subItem.label}
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 group-hover:text-emerald-200 truncate mt-0.5">
                  {subItem.badge}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Categories & Cards */}
      <div className="space-y-12">
        {filteredCategories.map((category) => (
          <div key={category.id} className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <span>{category.title}</span>
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">{category.subtitle}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${category.badgeColor}`}>
                {category.items.length} টি মডিউল
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {category.items.map((item) => {
                const IconComponent = item.icon;
                return (
                  <div
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className="group bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 hover:border-emerald-500/50 dark:hover:border-emerald-500/50 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-bl-full pointer-events-none group-hover:scale-110 transition-transform"></div>

                    <div className="space-y-4 relative z-10">
                      <div className="flex items-center justify-between">
                        <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/50 group-hover:scale-110 transition-transform shadow-xs">
                          <IconComponent className="w-6 h-6" />
                        </div>
                        <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                          {item.badge}
                        </span>
                      </div>

                      <div className="space-y-1">
                        <h3 className="font-bold text-base text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                          {item.title}
                        </h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                          {item.desc}
                        </p>
                      </div>

                      {/* Sub-functions Pills */}
                      <div className="flex flex-wrap gap-1.5 pt-2">
                        {item.subItems.map((sub, sIdx) => (
                          <span key={sIdx} className="px-2 py-0.5 rounded-md bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-400 text-[10px] font-medium border border-slate-200/60 dark:border-slate-700/60">
                            {sub}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="pt-5 mt-5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-bold text-emerald-600 dark:text-emerald-400 relative z-10">
                      <span>মডিউলে প্রবেশ করুন</span>
                      <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1.5 transition-transform" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
