import React, { useState } from 'react';
import { 
  Cpu, 
  Terminal, 
  Workflow, 
  Database, 
  ShieldCheck, 
  Key, 
  Globe, 
  Server, 
  Activity, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Play, 
  Plus, 
  Trash2, 
  Copy, 
  Check, 
  Lock, 
  Unlock, 
  Zap, 
  Layers, 
  Sliders,
  Settings,
  Radio,
  FileCode
} from 'lucide-react';
import { UnionParishadConfig } from '../types';

interface OmniControlCommandCenterProps {
  config: UnionParishadConfig;
}

export const OmniControlCommandCenter: React.FC<OmniControlCommandCenterProps> = ({ config }) => {
  const [activeSubTab, setActiveSubTab] = useState<'api' | 'webhook' | 'mcp' | 'ai_router' | 'database' | 'security'>('api');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  
  // Simulated state for API keys
  const [apiKeys, setApiKeys] = useState([
    { id: 'key_1', name: 'UPSM Official Webhook API', prefix: 'upsm_live_9f83...', created: '2026-08-01', rateLimit: '1000 req/min', status: 'ACTIVE' },
    { id: 'key_2', name: 'NID Auto-Sync Connector', prefix: 'upsm_sync_4a21...', created: '2026-08-10', rateLimit: '500 req/min', status: 'ACTIVE' },
    { id: 'key_3', name: 'Mobile App Gateway', prefix: 'upsm_mob_7c99...', created: '2026-08-15', rateLimit: '2000 req/min', status: 'ACTIVE' },
  ]);

  // Simulated state for Webhooks
  const [webhooks, setWebhooks] = useState([
    { id: 'wh_1', event: 'certificate.approved', targetUrl: 'https://api.n8n.baheratailup.gov.bd/webhook/cert-issued', status: 'ONLINE', deliveries: '1,420 success' },
    { id: 'wh_2', event: 'citizen.registered', targetUrl: 'https://hook.eu1.make.com/upsm-citizen-sync', status: 'ONLINE', deliveries: '890 success' },
    { id: 'wh_3', event: 'audit.flagged', targetUrl: 'https://api.linear.app/webhooks/upsm-alerts', status: 'WARNING', deliveries: '12 failed (retry)' },
  ]);

  // Simulated state for MCP (Model Context Protocol)
  const [mcpTools, setMcpTools] = useState([
    { name: 'NID_OCR_Extractor', scope: 'Read Data / Search', status: 'CONNECTED', latency: '42ms' },
    { name: 'Certificate_Template_Engine', scope: 'Generate Draft', status: 'CONNECTED', latency: '18ms' },
    { name: 'Holding_Tax_Verifier', scope: 'Database Query', status: 'CONNECTED', latency: '35ms' },
    { name: 'Human_Approval_Gatekeeper', scope: 'Approval Required', status: 'ACTIVE_HITL', latency: '12ms' },
  ]);

  // AI Router configuration
  const [aiProvider, setAiProvider] = useState<'gemini' | 'openai' | 'claude' | 'local_ollama'>('gemini');
  const [fallbackEnabled, setFallbackEnabled] = useState(true);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleAddApiKey = () => {
    const newName = prompt('নতুন API Key-এর নাম লিখুন:');
    if (!newName) return;
    const newKey = {
      id: 'key_' + Date.now(),
      name: newName,
      prefix: 'upsm_live_' + Math.random().toString(36).substring(2, 8) + '...',
      created: new Date().toISOString().split('T')[0],
      rateLimit: '1000 req/min',
      status: 'ACTIVE'
    };
    setApiKeys([...apiKeys, newKey]);
  };

  return (
    <div className="space-y-6 animate-fade-in pb-12 max-w-7xl mx-auto px-4 sm:px-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-emerald-500/30 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold mb-3">
              <Cpu className="w-4 h-4 animate-pulse text-emerald-400" />
              <span>OmniControl Master Command Center</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2">
              ০২নং বহেড়াতৈল ইউপি — ওমনি কন্ট্রোল ইন্টিগ্রেশন ও এআই প্ল্যাটফর্ম
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              সেন্ট্রাল API ম্যানেজার, ওয়েবহুক অটোমেশন, MCP (Model Context Protocol) টুলস, মাল্টি-মডেল AI রাউটার এবং সিকিউরিটি গর্ভন্যান্স কন্ট্রোল সেন্টার।
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0 flex-wrap">
            <span className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-emerald-900/80 text-emerald-300 border border-emerald-600 text-xs font-bold shadow-inner">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
              <span>All Systems Online</span>
            </span>
          </div>
        </div>
      </div>

      {/* Sub-Tabs Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800">
        {[
          { id: 'api', label: '1. API Manager', icon: Key },
          { id: 'webhook', label: '2. Webhook Manager', icon: Workflow },
          { id: 'mcp', label: '3. MCP Protocol', icon: Terminal },
          { id: 'ai_router', label: '4. AI Platform Center', icon: Cpu },
          { id: 'database', label: '5. Database Manager', icon: Database },
          { id: 'security', label: '6. Security & RBAC', icon: ShieldCheck },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 cursor-pointer ${
                isActive 
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/20' 
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: API Manager */}
      {activeSubTab === 'api' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">API Keys & External Access Management</h2>
              <p className="text-xs text-slate-500">Secure Bearer tokens and rate limiting for external integrations.</p>
            </div>
            <button
              onClick={handleAddApiKey}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2 shadow-sm transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন API Key তৈরি করুন</span>
            </button>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 font-semibold border-b border-slate-200 dark:border-slate-700">
                    <th className="p-4">কী নাম (Key Name)</th>
                    <th className="p-4">টোকেন প্রিফিক্স</th>
                    <th className="p-4">তৈরির তারিখ</th>
                    <th className="p-4">রেট লিমিট</th>
                    <th className="p-4">স্ট্যাটাস</th>
                    <th className="p-4 text-right">কার্যক্রম</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {apiKeys.map(k => (
                    <tr key={k.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="p-4 font-bold text-slate-900 dark:text-white">{k.name}</td>
                      <td className="p-4 font-mono text-emerald-600 dark:text-emerald-400">{k.prefix}</td>
                      <td className="p-4 text-slate-500">{k.created}</td>
                      <td className="p-4"><span className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono text-[11px]">{k.rateLimit}</span></td>
                      <td className="p-4">
                        <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold text-[10px]">
                          {k.status}
                        </span>
                      </td>
                      <td className="p-4 text-right space-x-2">
                        <button
                          onClick={() => handleCopy(k.prefix, k.id)}
                          className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold text-xs inline-flex items-center gap-1 cursor-pointer"
                        >
                          {copiedKey === k.id ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedKey === k.id ? 'কপি হয়েছে' : 'কপি'}</span>
                        </button>
                        <button
                          onClick={() => setApiKeys(apiKeys.filter(item => item.id !== k.id))}
                          className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 text-rose-600 dark:text-rose-400 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Webhook Manager */}
      {activeSubTab === 'webhook' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">Event-Driven Webhook Manager</h2>
              <p className="text-xs text-slate-500">Real-time triggers for n8n, Make, and external notification pipelines.</p>
            </div>
            <button
              onClick={() => {
                const ev = prompt('ওয়েবহুক ইভেন্ট নাম (যেমন: certificate.issued):');
                const url = prompt('টার্গেট ইউআরএল (Target URL):');
                if (ev && url) {
                  setWebhooks([...webhooks, { id: 'wh_' + Date.now(), event: ev, targetUrl: url, status: 'ONLINE', deliveries: '0 success' }]);
                }
              }}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2 shadow-sm transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন ওয়েবহুক যোগ করুন</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {webhooks.map(w => (
              <div key={w.id} className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-mono text-xs font-bold">
                    {w.event}
                  </span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    w.status === 'ONLINE' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200' : 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200'
                  }`}>
                    {w.status}
                  </span>
                </div>
                <div className="font-mono text-xs text-slate-600 dark:text-slate-400 break-all bg-slate-50 dark:bg-slate-800 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
                  {w.targetUrl}
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                  <span className="text-slate-500">{w.deliveries}</span>
                  <button
                    onClick={() => alert(`🧪 Test Webhook fired for ${w.event}! Payload sent successfully.`)}
                    className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-900 dark:text-white font-bold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 text-emerald-600" />
                    <span>টেস্ট ফায়ার</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: MCP Protocol */}
      {activeSubTab === 'mcp' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Model Context Protocol (MCP) Manager</h2>
            <p className="text-xs text-slate-500">Secure AI agent tools, resource permissions, and local bridge connections.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {mcpTools.map((m, idx) => (
              <div key={idx} className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span className="font-bold text-sm text-slate-900 dark:text-white">{m.name}</span>
                  </div>
                  <p className="text-xs text-slate-500">Scope: <span className="font-mono text-amber-600 dark:text-amber-400">{m.scope}</span></p>
                </div>
                <div className="text-right space-y-1">
                  <span className="inline-block px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold text-[10px]">
                    {m.status}
                  </span>
                  <p className="text-[11px] font-mono text-slate-400">Latency: {m.latency}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: AI Platform Center */}
      {activeSubTab === 'ai_router' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">AI Platform Center & Model Router</h2>
            <p className="text-xs text-slate-500">Switch between Gemini, OpenAI, Claude, and local Ollama runtimes.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { id: 'gemini', name: 'Google Gemini Pro / Flash', badge: 'Primary', desc: 'Native Google AI Studio & Cloud SDK' },
              { id: 'openai', name: 'OpenAI GPT-4o', badge: 'Cloud API', desc: 'Advanced reasoning & drafting' },
              { id: 'claude', name: 'Anthropic Claude 3.5 Sonnet', badge: 'Alternative', desc: 'Exceptional Bangla administrative nuance' },
              { id: 'local_ollama', name: 'Local Ollama (Llama 3)', badge: 'Offline/Secure', desc: '100% private local server processing' },
            ].map(p => (
              <div 
                key={p.id}
                onClick={() => setAiProvider(p.id as any)}
                className={`p-5 rounded-2xl border transition cursor-pointer space-y-3 ${
                  aiProvider === p.id 
                    ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-500 shadow-md ring-2 ring-emerald-500/20' 
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900 dark:text-white">{p.name}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">{p.badge}</span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">{p.desc}</p>
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-bold">
                  <span className={aiProvider === p.id ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}>
                    {aiProvider === p.id ? '● Active Provider' : 'Click to Select'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 5: Database Manager */}
      {activeSubTab === 'database' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Database Schema & Collections Manager</h2>
            <p className="text-xs text-slate-500">Firebase Firestore, Supabase PostgreSQL, and IndexedDB local tables.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-slate-900 dark:text-white">citizens_master</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">1,988 records</span>
              </div>
              <p className="text-xs text-slate-500">NID, Birth Reg, Bangla/English names, Address hierarchy.</p>
              <div className="pt-2 text-xs font-bold text-emerald-600 dark:text-emerald-400">🟢 Live Synchronized</div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-slate-900 dark:text-white">certificates_issued</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">4,312 records</span>
              </div>
              <p className="text-xs text-slate-500">Memo numbers, QR hashes, digital signatures, timestamps.</p>
              <div className="pt-2 text-xs font-bold text-emerald-600 dark:text-emerald-400">🟢 Live Synchronized</div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-slate-900 dark:text-white">audit_logs</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">12,450 logs</span>
              </div>
              <p className="text-xs text-slate-500">Immutable actor activity trail, IP hashes, approval gatekeeping.</p>
              <div className="pt-2 text-xs font-bold text-emerald-600 dark:text-emerald-400">🟢 Secure Append-Only</div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 6: Security & RBAC */}
      {activeSubTab === 'security' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Security Governance & Human-in-the-Loop Gatekeeper</h2>
            <p className="text-xs text-slate-500">Role-based access control, zero-trust rules, and mandatory officer approval gates.</p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">Human-in-the-Loop Enforcement</h3>
                  <p className="text-xs text-slate-500">AI drafts and extracts data, but final issuance requires authorized officer review.</p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-xs font-bold">
                ENFORCED (Strict Mode)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="font-bold text-xs text-slate-900 dark:text-white">Super Admin</div>
                <p className="text-[11px] text-slate-500">Full control over API keys, system policies, and database schemas.</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="font-bold text-xs text-slate-900 dark:text-white">Approval Officer</div>
                <p className="text-[11px] text-slate-500">Mandatory review and digital signature authorization gatekeeper.</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="font-bold text-xs text-slate-900 dark:text-white">Data Operator</div>
                <p className="text-[11px] text-slate-500">NID upload, OCR extraction, and initial draft preparation.</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
