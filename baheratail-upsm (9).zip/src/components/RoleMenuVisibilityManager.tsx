import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Eye, 
  EyeOff, 
  Save, 
  RotateCcw, 
  CheckCircle2, 
  AlertCircle, 
  Lock, 
  UserCheck, 
  Users, 
  Sliders, 
  Sparkles, 
  LayoutGrid, 
  Settings, 
  ShieldAlert, 
  HelpCircle,
  Play,
  Monitor,
  Check,
  X
} from 'lucide-react';
import { UnionParishadConfig } from '../types';
import { 
  ALL_NAV_MENUS, 
  ALL_SETTINGS_TABS, 
  DEFAULT_MENU_VISIBILITY, 
  DEFAULT_SETTINGS_TAB_VISIBILITY,
  getEffectiveMenuMatrix,
  getEffectiveSettingsTabMatrix
} from '../data/roleVisibility';
import { saveConfigToFirebase } from '../firebase';
import { useAuth, UserRole } from '../hooks/useAuth';

interface RoleMenuVisibilityManagerProps {
  config: UnionParishadConfig;
  onUpdateConfig: (newConfig: UnionParishadConfig) => void;
  onConfigFormChange?: (updatedConfig: UnionParishadConfig) => void;
}

export const RoleMenuVisibilityManager: React.FC<RoleMenuVisibilityManagerProps> = ({
  config,
  onUpdateConfig,
  onConfigFormChange
}) => {
  const { session, switchRole } = useAuth();
  const [activeSubTab, setActiveSubTab] = useState<'menus' | 'settings_tabs' | 'simulator'>('menus');
  
  // Local state for the editable matrices
  const [menuMatrix, setMenuMatrix] = useState<Record<string, Record<string, boolean>>>(() => {
    return getEffectiveMenuMatrix(config);
  });

  const [settingsMatrix, setSettingsMatrix] = useState<Record<string, Record<string, boolean>>>(() => {
    return getEffectiveSettingsTabMatrix(config);
  });

  const [selectedRoleFilter, setSelectedRoleFilter] = useState<string>('ALL');
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  const rolesList: { key: string; labelBn: string; desc: string; icon: any; color: string }[] = [
    { key: 'citizen', labelBn: 'পাবলিক / সাধারণ নাগরিক (Citizen)', desc: 'অনলাইন যাচাই, পাবলিক প্রোফাইল ও নোটিশ', icon: Users, color: 'border-blue-500 text-blue-800 bg-blue-50' },
    { key: 'udc', labelBn: 'ইউডিজি / ডাটা অপারেটর (Operator)', desc: 'প্রত্যয়ন আবেদন ড্রাফট, সিটিজেন খতিয়ান ও প্রিন্ট', icon: UserCheck, color: 'border-teal-500 text-teal-800 bg-teal-50' },
    { key: 'secretary', labelBn: 'ইউপি সচিব (Secretary)', desc: 'সচিব যাচাই, ড্রাফট রিভিউ, মাস্টার রেজিস্টার', icon: ShieldCheck, color: 'border-indigo-500 text-indigo-800 bg-indigo-50' },
    { key: 'chairman', labelBn: 'ইউপি চেয়ারম্যান (Chairman)', desc: 'চূড়ান্ত অনুমোদন, ই-স্বাক্ষর, পরিষদ নীতি', icon: ShieldAlert, color: 'border-emerald-500 text-emerald-800 bg-emerald-50' },
    { key: 'developer', labelBn: 'ডেভেলপার / সুপার এডমিন (Developer)', desc: 'সর্বময় নিয়ন্ত্রণ, মাস্টার কনসোল ও API', icon: Lock, color: 'border-amber-500 text-amber-800 bg-amber-50' }
  ];

  // Toggle single menu visibility for a role
  const handleToggleMenu = (roleKey: string, menuId: string) => {
    if (roleKey === 'developer' || roleKey === 'super_admin') return; // Developer always visible
    setMenuMatrix(prev => {
      const currentRole = prev[roleKey] || {};
      const currentVal = currentRole[menuId] ?? false;
      const nextRoleState = { ...currentRole, [menuId]: !currentVal };
      return { ...prev, [roleKey]: nextRoleState };
    });
  };

  // Toggle single settings tab visibility for a role
  const handleToggleSettingsTab = (roleKey: string, tabId: string) => {
    if (roleKey === 'developer' || roleKey === 'super_admin') return; // Developer always visible
    setSettingsMatrix(prev => {
      const currentRole = prev[roleKey] || {};
      const currentVal = currentRole[tabId] ?? false;
      const nextRoleState = { ...currentRole, [tabId]: !currentVal };
      return { ...prev, [roleKey]: nextRoleState };
    });
  };

  // 1-Click Preset: Strict Public Security (Hide all admin options from citizen)
  const handleApplyStrictCitizenPreset = () => {
    setMenuMatrix(prev => ({
      ...prev,
      citizen: { ...DEFAULT_MENU_VISIBILITY.citizen }
    }));
    setSettingsMatrix(prev => ({
      ...prev,
      citizen: { ...DEFAULT_SETTINGS_TAB_VISIBILITY.citizen }
    }));
    setSaveSuccessMsg('✅ সাধারণ নাগরিক/পাবলিক ভিউয়ের জন্য সকল এডমিন মেনু ও সেটিংস সুরক্ষিত ও হাইড করা হইয়াছে!');
    setTimeout(() => setSaveSuccessMsg(null), 4000);
  };

  // 1-Click Preset: Standard Chairman View
  const handleApplyChairmanPreset = () => {
    setMenuMatrix(prev => ({
      ...prev,
      chairman: { ...DEFAULT_MENU_VISIBILITY.chairman }
    }));
    setSettingsMatrix(prev => ({
      ...prev,
      chairman: { ...DEFAULT_SETTINGS_TAB_VISIBILITY.chairman }
    }));
    setSaveSuccessMsg('✅ চেয়ারম্যান ভিউয়ের আদর্শ ডিফল্ট মেনু ও সেটিংস প্রিসেট প্রযোজ্য করা হইয়াছে!');
    setTimeout(() => setSaveSuccessMsg(null), 4000);
  };

  // 1-Click Preset: Standard Secretary View
  const handleApplySecretaryPreset = () => {
    setMenuMatrix(prev => ({
      ...prev,
      secretary: { ...DEFAULT_MENU_VISIBILITY.secretary }
    }));
    setSettingsMatrix(prev => ({
      ...prev,
      secretary: { ...DEFAULT_SETTINGS_TAB_VISIBILITY.secretary }
    }));
    setSaveSuccessMsg('✅ সচিব ভিউয়ের আদর্শ ডিফল্ট মেনু ও সেটিংস প্রিসেট প্রযোজ্য করা হইয়াছে!');
    setTimeout(() => setSaveSuccessMsg(null), 4000);
  };

  // 1-Click Preset: Reset All to Factory Defaults
  const handleResetToFactoryDefaults = () => {
    if (window.confirm('আপনি কি নিশ্চিত যে সকল রোল মেনু ও সেটিংস দৃশ্যমানতা ফ্যাক্টরি ডিফল্টে ফিরিয়ে নিতে চান?')) {
      setMenuMatrix(JSON.parse(JSON.stringify(DEFAULT_MENU_VISIBILITY)));
      setSettingsMatrix(JSON.parse(JSON.stringify(DEFAULT_SETTINGS_TAB_VISIBILITY)));
      setSaveSuccessMsg('🔄 সকল মেনু ও সেটিংস ম্যাট্রিক্স ফ্যাক্টরি ডিফল্টে রিসেট করা হইয়াছে!');
      setTimeout(() => setSaveSuccessMsg(null), 4000);
    }
  };

  // Save changes to Firebase and Parent Configuration
  const handleSaveMatrix = async () => {
    setIsSaving(true);
    setSaveSuccessMsg(null);

    try {
      const updatedConfig: UnionParishadConfig = {
        ...config,
        menuVisibilityMatrix: menuMatrix,
        settingsTabVisibilityMatrix: settingsMatrix
      };

      // 1. Save to Backend / API
      await fetch('/api/admin/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ config: updatedConfig })
      });

      // 2. Save to Firestore
      await saveConfigToFirebase(updatedConfig);

      // 3. Update Parent State
      onUpdateConfig(updatedConfig);
      if (onConfigFormChange) {
        onConfigFormChange(updatedConfig);
      }

      setSaveSuccessMsg('🎉 অভিনন্দন! রোলভিত্তিক মেনু ও সেটিংস দৃশ্যমানতা কনফিগারেশন সফলভাবে ক্লাউডে সংরক্ষিত ও সমগ্র অ্যাপে সক্রিয় হইয়াছে!');
      setTimeout(() => setSaveSuccessMsg(null), 5000);
    } catch (err: any) {
      alert('সংরক্ষণ করতে সমস্যা হয়েছে: ' + (err?.message || err));
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 rounded-2xl text-white shadow-xl border border-indigo-800/40 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-full bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-400/20 border border-amber-400/40 text-amber-300 rounded-full text-xs font-black tracking-wide uppercase">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Developer Master Control — Role Visibility Engine</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-white flex items-center gap-2">
              <Sliders className="w-6 h-6 text-amber-400" />
              <span>রোলভিত্তিক মেনু ও সেটিংস দৃশ্যমানতা কন্ট্রোল প্যানেল</span>
            </h2>
            <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
              নাগরিক/পাবলিক, ইউডিজি অপারেটর, সচিব ও চেয়ারম্যান লগইন করলে কোন কোন অপশন ও সেটিংস মেনু দৃশ্যমান থাকবে এবং বাকি অপশনগুলো স্বয়ংক্রিয়ভাবে হাইড থাকবে—তা ডেভেলপার এখান থেকে সরাসরি নিয়ন্ত্রণ করতে পারবেন।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={handleSaveMatrix}
              disabled={isSaving}
              className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs rounded-xl shadow-lg hover:shadow-emerald-900/40 transition flex items-center gap-2 cursor-pointer"
            >
              {isSaving ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Save className="w-4 h-4 text-amber-300" />
              )}
              <span>{isSaving ? 'সংরক্ষণ হচ্ছে...' : 'সেটিংস সংরক্ষণ ও কার্যকর করুন'}</span>
            </button>
          </div>
        </div>

        {/* Success Alert */}
        {saveSuccessMsg && (
          <div className="mt-4 p-3 bg-emerald-900/90 border border-emerald-400 text-emerald-100 rounded-xl text-xs font-bold flex items-center gap-2 animate-bounce">
            <CheckCircle2 className="w-4 h-4 text-amber-300 shrink-0" />
            <span>{saveSuccessMsg}</span>
          </div>
        )}
      </div>

      {/* Sub Tabs Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-100 p-2 rounded-2xl border border-slate-200">
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveSubTab('menus')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'menus'
                ? 'bg-indigo-900 text-amber-300 shadow-md ring-2 ring-indigo-500/40'
                : 'text-slate-700 hover:bg-slate-200'
            }`}
          >
            <LayoutGrid className="w-4 h-4" />
            <span>১. সাইডবার মেনু দৃশ্যমানতা (Sidebar Nav Menus)</span>
          </button>

          <button
            onClick={() => setActiveSubTab('settings_tabs')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'settings_tabs'
                ? 'bg-indigo-900 text-amber-300 shadow-md ring-2 ring-indigo-500/40'
                : 'text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>২. এডমিন সেটিংস ট্যাব এক্সেস (Settings Tabs Matrix)</span>
          </button>

          <button
            onClick={() => setActiveSubTab('simulator')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'simulator'
                ? 'bg-indigo-900 text-amber-300 shadow-md ring-2 ring-indigo-500/40'
                : 'text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Monitor className="w-4 h-4" />
            <span>৩. লাইভ রোল সিমুলেটর ও প্রিভিউ টেস্টার (Live Simulator)</span>
          </button>
        </div>

        {/* Quick Presets Dropdown/Buttons */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] font-bold text-slate-500 mr-1">দ্রুত প্রিসেট:</span>
          <button
            onClick={handleApplyStrictCitizenPreset}
            className="px-2.5 py-1 bg-blue-100 hover:bg-blue-200 text-blue-900 rounded-lg text-[11px] font-bold transition border border-blue-300 cursor-pointer"
            title="সাধারণ নাগরিক ভিউ নিরাপদ রাখুন"
          >
            পাবলিক লক
          </button>
          <button
            onClick={handleApplyChairmanPreset}
            className="px-2.5 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 rounded-lg text-[11px] font-bold transition border border-emerald-300 cursor-pointer"
            title="চেয়ারম্যান ডিফল্ট"
          >
            চেয়ারম্যান ভিউ
          </button>
          <button
            onClick={handleApplySecretaryPreset}
            className="px-2.5 py-1 bg-indigo-100 hover:bg-indigo-200 text-indigo-900 rounded-lg text-[11px] font-bold transition border border-indigo-300 cursor-pointer"
            title="সচিব ডিফল্ট"
          >
            সচিব ভিউ
          </button>
          <button
            onClick={handleResetToFactoryDefaults}
            className="px-2.5 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-[11px] font-bold transition border border-slate-300 flex items-center gap-1 cursor-pointer"
            title="ফ্যাক্টরি ডিফল্টে রিসেট"
          >
            <RotateCcw className="w-3 h-3" />
            <span>রিসেট</span>
          </button>
        </div>
      </div>

      {/* ============================================================ */}
      {/* SUBTAB 1: SIDEBAR NAV MENUS VISIBILITY MATRIX                */}
      {/* ============================================================ */}
      {activeSubTab === 'menus' && (
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl text-xs text-amber-900 flex items-start gap-2.5">
            <HelpCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">মেনু দৃশ্যমানতা নির্দেশনা:</span> নিচের টেবিলে প্রতিটি সাইডবার মেনুর বিপরীতে কোন কোন রোলের জন্য টিকচিহ্ন (সবুজ) থাকবে তা নির্ধারণ করুন। যে রোলের টিকচিহ্ন উঠিয়ে দিবেন (লাল ক্রস), সেই রোল দিয়ে লগইন বা ভিজিট করলে সংশ্লিষ্ট সাইডবার অপশনটি সম্পূর্ণ হাইড হয়ে যাবে।
            </div>
          </div>

          {/* Role Filter Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <button
              onClick={() => setSelectedRoleFilter('ALL')}
              className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                selectedRoleFilter === 'ALL'
                  ? 'bg-slate-900 text-white'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              সকল রোল (মাস্টার ম্যাট্রিক্স)
            </button>
            {rolesList.map(r => (
              <button
                key={r.key}
                onClick={() => setSelectedRoleFilter(r.key)}
                className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  selectedRoleFilter === r.key
                    ? 'bg-indigo-900 text-amber-300 shadow-sm'
                    : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                <r.icon className="w-3.5 h-3.5" />
                <span>{r.labelBn.split('(')[0]}</span>
              </button>
            ))}
          </div>

          {/* Matrix Table */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-900 text-slate-200 uppercase tracking-wider text-[11px] font-black border-b border-slate-800">
                    <th className="p-3.5 pl-4 w-72">সাইডবার মেনুর নাম ও বিবরণ</th>
                    <th className="p-3.5 text-center w-28">ক্যাটাগরি</th>
                    {rolesList.map(role => {
                      if (selectedRoleFilter !== 'ALL' && selectedRoleFilter !== role.key) return null;
                      return (
                        <th key={role.key} className="p-3.5 text-center min-w-[120px]">
                          <div className="flex flex-col items-center gap-0.5">
                            <span className="text-amber-300 font-bold">{role.labelBn.split('(')[0]}</span>
                            <span className="text-[10px] text-slate-400 normal-case font-normal">{role.key}</span>
                          </div>
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {ALL_NAV_MENUS.map((menu, idx) => {
                    return (
                      <tr key={menu.id} className={idx % 2 === 0 ? 'bg-white hover:bg-slate-50' : 'bg-slate-50/50 hover:bg-slate-100/60'}>
                        {/* Menu Info */}
                        <td className="p-3.5 pl-4">
                          <div className="font-bold text-slate-900 text-xs">{menu.labelBn}</div>
                          <div className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">{menu.description}</div>
                          <div className="text-[10px] text-indigo-600 font-mono mt-0.5">ID: {menu.id}</div>
                        </td>

                        {/* Category Badge */}
                        <td className="p-3.5 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                            menu.category === 'public' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' :
                            menu.category === 'operator' ? 'bg-blue-50 text-blue-800 border-blue-200' :
                            menu.category === 'admin' ? 'bg-purple-50 text-purple-800 border-purple-200' :
                            'bg-amber-50 text-amber-800 border-amber-200'
                          }`}>
                            {menu.category === 'public' ? 'পাবলিক' :
                             menu.category === 'operator' ? 'অপারেটর' :
                             menu.category === 'admin' ? 'এডমিন' : 'ডেভেলপার'}
                          </span>
                        </td>

                        {/* Role Columns */}
                        {rolesList.map(role => {
                          if (selectedRoleFilter !== 'ALL' && selectedRoleFilter !== role.key) return null;
                          const isDevRole = role.key === 'developer' || role.key === 'super_admin';
                          const isVisible = isDevRole ? true : (menuMatrix[role.key]?.[menu.id] ?? false);

                          return (
                            <td key={role.key} className="p-3.5 text-center">
                              <button
                                type="button"
                                onClick={() => handleToggleMenu(role.key, menu.id)}
                                disabled={isDevRole}
                                className={`w-9 h-9 rounded-xl inline-flex items-center justify-center transition shadow-xs cursor-pointer ${
                                  isDevRole
                                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                                    : isVisible
                                    ? 'bg-emerald-600 text-white hover:bg-emerald-700 ring-2 ring-emerald-400/40'
                                    : 'bg-rose-100 text-rose-600 hover:bg-rose-200 ring-1 ring-rose-300'
                                }`}
                                title={`${role.labelBn}-এর জন্য ${isVisible ? 'দৃশ্যমান (Visible)' : 'লুকানো (Hidden)'}`}
                              >
                                {isVisible ? (
                                  <Eye className="w-4 h-4" />
                                ) : (
                                  <EyeOff className="w-4 h-4" />
                                )}
                              </button>
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* SUBTAB 2: SETTINGS TABS VISIBILITY MATRIX                    */}
      {/* ============================================================ */}
      {activeSubTab === 'settings_tabs' && (
        <div className="space-y-4">
          <div className="bg-indigo-50 border border-indigo-200 p-4 rounded-xl text-xs text-indigo-900 flex items-start gap-2.5">
            <Settings className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">এডমিন সেটিংস অপশন দৃশ্যমানতা পলিসি:</span> এডমিন সেটিংসের ১৪টি গুরুত্বপূর্ণ ট্যাবের মধ্যে কোন কোন ট্যাব সচিব বা চেয়ারম্যান দেখতে পারবেন এবং কোনগুলো সম্পূর্ণভাবে হাইড থাকবে তা এখান থেকে নির্ধারণ করুন। (সাধারণ নাগরিকের জন্য সেটিংস সর্বদা বন্ধ থাকে)।
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-indigo-950 text-indigo-100 uppercase tracking-wider text-[11px] font-black border-b border-indigo-900">
                    <th className="p-3.5 pl-4 w-80">সেটিংস ট্যাবের নাম ও পরিধি</th>
                    <th className="p-3.5 text-center w-28">বিভাগ</th>
                    {rolesList.filter(r => r.key !== 'citizen').map(role => (
                      <th key={role.key} className="p-3.5 text-center min-w-[120px]">
                        <div className="flex flex-col items-center gap-0.5">
                          <span className="text-amber-300 font-bold">{role.labelBn.split('(')[0]}</span>
                          <span className="text-[10px] text-indigo-300 normal-case font-normal">{role.key}</span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {ALL_SETTINGS_TABS.map((tab, idx) => {
                    return (
                      <tr key={tab.id} className={idx % 2 === 0 ? 'bg-white hover:bg-indigo-50/40' : 'bg-slate-50/50 hover:bg-indigo-50/40'}>
                        {/* Tab Info */}
                        <td className="p-3.5 pl-4">
                          <div className="font-bold text-slate-900 text-xs">{tab.labelBn}</div>
                          <div className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">{tab.description}</div>
                          <div className="text-[10px] text-indigo-600 font-mono mt-0.5">Tab ID: {tab.id}</div>
                        </td>

                        {/* Category Badge */}
                        <td className="p-3.5 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                            tab.category === 'office' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' :
                            tab.category === 'sign_print' ? 'bg-teal-50 text-teal-800 border-teal-200' :
                            tab.category === 'integration' ? 'bg-blue-50 text-blue-800 border-blue-200' :
                            tab.category === 'security' ? 'bg-purple-50 text-purple-800 border-purple-200' :
                            'bg-amber-50 text-amber-800 border-amber-200'
                          }`}>
                            {tab.category === 'office' ? 'দাপ্তরিক' :
                             tab.category === 'sign_print' ? 'স্বাক্ষর/প্রিন্ট' :
                             tab.category === 'integration' ? 'ক্লাউড ইন্টিগ্রেশন' :
                             tab.category === 'security' ? 'নিরাপত্তা' : 'ডেভেলপার'}
                          </span>
                        </td>

                        {/* Role Columns (Except Citizen) */}
                        {rolesList.filter(r => r.key !== 'citizen').map(role => {
                          const isDevRole = role.key === 'developer' || role.key === 'super_admin';
                          const isVisible = isDevRole ? true : (settingsMatrix[role.key]?.[tab.id] ?? false);

                          return (
                            <td key={role.key} className="p-3.5 text-center">
                              <button
                                type="button"
                                onClick={() => handleToggleSettingsTab(role.key, tab.id)}
                                disabled={isDevRole}
                                className={`w-9 h-9 rounded-xl inline-flex items-center justify-center transition shadow-xs cursor-pointer ${
                                  isDevRole
                                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                                    : isVisible
                                    ? 'bg-indigo-700 text-white hover:bg-indigo-800 ring-2 ring-indigo-400/40'
                                    : 'bg-rose-100 text-rose-600 hover:bg-rose-200 ring-1 ring-rose-300'
                                }`}
                                title={`${role.labelBn}-এর জন্য ${isVisible ? 'দৃশ্যমান (Visible)' : 'লুকানো (Hidden)'}`}
                              >
                                {isVisible ? (
                                  <Check className="w-4 h-4" />
                                ) : (
                                  <X className="w-4 h-4" />
                                )}
                              </button>
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* SUBTAB 3: LIVE ROLE SIMULATOR & TESTER                       */}
      {/* ============================================================ */}
      {activeSubTab === 'simulator' && (
        <div className="space-y-6">
          <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-lg border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Monitor className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-black text-white">লাইভ রোল সুইচ ও ইন্টারফেস সিমুলেটর</h3>
              </div>
              <span className="text-xs px-3 py-1 bg-emerald-950 text-emerald-300 border border-emerald-600 rounded-full font-bold">
                বর্তমান সেশন রোল: {session.role} ({session.name})
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              সিস্টেম ডেভেলপার হিসেবে আপনি যেকোনো একটি রোলে ক্লিক করে তাৎক্ষণিকভাবে সেই রোলের পারমিশন সক্রিয় করে দেখতে পারেন যে নাগরিক, সচিব বা চেয়ারম্যানের স্ক্রিনে সাইডবার এবং সেটিংস অপশনগুলো সঠিকভাবে ফিল্টার হচ্ছে কিনা।
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
              {rolesList.map(r => {
                const isCurrent = session.role === r.key;
                return (
                  <div
                    key={r.key}
                    className={`p-4 rounded-xl border transition flex flex-col justify-between ${
                      isCurrent
                        ? 'bg-gradient-to-br from-indigo-900 to-slate-900 border-amber-400 ring-2 ring-amber-400/40 shadow-lg'
                        : 'bg-slate-800/80 border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-white flex items-center gap-1.5">
                          <r.icon className="w-4 h-4 text-amber-300" />
                          <span>{r.labelBn.split('(')[0]}</span>
                        </span>
                        {isCurrent && (
                          <span className="px-2 py-0.5 bg-amber-400 text-slate-950 text-[10px] font-black rounded-full">
                            সক্রিয়
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400">{r.desc}</p>
                    </div>

                    <button
                      onClick={() => {
                        switchRole(r.key as UserRole);
                        setSaveSuccessMsg(`🎯 রোল সফলভাবে '${r.labelBn.split('(')[0]}'-এ পরিবর্তিত হইয়াছে! সাইডবার মেনু লক্ষ্য করুন।`);
                        setTimeout(() => setSaveSuccessMsg(null), 4000);
                      }}
                      className={`mt-3 w-full py-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                        isCurrent
                          ? 'bg-amber-400 text-slate-950 font-black'
                          : 'bg-slate-700 hover:bg-slate-600 text-slate-200'
                      }`}
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>{isCurrent ? 'বর্তমানে এই রোলে আছেন' : 'এই রোলে সুইচ করুন'}</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
