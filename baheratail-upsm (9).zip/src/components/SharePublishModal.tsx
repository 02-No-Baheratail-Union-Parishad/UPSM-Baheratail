import React, { useState } from 'react';
import { 
  Share2, 
  Copy, 
  Check, 
  ExternalLink, 
  QrCode, 
  Mail, 
  MessageCircle, 
  Send, 
  Smartphone, 
  Globe, 
  ShieldCheck, 
  Sparkles,
  X
} from 'lucide-react';
import { UnionParishadConfig } from '../types';

interface SharePublishModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: UnionParishadConfig;
}

export const SharePublishModal: React.FC<SharePublishModalProps> = ({ isOpen, onClose, config }) => {
  const [copiedShared, setCopiedShared] = useState(false);
  const [copiedDev, setCopiedDev] = useState(false);

  if (!isOpen) return null;

  const sharedUrl = window.location.origin; // or shared app url
  const devUrl = window.location.href;
  const officialEmail = 'Baheratailunion@gmail.com';

  const handleCopyShared = () => {
    navigator.clipboard.writeText(sharedUrl);
    setCopiedShared(true);
    setTimeout(() => setCopiedShared(false), 2500);
  };

  const handleCopyDev = () => {
    navigator.clipboard.writeText(devUrl);
    setCopiedDev(true);
    setTimeout(() => setCopiedDev(false), 2500);
  };

  const shareText = `০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল সার্ভিস ও সার্টিফিকেট অটোমেশন সিস্টেম (UPSM 2.0)। লাইভ লিংক: ${sharedUrl}`;

  const handleWhatsAppShare = () => {
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`, '_blank');
  };

  const handleEmailShare = () => {
    window.open(`mailto:${officialEmail}?subject=${encodeURIComponent('UPSM 2.0 - ইউনিয়ন পরিষদ ডিজিটাল সার্ভিস লিংক')}&body=${encodeURIComponent(shareText)}`, '_blank');
  };

  const handleTelegramShare = () => {
    window.open(`https://t.me/share/url?url=${encodeURIComponent(sharedUrl)}&text=${encodeURIComponent(shareText)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl relative space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
              <Share2 className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <span>লাইভ প্রিভিউ ও শেয়ারিং হাব</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                  {officialEmail}
                </span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                মোবাইল বা পিসি থেকে অন্যদের সাথে এক ক্লিকে অ্যাপটি শেয়ার করুন।
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* URLs Section */}
        <div className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5"><Globe className="w-3.5 h-3.5 text-emerald-600" /> শেয়ারড অ্যাপ লিংক (Shared App URL)</span>
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">পাবলিক ব্যবহারের জন্য</span>
            </label>
            <div className="flex items-center gap-2">
              <input 
                type="text" 
                readOnly 
                value={sharedUrl} 
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 font-mono select-all"
              />
              <button 
                onClick={handleCopyShared}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 shadow-sm"
              >
                {copiedShared ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedShared ? 'কপি হয়েছে!' : 'কপি'}</span>
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5"><Smartphone className="w-3.5 h-3.5 text-blue-600" /> ডেভেলপার প্রিভিউ লিংক (Development URL)</span>
              <span className="text-[10px] text-blue-600 dark:text-blue-400 font-semibold">মোবাইল লগইন: Baheratailunion@gmail.com</span>
            </label>
            <div className="flex items-center gap-2">
              <input 
                type="text" 
                readOnly 
                value={devUrl} 
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 font-mono select-all"
              />
              <button 
                onClick={handleCopyDev}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 text-white text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 shadow-sm"
              >
                {copiedDev ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedDev ? 'কপি হয়েছে!' : 'কপি'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Quick Social & Direct Share Buttons */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300">সরাসরি শেয়ার করুন</label>
          <div className="grid grid-cols-3 gap-3">
            <button
              onClick={handleWhatsAppShare}
              className="flex items-center justify-center gap-2 p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-colors text-xs font-bold"
            >
              <MessageCircle className="w-4 h-4 text-emerald-600" />
              <span>WhatsApp</span>
            </button>

            <button
              onClick={handleEmailShare}
              className="flex items-center justify-center gap-2 p-3 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors text-xs font-bold"
            >
              <Mail className="w-4 h-4 text-blue-600" />
              <span>Email</span>
            </button>

            <button
              onClick={handleTelegramShare}
              className="flex items-center justify-center gap-2 p-3 rounded-2xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 text-sky-700 dark:text-sky-300 hover:bg-sky-100 dark:hover:bg-sky-900/50 transition-colors text-xs font-bold"
            >
              <Send className="w-4 h-4 text-sky-600" />
              <span>Telegram</span>
            </button>
          </div>
        </div>

        {/* Info Box */}
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 flex items-start gap-3">
          <Sparkles className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1 text-xs text-amber-900 dark:text-amber-200">
            <p className="font-bold">মোবাইল বা অন্য ডিভাইসে ব্যবহারের নির্দেশনা:</p>
            <p className="leading-relaxed">
              আপনার মোবাইল ডিভাইসেও <strong className="underline">{officialEmail}</strong> একাউন্ট দিয়ে Google AI Studio (ai.studio/build) এ লগইন করে এই অ্যাপটির লাইভ প্রিভিউ, শেয়ার এবং পাবলিশ অপশন এক ক্লিকেই পরিচালনা করতে পারবেন।
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end pt-2 border-t border-slate-100 dark:border-slate-800">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-md"
          >
            বন্ধ করুন
          </button>
        </div>

      </div>
    </div>
  );
};
