import React, { useState, useMemo } from 'react';
import { 
  Sliders, 
  ShieldCheck, 
  UserCheck, 
  Building2, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Save, 
  RotateCcw, 
  Zap, 
  Shield, 
  Sparkles, 
  Layers, 
  Scale, 
  FileText, 
  DollarSign, 
  Cloud, 
  Radio, 
  HelpCircle, 
  ArrowRight, 
  Check, 
  Info,
  ToggleLeft,
  ToggleRight,
  Workflow,
  Lock,
  Unlock,
  QrCode
} from 'lucide-react';
import { UnionParishadConfig, SystemRuleItem } from '../types';
import { getEffectiveSystemRules, DEFAULT_SYSTEM_RULES } from '../data/systemRules';
import { saveConfigToFirebase } from '../firebase';

interface SystemPolicyControllerProps {
  config: UnionParishadConfig;
  onUpdateConfig: (updated: UnionParishadConfig) => void;
  onConfigFormChange?: (updated: UnionParishadConfig) => void;
  currentUserRole?: string;
}

export const SystemPolicyController: React.FC<SystemPolicyControllerProps> = ({
  config,
  onUpdateConfig,
  onConfigFormChange,
  currentUserRole = 'developer'
}) => {
  // Local state for all policy switches
  const [memberApprovalMandatory, setMemberApprovalMandatory] = useState<boolean>(() => {
    if (config.memberApprovalMandatory !== undefined) return config.memberApprovalMandatory;
    const rule = (config.systemRules || []).find(r => r.id === 'rule_member_approval');
    return rule ? rule.requirementLevel === 'mandatory' : false;
  });

  const [secretaryVerificationMandatory, setSecretaryVerificationMandatory] = useState<boolean>(() => {
    if (config.secretaryVerificationMandatory !== undefined) return config.secretaryVerificationMandatory;
    return true;
  });

  const [allowDirectChairmanIssue, setAllowDirectChairmanIssue] = useState<boolean>(() => {
    return config.allowDirectChairmanIssue ?? true;
  });

  const [strictNidBrnValidation, setStrictNidBrnValidation] = useState<boolean>(() => {
    return config.strictNidBrnValidation ?? true;
  });

  const [holdingTaxClearanceMandatory, setHoldingTaxClearanceMandatory] = useState<boolean>(() => {
    return config.holdingTaxClearanceMandatory ?? false;
  });

  const [allowDraftWithoutPayment, setAllowDraftWithoutPayment] = useState<boolean>(() => {
    return config.allowDraftWithoutPayment ?? true;
  });

  const [warishWitnessMandatory, setWarishWitnessMandatory] = useState<boolean>(() => {
    return config.warishWitnessMandatory ?? true;
  });

  const [autoInjectRulesInAiPrompt, setAutoInjectRulesInAiPrompt] = useState<boolean>(() => {
    return config.autoInjectRulesInAiPrompt ?? true;
  });

  const [instantCloudSyncOnAction, setInstantCloudSyncOnAction] = useState<boolean>(() => {
    return config.instantCloudSyncOnAction ?? true;
  });

  const [enableDigitalSignature, setEnableDigitalSignature] = useState<boolean>(() => {
    return config.enableDigitalSignature ?? true;
  });

  const [activePreset, setActivePreset] = useState<'express' | 'strict' | 'standard' | 'custom'>(() => {
    return config.activePolicyPreset || 'standard';
  });

  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [activeFilterCategory, setActiveFilterCategory] = useState<'all' | 'approval' | 'verification' | 'financial' | 'ai_cloud'>('all');

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Helper to compile and sync back to full config & systemRules items
  const compileUpdatedConfig = (overrides?: Partial<UnionParishadConfig>): UnionParishadConfig => {
    const memMandatory = overrides?.memberApprovalMandatory ?? memberApprovalMandatory;
    const secMandatory = overrides?.secretaryVerificationMandatory ?? secretaryVerificationMandatory;
    const taxMandatory = overrides?.holdingTaxClearanceMandatory ?? holdingTaxClearanceMandatory;
    const strictNid = overrides?.strictNidBrnValidation ?? strictNidBrnValidation;
    const warishMandatory = overrides?.warishWitnessMandatory ?? warishWitnessMandatory;

    // Update or clone the systemRules array so both modules stay 100% harmonized
    const currentRules = getEffectiveSystemRules(config);
    const updatedRules: SystemRuleItem[] = currentRules.map(rule => {
      if (rule.id === 'rule_member_approval' || rule.code === 'MEMBER_APPROVAL_OPTIONAL_RULE') {
        return {
          ...rule,
          requirementLevel: memMandatory ? 'mandatory' : 'optional',
          enabled: true,
          updatedAt: new Date().toISOString()
        };
      }
      if (rule.id === 'rule_secretary_verification') {
        return {
          ...rule,
          requirementLevel: secMandatory ? 'mandatory' : 'optional',
          enabled: secMandatory,
          updatedAt: new Date().toISOString()
        };
      }
      if (rule.id === 'rule_holding_tax_clearance') {
        return {
          ...rule,
          requirementLevel: taxMandatory ? 'mandatory' : 'advisory',
          enabled: true,
          updatedAt: new Date().toISOString()
        };
      }
      if (rule.id === 'rule_strict_nid_brn_digits') {
        return {
          ...rule,
          requirementLevel: strictNid ? 'mandatory' : 'optional',
          enabled: true,
          updatedAt: new Date().toISOString()
        };
      }
      if (rule.id === 'rule_warish_local_attestation') {
        return {
          ...rule,
          requirementLevel: warishMandatory ? 'mandatory' : 'optional',
          enabled: true,
          updatedAt: new Date().toISOString()
        };
      }
      return rule;
    });

    const newConfig: UnionParishadConfig = {
      ...config,
      ...overrides,
      memberApprovalMandatory: memMandatory,
      secretaryVerificationMandatory: secMandatory,
      allowDirectChairmanIssue: overrides?.allowDirectChairmanIssue ?? allowDirectChairmanIssue,
      strictNidBrnValidation: strictNid,
      holdingTaxClearanceMandatory: taxMandatory,
      allowDraftWithoutPayment: overrides?.allowDraftWithoutPayment ?? allowDraftWithoutPayment,
      warishWitnessMandatory: warishMandatory,
      autoInjectRulesInAiPrompt: overrides?.autoInjectRulesInAiPrompt ?? autoInjectRulesInAiPrompt,
      instantCloudSyncOnAction: overrides?.instantCloudSyncOnAction ?? instantCloudSyncOnAction,
      enableDigitalSignature: overrides?.enableDigitalSignature ?? enableDigitalSignature,
      activePolicyPreset: overrides?.activePolicyPreset ?? activePreset,
      systemRules: updatedRules
    };

    return newConfig;
  };

  // Immediate save on user interaction
  const handleTogglePolicy = (key: string, value: boolean) => {
    setActivePreset('custom');
    let overrides: Partial<UnionParishadConfig> = { activePolicyPreset: 'custom' };

    if (key === 'memberApprovalMandatory') {
      setMemberApprovalMandatory(value);
      overrides.memberApprovalMandatory = value;
    } else if (key === 'secretaryVerificationMandatory') {
      setSecretaryVerificationMandatory(value);
      overrides.secretaryVerificationMandatory = value;
    } else if (key === 'allowDirectChairmanIssue') {
      setAllowDirectChairmanIssue(value);
      overrides.allowDirectChairmanIssue = value;
    } else if (key === 'strictNidBrnValidation') {
      setStrictNidBrnValidation(value);
      overrides.strictNidBrnValidation = value;
    } else if (key === 'holdingTaxClearanceMandatory') {
      setHoldingTaxClearanceMandatory(value);
      overrides.holdingTaxClearanceMandatory = value;
    } else if (key === 'allowDraftWithoutPayment') {
      setAllowDraftWithoutPayment(value);
      overrides.allowDraftWithoutPayment = value;
    } else if (key === 'warishWitnessMandatory') {
      setWarishWitnessMandatory(value);
      overrides.warishWitnessMandatory = value;
    } else if (key === 'autoInjectRulesInAiPrompt') {
      setAutoInjectRulesInAiPrompt(value);
      overrides.autoInjectRulesInAiPrompt = value;
    } else if (key === 'instantCloudSyncOnAction') {
      setInstantCloudSyncOnAction(value);
      overrides.instantCloudSyncOnAction = value;
    } else if (key === 'enableDigitalSignature') {
      setEnableDigitalSignature(value);
      overrides.enableDigitalSignature = value;
    }

    const updated = compileUpdatedConfig(overrides);
    if (onConfigFormChange) onConfigFormChange(updated);
    onUpdateConfig(updated);
  };

  // Apply Preset Profile
  const handleApplyPreset = (preset: 'express' | 'strict' | 'standard') => {
    setActivePreset(preset);

    let memMandatory = false;
    let secMandatory = true;
    let dirChairman = true;
    let strictNid = true;
    let taxMandatory = false;
    let draftNoPay = true;
    let warishMand = true;

    if (preset === 'express') {
      // Fast citizen issuance: Member optional, Secretary fast-track, Tax advisory, Draft open
      memMandatory = false;
      secMandatory = false;
      dirChairman = true;
      strictNid = false;
      taxMandatory = false;
      draftNoPay = true;
      warishMand = false;
    } else if (preset === 'strict') {
      // Full high security: All approvals mandatory, strict verification, tax clearance required
      memMandatory = true;
      secMandatory = true;
      dirChairman = false;
      strictNid = true;
      taxMandatory = true;
      draftNoPay = false;
      warishMand = true;
    } else if (preset === 'standard') {
      // Standard UP protocol: Member optional (as requested), Secretary & Chairman verification mandatory
      memMandatory = false;
      secMandatory = true;
      dirChairman = true;
      strictNid = true;
      taxMandatory = false;
      draftNoPay = true;
      warishMand = true;
    }

    setMemberApprovalMandatory(memMandatory);
    setSecretaryVerificationMandatory(secMandatory);
    setAllowDirectChairmanIssue(dirChairman);
    setStrictNidBrnValidation(strictNid);
    setHoldingTaxClearanceMandatory(taxMandatory);
    setAllowDraftWithoutPayment(draftNoPay);
    setWarishWitnessMandatory(warishMand);

    const overrides: Partial<UnionParishadConfig> = {
      activePolicyPreset: preset,
      memberApprovalMandatory: memMandatory,
      secretaryVerificationMandatory: secMandatory,
      allowDirectChairmanIssue: dirChairman,
      strictNidBrnValidation: strictNid,
      holdingTaxClearanceMandatory: taxMandatory,
      allowDraftWithoutPayment: draftNoPay,
      warishWitnessMandatory: warishMand
    };

    const updated = compileUpdatedConfig(overrides);
    if (onConfigFormChange) onConfigFormChange(updated);
    onUpdateConfig(updated);

    showToast(`'${preset === 'express' ? 'এক্সপ্রেস সিটিজেন সার্ভিস' : preset === 'strict' ? 'সর্বোচ্চ প্রশাসনিক নিরাপত্তা' : 'স্ট্যান্ডার্ড প্রটোকল'}' প্রোফাইল সক্রিয় করা হইয়াছে।`, 'success');
  };

  // Master Save to Cloud
  const handleSaveToCloud = async () => {
    setIsSaving(true);
    try {
      const updated = compileUpdatedConfig();
      onUpdateConfig(updated);
      await saveConfigToFirebase(updated);
      showToast('সকল সিস্টেম পলিসি ও শর্ত সফলভাবে ক্লাউড ডাটাবেজে সংরক্ষিত ও কার্যকর হইয়াছে!', 'success');
    } catch (e) {
      console.error('Failed to save policy to cloud:', e);
      showToast('ক্লাউড সংরক্ষণে সমস্যা হইয়াছে, লোকাল ব্রাউজারে সংরক্ষিত রাখা হইল।', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6" id="system-policy-controller">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`fixed bottom-6 right-6 z-50 px-5 py-3.5 rounded-2xl shadow-2xl flex items-center gap-3 text-sm font-semibold transition-all animate-bounce ${
          toastMessage.type === 'success' ? 'bg-emerald-900 text-amber-200 border-2 border-amber-400' : 'bg-rose-900 text-rose-100 border-2 border-rose-500'
        }`}>
          {toastMessage.type === 'success' ? <CheckCircle2 className="w-5 h-5 text-amber-300" /> : <AlertTriangle className="w-5 h-5 text-rose-300" />}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Top Banner & Header */}
      <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-emerald-800/60 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-bold tracking-wider">
              <Sliders className="w-3.5 h-3.5 text-amber-300 animate-spin" />
              <span>LIVE WORKFLOW CONTROLLER</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white flex items-center gap-3">
              <span>সিস্টেম পলিসি ও ওয়ার্কফ্লো কন্ট্রোলার</span>
              <span className="text-xs bg-amber-400/20 text-amber-300 border border-amber-400/40 px-2.5 py-0.5 rounded-full font-bold">
                Master Rules Engine
              </span>
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
              ইউনিয়ন পরিষদের প্রশাসনিক সিদ্ধান্ত অনুযায়ী মেম্বার অনুমোদন, সচিবের ডাটাবেজ যাচাই, হোল্ডিং কর ক্লিয়ারেন্স ও সনদ ইস্যুর ওয়ার্কফ্লো শর্তসমূহ টগল সুইচের মাধ্যমে সরাসরি নিয়ন্ত্রণ করুন।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={handleSaveToCloud}
              disabled={isSaving}
              className="px-5 py-3 bg-gradient-to-r from-amber-400 to-amber-500 text-emerald-950 hover:from-amber-300 hover:to-amber-400 font-extrabold rounded-2xl shadow-lg transition-all flex items-center gap-2 text-xs sm:text-sm cursor-pointer active:scale-95 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'সংরক্ষণ হচ্ছে...' : 'পলিসি পরিবর্তন সংরক্ষণ করুন'}</span>
            </button>
          </div>
        </div>

        {/* Quick Presets Bar */}
        <div className="mt-6 pt-5 border-t border-emerald-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>এক-ক্লিকে পলিসি প্রিসেট লোড:</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => handleApplyPreset('standard')}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activePreset === 'standard'
                  ? 'bg-emerald-600 text-white shadow-md ring-2 ring-amber-400'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Scale className="w-3.5 h-3.5 text-amber-300" />
              <span>স্ট্যান্ডার্ড ইউপি মোড</span>
            </button>

            <button
              onClick={() => handleApplyPreset('express')}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activePreset === 'express'
                  ? 'bg-emerald-600 text-white shadow-md ring-2 ring-amber-400'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Zap className="w-3.5 h-3.5 text-amber-300" />
              <span>এক্সপ্রেস দ্রুত সেবা</span>
            </button>

            <button
              onClick={() => handleApplyPreset('strict')}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activePreset === 'strict'
                  ? 'bg-emerald-600 text-white shadow-md ring-2 ring-amber-400'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Shield className="w-3.5 h-3.5 text-amber-300" />
              <span>কঠোর নিরাপত্তা মোড</span>
            </button>
          </div>
        </div>
      </div>

      {/* Dynamic Workflow Visualization Map */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Workflow className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              বর্তমান ওয়ার্কফ্লো পাইপলাইন মানচিত্র (Live Workflow Pipeline)
            </h3>
          </div>
          <span className="text-xs px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-full font-semibold">
            {activePreset === 'express' ? '⚡ এক্সপ্রেস মোড সক্রিয়' : activePreset === 'strict' ? '🛡️ কঠোর মোড সক্রিয়' : activePreset === 'standard' ? '⚖️ স্ট্যান্ডার্ড মোড সক্রিয়' : '⚙️ কাস্টম পলিসি'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 relative">
          {/* Step 1 */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1.5 relative">
            <div className="flex items-center justify-between">
              <span className="w-6 h-6 rounded-full bg-emerald-700 text-white text-xs font-bold flex items-center justify-center">১</span>
              <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300 rounded-full">সর্বদা সক্রিয়</span>
            </div>
            <div className="font-bold text-xs text-slate-900 dark:text-white">নাগরিক ড্রাফট এন্ট্রি</div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">ইউডিসি উদ্যোক্তা কর্তৃক এনআইডি স্ক্যান ও এআই খসড়া প্রস্তুত</div>
          </div>

          {/* Step 2: Member */}
          <div className={`p-4 rounded-2xl border space-y-1.5 transition-all ${
            memberApprovalMandatory 
              ? 'bg-rose-50/70 dark:bg-rose-950/30 border-rose-300 dark:border-rose-800' 
              : 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/60 opacity-90'
          }`}>
            <div className="flex items-center justify-between">
              <span className="w-6 h-6 rounded-full bg-slate-700 text-white text-xs font-bold flex items-center justify-center">২</span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                memberApprovalMandatory 
                  ? 'bg-rose-600 text-white' 
                  : 'bg-emerald-600 text-white'
              }`}>
                {memberApprovalMandatory ? 'বাধ্যতামূলক (Mandatory)' : 'ঐচ্ছিক / শিথিল (Optional)'}
              </span>
            </div>
            <div className="font-bold text-xs text-slate-900 dark:text-white">ওয়ার্ড মেম্বার সুপারিশ</div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
              {memberApprovalMandatory 
                ? 'মেম্বার অনুমোদন ছাড়া সচিব বা চেয়ারম্যান ডেক্সে পৌঁছাবে না।' 
                : 'মেম্বার অনুমোদন ছাড়াই সরাসরি সচিব-চেয়ারম্যান অনুমোদন কার্যকর হইবে।'}
            </div>
          </div>

          {/* Step 3: Secretary */}
          <div className={`p-4 rounded-2xl border space-y-1.5 transition-all ${
            secretaryVerificationMandatory 
              ? 'bg-slate-50 dark:bg-slate-800/60 border-slate-300 dark:border-slate-700' 
              : 'bg-amber-50/50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800/60'
          }`}>
            <div className="flex items-center justify-between">
              <span className="w-6 h-6 rounded-full bg-slate-700 text-white text-xs font-bold flex items-center justify-center">৩</span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                secretaryVerificationMandatory ? 'bg-slate-800 text-white' : 'bg-amber-600 text-white'
              }`}>
                {secretaryVerificationMandatory ? 'বাধ্যতামূলক' : 'ফাস্ট-ট্র্যাক'}
              </span>
            </div>
            <div className="font-bold text-xs text-slate-900 dark:text-white">ইউপি সচিব প্রশাসনিক যাচাই</div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
              {secretaryVerificationMandatory ? 'প্রশাসনিক ডাটাবেজের তথ্যের সাথে মিল রেখে সুপারিশ।' : 'জরুরি সেবায় সচিব যাচাই বাইপাস করে সরাসরি অনুমোদন।'}
            </div>
          </div>

          {/* Step 4: Chairman */}
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-700 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="w-6 h-6 rounded-full bg-emerald-800 text-amber-300 text-xs font-bold flex items-center justify-center">৪</span>
              <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-700 text-amber-200 rounded-full">
                {allowDirectChairmanIssue ? '১-ক্লিক চূড়ান্ত সাইন' : 'স্ট্যান্ডার্ড সাইন'}
              </span>
            </div>
            <div className="font-bold text-xs text-slate-900 dark:text-white">চেয়ারম্যান অনুমোদন ও ই-স্বাক্ষর</div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">ডিজিটাল অনুমোদন ও অফিসিয়াল সিল যুক্তকরণ।</div>
          </div>

          {/* Step 5: Delivery */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="w-6 h-6 rounded-full bg-slate-700 text-white text-xs font-bold flex items-center justify-center">৫</span>
              <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300 rounded-full">কিউআর সিলযুক্ত</span>
            </div>
            <div className="font-bold text-xs text-slate-900 dark:text-white">সনদ মুদ্রণ ও হস্তান্তর</div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">প্যাড প্রিন্ট, পিডিএফ ডাউনলোড বা হোয়াটসঅ্যাপে শেয়ার</div>
          </div>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        <button
          onClick={() => setActiveFilterCategory('all')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeFilterCategory === 'all'
              ? 'bg-emerald-900 text-amber-300 shadow-sm ring-2 ring-amber-400/40'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>সকল পলিসি শর্ত (১০টি মাস্টার টগল)</span>
        </button>

        <button
          onClick={() => setActiveFilterCategory('approval')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeFilterCategory === 'approval'
              ? 'bg-emerald-900 text-amber-300 shadow-sm ring-2 ring-amber-400/40'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>অনুমোদন ও স্বাক্ষর পলিসি (৪)</span>
        </button>

        <button
          onClick={() => setActiveFilterCategory('verification')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeFilterCategory === 'verification'
              ? 'bg-emerald-900 text-amber-300 shadow-sm ring-2 ring-amber-400/40'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <UserCheck className="w-3.5 h-3.5" />
          <span>নাগরিক তথ্য ও সত্যতা যাচাই (২)</span>
        </button>

        <button
          onClick={() => setActiveFilterCategory('financial')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeFilterCategory === 'financial'
              ? 'bg-emerald-900 text-amber-300 shadow-sm ring-2 ring-amber-400/40'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          <span>ট্যাক্স ও সরকারি ফি শর্ত (২)</span>
        </button>

        <button
          onClick={() => setActiveFilterCategory('ai_cloud')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeFilterCategory === 'ai_cloud'
              ? 'bg-emerald-900 text-amber-300 shadow-sm ring-2 ring-amber-400/40'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>এআই ও ক্লাউড অটোমেশন (২)</span>
        </button>
      </div>

      {/* Main Interactive Policy Switch Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* POLICY 1: Member Approval Mandatory / Optional */}
        {(activeFilterCategory === 'all' || activeFilterCategory === 'approval') && (
          <div className={`p-5 rounded-3xl border transition-all flex flex-col justify-between ${
            memberApprovalMandatory
              ? 'bg-gradient-to-br from-rose-50 to-rose-100/50 dark:from-rose-950/40 dark:to-slate-900 border-rose-300 dark:border-rose-800 shadow-md ring-1 ring-rose-400/30'
              : 'bg-gradient-to-br from-emerald-50 to-teal-50/50 dark:from-emerald-950/40 dark:to-slate-900 border-emerald-300 dark:border-emerald-800 shadow-md ring-1 ring-emerald-400/30'
          }`}>
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="p-2.5 rounded-2xl bg-white dark:bg-slate-800 shadow-sm border border-slate-200 dark:border-slate-700 text-emerald-700 dark:text-emerald-400">
                  <UserCheck className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                    memberApprovalMandatory 
                      ? 'bg-rose-600 text-white border-rose-700' 
                      : 'bg-emerald-600 text-white border-emerald-700'
                  }`}>
                    {memberApprovalMandatory ? 'বাধ্যতামূলক (Mandatory)' : 'ঐচ্ছিক / শিথিল (Optional)'}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleTogglePolicy('memberApprovalMandatory', !memberApprovalMandatory)}
                    className={`relative inline-flex h-7 w-13 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      memberApprovalMandatory ? 'bg-rose-600' : 'bg-emerald-600'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        memberApprovalMandatory ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <span>ইউপি সদস্য / মেম্বার সুপারিশ ও অনুমোদন পলিসি</span>
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  নাগরিকের সনদ পেতে সংশ্লিষ্ট ওয়ার্ড মেম্বারের সুপারিশ বাধ্যতামূলক কি না। বন্ধ থাকলে মেম্বার অনুপলব্ধ থাকলেও সচিব ও চেয়ারম্যান সরাসরি সনদ প্রস্তুত ও অনুমোদন করতে পারবেন।
                </p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1 font-semibold">
                <Info className="w-3.5 h-3.5 text-emerald-600" />
                <span>ওয়ার্কফ্লো প্রভাব: {memberApprovalMandatory ? 'মেম্বার অনুমোদন ব্যতীত চূড়ান্ত স্বাক্ষর লক থাকবে।' : 'উদ্যোক্তা সরাসরি চেয়ারম্যান অনুমোদনে পাঠাতে পারেন।'}</span>
              </span>
            </div>
          </div>
        )}

        {/* POLICY 2: Secretary Verification */}
        {(activeFilterCategory === 'all' || activeFilterCategory === 'approval') && (
          <div className={`p-5 rounded-3xl border transition-all flex flex-col justify-between ${
            secretaryVerificationMandatory
              ? 'bg-gradient-to-br from-slate-50 to-slate-100/50 dark:from-slate-800/40 dark:to-slate-900 border-slate-300 dark:border-slate-700 shadow-md'
              : 'bg-gradient-to-br from-amber-50 to-amber-100/50 dark:from-amber-950/30 dark:to-slate-900 border-amber-300 dark:border-amber-800 shadow-md'
          }`}>
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="p-2.5 rounded-2xl bg-white dark:bg-slate-800 shadow-sm border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300">
                  <Building2 className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                    secretaryVerificationMandatory 
                      ? 'bg-slate-800 text-white border-slate-900' 
                      : 'bg-amber-600 text-white border-amber-700'
                  }`}>
                    {secretaryVerificationMandatory ? 'বাধ্যতামূলক (Mandatory)' : 'ফাস্ট-ট্র্যাক (Fast-Track)'}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleTogglePolicy('secretaryVerificationMandatory', !secretaryVerificationMandatory)}
                    className={`relative inline-flex h-7 w-13 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      secretaryVerificationMandatory ? 'bg-slate-800' : 'bg-amber-500'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        secretaryVerificationMandatory ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white">
                  ইউপি সচিবের প্রশাসনিক ডাটাবেজ যাচাইকরণ
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  চেয়ারম্যানের চূড়ান্ত স্বাক্ষরের পূর্বে সচিবের প্রশাসনিক ডাটাবেজ ও ভলিউম রেজিস্টারের সাথে তথ্য যাচাই বাধ্যতামূলক থাকবে কি না।
                </p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1 font-semibold">
                <Info className="w-3.5 h-3.5 text-amber-600" />
                <span>ওয়ার্কফ্লো প্রভাব: {secretaryVerificationMandatory ? 'সচিবের সুপারিশ ব্যতিরেকে চেয়ারম্যান পেন্ডিং লিস্টে যাবে না।' : 'সরাসরি চেয়ারম্যান ১-ক্লিকে অনুমোদন দিতে পারবেন।'}</span>
              </span>
            </div>
          </div>
        )}

        {/* POLICY 3: Direct Chairman 1-Click Approval */}
        {(activeFilterCategory === 'all' || activeFilterCategory === 'approval') && (
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="p-2.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                    allowDirectChairmanIssue 
                      ? 'bg-emerald-600 text-white border-emerald-700' 
                      : 'bg-slate-600 text-white border-slate-700'
                  }`}>
                    {allowDirectChairmanIssue ? 'সক্রিয় (Enabled)' : 'নিষ্ক্রিয় (Disabled)'}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleTogglePolicy('allowDirectChairmanIssue', !allowDirectChairmanIssue)}
                    className={`relative inline-flex h-7 w-13 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      allowDirectChairmanIssue ? 'bg-emerald-600' : 'bg-slate-400'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        allowDirectChairmanIssue ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white">
                  চেয়ারম্যানের সরাসরি ১-ক্লিক ডিজিটাল ইস্যু
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  জরুরি বা নিয়মিত সেবায় চেয়ারম্যান বা অথোরাইজড এডমিন পেন্ডিং লিস্ট থেকে সরাসরি ১-ক্লিকে ডিজিটাল সিল ও ই-স্বাক্ষরে সনদ ইস্যু করতে পারবেন।
                </p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="font-semibold">ওয়ার্কফ্লো প্রভাব: চেয়ারম্যান ডেক্সে সরাসরি অ্যাপ্রুভ বাটন উন্মুক্ত থাকবে।</span>
            </div>
          </div>
        )}

        {/* POLICY 4: Digital E-Signature & Dynamic QR Seal */}
        {(activeFilterCategory === 'all' || activeFilterCategory === 'approval') && (
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="p-2.5 rounded-2xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 border border-teal-200 dark:border-teal-800">
                  <QrCode className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                    enableDigitalSignature 
                      ? 'bg-teal-600 text-white border-teal-700' 
                      : 'bg-slate-600 text-white border-slate-700'
                  }`}>
                    {enableDigitalSignature ? 'স্বয়ংক্রিয় ডিজিটাল সীল' : 'শুধুমাত্র ম্যানুয়াল সই'}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleTogglePolicy('enableDigitalSignature', !enableDigitalSignature)}
                    className={`relative inline-flex h-7 w-13 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      enableDigitalSignature ? 'bg-teal-600' : 'bg-slate-400'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        enableDigitalSignature ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white">
                  ডিজিটাল ই-স্বাক্ষর ও কিউআর সিল প্রয়োগ
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  সনদ চূড়ান্ত হওয়ার পর প্রিন্ট কপির নিচের অংশে স্বয়ংক্রিয় ডিজিটাল ই-স্বাক্ষর ও ভেরিফিকেশন কিউআর সিল মুদ্রিত হইবে কি না।
                </p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="font-semibold">ওয়ার্কফ্লো প্রভাব: প্রিন্ট লেআউটে সরাসরি ই-স্বাক্ষর ও কিউআর স্ট্যাম্প যুক্ত হয়।</span>
            </div>
          </div>
        )}

        {/* POLICY 5: Strict NID & Birth Registration Validation */}
        {(activeFilterCategory === 'all' || activeFilterCategory === 'verification') && (
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="p-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                  <Lock className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                    strictNidBrnValidation 
                      ? 'bg-amber-600 text-white border-amber-700' 
                      : 'bg-emerald-600 text-white border-emerald-700'
                  }`}>
                    {strictNidBrnValidation ? 'কঠোর যাচাই (Strict)' : 'শিথিলযোগ্য (Flexible)'}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleTogglePolicy('strictNidBrnValidation', !strictNidBrnValidation)}
                    className={`relative inline-flex h-7 w-13 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      strictNidBrnValidation ? 'bg-amber-600' : 'bg-emerald-600'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        strictNidBrnValidation ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white">
                  কঠোর এনআইডি ও জন্মনিবন্ধন ডিজিট ফরম্যাট যাচাই
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  এনআইডি আবশ্যিকভাবে ১০, ১৩ বা ১৭ ডিজিট এবং জন্ম নিবন্ধন ১৭ ডিজিট ছাড়া আবেদন জমা নেওয়া বন্ধ রাখা হবে কি না।
                </p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="font-semibold">ওয়ার্কফ্লো প্রভাব: ভুল ডিজিটের ক্ষেত্রে আবেদন সাবমিট বাটন ব্লক বা সতর্কবার্তা দিবে।</span>
            </div>
          </div>
        )}

        {/* POLICY 6: Warish Local Attestation */}
        {(activeFilterCategory === 'all' || activeFilterCategory === 'verification') && (
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="p-2.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
                  <FileText className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                    warishWitnessMandatory 
                      ? 'bg-indigo-600 text-white border-indigo-700' 
                      : 'bg-slate-600 text-white border-slate-700'
                  }`}>
                    {warishWitnessMandatory ? 'বাধ্যতামূলক (Mandatory)' : 'ঐচ্ছিক (Optional)'}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleTogglePolicy('warishWitnessMandatory', !warishWitnessMandatory)}
                    className={`relative inline-flex h-7 w-13 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      warishWitnessMandatory ? 'bg-indigo-600' : 'bg-slate-400'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        warishWitnessMandatory ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white">
                  ওয়ারিশ সনদে স্থানীয় পঞ্চায়েত ও মেম্বার সত্যতা ঘোষণা
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  ওয়ারিশান সনদের ক্ষেত্রে কোনো জীবিত বৈধ ওয়ারিশ বাদ পড়ার দায় এড়াতে স্থানীয় মেম্বার বা গণ্যমান্য ব্যক্তির সাক্ষ্য আবশ্যিক থাকবে।
                </p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="font-semibold">ওয়ার্কফ্লো প্রভাব: ওয়ারিশ সনদের এন্ট্রি ফর্মে সাক্ষ্য প্রত্যয়ন ফিল্ড প্রদর্শিত হইবে।</span>
            </div>
          </div>
        )}

        {/* POLICY 7: Holding Tax Clearance Enforcement */}
        {(activeFilterCategory === 'all' || activeFilterCategory === 'financial') && (
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="p-2.5 rounded-2xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800">
                  <DollarSign className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                    holdingTaxClearanceMandatory 
                      ? 'bg-rose-600 text-white border-rose-700' 
                      : 'bg-emerald-600 text-white border-emerald-700'
                  }`}>
                    {holdingTaxClearanceMandatory ? 'কঠোর বকেয়া ব্লক' : 'উপদেশমূলক সতর্কবার্তা'}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleTogglePolicy('holdingTaxClearanceMandatory', !holdingTaxClearanceMandatory)}
                    className={`relative inline-flex h-7 w-13 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      holdingTaxClearanceMandatory ? 'bg-rose-600' : 'bg-emerald-600'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        holdingTaxClearanceMandatory ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white">
                  বকেয়া হোল্ডিং ট্যাক্স ক্লিয়ারেন্স শর্ত
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  নাগরিকের হোল্ডিং কর বকেয়া থাকলে সনদ আবেদন গ্রহণ ও প্রিন্ট বন্ধ রাখা হবে নাকি উপদেষ্টা সতর্কবার্তা দিয়ে সনদ প্রদান করা হবে।
                </p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="font-semibold">ওয়ার্কফ্লো প্রভাব: বকেয়া কর থাকলে আবেদন জমা দেওয়ার সময় ট্যাক্স নোটিশ দেখানো হয়।</span>
            </div>
          </div>
        )}

        {/* POLICY 8: Watermarked Draft Copy Before Payment */}
        {(activeFilterCategory === 'all' || activeFilterCategory === 'financial') && (
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="p-2.5 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800">
                  <FileText className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                    allowDraftWithoutPayment 
                      ? 'bg-blue-600 text-white border-blue-700' 
                      : 'bg-slate-600 text-white border-slate-700'
                  }`}>
                    {allowDraftWithoutPayment ? 'খসড়া প্রিন্ট উন্মুক্ত' : 'ফি পরিশোধ ব্যতিরেকে লক'}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleTogglePolicy('allowDraftWithoutPayment', !allowDraftWithoutPayment)}
                    className={`relative inline-flex h-7 w-13 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      allowDraftWithoutPayment ? 'bg-blue-600' : 'bg-slate-400'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        allowDraftWithoutPayment ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white">
                  ফি পরিশোধের পূর্বে ওয়াটারমার্কযুক্ত খসড়া প্রিন্ট
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  সরকারি ফি পরিশোধ করার পূর্বে নাগরিক বা উদ্যোক্তা যাচাইকরণের সুবিধার্থে ওয়াটারমার্কযুক্ত পরীক্ষামূলক খসড়া প্রিন্ট করতে পারবেন কি না।
                </p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="font-semibold">ওয়ার্কফ্লো প্রভাব: আবেদন ফর্মে "খসড়া প্রিন্ট (Draft Copy)" বাটন কার্যকর থাকে।</span>
            </div>
          </div>
        )}

        {/* POLICY 9: AI Gemini Policy Injection */}
        {(activeFilterCategory === 'all' || activeFilterCategory === 'ai_cloud') && (
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="p-2.5 rounded-2xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 border border-purple-200 dark:border-purple-800">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                    autoInjectRulesInAiPrompt 
                      ? 'bg-purple-600 text-white border-purple-700' 
                      : 'bg-slate-600 text-white border-slate-700'
                  }`}>
                    {autoInjectRulesInAiPrompt ? 'স্বয়ংক্রিয় ইনজেকশন সক্রিয়' : 'সাধারণ ড্রাফট'}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleTogglePolicy('autoInjectRulesInAiPrompt', !autoInjectRulesInAiPrompt)}
                    className={`relative inline-flex h-7 w-13 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      autoInjectRulesInAiPrompt ? 'bg-purple-600' : 'bg-slate-400'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        autoInjectRulesInAiPrompt ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white">
                  জেমিনি এআই প্রম্পটে লাইভ পলিসি রুলস ইনজেকশন
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  এআই ড্রাফটিং ও কাস্টম জেমিনির কাছে তথ্য পাঠানোর সময় বর্তমান সকল প্রশাসনিক পলিসি ও শর্ত স্বয়ংক্রিয়ভাবে প্রম্পট হিসেবে প্রেরণ করা হবে।
                </p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="font-semibold">ওয়ার্কফ্লো প্রভাব: জেমিনি এআই বর্তমান নীতি অনুযায়ী নির্ভুল অফিশিয়াল খসড়া লেখে।</span>
            </div>
          </div>
        )}

        {/* POLICY 10: Instant Realtime Cloud Backup */}
        {(activeFilterCategory === 'all' || activeFilterCategory === 'ai_cloud') && (
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="p-2.5 rounded-2xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 border border-cyan-200 dark:border-cyan-800">
                  <Cloud className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${
                    instantCloudSyncOnAction 
                      ? 'bg-cyan-600 text-white border-cyan-700' 
                      : 'bg-slate-600 text-white border-slate-700'
                  }`}>
                    {instantCloudSyncOnAction ? 'তাৎক্ষণিক সিঙ্ক সক্রিয়' : 'ম্যানুয়াল ব্যাকআপ'}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleTogglePolicy('instantCloudSyncOnAction', !instantCloudSyncOnAction)}
                    className={`relative inline-flex h-7 w-13 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      instantCloudSyncOnAction ? 'bg-cyan-600' : 'bg-slate-400'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                        instantCloudSyncOnAction ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white">
                  প্রতিটি অনুমোদন ও এন্ট্রিতে রিয়েল-টাইম ক্লাউড সিঙ্ক
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  যেকোনো সনদ অনুমোদন বা বাতিল হওয়ার সাথে সাথে স্বয়ংক্রিয় ব্যাকগ্রাউন্ড কিউ এর মাধ্যমে ফায়ারবেস ক্লাউড ও গুগল শিটসে সিঙ্ক হবে।
                </p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="font-semibold">ওয়ার্কফ্লো প্রভাব: শতভাগ ডাটা স্থায়ী ক্লাউড স্টোরেজে সুরক্ষিত থাকে।</span>
            </div>
          </div>
        )}
      </div>

      {/* Summary Box & Operator Notice */}
      <div className="p-6 rounded-3xl bg-slate-900 text-slate-200 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
            <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span>সিস্টেম পলিসি স্ট্যাটাস সামারি:</span>
          </div>
          <span className="text-xs text-slate-400">
            সর্বশেষ আপডেট: {new Date().toLocaleTimeString('bn-BD')}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/60">
            <div className="text-slate-400">মেম্বার সুপারিশ:</div>
            <div className={`font-bold mt-1 ${memberApprovalMandatory ? 'text-rose-400' : 'text-emerald-400'}`}>
              {memberApprovalMandatory ? '🔴 বাধ্যতামূলক' : '🟢 ঐচ্ছিক (শিথিল)'}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/60">
            <div className="text-slate-400">সচিব ডাটাবেজ যাচাই:</div>
            <div className={`font-bold mt-1 ${secretaryVerificationMandatory ? 'text-emerald-400' : 'text-amber-400'}`}>
              {secretaryVerificationMandatory ? '🟢 বাধ্যতামূলক' : '🟡 ফাস্ট-ট্র্যাক'}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/60">
            <div className="text-slate-400">হোল্ডিং ট্যাক্স ক্লিয়ারেন্স:</div>
            <div className={`font-bold mt-1 ${holdingTaxClearanceMandatory ? 'text-rose-400' : 'text-emerald-400'}`}>
              {holdingTaxClearanceMandatory ? '🔴 বকেয়া থাকলে লক' : '🟢 উপদেশমূলক'}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/60">
            <div className="text-slate-400">ডিজিটাল ই-স্বাক্ষর:</div>
            <div className="font-bold mt-1 text-teal-400">
              {enableDigitalSignature ? '🟢 স্বয়ংক্রিয় সিল' : '⚪ কাঁচা প্যাড'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
