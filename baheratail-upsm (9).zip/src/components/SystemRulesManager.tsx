import React, { useState, useMemo } from 'react';
import { 
  Sliders, 
  Plus, 
  Edit3, 
  Trash2, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Search, 
  Filter, 
  Save, 
  RotateCcw, 
  ShieldCheck, 
  Sparkles, 
  FileText, 
  UserCheck, 
  Users, 
  DollarSign, 
  Building2, 
  Check, 
  X, 
  Info, 
  ArrowRight,
  HelpCircle,
  ToggleLeft,
  ToggleRight,
  Shield,
  Layers,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { 
  SystemRuleItem, 
  UnionParishadConfig, 
  RuleRequirementLevel, 
  RuleCategoryType 
} from '../types';
import { 
  DEFAULT_SYSTEM_RULES, 
  RULE_CATEGORIES, 
  REQUIREMENT_LEVEL_LABELS,
  getEffectiveSystemRules 
} from '../data/systemRules';
import { CERTIFICATE_TYPES, CERTIFICATE_CATEGORIES } from '../data/certificateTypes';

interface SystemRulesManagerProps {
  config: UnionParishadConfig;
  onUpdateConfig: (newConfig: UnionParishadConfig) => void;
}

export const SystemRulesManager: React.FC<SystemRulesManagerProps> = ({ config, onUpdateConfig }) => {
  const [rules, setRules] = useState<SystemRuleItem[]>(() => getEffectiveSystemRules(config));
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedLevel, setSelectedLevel] = useState<string>('all');
  const [editingRule, setEditingRule] = useState<SystemRuleItem | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Form state for Add/Edit Modal
  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState<RuleCategoryType>('approval');
  const [formLevel, setFormLevel] = useState<RuleRequirementLevel>('optional');
  const [formAppliesToAll, setFormAppliesToAll] = useState(true);
  const [formSelectedTypes, setFormSelectedTypes] = useState<string[]>([]);
  const [formInstruction, setFormInstruction] = useState('');
  const [formEnabled, setFormEnabled] = useState(true);

  // Show Toast
  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Sync to Parent Config
  const saveRulesToConfig = (updatedRules: SystemRuleItem[], customMsg?: string) => {
    setRules(updatedRules);
    
    // Check specific high-level flags to keep config in sync
    const memberRule = updatedRules.find(r => r.id === 'rule_member_approval' || r.code === 'MEMBER_APPROVAL_OPTIONAL_RULE');
    const secretaryRule = updatedRules.find(r => r.id === 'rule_secretary_verification');
    const taxRule = updatedRules.find(r => r.id === 'rule_holding_tax_clearance');

    const updatedConfig: UnionParishadConfig = {
      ...config,
      systemRules: updatedRules,
      memberApprovalMandatory: memberRule ? (memberRule.requirementLevel === 'mandatory' && memberRule.enabled) : false,
      secretaryVerificationMandatory: secretaryRule ? (secretaryRule.requirementLevel === 'mandatory' && secretaryRule.enabled) : true,
      holdingTaxClearanceMandatory: taxRule ? (taxRule.requirementLevel === 'mandatory' && taxRule.enabled) : false,
    };

    onUpdateConfig(updatedConfig);
    showToast(customMsg || 'সিস্টেমের শর্ত ও নির্দেশনা সফলভাবে সংরক্ষিত হইয়াছে।', 'success');
  };

  // Quick 1-Click Level Cycler
  const cycleRuleLevel = (ruleId: string) => {
    const levels: RuleRequirementLevel[] = ['optional', 'mandatory', 'advisory', 'disabled'];
    const updated = rules.map(r => {
      if (r.id === ruleId) {
        const currIdx = levels.indexOf(r.requirementLevel);
        const nextLevel = levels[(currIdx + 1) % levels.length];
        return {
          ...r,
          requirementLevel: nextLevel,
          enabled: nextLevel !== 'disabled',
          updatedAt: new Date().toISOString()
        };
      }
      return r;
    });
    saveRulesToConfig(updated, 'শর্তের লেভেল পরিবর্তন করা হইয়াছে।');
  };

  // Toggle Rule Enable/Disable
  const toggleRuleEnabled = (ruleId: string) => {
    const updated = rules.map(r => {
      if (r.id === ruleId) {
        const nextEnabled = !r.enabled;
        return {
          ...r,
          enabled: nextEnabled,
          requirementLevel: nextEnabled ? (r.requirementLevel === 'disabled' ? 'optional' : r.requirementLevel) : 'disabled',
          updatedAt: new Date().toISOString()
        };
      }
      return r;
    });
    saveRulesToConfig(updated, 'শর্তের সক্রিয়তা পরিবর্তন হইয়াছে।');
  };

  // Open Edit Modal
  const handleOpenEdit = (rule: SystemRuleItem) => {
    setEditingRule(rule);
    setFormTitle(rule.title);
    setFormCategory(rule.category);
    setFormLevel(rule.requirementLevel);
    setFormAppliesToAll(rule.appliesTo === 'all');
    setFormSelectedTypes(Array.isArray(rule.appliesTo) ? rule.appliesTo : []);
    setFormInstruction(rule.instructionText);
    setFormEnabled(rule.enabled);
    setIsCreatingNew(false);
  };

  // Open Create Modal
  const handleOpenCreate = () => {
    setEditingRule(null);
    setFormTitle('');
    setFormCategory('custom');
    setFormLevel('optional');
    setFormAppliesToAll(true);
    setFormSelectedTypes([]);
    setFormInstruction('');
    setFormEnabled(true);
    setIsCreatingNew(true);
  };

  // Submit Add / Edit Form
  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      showToast('অনুগ্রহ করে শর্ত বা নির্দেশনার শিরোনাম লিখুন।', 'error');
      return;
    }
    if (!formInstruction.trim()) {
      showToast('অনুগ্রহ করে শর্তের বিস্তারিত নির্দেশনা লিখুন।', 'error');
      return;
    }

    const categoryObj = RULE_CATEGORIES.find(c => c.key === formCategory);
    const categoryLabel = categoryObj ? categoryObj.label : 'কাস্টম শর্ত';

    if (isCreatingNew) {
      const newRule: SystemRuleItem = {
        id: `rule_custom_${Date.now()}`,
        code: `CUSTOM_RULE_${Date.now()}`,
        title: formTitle.trim(),
        category: formCategory,
        categoryLabel: categoryLabel,
        appliesTo: formAppliesToAll ? 'all' : formSelectedTypes,
        requirementLevel: formLevel,
        instructionText: formInstruction.trim(),
        enabled: formEnabled,
        isSystemDefault: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        lastUpdatedBy: 'ইউপি অ্যাডমিন'
      };
      const updated = [newRule, ...rules];
      saveRulesToConfig(updated, 'নতুন শর্ত ও নির্দেশনা যুক্ত হইয়াছে।');
    } else if (editingRule) {
      const updated = rules.map(r => {
        if (r.id === editingRule.id) {
          return {
            ...r,
            title: formTitle.trim(),
            category: formCategory,
            categoryLabel: categoryLabel,
            appliesTo: formAppliesToAll ? 'all' : formSelectedTypes,
            requirementLevel: formLevel,
            instructionText: formInstruction.trim(),
            enabled: formEnabled,
            updatedAt: new Date().toISOString(),
            lastUpdatedBy: 'ইউপি অ্যাডমিন'
          };
        }
        return r;
      });
      saveRulesToConfig(updated, 'শর্তের তথ্য সফলভাবে হালনাগাদ করা হইয়াছে।');
    }

    setEditingRule(null);
    setIsCreatingNew(false);
  };

  // Delete Rule
  const handleDeleteRule = (ruleId: string) => {
    if (window.confirm('আপনি কি নিশ্চিত যে এই শর্তটি সম্পূর্ণ মুছে ফেলতে চান?')) {
      const updated = rules.filter(r => r.id !== ruleId);
      saveRulesToConfig(updated, 'শর্তটি সিস্টেম থেকে মুছে ফেলা হইয়াছে।');
    }
  };

  // Reset to Defaults
  const handleResetDefaults = () => {
    if (window.confirm('আপনি কি সকল শর্ত ও নির্দেশনা সিস্টেমের প্রমিত ফ্যাক্টরি ডিফল্টে রিসেট করতে চান?')) {
      saveRulesToConfig(DEFAULT_SYSTEM_RULES, 'সকল শর্ত ও নির্দেশনা ফ্যাক্টরি ডিফল্টে রিসেট করা হইয়াছে।');
    }
  };

  // Toggle quick presets directly from top summary
  const toggleMemberApprovalQuick = (toMandatory: boolean) => {
    const updated = rules.map(r => {
      if (r.id === 'rule_member_approval' || r.code === 'MEMBER_APPROVAL_OPTIONAL_RULE') {
        return {
          ...r,
          requirementLevel: (toMandatory ? 'mandatory' : 'optional') as RuleRequirementLevel,
          enabled: true,
          updatedAt: new Date().toISOString()
        };
      }
      return r;
    });
    saveRulesToConfig(
      updated, 
      toMandatory 
        ? '🔴 মেম্বার অনুমোদন বাধ্যতামূলক করা হইয়াছে।' 
        : '🟢 মেম্বার অনুমোদন ঐচ্ছিক/বাতিল করা হইয়াছে (সরাসরি সচিব-চেয়ারম্যান অনুমোদন কার্যকর)।'
    );
  };

  // Filtered Rules
  const filteredRules = useMemo(() => {
    return rules.filter(r => {
      const matchesSearch = !searchQuery.trim() || 
        r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.instructionText.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (r.code && r.code.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesCat = selectedCategory === 'all' || r.category === selectedCategory;
      const matchesLevel = selectedLevel === 'all' || r.requirementLevel === selectedLevel;

      return matchesSearch && matchesCat && matchesLevel;
    });
  }, [rules, searchQuery, selectedCategory, selectedLevel]);

  // Statistics
  const stats = useMemo(() => {
    const total = rules.length;
    const mandatory = rules.filter(r => r.enabled && r.requirementLevel === 'mandatory').length;
    const optional = rules.filter(r => r.enabled && r.requirementLevel === 'optional').length;
    const advisory = rules.filter(r => r.enabled && r.requirementLevel === 'advisory').length;
    const disabled = rules.filter(r => !r.enabled || r.requirementLevel === 'disabled').length;

    const isMemberMandatory = rules.some(
      r => (r.id === 'rule_member_approval' || r.code === 'MEMBER_APPROVAL_OPTIONAL_RULE') && 
           r.enabled && r.requirementLevel === 'mandatory'
    );

    return { total, mandatory, optional, advisory, disabled, isMemberMandatory };
  }, [rules]);

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`fixed top-5 right-5 z-50 px-5 py-3 rounded-xl shadow-2xl border flex items-center gap-3 text-xs font-bold transition animate-bounce ${
            toastMessage.type === 'success'
              ? 'bg-emerald-950 text-amber-300 border-amber-400/40'
              : 'bg-rose-950 text-rose-200 border-rose-500/40'
          }`}
        >
          {toastMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-amber-300" />
          ) : (
            <XCircle className="w-4 h-4 text-rose-400" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Hero Header & Quick Action Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-emerald-700/60 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-emerald-800/80 backdrop-blur border border-emerald-500/50 text-amber-300 px-3 py-1 rounded-full text-xs font-bold">
              <Sliders className="w-3.5 h-3.5" />
              <span>ডায়নামিক সিস্টেম পলিসি ও শর্ত ইঞ্জিন (System Condition & Rules Engine)</span>
            </div>

            <h2 className="text-xl md:text-2xl font-extrabold tracking-tight text-white flex items-center gap-2">
              <span>প্রশাসনিক শর্ত, কন্ডিশন ও এআই নির্দেশনা ব্যবস্থাপনা</span>
            </h2>

            <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
              সিস্টেমে সনদ অনুমোদন, তথ্য যাচাই, ফি নির্ধারণ ও ভাষা প্রম্পটের শর্তাবলি ম্যানুয়ালি পরিচালনা করুন। 
              যেমন: <strong>মেম্বারের অনুমোদন ঐচ্ছিক/বাতিল</strong> রাখা বা যেকোনো সময় <strong>বাধ্যতামূলক</strong> করার মতো নীতিমালা নিয়ন্ত্রণ করুন।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleOpenCreate}
              className="bg-amber-400 hover:bg-amber-300 text-slate-950 px-4 py-2.5 rounded-xl text-xs font-bold shadow-lg transition flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন শর্ত / নির্দেশনা যুক্ত করুন</span>
            </button>

            <button
              onClick={handleResetDefaults}
              className="bg-emerald-950/80 hover:bg-emerald-900 text-emerald-200 border border-emerald-700/60 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer"
              title="ফ্যাক্টরি ডিফল্ট শর্তে রিসেট"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>ডিফল্ট রিসেট</span>
            </button>
          </div>
        </div>

        {/* Highlighted Direct Toggle: Member Approval Condition */}
        <div className="mt-6 pt-4 border-t border-emerald-800/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-emerald-950/40 p-4 rounded-xl">
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-xl ${stats.isMemberMandatory ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'}`}>
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white">মেম্বার (ইউপি সদস্য) সুপারিশ ও অনুমোদন শর্ত:</span>
                <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-extrabold ${stats.isMemberMandatory ? 'bg-rose-600 text-white' : 'bg-emerald-500 text-slate-950'}`}>
                  {stats.isMemberMandatory ? 'বাধ্যতামূলক (Mandatory)' : 'ঐচ্ছিক / বাতিল (Optional)'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                {stats.isMemberMandatory 
                  ? 'বর্তমানে কোনো সনদ মেম্বারের স্বাক্ষর/সুপারিশ ছাড়া চূড়ান্ত অনুমোদন হইবে না।'
                  : 'বর্তমানে মেম্বারের অনুমোদন বাধ্যতামূলক নয়; সচিব যাচাই ও চেয়ারম্যানের চূড়ান্ত স্বাক্ষরে সরাসরি সনদ ইস্যু করা যাইবে।'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            {stats.isMemberMandatory ? (
              <button
                onClick={() => toggleMemberApprovalQuick(false)}
                className="bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow"
              >
                <Check className="w-3.5 h-3.5" />
                <span>মেম্বার অনুমোদন ঐচ্ছিক / বাতিল করুন</span>
              </button>
            ) : (
              <button
                onClick={() => toggleMemberApprovalQuick(true)}
                className="bg-rose-600 hover:bg-rose-500 text-white px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>মেম্বার অনুমোদন বাধ্যতামূলক করুন</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs text-slate-500 dark:text-slate-400 block font-medium">মোট শর্তাবলি</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-2xl font-black text-slate-800 dark:text-white">{stats.total}</span>
            <Sliders className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          </div>
        </div>

        <div className="bg-rose-50/70 dark:bg-rose-950/30 p-4 rounded-xl border border-rose-200 dark:border-rose-900/50 shadow-sm">
          <span className="text-xs text-rose-700 dark:text-rose-400 block font-semibold">বাধ্যতামূলক শর্ত</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-2xl font-black text-rose-700 dark:text-rose-300">{stats.mandatory}</span>
            <ShieldCheck className="w-5 h-5 text-rose-600" />
          </div>
        </div>

        <div className="bg-emerald-50/70 dark:bg-emerald-950/30 p-4 rounded-xl border border-emerald-200 dark:border-emerald-900/50 shadow-sm">
          <span className="text-xs text-emerald-700 dark:text-emerald-400 block font-semibold">ঐচ্ছিক শর্ত</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-2xl font-black text-emerald-700 dark:text-emerald-300">{stats.optional}</span>
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          </div>
        </div>

        <div className="bg-amber-50/70 dark:bg-amber-950/30 p-4 rounded-xl border border-amber-200 dark:border-amber-900/50 shadow-sm">
          <span className="text-xs text-amber-700 dark:text-amber-400 block font-semibold">সতর্কবার্তা / উপদেশ</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-2xl font-black text-amber-700 dark:text-amber-300">{stats.advisory}</span>
            <AlertTriangle className="w-5 h-5 text-amber-600" />
          </div>
        </div>

        <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-xl border border-slate-300 dark:border-slate-700 shadow-sm col-span-2 sm:col-span-1">
          <span className="text-xs text-slate-500 dark:text-slate-400 block font-medium">স্থগিত / নিষ্ক্রিয়</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-2xl font-black text-slate-600 dark:text-slate-400">{stats.disabled}</span>
            <XCircle className="w-5 h-5 text-slate-400" />
          </div>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="শর্তের নাম বা নির্দেশনা খুঁজুন..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none dark:text-white"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
            <Filter className="w-3.5 h-3.5" />
            <span>ক্যাটাগরি:</span>
          </div>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs rounded-lg px-3 py-2 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">সকল ক্যাটাগরি</option>
            {RULE_CATEGORIES.map(c => (
              <option key={c.key} value={c.key}>{c.label}</option>
            ))}
          </select>

          <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400 ml-2">
            <span>লেভেল:</span>
          </div>
          <select
            value={selectedLevel}
            onChange={(e) => setSelectedLevel(e.target.value)}
            className="bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs rounded-lg px-3 py-2 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">সকল লেভেল</option>
            <option value="mandatory">বাধ্যতামূলক</option>
            <option value="optional">ঐচ্ছিক</option>
            <option value="advisory">উপদেশমূলক</option>
            <option value="disabled">স্থগিত / নিষ্ক্রিয়</option>
          </select>

          {(searchQuery || selectedCategory !== 'all' || selectedLevel !== 'all') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setSelectedLevel('all');
              }}
              className="text-xs text-rose-600 hover:text-rose-700 font-semibold px-2 py-1 ml-auto md:ml-0"
            >
              রিসেট
            </button>
          )}
        </div>
      </div>

      {/* Rules List Grid */}
      <div className="space-y-3">
        {filteredRules.length === 0 ? (
          <div className="bg-white dark:bg-slate-800 p-12 text-center rounded-2xl border border-slate-200 dark:border-slate-700">
            <Sliders className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
            <h4 className="text-base font-bold text-slate-700 dark:text-slate-300">কোনো শর্ত পাওয়া যায়নি</h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">অনুসন্ধান ফিল্টার পরিবর্তন করুন অথবা নতুন শর্ত যুক্ত করুন।</p>
          </div>
        ) : (
          filteredRules.map((rule) => {
            const levelInfo = REQUIREMENT_LEVEL_LABELS[rule.requirementLevel] || REQUIREMENT_LEVEL_LABELS.optional;
            const isSystem = rule.isSystemDefault;

            return (
              <div
                key={rule.id}
                className={`bg-white dark:bg-slate-800 rounded-xl border transition-all duration-200 shadow-sm hover:shadow-md p-4 sm:p-5 ${
                  rule.enabled ? 'border-slate-200 dark:border-slate-700' : 'border-slate-200 dark:border-slate-800 opacity-70 bg-slate-50/50 dark:bg-slate-900/40'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="space-y-2 flex-1">
                    {/* Header Chips */}
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-600">
                        {rule.categoryLabel}
                      </span>

                      {/* Requirement Level Badge (Clickable to cycle) */}
                      <button
                        onClick={() => cycleRuleLevel(rule.id)}
                        className={`text-[11px] font-bold px-3 py-0.5 rounded-full border transition flex items-center gap-1 cursor-pointer active:scale-95 ${levelInfo.color}`}
                        title="ক্লিক করে লেভেল পরিবর্তন করুন"
                      >
                        <span>{levelInfo.label}</span>
                        <ChevronDown className="w-3 h-3 opacity-60" />
                      </button>

                      {/* Target Certificate Scope */}
                      <span className="text-[10px] font-medium text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-900 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-800">
                        {rule.appliesTo === 'all' ? 'প্রযোজ্য: সমগ্র ৫০+ সনদ' : `প্রযোজ্য: ${Array.isArray(rule.appliesTo) ? rule.appliesTo.length : 0}টি নির্দিষ্ট সনদে`}
                      </span>

                      {isSystem && (
                        <span className="text-[9px] font-bold text-teal-700 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/50 border border-teal-200 dark:border-teal-800 px-1.5 py-0.5 rounded">
                          সিস্টেম ডিফল্ট
                        </span>
                      )}
                    </div>

                    {/* Rule Title */}
                    <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <span>{rule.title}</span>
                    </h3>

                    {/* Instruction Details */}
                    <div className="bg-slate-50 dark:bg-slate-900/60 p-3 rounded-lg border border-slate-200/80 dark:border-slate-700/80 text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-sans">
                      <p className="font-normal">{rule.instructionText}</p>
                    </div>

                    {/* Timestamp & Operator note */}
                    <div className="flex items-center gap-4 text-[10px] text-slate-400 pt-1">
                      <span>হালনাগাদ: {new Date(rule.updatedAt).toLocaleDateString('bn-BD')}</span>
                      {rule.lastUpdatedBy && <span>কর্তৃক: {rule.lastUpdatedBy}</span>}
                    </div>
                  </div>

                  {/* Actions & Toggles */}
                  <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-start gap-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100 dark:border-slate-700">
                    <button
                      onClick={() => toggleRuleEnabled(rule.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                        rule.enabled 
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800'
                          : 'bg-slate-100 text-slate-600 border border-slate-200 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-400'
                      }`}
                    >
                      {rule.enabled ? (
                        <>
                          <ToggleRight className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                          <span>সক্রিয়</span>
                        </>
                      ) : (
                        <>
                          <ToggleLeft className="w-4 h-4 text-slate-400" />
                          <span>স্থগিত</span>
                        </>
                      )}
                    </button>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(rule)}
                        className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition text-xs flex items-center gap-1 cursor-pointer"
                        title="সম্পাদনা করুন"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">সম্পাদনা</span>
                      </button>

                      {!isSystem && (
                        <button
                          onClick={() => handleDeleteRule(rule.id)}
                          className="p-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition text-xs cursor-pointer"
                          title="মুছে ফেলুন"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add / Edit Rule Modal */}
      {(isCreatingNew || editingRule) && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden my-8">
            <div className="bg-emerald-900 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Sliders className="w-5 h-5 text-amber-300" />
                <h3 className="text-base font-bold">
                  {isCreatingNew ? 'নতুন সিস্টেম শর্ত ও নির্দেশনা তৈরি করুন' : 'শর্ত ও নির্দেশনা সম্পাদনা করুন'}
                </h3>
              </div>
              <button
                onClick={() => {
                  setEditingRule(null);
                  setIsCreatingNew(false);
                }}
                className="p-1 text-slate-300 hover:text-white rounded-lg transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              {/* Title */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  শর্ত বা নির্দেশনার নাম / শিরোনাম *
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="যেমন: মেম্বার স্বাক্ষর ব্যতীত জরুরি সনদ প্রদান নিয়ম / বীর মুক্তিযোদ্ধা গেজেট যাচাই..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none dark:text-white"
                />
              </div>

              {/* Category & Requirement Level */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    শর্তের ক্যাটাগরি
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as RuleCategoryType)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none dark:text-white"
                  >
                    {RULE_CATEGORIES.map(c => (
                      <option key={c.key} value={c.key}>{c.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    শর্তের লেভেল / কন্ডিশন বাধ্যবাধকতা *
                  </label>
                  <select
                    value={formLevel}
                    onChange={(e) => setFormLevel(e.target.value as RuleRequirementLevel)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none dark:text-white"
                  >
                    <option value="optional">ঐচ্ছিক (Optional / বাধ্যতামুলক নয়)</option>
                    <option value="mandatory">বাধ্যতামূলক (Mandatory)</option>
                    <option value="advisory">উপদেশমূলক / সতর্কবার্তা (Advisory)</option>
                    <option value="disabled">স্থগিত / বাতিল (Disabled)</option>
                  </select>
                </div>
              </div>

              {/* Scope of Application */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  প্রযোজ্যতার পরিধি (Scope)
                </label>
                <div className="flex items-center gap-4 mb-2">
                  <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                    <input
                      type="radio"
                      checked={formAppliesToAll}
                      onChange={() => setFormAppliesToAll(true)}
                      className="text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>সকল সনদের ক্ষেত্রে প্রযোজ্য (All 50+ Types)</span>
                  </label>
                  <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                    <input
                      type="radio"
                      checked={!formAppliesToAll}
                      onChange={() => setFormAppliesToAll(false)}
                      className="text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>নির্দিষ্ট সনদের ক্ষেত্রে প্রযোজ্য</span>
                  </label>
                </div>

                {!formAppliesToAll && (
                  <div className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl max-h-40 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {CERTIFICATE_TYPES.map(cert => {
                      const isSelected = formSelectedTypes.includes(cert.key);
                      return (
                        <label key={cert.key} className="flex items-center gap-2 cursor-pointer hover:text-emerald-600">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFormSelectedTypes([...formSelectedTypes, cert.key]);
                              } else {
                                setFormSelectedTypes(formSelectedTypes.filter(k => k !== cert.key));
                              }
                            }}
                            className="text-emerald-600 rounded focus:ring-emerald-500"
                          />
                          <span className="truncate">{cert.label}</span>
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Instruction Text */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  শর্ত ও নির্দেশনার বিস্তারিত বিবরণী (Instruction / Policy Content) *
                </label>
                <textarea
                  rows={4}
                  required
                  value={formInstruction}
                  onChange={(e) => setFormInstruction(e.target.value)}
                  placeholder="শর্তের মূল নিয়ম বা এআই প্রম্পটের বিস্তারিত লিখুন..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none dark:text-white leading-relaxed font-sans"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  এই নির্দেশনাটি এআই ড্রাফটিং প্রম্পট এবং ইউনিয়ন পরিষদ আবেদন যাচাই প্রক্রিয়ায় সরাসরি কার্যকর হইবে।
                </p>
              </div>

              {/* Active Toggle */}
              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                <div>
                  <span className="text-xs font-bold text-slate-800 dark:text-white block">শর্তের বর্তমান স্ট্যাটাস</span>
                  <span className="text-[11px] text-slate-500">অনুমোদন প্রক্রিয়ায় এটি সক্রিয় বা নিষ্ক্রিয় রাখুন</span>
                </div>
                <button
                  type="button"
                  onClick={() => setFormEnabled(!formEnabled)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    formEnabled ? 'bg-emerald-600 text-white' : 'bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {formEnabled ? 'সক্রিয় (Active)' : 'নিষ্ক্রিয় (Inactive)'}
                </button>
              </div>

              {/* Footer Buttons */}
              <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setEditingRule(null);
                    setIsCreatingNew(false);
                  }}
                  className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer"
                >
                  বাতিল
                </button>

                <button
                  type="submit"
                  className="bg-emerald-700 hover:bg-emerald-600 text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-lg transition flex items-center gap-2 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>সংরক্ষণ করুন</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
