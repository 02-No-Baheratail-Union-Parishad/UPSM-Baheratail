import React, { useState, useMemo } from 'react';
import { 
  X, 
  Calculator, 
  Building2, 
  Home, 
  Store, 
  Factory, 
  Trees, 
  Sparkles, 
  Printer, 
  Download, 
  Plus, 
  Check, 
  HelpCircle, 
  Layers, 
  ShieldCheck, 
  ArrowRight,
  RefreshCw,
  Info,
  DollarSign,
  TrendingUp,
  Landmark
} from 'lucide-react';
import { HoldingType, UnionParishadConfig, HoldingTaxRecord } from '../../types';
import { downloadElementAsPDF } from '../../utils/taxReceiptPdf';

interface TaxAssessmentCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: UnionParishadConfig;
  onApplyToNewHolding?: (assessmentData: {
    holdingType: HoldingType;
    structureType: string;
    annualValuation: number;
    currentTaxDemand: number;
    arrearsDue: number;
    totalDemand: number;
    notes: string;
  }) => void;
  existingRecords?: HoldingTaxRecord[];
}

export type LandCategory = 
  | 'residential_kacha'
  | 'residential_semi_pucca'
  | 'residential_pucca_single'
  | 'residential_pucca_multi'
  | 'commercial_village_shop'
  | 'commercial_market_pucca'
  | 'commercial_shopping_complex'
  | 'industrial_rice_mill'
  | 'industrial_saw_mill'
  | 'industrial_poultry_agro'
  | 'industrial_heavy_factory'
  | 'agricultural_crop_land'
  | 'agricultural_pond_fishery'
  | 'agricultural_orchard'
  | 'institutional_private_school'
  | 'institutional_clinic_ngo';

export type AreaUnit = 'sqft' | 'shotangsho' | 'katha' | 'bigha';

interface LandRateRule {
  label: string;
  categoryName: string;
  holdingType: HoldingType;
  structureType: string;
  ratePerSqft: number; // Annual rental / valuation rate per sqft in BDT
  ratePerShotangsho: number; // For agricultural land
  defaultMaintenanceDiscountPercent: number; // Maintenance allowance (e.g., 20% for residential)
  taxRatePercent: number; // Standard UP Tax rate (usually 5% to 7%)
  description: string;
}

const LAND_RATE_RULES: Record<LandCategory, LandRateRule> = {
  residential_kacha: {
    label: 'বসতবাড়ি — কাঁচা / টিনের ঘর',
    categoryName: 'বসতবাড়ি (কাঁচা)',
    holdingType: 'residential',
    structureType: 'kacha',
    ratePerSqft: 20, // ৳২০/বর্গফুট বার্ষিক ভাড়া মূল্যায়ন
    ratePerShotangsho: 8700,
    defaultMaintenanceDiscountPercent: 20,
    taxRatePercent: 5,
    description: 'মাটি বা বাঁশের বেড়া ও টিনের ছাদযুক্ত গ্রামীণ বসতবাড়ি'
  },
  residential_semi_pucca: {
    label: 'বসতবাড়ি — আধাপাকা (টিনশেড দালান)',
    categoryName: 'বসতবাড়ি (আধাপাকা)',
    holdingType: 'residential',
    structureType: 'semi_pucca',
    ratePerSqft: 40, // ৳৪০/বর্গফুট
    ratePerShotangsho: 17400,
    defaultMaintenanceDiscountPercent: 20,
    taxRatePercent: 5,
    description: 'ইটের দেয়াল ও টিনের ছাদবিশিষ্ট আধাপাকা বসতঘর'
  },
  residential_pucca_single: {
    label: 'বসতবাড়ি — পাকা একতলা পাকা বাড়ি',
    categoryName: 'বসতবাড়ি (পাকা একতলা)',
    holdingType: 'residential',
    structureType: 'pucca',
    ratePerSqft: 75, // ৳৭৫/বর্গফুট
    ratePerShotangsho: 32600,
    defaultMaintenanceDiscountPercent: 20,
    taxRatePercent: 7,
    description: 'আরসিসি ছাদযুক্ত আধুনিক একতলা পাকা আবাসিক ভবন'
  },
  residential_pucca_multi: {
    label: 'বসতবাড়ি — বহুতল পাকা আবাসিক ভবন',
    categoryName: 'বসতবাড়ি (বহুতল পাকা)',
    holdingType: 'residential',
    structureType: 'multi_storied',
    ratePerSqft: 110, // ৳১১০/বর্গফুট
    ratePerShotangsho: 47900,
    defaultMaintenanceDiscountPercent: 15,
    taxRatePercent: 7,
    description: 'দুই বা ততোধিক তলাবিশিষ্ট আরসিসি পাকা ভবন'
  },
  commercial_village_shop: {
    label: 'বাণিজ্যিক — গ্রামীণ বাজার দোকান / চা-স্টল / মুদি দোকান',
    categoryName: 'ব্যবসা প্রতিষ্ঠান (বাজার দোকান)',
    holdingType: 'commercial',
    structureType: 'semi_pucca',
    ratePerSqft: 90, // ৳৯০/বর্গফুট
    ratePerShotangsho: 39200,
    defaultMaintenanceDiscountPercent: 10,
    taxRatePercent: 7,
    description: 'স্থানীয় হাট-বাজারের কাঁচা বা আধাপাকা দোকানপাট'
  },
  commercial_market_pucca: {
    label: 'বাণিজ্যিক — পাকা মার্কেট ও বাণিজ্যিক আউটলেট',
    categoryName: 'ব্যবসা প্রতিষ্ঠান (পাকা মার্কেট)',
    holdingType: 'commercial',
    structureType: 'pucca',
    ratePerSqft: 160, // ৳১৬০/বর্গফুট
    ratePerShotangsho: 69600,
    defaultMaintenanceDiscountPercent: 10,
    taxRatePercent: 7,
    description: 'পাকা বাণিজ্যিক মার্কেট, ব্যাংক শাখা, ফার্মেসি ইত্যাদি'
  },
  commercial_shopping_complex: {
    label: 'বাণিজ্যিক — বহুতল শপিং কমপ্লেক্স / কমিউনিটি সেন্টার',
    categoryName: 'ব্যবসা প্রতিষ্ঠান (শপিং কমপ্লেক্স)',
    holdingType: 'commercial',
    structureType: 'multi_storied',
    ratePerSqft: 220, // ৳২২০/বর্গফুট
    ratePerShotangsho: 95800,
    defaultMaintenanceDiscountPercent: 10,
    taxRatePercent: 7,
    description: 'বড় বাণিজ্যিক শপিং কমপ্লেক্স, চাইনিজ রেস্তোরাঁ বা কনভেনশন হল'
  },
  industrial_rice_mill: {
    label: 'শিল্প / কারখানা — অটো রাইস মিল / হাসকিং মিল',
    categoryName: 'শিল্প কারখানা (রাইস মিল)',
    holdingType: 'industrial',
    structureType: 'pucca',
    ratePerSqft: 130, // ৳১৩০/বর্গফুট
    ratePerShotangsho: 56600,
    defaultMaintenanceDiscountPercent: 15,
    taxRatePercent: 7,
    description: 'ধান মাড়াই, হাসকিং বা সেমি-অটো চাল প্রক্রিয়াকরণ কল'
  },
  industrial_saw_mill: {
    label: 'শিল্প / কারখানা — স-মিল (Saw Mill) ও কাঠ চেরাই কারখানা',
    categoryName: 'শিল্প ইউনিট (স-মিল)',
    holdingType: 'industrial',
    structureType: 'semi_pucca',
    ratePerSqft: 100, // ৳১০০/বর্গফুট
    ratePerShotangsho: 43500,
    defaultMaintenanceDiscountPercent: 15,
    taxRatePercent: 7,
    description: 'কাঠ চেরাই, ফার্নিচার কারখানা বা মেটাল ওয়ার্কশপ'
  },
  industrial_poultry_agro: {
    label: 'কৃষিভিত্তিক শিল্প — পোল্ট্রি ফার্ম / ডেইরি ফার্ম / হ্যাচারি',
    categoryName: 'কৃষিভিত্তিক শিল্প (পোল্ট্রি/ডেইরি)',
    holdingType: 'industrial',
    structureType: 'semi_pucca',
    ratePerSqft: 50, // ৳৫০/বর্গফুট
    ratePerShotangsho: 21700,
    defaultMaintenanceDiscountPercent: 20,
    taxRatePercent: 5,
    description: 'বড় আকারের মুরগির খামার, গাভী পালন বা মাৎস্য হ্যাচারি'
  },
  industrial_heavy_factory: {
    label: 'শিল্প — টেক্সটাইল / ইটভাটা (Brickfield) / কোল্ড স্টোরেজ',
    categoryName: 'ভারী শিল্প (ইটভাটা/কারখানা)',
    holdingType: 'industrial',
    structureType: 'multi_storied',
    ratePerSqft: 180, // ৳১৮০/বর্গফুট
    ratePerShotangsho: 78400,
    defaultMaintenanceDiscountPercent: 10,
    taxRatePercent: 7,
    description: 'ইটভাটা, ফিড মিল, হিমাগার বা তৈরি পোশাক কারখানা'
  },
  agricultural_crop_land: {
    label: 'কৃষি জমি — আবাদি ফসলি জমি (নাল জমি)',
    categoryName: 'কৃষি জমি (ফসলি)',
    holdingType: 'residential',
    structureType: 'kacha',
    ratePerSqft: 5, // ৳৫/বর্গফুট বা ৳২২০/শতাংশ
    ratePerShotangsho: 220,
    defaultMaintenanceDiscountPercent: 0,
    taxRatePercent: 5,
    description: 'ধান, পাট বা শাকসবজি চাষের নাল জমি'
  },
  agricultural_pond_fishery: {
    label: 'জলাশয় — বাণিজ্যিক পুকুর / মাছের খামার',
    categoryName: 'কৃষি জমি (বাণিজ্যিক পুকুর)',
    holdingType: 'residential',
    structureType: 'kacha',
    ratePerSqft: 12,
    ratePerShotangsho: 520,
    defaultMaintenanceDiscountPercent: 0,
    taxRatePercent: 5,
    description: 'বাণিজ্যিক মাছ চাষের জন্য খননকৃত বড় পুকুর বা দিঘি'
  },
  agricultural_orchard: {
    label: 'বাগান — ফলজ বাগান (আম/আনারস/মাল্টা/টিম্বার)',
    categoryName: 'কৃষি জমি (ফলজ বাগান)',
    holdingType: 'residential',
    structureType: 'kacha',
    ratePerSqft: 15,
    ratePerShotangsho: 650,
    defaultMaintenanceDiscountPercent: 0,
    taxRatePercent: 5,
    description: 'বাণিজ্যিক ফলের বাগান বা শাল-গজারি বনায়ন'
  },
  institutional_private_school: {
    label: 'প্রতিষ্ঠান — কিন্ডারগার্টেন / বেসরকারি স্কুল / মাদ্রাসা',
    categoryName: 'প্রতিষ্ঠান (শিক্ষা)',
    holdingType: 'institutional',
    structureType: 'pucca',
    ratePerSqft: 60,
    ratePerShotangsho: 26100,
    defaultMaintenanceDiscountPercent: 25,
    taxRatePercent: 5,
    description: 'বেসরকারি শিক্ষা প্রতিষ্ঠান, কিন্ডারগার্টেন বা মাদ্রাসা'
  },
  institutional_clinic_ngo: {
    label: 'প্রতিষ্ঠান — প্রাইভেট ক্লিনিক / এনজিও অফিস / ডায়াগনস্টিক',
    categoryName: 'প্রতিষ্ঠান (স্বাস্থ্য/এনজিও)',
    holdingType: 'institutional',
    structureType: 'pucca',
    ratePerSqft: 140,
    ratePerShotangsho: 60900,
    defaultMaintenanceDiscountPercent: 15,
    taxRatePercent: 7,
    description: 'বেসরকারি হাসপাতাল, ডায়াগনস্টিক সেন্টার বা মাইক্রোক্রেডিট অফিস'
  }
};

export const TaxAssessmentCalculatorModal: React.FC<TaxAssessmentCalculatorModalProps> = ({
  isOpen,
  onClose,
  config,
  onApplyToNewHolding,
  existingRecords
}) => {
  // Calculator Inputs
  const [landCategory, setLandCategory] = useState<LandCategory>('residential_semi_pucca');
  const [areaValue, setAreaValue] = useState<string>('800'); // 800 sqft default
  const [areaUnit, setAreaUnit] = useState<AreaUnit>('sqft');
  const [storiesCount, setStoriesCount] = useState<number>(1); // 1-story
  const [wardLocationMultiplier, setWardLocationMultiplier] = useState<number>(1.0); // Ward growth factor
  const [customValuationRate, setCustomValuationRate] = useState<string>(''); // Override rate if needed
  
  // Arrears Calculation Inputs
  const [unpaidYearsCount, setUnpaidYearsCount] = useState<number>(1); // Number of unpaid past years
  const [applySurcharge, setApplySurcharge] = useState<boolean>(true); // 5% legal surcharge on arrears
  const [manualArrearsAmount, setManualArrearsAmount] = useState<string>(''); // If manual arrears entered

  // State for printable report
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [assessmentOwnerName, setAssessmentOwnerName] = useState<string>('');
  const [assessmentWardNo, setAssessmentWardNo] = useState<string>('০১');
  const [assessmentVillage, setAssessmentVillage] = useState<string>('ডাবাইল');

  // Active Rule
  const activeRule = useMemo(() => {
    return LAND_RATE_RULES[landCategory] || LAND_RATE_RULES.residential_semi_pucca;
  }, [landCategory]);

  // Convert area to Square Feet (বর্গফুট)
  const convertedSqft = useMemo(() => {
    const val = parseFloat(areaValue) || 0;
    switch (areaUnit) {
      case 'sqft':
        return val;
      case 'shotangsho':
        return val * 435.6; // 1 শতাংশ = 435.6 বর্গফুট
      case 'katha':
        return val * 720; // 1 কাঠা = 720 বর্গফুট
      case 'bigha':
        return val * 14400; // 1 বিঘা = 14,400 বর্গফুট
      default:
        return val;
    }
  }, [areaValue, areaUnit]);

  // Convert to Shotangsho
  const convertedShotangsho = useMemo(() => {
    return (convertedSqft / 435.6).toFixed(2);
  }, [convertedSqft]);

  // Total Effective Area (Accounting for multi-story buildings)
  const totalFloorAreaSqft = useMemo(() => {
    const isMulti = activeRule.structureType === 'multi_storied' || storiesCount > 1;
    return isMulti ? convertedSqft * Math.max(1, storiesCount) : convertedSqft;
  }, [convertedSqft, activeRule.structureType, storiesCount]);

  // Rate per sqft
  const effectiveRatePerSqft = useMemo(() => {
    if (customValuationRate && parseFloat(customValuationRate) > 0) {
      return parseFloat(customValuationRate);
    }
    return activeRule.ratePerSqft * wardLocationMultiplier;
  }, [customValuationRate, activeRule.ratePerSqft, wardLocationMultiplier]);

  // Calculations
  const calculations = useMemo(() => {
    // 1. Gross Annual Valuation (বাৎসরিক মোট ভাড়া বা মূল্যায়ন)
    const grossAnnualValuation = Math.round(totalFloorAreaSqft * effectiveRatePerSqft);

    // 2. Maintenance Exemption (রক্ষণাবেক্ষণ ও মেরামত বাবদ নির্ধারিত সরকারি ছাড়)
    const discountPercent = activeRule.defaultMaintenanceDiscountPercent;
    const maintenanceDiscountAmount = Math.round((grossAnnualValuation * discountPercent) / 100);

    // 3. Net Taxable Valuation (নিট বাৎসরিক করযোগ্য মূল্যায়ন)
    const netAnnualValuation = Math.max(0, grossAnnualValuation - maintenanceDiscountAmount);

    // 4. Current Year Tax Demand (চলতি অর্থবছরের ধার্যকৃত কর = নিট মূল্যায়নের ৫% বা ৭%)
    const taxRate = activeRule.taxRatePercent;
    const currentTaxDemand = Math.round((netAnnualValuation * taxRate) / 100);

    // 5. Previous Arrears Calculation (পূর্বের বকেয়া ও বিলম্ব সারচার্জ)
    let arrearsDue = 0;
    let surchargeAmount = 0;

    if (manualArrearsAmount && parseFloat(manualArrearsAmount) > 0) {
      arrearsDue = Math.round(parseFloat(manualArrearsAmount));
    } else if (unpaidYearsCount > 0) {
      // Arrears = Years × Current Tax Demand
      const baseArrears = unpaidYearsCount * currentTaxDemand;
      if (applySurcharge && unpaidYearsCount >= 2) {
        surchargeAmount = Math.round(baseArrears * 0.05); // 5% surcharge for >= 2 years
      }
      arrearsDue = baseArrears + surchargeAmount;
    }

    // 6. Total Demand (সর্বমোট প্রদেয় দাবি = চলতি কর + বকেয়া)
    const totalDemand = currentTaxDemand + arrearsDue;

    // 7. Early Bird Rebate (১৫ দিনের মধ্যে দিলে ৫% ছাড়)
    const rebateAmount = Math.round(currentTaxDemand * 0.05);
    const discountedTotalDemand = Math.max(0, totalDemand - rebateAmount);

    return {
      grossAnnualValuation,
      maintenanceDiscountAmount,
      discountPercent,
      netAnnualValuation,
      taxRate,
      currentTaxDemand,
      unpaidYearsCount,
      surchargeAmount,
      arrearsDue,
      totalDemand,
      rebateAmount,
      discountedTotalDemand
    };
  }, [
    totalFloorAreaSqft, 
    effectiveRatePerSqft, 
    activeRule.defaultMaintenanceDiscountPercent, 
    activeRule.taxRatePercent,
    unpaidYearsCount,
    applySurcharge,
    manualArrearsAmount
  ]);

  if (!isOpen) return null;

  // Handle Export Assessment Slip
  const handleDownloadAssessmentSlip = async () => {
    setIsExportingPdf(true);
    try {
      const fileName = `BUP_Tax_Assessment_Calculation_${assessmentOwnerName ? assessmentOwnerName.replace(/\s+/g, '_') : 'Holding'}`;
      const success = await downloadElementAsPDF('printable-tax-assessment-slip', fileName);
      if (!success) {
        alert('PDF তৈরিতে সমস্যা হয়েছে, অনুগ্রহ করে ব্রাউজার প্রিন্ট ব্যবহার করুন।');
      }
    } catch (err: any) {
      console.error(err);
      alert('ত্রুটি: ' + err.message);
    } finally {
      setIsExportingPdf(false);
    }
  };

  // Handle Apply to New Holding Registration
  const handleApplyToRegistration = () => {
    if (onApplyToNewHolding) {
      onApplyToNewHolding({
        holdingType: activeRule.holdingType,
        structureType: activeRule.structureType,
        annualValuation: calculations.netAnnualValuation,
        currentTaxDemand: calculations.currentTaxDemand,
        arrearsDue: calculations.arrearsDue,
        totalDemand: calculations.totalDemand,
        notes: `স্বয়ংক্রিয় অ্যাসেসমেন্ট: ${activeRule.label}, আয়তন: ${areaValue} ${areaUnit} (${totalFloorAreaSqft.toFixed(0)} বর্গফুট), তলা: ${storiesCount}`
      });
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fadeIn overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-3xl max-w-5xl w-full p-6 sm:p-8 shadow-2xl space-y-6 my-8 border border-slate-200 dark:border-slate-800">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <Calculator className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                হোল্ডিং ট্যাক্স ও বাৎসরিক কর মূল্যায়ন ক্যালকুলেটর
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                জমির শ্রেণি, আয়তন ও কাঠামোর ভিত্তিতে স্থানীয় সরকার (ইউপি) বিধি মোতাবেক নিখুঁত কর ও বকেয়া নির্ধারণ টুল
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setLandCategory('residential_semi_pucca');
                setAreaValue('800');
                setAreaUnit('sqft');
                setStoriesCount(1);
                setUnpaidYearsCount(1);
                setCustomValuationRate('');
                setManualArrearsAmount('');
              }}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer"
              title="রিসেট"
            >
              <RefreshCw className="w-3.5 h-3.5" /> রিসেট
            </button>
            <button 
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Grid: Inputs (Left) & Realtime Output Breakdown (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* ============================================================ */}
          {/* LEFT: INTERACTIVE PARAMETER CONTROLS (7 COLS) */}
          {/* ============================================================ */}
          <div className="lg:col-span-7 space-y-4">
            
            {/* 1. Land & Property Category Selector */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center justify-between">
                <span>১. জমির শ্রেণি ও স্থাপনার ধরন নির্বাচন করুন *</span>
                <span className="text-[11px] font-normal text-emerald-600 dark:text-emerald-400 font-mono">
                  {activeRule.taxRatePercent}% কর হার
                </span>
              </label>
              
              <select
                value={landCategory}
                onChange={(e) => setLandCategory(e.target.value as LandCategory)}
                className="w-full px-3.5 py-2.5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl text-xs font-bold text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500"
              >
                <optgroup label="বসতবাড়ি ও আবাসিক জমি (Residential)">
                  <option value="residential_kacha">বসতবাড়ি — কাঁচা / টিনের ঘর (৳২০/বর্গফুট)</option>
                  <option value="residential_semi_pucca">বসতবাড়ি — আধাপাকা টিনশেড দালান (৳৪০/বর্গফুট)</option>
                  <option value="residential_pucca_single">বসতবাড়ি — পাকা একতলা দালান (৳৭৫/বর্গফুট)</option>
                  <option value="residential_pucca_multi">বসতবাড়ি — বহুতল পাকা আবাসিক ভবন (৳১১০/বর্গফুট)</option>
                </optgroup>
                <optgroup label="বাণিজ্যিক ও ব্যবসা প্রতিষ্ঠান (Commercial)">
                  <option value="commercial_village_shop">বাণিজ্যিক — বাজার দোকান / মুদি / চায়ের স্টল (৳৯০/বর্গফুট)</option>
                  <option value="commercial_market_pucca">বাণিজ্যিক — পাকা মার্কেট ও আউটলেট (৳১৬০/বর্গফুট)</option>
                  <option value="commercial_shopping_complex">বাণিজ্যিক — বহুতল শপিং কমপ্লেক্স / কনভেনশন হল (৳২২০/বর্গফুট)</option>
                </optgroup>
                <optgroup label="শিল্প কারখানা ও কৃষি খামার (Industrial & Agro)">
                  <option value="industrial_rice_mill">শিল্প — রাইস মিল / হাসকিং মিল (৳১৩০/বর্গফুট)</option>
                  <option value="industrial_saw_mill">শিল্প — স-মিল ও কাঠ চেরাই কারখানা (৳১০০/বর্গফুট)</option>
                  <option value="industrial_poultry_agro">কৃষি খামার — পোল্ট্রি ফার্ম / ডেইরি ফার্ম / হ্যাচারি (৳৫০/বর্গফুট)</option>
                  <option value="industrial_heavy_factory">ভারী শিল্প — ইটভাটা / কোল্ড স্টোরেজ / কারখানা (৳১৮০/বর্গফুট)</option>
                </optgroup>
                <optgroup label="কৃষি জমি, জলাশয় ও বাগান (Agricultural)">
                  <option value="agricultural_crop_land">কৃষি জমি — নাল / ফসলি আবাদি জমি (৳৫/বর্গফুট বা ৳২২০/শতাংশ)</option>
                  <option value="agricultural_pond_fishery">বাণিজ্যিক পুকুর / মাছের খামার (৳১২/বর্গফুট বা ৳৫২০/শতাংশ)</option>
                  <option value="agricultural_orchard">ফলজ বাগান — আম/আনারস/মাল্টা বাগান (৳১৫/বর্গফুট বা ৳৬৫০/শতাংশ)</option>
                </optgroup>
                <optgroup label="প্রাতিষ্ঠানিক ও স্বাস্থ্য (Institutional)">
                  <option value="institutional_private_school">প্রতিষ্ঠান — বেসরকারি স্কুল / কিন্ডারগার্টেন / মাদ্রাসা (৳৬০/বর্গফুট)</option>
                  <option value="institutional_clinic_ngo">প্রতিষ্ঠান — প্রাইভেট ক্লিনিক / এনজিও অফিস (৳১৪০/বর্গফুট)</option>
                </optgroup>
              </select>

              <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 pt-0.5">
                <Info className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>{activeRule.description} (রক্ষণাবেক্ষণ ছাড়: {activeRule.defaultMaintenanceDiscountPercent}%)</span>
              </div>
            </div>

            {/* 2. Land Area Measurement & Unit */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                ২. জমি বা স্থাপনার আয়তন ও পরিমাপ *
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                    জমির পরিমাণের মান
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    value={areaValue}
                    onChange={(e) => setAreaValue(e.target.value)}
                    placeholder="উদা: 800"
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl text-sm font-bold text-emerald-600 dark:text-emerald-400 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                    পরিমাপের একক
                  </label>
                  <select
                    value={areaUnit}
                    onChange={(e) => setAreaUnit(e.target.value as AreaUnit)}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl text-xs font-semibold"
                  >
                    <option value="sqft">বর্গফুট (Square Feet - sqft)</option>
                    <option value="shotangsho">শতাংশ / ডেসিমাল (Shotangsho / Decimal)</option>
                    <option value="katha">কাঠা (Katha)</option>
                    <option value="bigha">বিঘা (Bigha)</option>
                  </select>
                </div>
              </div>

              {/* Area Quick Conversion Ribbon */}
              <div className="p-2.5 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-mono">
                <span className="text-slate-500">মোট কার্যকর আয়তন:</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {totalFloorAreaSqft.toLocaleString('bn-BD')} বর্গফুট ({convertedShotangsho} শতাংশ)
                </span>
              </div>
            </div>

            {/* 3. Building Stories & Ward Commercial Multiplier */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Stories Count */}
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1.5">
                <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                  ভবনের তলার সংখ্যা (Stories)
                </label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setStoriesCount(s)}
                      className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                        storiesCount === s
                          ? 'bg-emerald-600 text-white shadow-sm'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {s} তলা
                    </button>
                  ))}
                </div>
              </div>

              {/* Ward Location Growth Multiplier */}
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1.5">
                <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                  এলাকা / সড়কের অবস্থান
                </label>
                <select
                  value={wardLocationMultiplier}
                  onChange={(e) => setWardLocationMultiplier(parseFloat(e.target.value))}
                  className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl text-xs font-semibold"
                >
                  <option value={1.0}>সাধারণ গ্রাম্য এলাকা (১.০× স্ট্যান্ডার্ড)</option>
                  <option value={1.2}>পাকা ইউনিয়ন সংযোগ সড়ক (১.২× গুণক)</option>
                  <option value={1.4}>ইউনিয়ন পরিষদ বাজার সংলগ্ন (১.৪× গুণক)</option>
                  <option value={1.6}>উপজেলা প্রধান মহাসড়ক সংলগ্ন (১.৬× গুণক)</option>
                </select>
              </div>
            </div>

            {/* 4. Arrears & Unpaid Past Years Assessment */}
            <div className="p-4 bg-rose-50/60 dark:bg-rose-950/20 rounded-2xl border border-rose-200 dark:border-rose-900/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-rose-900 dark:text-rose-300 flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4" /> ৩. পূর্বের বকেয়া ও বিলম্ব সারচার্জ হিসাব
                </span>
                <span className="text-[11px] text-rose-700 dark:text-rose-400">
                  অনাদায়ী বছর: {unpaidYearsCount} বছর
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-700 dark:text-slate-300 mb-1">
                    বকেয়া অর্থবছরের সংখ্যা
                  </label>
                  <select
                    value={unpaidYearsCount}
                    onChange={(e) => {
                      setUnpaidYearsCount(parseInt(e.target.value));
                      setManualArrearsAmount('');
                    }}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-rose-300 dark:border-rose-800 rounded-xl text-xs font-bold text-rose-700 dark:text-rose-300"
                  >
                    <option value={0}>কোনো পূর্বের বকেয়া নাই (০ বছর)</option>
                    <option value={1}>১ বছর বকেয়া (পূর্বের অর্থবছর)</option>
                    <option value={2}>২ বছর বকেয়া (+৫% বিলম্ব ফি)</option>
                    <option value={3}>৩ বছর বকেয়া (+৫% বিলম্ব ফি)</option>
                    <option value={4}>৪ বছর বকেয়া (+৫% বিলম্ব ফি)</option>
                    <option value={5}>৫ বছর বা ততোধিক বকেয়া</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-700 dark:text-slate-300 mb-1">
                    অথবা নির্দিষ্ট বকেয়া টাকা (যদি থাকে)
                  </label>
                  <input
                    type="number"
                    value={manualArrearsAmount}
                    onChange={(e) => setManualArrearsAmount(e.target.value)}
                    placeholder="উদা: 2500"
                    className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-rose-300 dark:border-rose-800 rounded-xl text-xs font-mono font-bold text-rose-600"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <input
                  type="checkbox"
                  id="checkbox-apply-surcharge"
                  checked={applySurcharge}
                  onChange={(e) => setApplySurcharge(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="checkbox-apply-surcharge" className="text-[11px] text-slate-600 dark:text-slate-400 cursor-pointer">
                  ২ বা ততোধিক বছরের বকেয়ায় সরকারি ৫% বিলম্ব সারচার্জ স্বয়ংক্রিয়ভাবে যোগ করুন
                </label>
              </div>
            </div>

          </div>

          {/* ============================================================ */}
          {/* RIGHT: REALTIME CALCULATION BREAKDOWN & RESULT (5 COLS) */}
          {/* ============================================================ */}
          <div className="lg:col-span-5 space-y-4 flex flex-col justify-between">
            
            {/* Calculation Card */}
            <div className="bg-gradient-to-br from-slate-900 to-emerald-950 text-white p-5 rounded-3xl border border-emerald-800/40 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-emerald-800/50 pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-amber-400" />
                  <span className="font-bold text-sm text-emerald-300 uppercase tracking-wider">
                    স্বয়ংক্রিয় কর মূল্যায়ন সারাংশ
                  </span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {config.upName}
                </span>
              </div>

              {/* Itemized Calculation Math */}
              <div className="space-y-2.5 text-xs text-slate-300">
                
                {/* Gross Annual Valuation */}
                <div className="flex justify-between items-center py-1 border-b border-slate-800">
                  <span className="text-slate-400">বাৎসরিক মোট ভাড়া মূল্যায়ন:</span>
                  <span className="font-mono font-bold text-white text-sm">
                    ৳{calculations.grossAnnualValuation.toLocaleString('bn-BD')}
                  </span>
                </div>

                {/* Maintenance Deduction */}
                <div className="flex justify-between items-center py-1 border-b border-slate-800 text-amber-300">
                  <span>(-) মেরামত ও রক্ষণাবেক্ষণ ছাড় ({calculations.discountPercent}%):</span>
                  <span className="font-mono font-bold">
                    -৳{calculations.maintenanceDiscountAmount.toLocaleString('bn-BD')}
                  </span>
                </div>

                {/* Net Annual Valuation */}
                <div className="flex justify-between items-center py-1 border-b border-slate-800 font-semibold text-slate-200">
                  <span>(=) নিট করযোগ্য বার্ষিক মূল্যায়ন:</span>
                  <span className="font-mono text-emerald-300 font-bold">
                    ৳{calculations.netAnnualValuation.toLocaleString('bn-BD')}
                  </span>
                </div>

                {/* Current Year Demand */}
                <div className="flex justify-between items-center py-1.5 border-b border-slate-800 text-emerald-400 font-bold text-xs bg-emerald-950/40 px-2 rounded-lg">
                  <span>চলতি বাৎসরিক হোল্ডিং কর ({calculations.taxRate}%):</span>
                  <span className="font-mono text-sm">
                    ৳{calculations.currentTaxDemand.toLocaleString('bn-BD')}
                  </span>
                </div>

                {/* Arrears Amount */}
                <div className="flex justify-between items-center py-1 border-b border-slate-800 text-rose-300">
                  <span>(+) পূর্বের অনাদায়ী বকেয়া ও সারচার্জ:</span>
                  <span className="font-mono font-bold">
                    ৳{calculations.arrearsDue.toLocaleString('bn-BD')}
                  </span>
                </div>
              </div>

              {/* Total Grand Demand Box */}
              <div className="p-4 bg-emerald-900/60 rounded-2xl border border-emerald-500/30 space-y-1">
                <div className="text-[11px] font-bold text-emerald-200 uppercase tracking-wider">
                  সর্বমোট করের দাবি (Total Demand)
                </div>
                <div className="text-3xl font-black text-white flex items-baseline gap-1">
                  <span>৳{calculations.totalDemand.toLocaleString('bn-BD')}</span>
                  <span className="text-xs font-normal text-emerald-300">/ টাকা</span>
                </div>
                {calculations.rebateAmount > 0 && (
                  <div className="text-[11px] text-amber-300 font-medium pt-1 border-t border-emerald-800/60 flex justify-between">
                    <span>*এককালীন ১৫ দিনে দিলে (৫% রিবেট):</span>
                    <strong className="text-white">৳{calculations.discountedTotalDemand.toLocaleString('bn-BD')}/-</strong>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Actions (Apply to New Holding & Print Calculation Slip) */}
            <div className="space-y-2.5 pt-2">
              {onApplyToNewHolding && (
                <button
                  id="btn-apply-assessment-to-registration"
                  onClick={handleApplyToRegistration}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-xs font-bold shadow-lg shadow-emerald-950/40 flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  নতুন হোল্ডিং ফর্মে এই হিসাব প্রয়োগ করুন
                </button>
              )}

              <button
                id="btn-download-assessment-slip-pdf"
                onClick={handleDownloadAssessmentSlip}
                disabled={isExportingPdf}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-2xl text-xs font-semibold flex items-center justify-center gap-2 transition cursor-pointer border border-slate-700"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                অ্যাসেসমেন্ট স্লিপ PDF ডাউনলোড করুন
              </button>
            </div>

          </div>

        </div>

        {/* Hidden Printable Assessment Calculation Sheet (for PDF Generation & Direct Print) */}
        <div className="hidden">
          <div 
            id="printable-tax-assessment-slip"
            className="p-8 bg-white text-slate-900 font-sans space-y-6 max-w-2xl mx-auto border-4 border-double border-emerald-800 rounded-2xl"
          >
            <div className="text-center space-y-1 border-b-2 border-emerald-800 pb-3">
              <div className="text-xs font-bold uppercase tracking-widest text-emerald-800">
                গণপ্রজাতন্ত্রী বাংলাদেশ সরকার
              </div>
              <h2 className="text-2xl font-black text-emerald-950">{config.upName}</h2>
              <div className="text-xs text-slate-600">
                উপজেলা: {config.upazila}, জেলা: {config.district} | রাজস্ব সেল
              </div>
              <div className="inline-block mt-1 px-5 py-0.5 rounded-full bg-emerald-800 text-white font-bold text-xs">
                হোল্ডিং কর নির্ধারণ ও বাৎসরিক মূল্যায়ন বিবরণী স্লিপ
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-xl border border-slate-300">
              <div><strong>জমির শ্রেণি:</strong> {activeRule.label}</div>
              <div><strong>তারিখ:</strong> {new Date().toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' })}</div>
              <div><strong>কার্যকর আয়তন:</strong> {totalFloorAreaSqft.toFixed(0)} বর্গফুট ({convertedShotangsho} শতাংশ)</div>
              <div><strong>তলার সংখ্যা:</strong> {storiesCount} তলা</div>
            </div>

            <table className="w-full text-xs border border-slate-300">
              <tbody>
                <tr className="border-b border-slate-200 bg-slate-100">
                  <td className="p-2 font-bold">বাৎসরিক মোট ভাড়া মূল্যায়ন:</td>
                  <td className="p-2 text-right font-bold">৳{calculations.grossAnnualValuation.toLocaleString('bn-BD')}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-2">(-) সরকারি মেরামত ও রক্ষণাবেক্ষণ ছাড় ({calculations.discountPercent}%):</td>
                  <td className="p-2 text-right text-rose-700">-৳{calculations.maintenanceDiscountAmount.toLocaleString('bn-BD')}</td>
                </tr>
                <tr className="border-b border-slate-200 bg-slate-50 font-bold">
                  <td className="p-2">(=) নিট করযোগ্য বাৎসরিক মূল্যায়ন:</td>
                  <td className="p-2 text-right font-mono">৳{calculations.netAnnualValuation.toLocaleString('bn-BD')}</td>
                </tr>
                <tr className="border-b border-slate-200 bg-emerald-50 text-emerald-950 font-bold">
                  <td className="p-2">চলতি অর্থবছরের বাৎসরিক কর ({calculations.taxRate}%):</td>
                  <td className="p-2 text-right font-mono">৳{calculations.currentTaxDemand.toLocaleString('bn-BD')}</td>
                </tr>
                <tr className="border-b border-slate-200 text-rose-800">
                  <td className="p-2">(+) পূর্ববর্তী {calculations.unpaidYearsCount} বছরের বকেয়া ও বিলম্ব ফি:</td>
                  <td className="p-2 text-right font-mono font-bold">৳{calculations.arrearsDue.toLocaleString('bn-BD')}</td>
                </tr>
                <tr className="bg-emerald-900 text-white font-black text-sm">
                  <td className="p-2.5">সর্বমোট ধার্যকৃত করের দাবি (Total Demand):</td>
                  <td className="p-2.5 text-right font-mono">৳{calculations.totalDemand.toLocaleString('bn-BD')}/-</td>
                </tr>
              </tbody>
            </table>

            <div className="flex justify-between items-end pt-6 border-t border-slate-300 text-xs">
              <div className="text-[10px] text-slate-500">
                *এই স্লিপটি স্থানীয় সরকার (ইউনিয়ন পরিষদ) ট্যাক্স বিধিমালা অনুযায়ী সফটওয়্যারের মাধ্যমে প্রস্তুতকৃত।
              </div>
              <div className="text-center space-y-1">
                <div className="w-32 border-b border-slate-400 mx-auto" />
                <div className="font-bold text-slate-800">অ্যাসেসমেন্ট কর্মকর্তা</div>
                <div className="text-[9px] text-slate-500">{config.upName}</div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
