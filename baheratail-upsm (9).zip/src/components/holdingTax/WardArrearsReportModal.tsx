import React, { useState, useEffect } from 'react';
import { 
  X, 
  Download, 
  Printer, 
  FileText, 
  ShieldCheck, 
  Landmark, 
  Loader2, 
  Building2,
  Calendar,
  AlertTriangle,
  QrCode,
  CheckCircle2
} from 'lucide-react';
import { HoldingTaxRecord, UnionParishadConfig, HoldingTaxWardSummary } from '../../types';
import { downloadElementAsPDF, generateWardReportQRCode } from '../../utils/taxReceiptPdf';

interface WardArrearsReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  wardNo: string;
  onWardChange: (ward: string) => void;
  records: HoldingTaxRecord[];
  wardSummaries: HoldingTaxWardSummary[];
  config: UnionParishadConfig;
  fiscalYear: string;
}

export const WardArrearsReportModal: React.FC<WardArrearsReportModalProps> = ({
  isOpen,
  onClose,
  wardNo,
  onWardChange,
  records,
  wardSummaries,
  config,
  fiscalYear
}) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const [holdingTypeFilter, setHoldingTypeFilter] = useState<string>('all');

  // Filter records for the target ward and arrears only
  const wardRecords = React.useMemo(() => {
    let list = records.filter(r => (r.currentDue || 0) > 0);
    if (wardNo !== 'all') {
      list = list.filter(r => r.wardNo === wardNo);
    }
    if (holdingTypeFilter !== 'all') {
      list = list.filter(r => r.holdingType === holdingTypeFilter);
    }
    return list;
  }, [records, wardNo, holdingTypeFilter]);

  // Ward summary details
  const activeWardSummary = React.useMemo(() => {
    if (wardNo === 'all') return null;
    return wardSummaries.find(w => w.wardNo === wardNo) || null;
  }, [wardSummaries, wardNo]);

  // Calculate totals
  const totalDemand = wardRecords.reduce((sum, r) => sum + (r.totalDemand || 0), 0);
  const totalCollected = wardRecords.reduce((sum, r) => sum + (r.paidAmount || 0), 0);
  const totalDue = wardRecords.reduce((sum, r) => sum + (r.currentDue || 0), 0);
  const residentialDue = wardRecords.filter(r => r.holdingType === 'residential').reduce((sum, r) => sum + (r.currentDue || 0), 0);
  const commercialDue = wardRecords.filter(r => r.holdingType === 'commercial').reduce((sum, r) => sum + (r.currentDue || 0), 0);

  // Generate QR code for the report
  useEffect(() => {
    if (isOpen) {
      generateWardReportQRCode(wardNo, fiscalYear, totalDue).then(url => setQrCodeUrl(url));
    }
  }, [isOpen, wardNo, fiscalYear, totalDue]);

  if (!isOpen) return null;

  const handleDownloadPDF = async () => {
    setIsDownloading(true);
    try {
      const fileName = `BUP_Tax_Arrears_Report_${wardNo !== 'all' ? `Ward_${wardNo}` : 'All_Wards'}_${fiscalYear}`;
      const success = await downloadElementAsPDF('printable-ward-arrears-report-sheet', fileName);
      if (!success) {
        alert('PDF জেনারেশনে সমস্যা হয়েছে, অনুগ্রহ করে প্রিন্ট অপশনটি ব্যবহার করুন।');
      }
    } catch (err: any) {
      console.error(err);
      alert('ত্রুটি: ' + err.message);
    } finally {
      setIsDownloading(false);
    }
  };

  const todayBn = new Date().toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fadeIn overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-3xl max-w-5xl w-full p-6 sm:p-8 shadow-2xl space-y-6 my-8 border border-slate-200 dark:border-slate-800">
        {/* Top Control Bar (Hidden on print) */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4 print:hidden">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-rose-500/10 text-rose-600 dark:text-rose-400">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-lg flex items-center gap-2">
                বকেয়া হোল্ডিং ট্যাক্স সারাংশ প্রতিবেদন (PDF Export Report)
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {wardNo !== 'all' ? `ওয়ার্ড নং ${wardNo}-এর ` : 'সকল ওয়ার্ডের '}
                মোট {wardRecords.length} জন বকেয়া করদাতার অফিশিয়াল রিপোর্ট
              </p>
            </div>
          </div>

          {/* Action Buttons & Ward Select */}
          <div className="flex flex-wrap items-center gap-2.5">
            <select
              value={wardNo}
              onChange={(e) => onWardChange(e.target.value)}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-emerald-700 dark:text-emerald-300"
            >
              <option value="all">সকল ওয়ার্ড (১ হতে ৯)</option>
              {['০১', '০২', '০৩', '০৪', '০৫', '০৬', '০৭', '০৮', '০৯'].map(w => (
                <option key={w} value={w}>ওয়ার্ড নং {w}</option>
              ))}
            </select>

            <select
              value={holdingTypeFilter}
              onChange={(e) => setHoldingTypeFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium"
            >
              <option value="all">সকল ধরন</option>
              <option value="residential">শুধুমাত্র বসতবাড়ি</option>
              <option value="commercial">শুধুমাত্র ব্যবসা প্রতিষ্ঠান</option>
            </select>

            <button
              id="btn-confirm-download-pdf-report"
              onClick={handleDownloadPDF}
              disabled={isDownloading}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5 transition active:scale-95 cursor-pointer disabled:opacity-50"
            >
              {isDownloading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>PDF তৈরি হচ্ছে...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>PDF রিপোর্ট ডাউনলোড</span>
                </>
              )}
            </button>

            <button
              onClick={() => window.print()}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold shadow flex items-center gap-1.5 transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>প্রিন্ট</span>
            </button>

            <button 
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Report Sheet Content */}
        <div 
          id="printable-ward-arrears-report-sheet"
          className="bg-white text-slate-900 p-6 sm:p-8 rounded-2xl border-4 border-double border-emerald-900 space-y-6 shadow-sm relative overflow-hidden"
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b-2 border-emerald-900 pb-4 gap-4">
            <div className="flex-shrink-0">
              <img 
                src={config.logoUrl || '/baheratail_seal.svg'} 
                alt="Union Parishad Logo" 
                className="w-16 h-16 sm:w-20 sm:h-20 object-contain rounded-full border border-emerald-900/30 p-1 bg-white shadow-xs"
                crossOrigin="anonymous"
              />
            </div>
            <div className="text-center flex-1 space-y-1">
              <div className="text-[11px] font-bold uppercase tracking-widest text-emerald-800">
                গণপ্রজাতন্ত্রী বাংলাদেশ সরকার
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-emerald-950">{config.upName}</h2>
              <div className="text-xs text-slate-600 font-medium">
                উপজেলা: {config.upazila}, জেলা: {config.district} | ই-মেইল: {config.email}
              </div>
              <div className="inline-block mt-1.5 px-6 py-1 rounded-full bg-rose-900 text-white font-bold text-xs tracking-wider shadow-sm">
                {wardNo !== 'all' ? `ওয়ার্ড নং ${wardNo} — ` : 'ইউনিয়ন পরিষদের '} 
                অনাদায়ী ও বকেয়া হোল্ডিং ট্যাক্স সারাংশ প্রতিবেদন
              </div>
            </div>
            <div className="hidden sm:flex flex-col items-center justify-center p-2 rounded-xl bg-slate-50 border border-slate-200 text-center w-20">
              <span className="text-[10px] font-bold text-slate-500 uppercase">অর্থবছর</span>
              <span className="text-xs font-black text-emerald-900">{fiscalYear}</span>
            </div>
          </div>

          {/* Memo & Meta Details */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-300 text-xs">
            <div>
              <span className="text-slate-500 block">স্মারক নম্বর:</span>
              <span className="font-mono font-bold text-emerald-900">বইউপি/কর/রিপোর্ট/২০২৬/{wardNo}</span>
            </div>
            <div>
              <span className="text-slate-500 block">অর্থবছর:</span>
              <span className="font-bold text-slate-900">{fiscalYear}</span>
            </div>
            <div>
              <span className="text-slate-500 block">প্রতিবেদন তৈরির তারিখ:</span>
              <span className="font-semibold text-slate-900">{todayBn}</span>
            </div>
            <div>
              <span className="text-slate-500 block">আওতাভুক্ত এলাকা:</span>
              <span className="font-semibold text-slate-900">
                {activeWardSummary ? activeWardSummary.villages.join(', ') : 'সকল গ্রাম (১-৯ ওয়ার্ড)'}
              </span>
            </div>
          </div>

          {/* KPI Summary Block for Report */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center text-xs">
            <div className="p-3 bg-slate-100/80 rounded-xl border border-slate-300">
              <span className="text-slate-600 block text-[11px]">মোট বকেয়া হোল্ডিং</span>
              <span className="text-lg font-black text-slate-900">{wardRecords.length} টি</span>
            </div>
            <div className="p-3 bg-purple-50 rounded-xl border border-purple-200">
              <span className="text-purple-700 block text-[11px]">ধার্যকৃত সর্বমোট দাবি</span>
              <span className="text-lg font-black text-purple-900">৳{totalDemand.toLocaleString('bn-BD')}</span>
            </div>
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
              <span className="text-emerald-700 block text-[11px]">আদায়কৃত অর্থ</span>
              <span className="text-lg font-black text-emerald-900">৳{totalCollected.toLocaleString('bn-BD')}</span>
            </div>
            <div className="p-3 bg-rose-50 rounded-xl border border-rose-300">
              <span className="text-rose-700 block text-[11px]">সর্বমোট বকেয়া পরিমাণ</span>
              <span className="text-lg font-black text-rose-900">৳{totalDue.toLocaleString('bn-BD')}</span>
            </div>
          </div>

          {/* Arrears Sub-breakdown */}
          <div className="flex flex-wrap items-center justify-between text-xs px-2 text-slate-600">
            <div>
              * বসতবাড়ি বকেয়া: <strong className="text-slate-900">৳{residentialDue.toLocaleString('bn-BD')}</strong> | ব্যবসা প্রতিষ্ঠান বকেয়া: <strong className="text-slate-900">৳{commercialDue.toLocaleString('bn-BD')}</strong>
            </div>
            <div>
              * অনাদায়ী তালিকার মোট সদস্য: <strong className="text-rose-800">{wardRecords.length} জন করদাতা</strong>
            </div>
          </div>

          {/* Defaulters Table */}
          <div className="border border-slate-300 rounded-xl overflow-hidden text-xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300 text-[11px]">
                  <th className="py-2.5 px-3 text-center w-10">ক্র:</th>
                  <th className="py-2.5 px-3">হোল্ডিং নং</th>
                  <th className="py-2.5 px-3">করদাতার নাম ও অভিভাবক</th>
                  <th className="py-2.5 px-3">গ্রাম ও ওয়ার্ড</th>
                  <th className="py-2.5 px-3">ধরন</th>
                  <th className="py-2.5 px-3 text-right">চলতি দাবি</th>
                  <th className="py-2.5 px-3 text-right">আদায়কৃত</th>
                  <th className="py-2.5 px-3 text-right">বকেয়া (৳)</th>
                  <th className="py-2.5 px-3 text-center">মোবাইল</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {wardRecords.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-8 text-center text-slate-500">
                      নির্বাচিত ওয়ার্ডে কোনো বকেয়া করদাতা পাওয়া যায় নাই।
                    </td>
                  </tr>
                ) : (
                  wardRecords.map((r, index) => (
                    <tr key={r.id} className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 text-center font-semibold text-slate-500">{index + 1}</td>
                      <td className="py-2 px-3 font-mono font-bold text-emerald-950 whitespace-nowrap">{r.holdingNo}</td>
                      <td className="py-2 px-3">
                        <div className="font-bold text-slate-900">{r.ownerName}</div>
                        <div className="text-[10px] text-slate-500">পিতা/স্বামী: {r.guardianName}</div>
                      </td>
                      <td className="py-2 px-3 whitespace-nowrap">
                        <div className="text-slate-800">{r.village}</div>
                        <div className="text-[10px] text-slate-500">ওয়ার্ড নং {r.wardNo}</div>
                      </td>
                      <td className="py-2 px-3 whitespace-nowrap">
                        <span className="text-[10px] font-semibold text-slate-700">
                          {r.holdingType === 'residential' ? 'বসতবাড়ি' : 'ব্যবসা প্রতিষ্ঠান'}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right text-slate-800 whitespace-nowrap">৳{r.totalDemand}</td>
                      <td className="py-2 px-3 text-right text-emerald-700 font-semibold whitespace-nowrap">৳{r.paidAmount}</td>
                      <td className="py-2 px-3 text-right font-bold text-rose-700 whitespace-nowrap">৳{r.currentDue}</td>
                      <td className="py-2 px-3 text-center font-mono text-[10px] text-slate-600 whitespace-nowrap">
                        {r.mobile || '-'}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              <tfoot>
                <tr className="bg-slate-100 text-slate-900 font-bold border-t-2 border-slate-300">
                  <td colSpan={5} className="py-2.5 px-3 text-right uppercase">সর্বমোট বকেয়ার পরিমাণ (Grand Total):</td>
                  <td className="py-2.5 px-3 text-right">৳{totalDemand.toLocaleString('bn-BD')}</td>
                  <td className="py-2.5 px-3 text-right text-emerald-800">৳{totalCollected.toLocaleString('bn-BD')}</td>
                  <td className="py-2.5 px-3 text-right text-rose-900 font-black text-sm">৳{totalDue.toLocaleString('bn-BD')}</td>
                  <td className="py-2.5 px-3 text-center text-[10px] text-slate-500">{wardRecords.length} জন</td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Footer with QR Code & Official Signatures */}
          <div className="flex items-end justify-between pt-6 border-t-2 border-slate-300 text-xs">
            {/* QR Section */}
            <div className="flex items-center gap-3">
              {qrCodeUrl ? (
                <img 
                  src={qrCodeUrl} 
                  alt="Report QR Verification" 
                  className="w-20 h-20 border-2 border-emerald-800 p-1 rounded-xl bg-white shadow-sm"
                />
              ) : (
                <div className="w-20 h-20 border border-slate-300 rounded-xl flex items-center justify-center bg-slate-100">
                  <QrCode className="w-8 h-8 text-slate-400" />
                </div>
              )}
              <div className="space-y-0.5">
                <div className="font-bold text-emerald-950 flex items-center gap-1">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" /> ডিজিটাল রাজস্ব অডিট ও ভেরিফিকেশন QR
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  যাচাই লিংক: bup-gov.bd/tax/report
                </div>
                <div className="text-[10px] text-slate-400">
                  *এই রিপোর্টটি স্বয়ংক্রিয় ডিজিটাল ইউনিয়ন অটোমেশন ডাটাবেজ থেকে সংকলিত
                </div>
              </div>
            </div>

            {/* Official Signatures */}
            <div className="flex items-center gap-8 text-center">
              <div className="space-y-1">
                <div className="w-32 border-b border-slate-500 mx-auto" />
                <div className="font-bold text-slate-800 text-[11px]">ইউপি সচিব / উদ্যোক্তা</div>
                <div className="text-[9px] text-slate-500">{config.upName}</div>
              </div>

              <div className="space-y-1">
                <div className="w-32 border-b border-slate-500 mx-auto" />
                <div className="font-bold text-slate-900 text-[11px]">{config.chairmanName}</div>
                <div className="text-[9px] text-slate-600">চেয়ারম্যান, {config.upName}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Close / Action */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800 print:hidden text-xs">
          <button
            onClick={handleDownloadPDF}
            disabled={isDownloading}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow flex items-center gap-1.5 transition cursor-pointer"
          >
            <Download className="w-4 h-4" />
            PDF রিপোর্ট ডাউনলোড করুন
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-semibold cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
