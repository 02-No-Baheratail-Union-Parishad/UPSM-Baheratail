import { CertificateTypeConfig } from '../types';

export const CERTIFICATE_TYPES: CertificateTypeConfig[] = [
  // ১. নাগরিকত্ব ও সাধারণ চারিত্রিক (1-7)
  {
    key: 'citizenship',
    label: 'নাগরিকত্ব সনদপত্র',
    category: 'নাগরিকত্ব ও পরিচয়',
    promptInstruction: 'উক্ত নাগরিক বাংলাদেশের জন্মসূত্রে একজন স্থায়ী নাগরিক এবং সুনামের সহিত বসবাস করিয়া আসিতেছেন।',
    simpleFields: [
      { key: 'voterNo', label: 'ভোটার নম্বর (যদি থাকে)', placeholder: 'ঐচ্ছিক' }
    ]
  },
  {
    key: 'character',
    label: 'চারিত্রিক সনদপত্র',
    category: 'নাগরিকত্ব ও পরিচয়',
    promptInstruction: 'উক্ত ব্যক্তি সৎ, চরিত্রবান ও শান্ত স্বভাবের লোক। তাহার বিরুদ্ধে রাষ্ট্র ও সমাজবিরোধী কোনো কার্যকলাপের রেকর্ড নাই।',
    simpleFields: [
      { key: 'purpose', label: 'সনদের উদ্দেশ্য', placeholder: 'যেমন: চাকরির আবেদনের জন্য' }
    ]
  },
  {
    key: 'provisional_id',
    label: 'সাময়িক পরিচিতি সনদপত্র',
    category: 'নাগরিকত্ব ও পরিচয়',
    promptInstruction: 'এনআইডি বা জন্ম সনদ প্রক্রিয়াধীন থাকায় তাহার সাময়িক পরিচিতি নিশ্চিত করা হইতেছে।',
    simpleFields: [
      { key: 'regNo', label: 'স্মারক / ভোটার ফরম নম্বর', placeholder: 'যেমন: ১০২৪৫' }
    ]
  },
  {
    key: 'permanent_resident',
    label: 'স্থায়ী বাসিন্দা সনদপত্র',
    category: 'নাগরিকত্ব ও পরিচয়',
    promptInstruction: 'উক্ত ব্যক্তি উক্ত গ্রামে দীর্ঘদিন যাবৎ স্থায়ীভাবে পরিবার পরিজনসহ বসবাস করিয়া আসিতেছেন।',
  },
  {
    key: 'same_person',
    label: 'একই ব্যক্তি প্রত্যয়নপত্র',
    category: 'নাগরিকত্ব ও পরিচয়',
    promptInstruction: 'আবেদনকারীর দলিল, এনআইডি ও শিক্ষাগত যোগ্যতার সনদে নামের ভিন্নতা থাকিলেও উভয়ে একই ব্যক্তি।',
    simpleFields: [
      { key: 'nameInNid', label: 'এনআইডি অনুযায়ী নাম', placeholder: 'যেমন: মোঃ আব্দুর রহিম' },
      { key: 'nameInCert', label: 'সনদ/দলিলে নাম', placeholder: 'যেমন: আব্দুর রহিম' }
    ]
  },
  {
    key: 'nationality_attestation',
    label: 'জাতীয়তা সত্যায়ন প্রত্যয়নপত্র',
    category: 'নাগরিকত্ব ও পরিচয়',
    promptInstruction: 'উক্ত ব্যক্তি জন্মসূত্রে বাংলাদেশের নাগরিক এবং অত্র ইউনিয়নের সুনামধন্য আদি অধিবাসী।',
    simpleFields: [
      { key: 'purpose', label: 'ব্যবহারের ক্ষেত্র', placeholder: 'যেমন: জাতীয় পাসপোর্ট ও ভিসা প্রাপ্তি' }
    ]
  },
  {
    key: 'good_conduct',
    label: 'সচ্চরিত্র ও সমাজসেবা প্রত্যয়ন',
    category: 'নাগরিকত্ব ও পরিচয়',
    promptInstruction: 'উক্ত নাগরিক সামাজিক কর্মকাণ্ডে নিবেদিত এবং একজন উত্তম চরিত্রের অধিকারী। তাহার স্বভাব প্রশংসনীয়।',
    simpleFields: [
      { key: 'socialWork', label: 'সামাজিক অবদান', placeholder: 'যেমন: যুব উন্নয়ন ও ক্রীড়া সংগঠক' }
    ]
  },

  // ২. পরিবার ও উত্তরাধিকার (8-15)
  {
    key: 'warish',
    label: 'ওয়ারিশান / উত্তরাধিকার সনদপত্র',
    category: 'উত্তরাধিকার ও পরিবার',
    promptInstruction: 'উক্ত মৃত ব্যক্তির মৃত্যুর সময় নিম্নলিখিত ওয়ারিশগণ জীবিত রহিয়াছেন। তাহারা ব্যতীত অন্য কোনো ওয়ারিশ নাই।',
    simpleFields: [
      { key: 'deceasedName', label: 'মৃত ব্যক্তির নাম', required: true },
      { key: 'deathDate', label: 'মৃত্যুর তারিখ', placeholder: 'যেমন: ১২/০৫/২০২৩' },
      { key: 'relationWithApplicant', label: 'আবেদনকারীর সাথে সম্পর্ক', placeholder: 'যেমন: পুত্র' }
    ],
    tables: [
      {
        key: 'warish_list',
        title: 'ওয়ারিশগণের তালিকা (উত্তরাধিকার)',
        headers: ['ক্রমিক নং', 'নাম', 'জাতীয় পরিচয় পত্র নং', 'জন্ম তারিখ', 'সম্পর্ক', 'মন্তব্য']
      }
    ]
  },
  {
    key: 'family_certificate',
    label: 'পারিবারিক সনদপত্র',
    category: 'উত্তরাধিকার ও পরিবার',
    promptInstruction: 'আবেদনকারীর পরিবারে নিম্নলিখিত সদস্যগণ একত্রে বসবাস করিয়া আসিতেছেন।',
    simpleFields: [
      { key: 'headOfFamily', label: 'পরিবার প্রধানের নাম' }
    ],
    tables: [
      {
        key: 'family_list',
        title: 'পরিবারের সদস্যদের তালিকা',
        headers: ['ক্রমিক নং', 'নাম', 'জাতীয় পরিচয় পত্র নং', 'জন্ম তারিখ', 'সম্পর্ক', 'মন্তব্য']
      }
    ]
  },
  {
    key: 'deceased_warish',
    label: 'মৃত ব্যক্তির ওয়ারিশ সনদ',
    category: 'উত্তরাধিকার ও পরিবার',
    promptInstruction: 'উক্ত মৃত ব্যক্তি তাহার মৃত্যুর সময় নিম্নলিখিত প্রকৃত আইনি ওয়ারিশগণকে রাখিয়া মৃত্যুবরণ করিয়াছেন।',
    simpleFields: [
      { key: 'deceasedName', label: 'মৃত ব্যক্তির নাম', required: true },
      { key: 'deathPlace', label: 'মৃত্যুর স্থান', placeholder: 'যেমন: নিজ গৃহ' }
    ],
    tables: [
      {
        key: 'deceased_warish_list',
        title: 'জীবিত ওয়ারিশগণের বিবরণ',
        headers: ['ক্রমিক নং', 'নাম', 'জাতীয় পরিচয় পত্র নং', 'জন্ম তারিখ', 'সম্পর্ক', 'মন্তব্য']
      }
    ]
  },
  {
    key: 'guardianship',
    label: 'অভিভাবকত্ব সনদপত্র',
    category: 'উত্তরাধিকার ও পরিবার',
    promptInstruction: 'আবেদনকারী তাহার পিতা/মাতার অনুপস্থিতিতে পরিবার ও নাবালকদের আইনানুগ অভিভাবক হিসেবে দায়িত্ব পালন করিতেছেন।',
    simpleFields: [
      { key: 'wardName', label: 'যার অভিভাবক (নাম)', placeholder: 'নাবালকের নাম' },
      { key: 'relation', label: 'সম্পর্ক', placeholder: 'যেমন: চাচা / জ্যেষ্ঠ ভ্রাতা' }
    ]
  },
  {
    key: 'heirship_proof',
    label: 'জমি সংক্রান্ত উত্তরাধিকার প্রত্যয়ন',
    category: 'উত্তরাধিকার ও পরিবার',
    promptInstruction: 'উক্ত জমির মালিকের মৃত্যুর পর তাহার বৈধ ওয়ারিশগণ যৌথ মালিকানা লাভ করিয়াছেন।',
    simpleFields: [
      { key: 'landOwner', label: 'মূল জমির মালিকের নাম' },
      { key: 'khatianNo', label: 'খতিয়ান/দাগ নং (যদি থাকে)', placeholder: 'যেমন: খতিয়ান ১২৩, দাগ ৪৫৬' }
    ]
  },
  {
    key: 'separation_of_family',
    label: 'পৃথকান্ন / পৃথক পরিবার প্রত্যয়নপত্র',
    category: 'উত্তরাধিকার ও পরিবার',
    promptInstruction: 'উক্ত ব্যক্তি তাহার যৌথ পরিবার হইতে পৃথক হইয়া পৃথক হাঁড়ি-পাতি ও খরচে আলাদা পরিবার পরিচালনা করিতেছেন।',
    simpleFields: [
      { key: 'parentOrBrotherName', label: 'মূল যৌথ পরিবারের প্রধান', placeholder: 'যেমন: পিতার নাম' },
      { key: 'separatedSince', label: 'পৃথক হওয়ার বছর', placeholder: 'যেমন: ২০২২ ইং হইতে' }
    ]
  },
  {
    key: 'dependent_attestation',
    label: 'পোষ্য / নির্ভরশীল প্রত্যয়নপত্র',
    category: 'উত্তরাধিকার ও পরিবার',
    promptInstruction: 'উক্ত নাগরিক তাহার পিতা/অভিভাবকের আয়ের উপর সম্পূর্ণ নির্ভরশীল এবং তাহার কোনো নিজস্ব রোজগার নাই।',
    simpleFields: [
      { key: 'guardianName', label: 'অভিভাবকের নাম', required: true },
      { key: 'guardianOccupation', label: 'অভিভাবকের পেশা' }
    ]
  },
  {
    key: 'death_certificate_attestation',
    label: 'স্থানীয় মৃত্যু সত্যায়ন প্রত্যয়ন',
    category: 'উত্তরাধিকার ও পরিবার',
    promptInstruction: 'উক্ত ব্যক্তি উক্ত তারিখ ও স্থানে স্বাভাবিক/বার্ধক্যজনিত কারণে মৃত্যুবরণ করিয়াছেন।',
    simpleFields: [
      { key: 'deceasedName', label: 'মৃতের নাম', required: true },
      { key: 'deathDate', label: 'মৃত্যুর তারিখ', required: true },
      { key: 'causeOfDeath', label: 'মৃত্যুর কারণ', placeholder: 'যেমন: বার্ধক্যজনিত' }
    ]
  },

  // ৩. বৈবাহিক ও বৈবাহিক অবস্থা (16-22)
  {
    key: 'unmarried',
    label: 'অবিবাহিত সনদপত্র',
    category: 'বৈবাহিক অবস্থা',
    promptInstruction: 'উক্ত ব্যক্তি অদ্যবধি বিবাহ বন্ধনে আবদ্ধ হন নাই। তিনি সম্পূর্ণ অবিবাহিত।',
    simpleFields: [
      { key: 'purpose', label: 'ব্যবহারের কারণ', placeholder: 'যেমন: চাকরির জন্য / বিদেশে গমন' }
    ]
  },
  {
    key: 'married',
    label: 'বিবাহিত সনদপত্র',
    category: 'বৈবাহিক অবস্থা',
    promptInstruction: 'উক্ত ব্যক্তি আইনগত ও ইসলামী শরীয়ত মোতাবেক বিবাহ বন্ধনে আবদ্ধ হইয়া শান্তিতে সংসার করিতেছেন।',
    simpleFields: [
      { key: 'marriageDate', label: 'বিবাহের তারিখ', placeholder: 'যেমন: ১০/০১/২০২০' },
      { key: 'spouseNid', label: 'স্বামী/স্ত্রীর এনআইডি/জন্ম সনদ' }
    ]
  },
  {
    key: 'no_remarriage',
    label: 'পুনঃবিবাহ না হওয়ার সনদপত্র',
    category: 'বৈবাহিক অবস্থা',
    promptInstruction: 'উক্ত স্বামীহারা/স্ত্রীহারা ব্যক্তি স্বামী/স্ত্রীর মৃত্যুর পর অদ্যবধি দ্বিতীয় বিবাহে আবদ্ধ হন নাই।',
    simpleFields: [
      { key: 'lateSpouseName', label: 'মৃত স্বামী/স্ত্রীর নাম', required: true },
      { key: 'deathYear', label: 'মৃত্যুর বছর' }
    ]
  },
  {
    key: 'widow',
    label: 'বিধবা / স্বামীহীন সনদপত্র',
    category: 'বৈবাহিক অবস্থা',
    promptInstruction: 'উক্ত মহিলার স্বামী মৃত্যুবরণ করায় তিনি একজন অসহায় বিধবা নারী।',
    simpleFields: [
      { key: 'lateHusbandName', label: 'মৃত স্বামীর নাম', required: true },
      { key: 'husbandDeathDate', label: 'মৃত্যুর তারিখ' }
    ]
  },
  {
    key: 'divorced',
    label: 'তালাকপ্রাপ্তা / স্বামী পরিত্যক্তা সনদ',
    category: 'বৈবাহিক অবস্থা',
    promptInstruction: 'উক্ত নারী আইনগতভাবে তালাকপ্রাপ্তা এবং স্বামী কর্তৃক পরিত্যক্তা হইয়া পিতার গৃহে অবস্থান করিতেছেন।',
    simpleFields: [
      { key: 'exHusbandName', label: 'সাবেক স্বামীর নাম' },
      { key: 'divorceDate', label: 'তালাকের তারিখ' }
    ]
  },
  {
    key: 'single_mother',
    label: 'একক অভিভাবক / মাতৃত্ব সনদ',
    category: 'বৈবাহিক অবস্থা',
    promptInstruction: 'উক্ত মাতা তাহার সন্তানকে এককভাবে লালন পালন করিয়া আসিতেছেন।',
    simpleFields: [
      { key: 'childName', label: 'সন্তানের নাম' }
    ]
  },
  {
    key: 'interfaith_marriage_noc',
    label: 'বিবাহ নিবন্ধন অনাপত্তি প্রত্যয়ন',
    category: 'বৈবাহিক অবস্থা',
    promptInstruction: 'উক্ত বর/কনের বিবাহ রেজিস্ট্রি ও সামাজিক বিবাহে স্থানীয়ভাবে কোনো বাধা বা আপত্তি নাই।',
    simpleFields: [
      { key: 'spouseName', label: 'হবু বর/কনের নাম', required: true },
      { key: 'spouseAddress', label: 'হবু বর/কনের ঠিকানা' }
    ]
  },

  // ৪. অর্থনৈতিক, পেশা ও আর্থিক অবস্থা (23-31)
  {
    key: 'annual_income',
    label: 'বার্ষিক আয় সনদপত্র',
    category: 'অর্থনৈতিক ও পেশা',
    promptInstruction: 'উক্ত ব্যক্তির সকল বৈধ উৎস হতে বাৎসরিক আনুমানিক আয় উল্লেখপূর্বক সনদ প্রদান করা হইতেছে।',
    simpleFields: [
      { key: 'amountInTaka', label: 'বাৎসরিক আয় (টাকায়)', placeholder: 'যেমন: ১,২০,০০০/-', required: true },
      { key: 'sourceOfIncome', label: 'আয়ের উৎস', placeholder: 'যেমন: কৃষি ও ক্ষুদ্র ব্যবসা' }
    ]
  },
  {
    key: 'landless',
    label: 'ভূমিহীন সনদপত্র',
    category: 'অর্থনৈতিক ও পেশা',
    promptInstruction: 'উক্ত ব্যক্তির নিজস্ব কোনো বসতভিটা বা কৃষি জমি নাই। তিনি সম্পূর্ণ ভূমিহীন ও দুস্থ।',
    simpleFields: [
      { key: 'currentLivingStatus', label: 'বর্তমান আবাসনের ধরন', placeholder: 'যেমন: সরকারি খাস জমিতে / ভাড়া' }
    ]
  },
  {
    key: 'river_erosion',
    label: 'নদী ভাঙন এলাকা সনদ',
    category: 'অর্থনৈতিক ও পেশা',
    promptInstruction: 'উক্ত নাগরিকের বসতভিটা নদী ভাঙনে বিলীন হওয়ায় তিনি ক্ষতিগ্রস্ত হইয়াছেন।',
    simpleFields: [
      { key: 'riverName', label: 'নদীর নাম / এলাকা', placeholder: 'যেমন: বংশী নদী অববাহিকা' }
    ]
  },
  {
    key: 'farmer_cert',
    label: 'কৃষক প্রত্যয়নপত্র',
    category: 'অর্থনৈতিক ও পেশা',
    promptInstruction: 'উক্ত ব্যক্তি একজন প্রকৃত কৃষক এবং তিনি সরাসরি কৃষি কাজের সহিত জড়িত।',
    simpleFields: [
      { key: 'cropType', label: 'প্রধান উৎপাদিত ফসল', placeholder: 'যেমন: ধান, সরিষা, শাকসবজি' },
      { key: 'landAmount', label: 'কৃষি জমির পরিমাণ (শতক)', placeholder: 'যেমন: ৫০ শতক' }
    ]
  },
  {
    key: 'indigent',
    label: 'অসচ্ছল / দুস্থ সনদপত্র',
    category: 'অর্থনৈতিক ও পেশা',
    promptInstruction: 'উক্ত ব্যক্তি অতি দরিদ্র ও আর্থিক অভাব-অনটনে দিনাতিপাত করিতেছেন।',
    simpleFields: [
      { key: 'familyMembersCount', label: 'পরিবারের সদস্য সংখ্যা' }
    ]
  },
  {
    key: 'pre_business_noc',
    label: 'ব্যবসা অনাপত্তি সনদ (NOC)',
    category: 'অর্থনৈতিক ও পেশা',
    promptInstruction: 'উক্ত স্থানে ব্যবসা প্রতিষ্ঠান পরিচালনায় ইউনিয়ন পরিষদের কোনো প্রকার আপত্তি নাই।',
    simpleFields: [
      { key: 'businessName', label: 'ব্যবসা প্রতিষ্ঠানের নাম', required: true },
      { key: 'businessType', label: 'ব্যবসার ধরন', placeholder: 'যেমন: মুদি দোকান / রাইস মিল' }
    ]
  },
  {
    key: 'trade_license_cert',
    label: 'ট্রেড লাইসেন্স সুপারিশ প্রত্যয়ন',
    category: 'অর্থনৈতিক ও পেশা',
    promptInstruction: 'উক্ত ব্যবসাপ্রতিষ্ঠান নিয়মিত কর পরিশোধ করিয়া স্থানীয়ভাবে সুনামের সাথে পরিচালিত হইতেছে।',
    simpleFields: [
      { key: 'tradeLicenseNo', label: 'ট্রেড লাইসেন্স নম্বর (যদি থাকে)' },
      { key: 'businessCapital', label: 'ব্যবসায়ের মূলধন' }
    ]
  },
  {
    key: 'unemployed',
    label: 'বেকারত্ব সনদপত্র',
    category: 'অর্থনৈতিক ও পেশা',
    promptInstruction: 'উক্ত ব্যক্তি শিক্ষাগত যোগ্যতা সম্পন্ন হইয়াও বর্তমানে কোনো স্থায়ী কর্মসংস্থানে নিযুক্ত নাই।',
    simpleFields: [
      { key: 'educationalQualification', label: 'সর্বোচ্চ শিক্ষাগত যোগ্যতা', placeholder: 'যেমন: বিএ (অনার্স)' }
    ]
  },
  {
    key: 'daily_wage_earner',
    label: 'দিনমজুর / শ্রমিক প্রত্যয়ন',
    category: 'অর্থনৈতিক ও পেশা',
    promptInstruction: 'উক্ত ব্যক্তি একজন কায়িক শ্রমজীবী ও দিনমজুর। দৈনিক শ্রমের উপর তাহার জীবিকা নির্ভরশীল।',
    simpleFields: [
      { key: 'tradeType', label: 'শ্রমের ধরন', placeholder: 'যেমন: দিনমজুর / রিকশাচালক / নির্মাণ শ্রমিক' }
    ]
  },

  // ৫. বিশেষ ক্যাটাগরি ও সামাজিক নিরাপত্তা (32-38)
  {
    key: 'disability',
    label: 'প্রতিবন্ধী প্রত্যয়নপত্র',
    category: 'বিশেষ ক্যাটাগরি',
    promptInstruction: 'উক্ত ব্যক্তি শারীরিকভাবে প্রতিবন্ধী এবং ভাতা/সহযোগিতার জন্য উপযুক্ত।',
    simpleFields: [
      { key: 'disabilityType', label: 'প্রতিবন্ধিতার ধরন', placeholder: 'যেমন: দৃষ্টি / শারীরিক / মানসিক' }
    ]
  },
  {
    key: 'orphan',
    label: 'এতিম সনদপত্র',
    category: 'বিশেষ ক্যাটাগরি',
    promptInstruction: 'উক্ত শিশুর পিতা মৃত্যুবরণ করায় সে একজন পিতৃহীন এতিম শিশু।',
    simpleFields: [
      { key: 'orphanageName', label: 'এতিমখানার নাম (যদি থাকে)', placeholder: 'ঐচ্ছিক' }
    ]
  },
  {
    key: 'religious_minority',
    label: 'ধর্মীয় / সংখ্যালঘু পরিচয় সনদ',
    category: 'বিশেষ ক্যাটাগরি',
    promptInstruction: 'উক্ত ব্যক্তি সনাতন/খ্রিস্টান/বৌদ্ধ ধর্মীয় সম্প্রদায়ের একজন শান্তিপ্রিয় নাগরিক।',
    simpleFields: [
      { key: 'religion', label: 'ধর্ম', placeholder: 'যেমন: সনাতন (হিন্দু)' }
    ]
  },
  {
    key: 'freedom_fighter_descendant',
    label: 'বীর মুক্তিযোদ্ধা উত্তরাধিকার প্রত্যয়ন',
    category: 'বিশেষ ক্যাটাগরি',
    promptInstruction: 'উক্ত ব্যক্তি তালিকাভুক্ত বীর মুক্তিযোদ্ধার সন্তান/নাতনি।',
    simpleFields: [
      { key: 'ffName', label: 'বীর মুক্তিযোদ্ধার নাম', required: true },
      { key: 'ffGazetteNo', label: 'গেজেট/সনদ নম্বর', required: true },
      { key: 'relationWithFF', label: 'সম্পর্ক', placeholder: 'যেমন: সন্তান / নাতি' }
    ]
  },
  {
    key: 'caste_ethnicity',
    label: 'ক্ষুদ্র নৃ-গোষ্ঠী / ক্ষুদ্র জাতিগোষ্ঠী সনদ',
    category: 'বিশেষ ক্যাটাগরি',
    promptInstruction: 'উক্ত ব্যক্তি স্থানীয় ক্ষুদ্র নৃ-গোষ্ঠী সম্প্রদায়ের অন্তর্ভুক্ত।',
    simpleFields: [
      { key: 'ethnicGroup', label: 'জাতিগোষ্ঠীর নাম', placeholder: 'যেমন: গারো / বর্মণ / সাঁওতাল' }
    ]
  },
  {
    key: 'social_safety_net',
    label: 'সামাজিক নিরাপত্তা সুবিধা পাওয়ার যোগ্যতা প্রত্যয়ন',
    category: 'বিশেষ ক্যাটাগরি',
    promptInstruction: 'উক্ত দুস্থ নাগরিক সরকারি ভাতা ও সামাজিক সাহায্য পাওয়ার জন্য সম্পূর্ণ উপযুক্ত।',
    simpleFields: [
      { key: 'schemeName', label: 'ভাতার ধরন', placeholder: 'যেমন: বয়স্ক ভাতা / বিধবা ভাতা' }
    ]
  },
  {
    key: 'senior_citizen_cert',
    label: 'প্রবীণ নাগরিক / বয়োজ্যেষ্ঠ প্রত্যয়ন',
    category: 'বিশেষ ক্যাটাগরি',
    promptInstruction: 'উক্ত নাগরিক ৬৫ বৎসর বা তদূর্ধ্ব বয়সী একজন সম্মানিত প্রবীণ ব্যক্তি।',
    simpleFields: [
      { key: 'calculatedAge', label: 'বয়স', placeholder: 'যেমন: ৬৮ বৎসর' }
    ]
  },

  // ৬. সংশোধন ও দাপ্তরিক প্রত্যয়ন (39-46)
  {
    key: 'nid_correction',
    label: 'এনআইডি তথ্য সংশোধন প্রত্যয়ন',
    category: 'সংশোধন ও দাপ্তরিক',
    promptInstruction: 'এনআইডি কার্ডে ভুলবশত তথ্য ভুল আসায় ইউনিয়ন পরিষদের রেকর্ড অনুযায়ী সঠিক তথ্য প্রত্যয়ন করা হইল।',
    simpleFields: [
      { key: 'incorrectInfo', label: 'এনআইডির বর্তমান ভুল তথ্য', required: true },
      { key: 'correctInfo', label: 'সঠিক তথ্য (যা হবে)', required: true }
    ],
    tables: [
      {
        key: 'name_correction_list',
        title: 'নাম / তথ্য বানান সংশোধন টেবিল',
        headers: ['ক্রমিক নং', 'বিবরণ', 'ভুল তথ্য', 'সঠিক তথ্য']
      }
    ]
  },
  {
    key: 'birth_cert_correction',
    label: 'জন্ম সনদ তথ্য সংশোধন প্রত্যয়ন',
    category: 'সংশোধন ও দাপ্তরিক',
    promptInstruction: 'জন্ম সনদের নাম/পিতার নাম/তারিখ সংশোধনের উদ্দেশ্যে সঠিক ইউনিয়ন তথ্য নিশ্চিত করা হইল।',
    simpleFields: [
      { key: 'birthCertNo', label: 'জন্ম নম্বর (১৭ ডিজিট)', required: true },
      { key: 'correctionDetails', label: 'সংশোধনের বিবরণ' }
    ],
    tables: [
      {
        key: 'birth_correction_list',
        title: 'জন্ম সনদ তথ্য সংশোধন টেবিল',
        headers: ['সংশোধনীয় বিষয়', 'ভুল তথ্য', 'সঠিক তথ্য']
      }
    ]
  },
  {
    key: 'general_affidavit',
    label: 'সাধারণ হলফনামা / অঙ্গীকারনামা',
    category: 'সংশোধন ও দাপ্তরিক',
    promptInstruction: 'উক্ত নাগরিক দাপ্তরিক প্রয়োজনে স্বীয় জ্ঞানে লিখিত বিবরণী ও সাধারণ হলফনামা প্রদান করিয়াছেন।',
    simpleFields: [
      { key: 'affidavitSubject', label: 'হলফনামার বিষয়', required: true, placeholder: 'যেমন: বয়স বা স্বত্বাধিকারী ঘোষণা' }
    ],
    tables: [
      {
        key: 'affidavit_list',
        title: 'হলফনামা বিবরণী টেবিল',
        headers: ['বিবরণ', 'তথ্যের ধরণ', 'মন্তব্য']
      }
    ]
  },
  {
    key: 'passport_endorsement',
    label: 'পাসপোর্ট প্রত্যয়নপত্র',
    category: 'সংশোধন ও দাপ্তরিক',
    promptInstruction: 'পাসপোর্ট আবেদনের নিমিত্তে নাগরিকের পরিচয় ও চারিত্রিক তথ্য সত্যায়ন করা হইল।',
    simpleFields: [
      { key: 'passportPurpose', label: 'পাসপোর্টের ধরন', placeholder: 'নতুন পাসপোর্ট / নবায়ন' }
    ]
  },
  {
    key: 'electricity_noc',
    label: 'বিদ্যুৎ সংযোগের অনাপত্তি সনদ',
    category: 'সংশোধন ও দাপ্তরিক',
    promptInstruction: 'উক্ত বসতবাড়ি/প্রতিষ্ঠানে নতুন বিদ্যুৎ মিটার সংযোগ প্রদান করিলে ইউনিয়ন পরিষদের কোনো আপত্তি নাই।',
    simpleFields: [
      { key: 'dagKhatian', label: 'দাগ ও খতিয়ান নম্বর', placeholder: 'যেমন: দাগ নং ৭৭, খতিয়ান ৪৫' }
    ]
  },
  {
    key: 'non_residential',
    label: 'অনাবাসিক / প্রাতিষ্ঠানিক প্রত্যয়ন',
    category: 'সংশোধন ও দাপ্তরিক',
    promptInstruction: 'উক্ত প্রতিষ্ঠানটি ইউনিয়ন পরিষদ সীমানার মধ্যে অবস্থিত।',
    simpleFields: [
      { key: 'instName', label: 'প্রতিষ্ঠানের নাম' }
    ]
  },
  {
    key: 'deep_tubewell_noc',
    label: 'গভীর / অগভীর নলকূপ স্থাপন অনাপত্তি',
    category: 'সংশোধন ও দাপ্তরিক',
    promptInstruction: 'বিশুদ্ধ খাবার পানি উত্তোলনের নিমিত্তে অত্র জমিতে নলকূপ স্থাপনে কোনো পরিবেশগত বা আইনি আপত্তি নাই।',
    simpleFields: [
      { key: 'mouzaDag', label: 'মৌজা ও দাগ নং', placeholder: 'যেমন: বহেড়াতৈল মৌজা, দাগ ১০২' }
    ]
  },
  {
    key: 'building_construction_noc',
    label: 'ইমারত / গৃহ নির্মাণ অনাপত্তি সনদ',
    category: 'সংশোধন ও দাপ্তরিক',
    promptInstruction: 'উক্ত নিজস্ব জমিতে সরকারি নিয়মানুযায়ী আবাসিক ভবন নির্মাণে ইউনিয়ন পরিষদের অনাপত্তি জ্ঞাপন করা হইল।',
    simpleFields: [
      { key: 'landDetails', label: 'জমির তফসিল ও দাগ', placeholder: 'যেমন: দাগ ৫৮, খতিয়ান ৩২০' }
    ]
  },

  // ৭. শিক্ষা, ব্যাংকিং ও বিবিধ (47-51)
  {
    key: 'student_attestation',
    label: 'শিক্ষার্থী পরিচয় ও উপবৃত্তি প্রত্যয়ন',
    category: 'নাগরিকত্ব ও পরিচয়',
    promptInstruction: 'উক্ত শিক্ষার্থী একজন নিয়মিত অধ্যায়নরত মেধাবী ছাত্র/ছাত্রী এবং উপবৃত্তি প্রাপ্তির উপযুক্ত।',
    simpleFields: [
      { key: 'institutionName', label: 'শিক্ষা প্রতিষ্ঠানের নাম' },
      { key: 'classOrDegree', label: 'শ্রেণী / বিভাগ' }
    ]
  },
  {
    key: 'bank_account_noc',
    label: 'ব্যাংক হিসাব খোলার প্রত্যয়ন',
    category: 'অর্থনৈতিক ও পেশা',
    promptInstruction: 'উক্ত ব্যক্তির অনুকূলে ব্যাংকে চলতি/সঞ্চয়ী হিসাব পরিচালনায় কোনো আইনগত বাধা নাই।',
    simpleFields: [
      { key: 'bankName', label: 'ব্যাংকের নাম (যদি নির্দিষ্ট থাকে)', placeholder: 'যেমন: সোনালী ব্যাংক' }
    ]
  },
  {
    key: 'migration_resident',
    label: 'স্থানান্তর / নতুন বাসিন্দা প্রত্যয়ন',
    category: 'নাগরিকত্ব ও পরিচয়',
    promptInstruction: 'উক্ত ব্যক্তি পূর্বে অন্য এলাকায় বসবাস করিলেও বর্তমানে এই ইউনিয়নে স্থায়ীভাবে বসতি স্থাপন করিয়াছেন।',
    simpleFields: [
      { key: 'previousAddress', label: 'পূর্বের ঠিকানা' }
    ]
  },
  {
    key: 'house_ownership',
    label: 'গৃহ মালিকানা ও হোল্ডিং ট্যাক্স প্রত্যয়নপত্র',
    category: 'অর্থনৈতিক ও পেশা',
    promptInstruction: 'উক্ত বসতবাড়ির স্বত্বাধিকারী ও মালিক হিসেবে নাগরিকের তথ্য নিশ্চিত করা হইল এবং হোল্ডিং নিয়মিত পরিশোধিত।',
    simpleFields: [
      { key: 'holdingNo', label: 'হোল্ডিং নম্বর (যদি থাকে)' }
    ]
  },
  {
    key: 'miscellaneous',
    label: 'বিবিধ বিশেষ প্রত্যয়নপত্র',
    category: 'অন্যান্য',
    promptInstruction: 'নাগরিকের আবেদনের প্রেক্ষিতে দাপ্তরিক অনুসন্ধানের ভিত্তিতে এই বিবিধ প্রত্যয়নপত্র প্রদান করা হইল।',
    simpleFields: [
      { key: 'customSubject', label: 'প্রত্যয়নের বিষয়', required: true, placeholder: 'যেমন: পুকুর খনন অনাপত্তি' },
      { key: 'customNote', label: 'বিশেষ বিবরণ', placeholder: 'প্রয়োজনীয় তথ্য লিখুন' }
    ]
  }
];

export const CERTIFICATE_CATEGORIES = [
  'সব ধরন',
  'নাগরিকত্ব ও পরিচয়',
  'উত্তরাধিকার ও পরিবার',
  'বৈবাহিক অবস্থা',
  'অর্থনৈতিক ও পেশা',
  'বিশেষ ক্যাটাগরি',
  'সংশোধন ও দাপ্তরিক',
  'অন্যান্য'
];
