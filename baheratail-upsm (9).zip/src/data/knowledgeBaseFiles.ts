export interface KnowledgeFile {
  id: string;
  filename: string;
  title: string;
  category: 'core' | 'catalog' | 'validation' | 'instructions' | 'automation' | 'security';
  description: string;
  content: string;
  isEditable?: boolean;
}

export const INITIAL_KNOWLEDGE_FILES: KnowledgeFile[] = [
  {
    id: '01_master_kb',
    filename: '01_MASTER_KNOWLEDGE_BASE.md',
    title: '০১. ইউনিয়ন পরিষদ মাস্টার ফ্যাক্ট শিট (Master Fact Sheet)',
    category: 'core',
    description: 'ইউনিয়ন পরিষদের দাপ্তরিক বিবরণী, ৯টি ওয়ার্ড, ৪টি ডাকঘর, ২০টি অনুমোদিত গ্রাম এবং Source Priority নিয়ম।',
    content: `# ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ — মাস্টার ফ্যাক্ট শিট (Master Knowledge Base)
**অধিক্ষেত্র:** ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, ডাকঘর: বহেড়াতৈল (১৯৫০), উপজেলা: সখিপুর, জেলা: টাঙ্গাইল, বাংলাদেশ।

---

## ১. অফিস পরিচিতি — CONFIRMED
- **ইউনিয়ন:** ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ
- **উপজেলা:** সখিপুর, **জেলা:** টাঙ্গাইল
- **বিভাগ:** ঢাকা, **দেশ:** বাংলাদেশ
- **কার্যালয় ধরন:** ইউনিয়ন পরিষদ ডিজিটাল সেন্টার (UDC)
- **হেল্পলাইন:** ০১৮৩৪-৩৩৩৩৩০০, **ইমেইল:** up.baheratail@gmail.com
- **ওয়েবসাইট:** boheratoilup.tangail.gov.bd

---

## ২. প্রশাসনিক কাঠামো ও ভৌগোলিক ম্যাপিং — CONFIRMED
- **মোট ওয়ার্ড:** ০৯ টি (০১ থেকে ০৯)
- **মোট ডাকঘর:** ০৪ টি (বহেড়াতৈল-১৯৫০, নাগবাড়ী-১৯৭২, বেতুয়া-১৯৫০, ছিলিমপুর-১৯৫০)
- **মোট অনুমোদিত গ্রাম:** ২০ টি

### ওয়ার্ডভিত্তিক অনুমোদিত গ্রাম ও ডাকঘর ম্যাপিং তালিকা:
| ওয়ার্ড নং | অনুমোদিত গ্রামসমূহ | নির্ধারিত ডাকঘর ও কোড |
|:---:|:---|:---|
| **০১** | ডাবাইল, কামারঙ্গ, গোহাইলবাড়ী | নাগবাড়ী (১৯৭২) |
| **০২** | গোহাইলবাড়ী, যোগীর কোফা | নাগবাড়ী (১৯৭২) / বহেড়াতৈল (১৯৫০) |
| **০৩** | ঘাটেশ্বরী | বহেড়াতৈল (১৯৫০) |
| **০৪** | বহেড়াতৈল, নয়াপড়া, ভুগলীচালা, নেরগীছ চালা, ধোপার চালা | বহেড়াতৈল (১৯৫০) |
| **০৫** | আমতৈল, শালগ্রামপুর | বেতুয়া (১৯৫০) / ছিলিমপুর (১৯৫০) |
| **০৬** | বগাপ্রতিমা, ছাতিয়াচালা, আন্দি | বহেড়াতৈল (১৯৫০) |
| **০৭** | বেতুয়া | বেতুয়া (১৯৫০) |
| **০৮** | কালিয়ান, বেতুয়া (পশ্চিম পাড়া) | বেতুয়া (১৯৫০) |
| **০৯** | কালিয়ান (উত্তর ও পূর্ব পাড়া), হাতিবান্ধা | বেতুয়া (১৯৫০) |

*সতর্কতা: অনুমোদিত ২০টি গ্রামের বাইরে কোনো কাল্পনিক গ্রাম AI নিজে থেকে তৈরি করবে না।*

---

## ৩. উৎসের অগ্রাধিকার ক্রম (SOURCE PRIORITY HIERARCHY)
একাধিক ফাইলে তথ্যের গরমিল থাকলে নিচের ক্রমানুসারে অগ্রাধিকার দিতে হবে:

1. **PRIORITY 1:** সর্বশেষ অনুমোদিত ও স্বাক্ষরিত সরকারি সার্টিফিকেট টেমপ্লেট।
2. **PRIORITY 2:** সর্বশেষ নিশ্চিত মাস্টার ফ্যাক্ট শিট (এই ফাইল — ওয়ার্ড, গ্রাম, ডাকঘর, ফি)।
3. **PRIORITY 3:** বর্তমান Google Workspace ও Apps Script কনফিগারেশন।
4. **PRIORITY 4:** পুরাতন PDF/MD ড্রাফট ও রেফারেন্স ফাইল।
5. **PRIORITY 5:** AI-এর সাধারণ জ্ঞান (General AI Knowledge — স্থানীয় তথ্য কখনোই override করবে না)।

*যদি কোনো তথ্যে দ্বিমত থাকে, তবে স্বয়ংক্রিয়ভাবে নির্বাচন না করে স্ট্যাটাস দেখাবে: \`STATUS: NEEDS VERIFICATION\`।*

---

## ৪. স্মারক নম্বর ফরম্যাট (Memo Number Pattern)
- **ফরম্যাট:** \`ইউপি/সনদ/২০২৬/০০১\` অথবা \`BUP-2026-XXXXX\`
- ক্রমিক অংশ অপারেটর বা সিস্টেম সিকোয়েন্স থেকে নিশ্চিত করবে। AI কখনো ভুয়া স্মারক বানাবে না।
`
  },
  {
    id: '02_cert_catalog',
    filename: '02_CERTIFICATE_CATALOG.md',
    title: '০২. সার্টিফিকেট ও প্রত্যয়নপত্র ক্যাটালগ (Certificate Catalog - ৫১টি ধরন)',
    category: 'catalog',
    description: '৫১ ধরনের সনদ ও সেবার পূর্ণাঙ্গ তালিকা, ৭টি প্রধান ক্যাটাগরি, সক্রিয় (Active) স্ট্যাটাস ও সরকারি ফি নির্দেশিকা।',
    content: `# ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ — সনদ ও প্রত্যয়ন ক্যাটালগ (৫১টি সক্রিয় ধরন)

## ১. নাগরিকত্ব ও পরিচয় ক্যাটাগরি (Citizenship & Identity):
| কোড (Key) | সনদের পূর্ণ নাম | ক্যাটাগরি | প্রমিত ফি |
|---|---|---|---|
| **citizenship** | নাগরিকত্ব সনদপত্র | নাগরিকত্ব ও পরিচয় | ৳ ৫০ |
| **character** | চারিত্রিক সনদপত্র | নাগরিকত্ব ও পরিচয় | ৳ ৫০ |
| **provisional_id** | সাময়িক পরিচিতি সনদপত্র | নাগরিকত্ব ও পরিচয় | ৳ ৫০ |
| **permanent_resident** | স্থায়ী বাসিন্দা সনদপত্র | নাগরিকত্ব ও পরিচয় | ৳ ৫০ |
| **same_person** | একই ব্যক্তি প্রত্যয়নপত্র | নাগরিকত্ব ও পরিচয় | ৳ ৫০ |
| **nationality_attestation** | জাতীয়তা সত্যায়ন প্রত্যয়নপত্র | নাগরিকত্ব ও পরিচয় | ৳ ৫০ |
| **good_conduct** | সচ্চরিত্র ও সমাজসেবা প্রত্যয়ন | নাগরিকত্ব ও পরিচয় | ৳ ৫০ |
| **migration_resident** | স্থানান্তর / নতুন বাসিন্দা প্রত্যয়ন | নাগরিকত্ব ও পরিচয় | ৳ ৫০ |

---

## ২. পরিবার ও উত্তরাধিকার ক্যাটাগরি (Family & Inheritance):
| কোড (Key) | সনদের পূর্ণ নাম | ক্যাটাগরি | প্রমিত ফি |
|---|---|---|---|
| **warish** | ওয়ারিশান / উত্তরাধিকার সনদপত্র | উত্তরাধিকার ও পরিবার | ৳ ১০০ |
| **family_certificate** | পারিবারিক সনদপত্র | উত্তরাধিকার ও পরিবার | ৳ ৫০ |
| **guardian_cert** | অভিভাবকত্ব সনদপত্র | উত্তরাধিকার ও পরিবার | ৳ ৫০ |
| **family_partition** | পারিবারিক সম্পত্তি আপোষ বণ্টননামা প্রত্যয়ন | উত্তরাধিকার ও পরিবার | ৳ ১০০ |
| **adoption_cert** | পোষ্য / দত্তক প্রত্যয়নপত্র | উত্তরাধিকার ও পরিবার | ৳ ৫০ |
| **missing_person** | নিখোঁজ ব্যক্তি সংক্রান্ত প্রত্যয়নপত্র | উত্তরাধিকার ও পরিবার | ৳ ৫০ |
| **orphan_cert** | এতিম / পিতৃহীন প্রত্যয়নপত্র | উত্তরাধিকার ও পরিবার | ৳ ০ (ফ্রি) |
| **dependent_cert** | পোষ্য ও নির্ভরশীলতা প্রত্যয়নপত্র | উত্তরাধিকার ও পরিবার | ৳ ৫০ |

---

## ৩. বৈবাহিক অবস্থা ক্যাটাগরি (Marital Status):
| কোড (Key) | সনদের পূর্ণ নাম | ক্যাটাগরি | প্রমিত ফি |
|---|---|---|---|
| **unmarried** | অবিবাহিত সনদপত্র | বৈবাহিক অবস্থা | ৳ ৫০ |
| **married** | বিবাহিত সনদপত্র | বৈবাহিক অবস্থা | ৳ ৫০ |
| **remarriage_not** | পুনঃ বিবাহ না হওয়ার প্রত্যয়নপত্র | বৈবাহিক অবস্থা | ৳ ৫০ |
| **widow** | বিধবা প্রত্যয়নপত্র | বৈবাহিক অবস্থা | ৳ ০ (ফ্রি) |
| **widower** | বিপত্নীক প্রত্যয়নপত্র | বৈবাহিক অবস্থা | ৳ ৫০ |
| **divorced_cert** | তালাকপ্রাপ্তা / বিবাহ বিচ্ছেদ প্রত্যয়ন | বৈবাহিক অবস্থা | ৳ ৫০ |
| **single_mother** | একক মাতা / নিঃসঙ্গ নারী প্রত্যয়ন | বৈবাহিক অবস্থা | ৳ ০ (ফ্রি) |

---

## ৪. অর্থনৈতিক ও পেশা ক্যাটাগরি (Economic, Trade & Agriculture):
| কোড (Key) | সনদের পূর্ণ নাম | ক্যাটাগরি | প্রমিত ফি |
|---|---|---|---|
| **trade_license** | ট্রেড লাইসেন্স (ব্যবসা অনুমতিপত্র) | অর্থনৈতিক ও পেশা | ৳ ৩৩০-৫০০ |
| **income** | বাৎসরিক / মাসিক আয়ের সনদপত্র | অর্থনৈতিক ও পেশা | ৳ ৫০ |
| **farmer** | কৃষক প্রত্যয়নপত্র | অর্থনৈতিক ও পেশা | ৳ ০ (ফ্রি) |
| **financial_insolvency** | নদীভাঙন ও অর্থনৈতিক অসচ্ছলতা সনদ | অর্থনৈতিক ও পেশা | ৳ ০ (ফ্রি) |
| **unemployed** | বেকারত্ব প্রত্যয়নপত্র | অর্থনৈতিক ও পেশা | ৳ ৫০ |
| **fisherman** | মৎস্যজীবী প্রত্যয়নপত্র | অর্থনৈতিক ও পেশা | ৳ ০ (ফ্রি) |
| **expatriate_remittance** | প্রবাসী ও রেমিট্যান্স যোদ্ধা প্রত্যয়ন | অর্থনৈতিক ও পেশা | ৳ ৫০ |
| **bank_account_noc** | ব্যাংক হিসাব খোলার প্রত্যয়ন | অর্থনৈতিক ও পেশা | ৳ ৫০ |
| **house_ownership** | গৃহ মালিকানা ও হোল্ডিং ট্যাক্স প্রত্যয়নপত্র | অর্থনৈতিক ও পেশা | ৳ ৫০ |

---

## ৫. বিশেষ ক্যাটাগরি ও সমাজকল্যাণ (Special Categories & Welfare):
| কোড (Key) | সনদের পূর্ণ নাম | ক্যাটাগরি | প্রমিত ফি |
|---|---|---|---|
| **freedom_fighter_child** | বীর মুক্তিযোদ্ধা সন্তান / নাতি-নাতনি প্রত্যয়ন | বিশেষ ক্যাটাগরি | ৳ ০ (ফ্রি) |
| **disability** | প্রতিবন্ধী প্রত্যয়নপত্র | বিশেষ ক্যাটাগরি | ৳ ০ (ফ্রি) |
| **landless** | ভূমিহীন প্রত্যয়নপত্র | বিশেষ ক্যাটাগরি | ৳ ০ (ফ্রি) |
| **minority_ethnic** | ক্ষুদ্র নৃ-গোষ্ঠী প্রত্যয়নপত্র | বিশেষ ক্যাটাগরি | ৳ ৫০ |
| **religious_minority** | ধর্মীয় সংখ্যালঘু প্রত্যয়নপত্র | বিশেষ ক্যাটাগরি | ৳ ৫০ |
| **senior_citizen** | জ্যেষ্ঠ নাগরিক (Senior Citizen) প্রত্যয়ন | বিশেষ ক্যাটাগরি | ৳ ০ (ফ্রি) |
| **climate_victim** | প্রাকৃতিক দুর্যোগ ও জলবায়ু উদ্বাস্তু প্রত্যয়ন | বিশেষ ক্যাটাগরি | ৳ ০ (ফ্রি) |

---

## ৬. সংশোধন, বয়স ও দাপ্তরিক অনাপত্তি (Correction, Age & NOC):
| কোড (Key) | সনদের পূর্ণ নাম | ক্যাটাগরি | প্রমিত ফি |
|---|---|---|---|
| **nid_correction_info** | এনআইডি / জন্ম নিবন্ধন তথ্য সংশোধন প্রত্যয়ন | সংশোধন ও দাপ্তরিক | ৳ ৫০ |
| **death_verification** | মৃত্যু নিবন্ধন যাচাই প্রত্যয়নপত্র | সংশোধন ও দাপ্তরিক | ৳ ৫০ |
| **electricity_noc** | পল্লী বিদ্যুৎ সংযোগ অনাপত্তি পত্র (NOC) | সংশোধন ও দাপ্তরিক | ৳ ৫০ |
| **building_noc** | গৃহ নির্মাণ ও সীমানা অনাপত্তি পত্র (NOC) | সংশোধন ও দাপ্তরিক | ৳ ১০০ |
| **new_voter_transfer** | নতুন ভোটার স্থানান্তর ও অন্তর্ভুক্তি প্রত্যয়ন | সংশোধন ও দাপ্তরিক | ৳ ৫০ |
| **lost_document_gd** | সনদ / দলিল হারানো প্রত্যয়নপত্র | সংশোধন ও দাপ্তরিক | ৳ ৫০ |
| **age_estimate** | বয়স প্রাক্কলন প্রত্যয়নপত্র | সংশোধন ও দাপ্তরিক | ৳ ৫০ |
| **student_attestation** | অধ্যয়নরত ছাত্রত্ব প্রত্যয়নপত্র | সংশোধন ও দাপ্তরিক | ৳ ৫০ |

---

## ৭. অন্যান্য ও বিশেষ (Miscellaneous):
| কোড (Key) | সনদের পূর্ণ নাম | ক্যাটাগরি | প্রমিত ফি |
|---|---|---|---|
| **miscellaneous** | বিবিধ বিশেষ প্রত্যয়নপত্র | অন্যান্য | ৳ ৫০ |

*নিয়মাবলী:*
1. সমস্ত সনদ তৈরিতে ইউনিয়ন পরিষদের অনুমোদিত লগো ও বিল্ট-ইন কিউআর কোড যুক্ত থাকে।
2. কোনো অপ্রয়োজনীয় এক্সটার্নাল লিংক বা ইউআরএল প্রিন্টআউটে রাখা হয় না।
3. প্রতিটি সনদপ্রক্রিয়ায় দাপ্তরিক সত্যতা ও অপারেটর ভ্যালিডেশন বাধ্যতামূলক।
`
  },
  {
    id: '03_cert_templates',
    filename: '03_CERTIFICATE_TEMPLATES.md',
    title: '০৩. অনুমোদিত সরকারি সনদ টেমপ্লেটসমূহ (Approved Templates)',
    category: 'catalog',
    description: 'নাগরিকত্ব, চারিত্রিক, ওয়ারিশান, ট্রেড লাইসেন্স ও আয় সনদের প্রমিত দাপ্তরিক বাংলা বয়ান।',
    content: `# অনুমোদিত সরকারি সনদ টেমপ্লেট সংকলন

## টেমপ্লেট ১: নাগরিকত্ব ও স্থায়ী বাসিন্দা সনদ (Citizenship Certificate)
\`\`\`text
গণপ্রজাতন্ত্রী বাংলাদেশ সরকার
০২নং বহেড়াতৈল ইউনিয়ন পরিষদ কার্যালয়
সখিপুর, টাঙ্গাইল।

স্মারক নং: [স্মারক নম্বর]
তারিখ: [ইস্যু তারিখ]

নাগরিক সনদপত্র

এই মর্মে প্রত্যয়ন করা যাইতেছে যে,
নাম: [নাগরিকের নাম]
পিতা/স্বামী: [পিতা বা স্বামীর নাম]
মাতা: [মাতার নাম]
গ্রাম: [গ্রামের নাম], ওয়ার্ড নং: [ওয়ার্ড নং], ডাকঘর: [ডাকঘর] (কোড: ১৯৫০)
উপজেলা: সখিপুর, জেলা: টাঙ্গাইল।
জাতীয় পরিচয়পত্র / জন্ম নিবন্ধন নং: [NID/BR নম্বর]

তিনি অত্র ইউনিয়নের একজন স্থায়ী বাসিন্দা এবং বাংলাদেশ সরকারের একজন সুযোগ্য নাগরিক। আমার জানামতে তিনি কোনো রাষ্ট্র বা সমাজবিরোধী কার্যকলাপে জড়িত নহেন।

আমি তাঁহার সর্বাঙ্গীন মঙ্গল ও উত্তরোত্তর সাফল্য কামনা করি।

[সিল ও স্বাক্ষর]
চেয়ারম্যান / দায়িত্বপ্রাপ্ত প্রশাসক
০২নং বহেড়াতৈল ইউনিয়ন পরিষদ
\`\`\`

---

## টেমপ্লেট ২: চারিত্রিক সনদপত্র (Character Certificate)
\`\`\`text
চারিত্রিক সনদপত্র

এই মর্মে প্রত্যয়ন করা যাইতেছে যে, [নাম], পিতা: [পিতার নাম], মাতা: [মাতার নাম], গ্রাম: [গ্রাম], ওয়ার্ড নং: [ওয়ার্ড], ডাকঘর: [ডাকঘর], উপজেলা: সখিপুর, জেলা: টাঙ্গাইল।

তিনি অত্র ইউনিয়নের একজন স্থায়ী বাসিন্দা ও আমার পূর্ব পরিচিত। তাঁহার নৈতিক চরিত্র অত্যন্ত ভালো, তিনি সৎ, ভদ্র ও পরোপকারী স্বভাবের অধিকারী। অত্র ইউনিয়নের কোথাও তাঁহার বিরুদ্ধে কোনো প্রকার ফৌজদারি বা সমাজবিরোধী অভিযোগ নাই।

আমি তাঁহার ভবিষ্যৎ জীবনের উন্নতি ও মঙ্গল কামনা করি।
\`\`\`

---

## টেমপ্লেট ৩: ওয়ারিশান সনদপত্র (Warish Certificate)
\`\`\`text
ওয়ারিশান সনদপত্র

এই মর্মে প্রত্যয়ন করা যাইতেছে যে, অত্র ইউনিয়নের [গ্রাম] নিবাসী মরহুম [মৃত ব্যক্তির নাম], পিতা: [পিতার নাম], তিনি বিগত [মৃত্যুর তারিখ] ইং তারিখে মৃত্যুবরণ করিয়াছেন। 

মৃত্যুকালে তিনি নিম্নলিখিত বৈধ ওয়ারিশগণকে রাখিয়া গিয়াছেন:

| ক্রমিক | ওয়ারিশের নাম | সম্পর্ক | বয়স / জন্মতারিখ | অবস্থা |
|:---:|:---|:---:|:---:|:---:|
| ১ | [নাম] | স্ত্রী/স্বামী | [বয়স] | জীবিত |
| ২ | [নাম] | পুত্র | [বয়স] | জীবিত |
| ৩ | [নাম] | কন্যা | [বয়স] | জীবিত |

স্থানীয় তদন্ত ও মেম্বারের সুপারিশ মোতাবেক এতদ্ব্যতীত তাঁহার আর কোনো ওয়ারিশ নাই।
*নোট: এই সনদ উত্তরাধিকার তালিকা মাত্র, আইনগত চূড়ান্ত স্বত্ব নির্ধারণ নহে।*
\`\`\`
`
  },
  {
    id: '04_required_fields',
    filename: '04_REQUIRED_FIELDS.md',
    title: '০৪. সনদভিত্তিক প্রয়োজনীয় তথ্যাবলীর তালিকা (Required Fields Engine)',
    category: 'validation',
    description: 'প্রতিটি সনদের জন্য আবশ্যক ও ঐচ্ছিক ফিল্ডের তালিকা যাতে অপ্রয়োজনীয় তথ্য ইনপুট না চাওয়া হয়।',
    content: `# সনদভিত্তিক আবশ্যিক ফিল্ড নির্দেশিকা

## ১. নাগরিক সনদ (CITIZEN)
- **আবশ্যিক:** নাম (বাংলা), পিতা/স্বামীর নাম, মাতার নাম, গ্রাম, ওয়ার্ড নং (১-৯), ডাকঘর, NID বা জন্ম নিবন্ধন নম্বর, ইস্যু তারিখ।
- **ঐচ্ছিক:** হোল্ডিং নম্বর, মোবাইল নম্বর, পেশা, জন্ম তারিখ।

## ২. চারিত্রিক সনদ (CHARACTER)
- **আবশ্যিক:** নাম, পিতার নাম, মাতার নাম, গ্রাম, ওয়ার্ড নং, ডাকঘর, NID/জন্ম নম্বর।

## ৩. ওয়ারিশ সনদ (WARISH)
- **আবশ্যিক:** মৃত ব্যক্তির নাম, পিতার নাম, মৃত্যুর তারিখ, মৃত্যুর স্থান, ওয়ারিশ তালিকা (নাম, সম্পর্ক, বয়স, জাতীয় পরিচয়পত্র)।
- **বিশেষ নিয়ম:** AI নিজে থেকে ফারায়েজ বা অংশ নির্ধারণ করবে না, শুধু পারিবারিক তালিকা সাজাবে।

## ৪. ট্রেড লাইসেন্স (TRADE)
- **আবশ্যিক:** ব্যবসা প্রতিষ্ঠানের নাম, স্বত্বাধিকারীর নাম, পিতার নাম, ব্যবসার ধরন (একক/যৌথ), দোকানের ঠিকানা, সাইনবোর্ড ফি, লাইসেন্স ফি।

## ৫. আয়ের সনদ (INCOME)
- **আবশ্যিক:** নাম, পিতা, গ্রাম, ওয়ার্ড, মাসিক বা বাৎসরিক আয়ের পরিমাণ (অংকে ও কথায়), আয়ের উৎস।
`
  },
  {
    id: '05_validation_rules',
    filename: '05_VALIDATION_RULES.md',
    title: '০৫. ডাটা ভ্যালিডেশন ও ত্রুটি বার্তা নিয়মাবলী (Validation Rules)',
    category: 'validation',
    description: 'ঠিকানা, ওয়ার্ড-গ্রাম সংগতি, NID/জন্ম সনদ ফরম্যাট চেক ও প্রশাসনিক বাংলা ত্রুটি বার্তার তালিকা।',
    content: `# ভ্যালিডেশন ইঞ্জিন ও ত্রুটি বার্তা নিয়মাবলী

## ১. ঠিকানা ও ওয়ার্ড সংগতি ভ্যালিডেশন:
- ওয়ার্ড নম্বর অবশ্যই ১ থেকে ৯ এর মধ্যে হতে হবে। (অন্যথায়: \`⚠️ INVALID WARD\`)
- নির্বাচিত গ্রামটি অবশ্যই নির্বাচিত ওয়ার্ডের অনুমোদিত তালিকার সাথে মিলতে হবে। (অমিল হলে: \`⚠️ ADDRESS MISMATCH — গ্রাম ও ওয়ার্ডের তথ্য Knowledge Base-এর সঙ্গে মিলছে না।\`)
- ডাকঘর অবশ্যই ৪টির একটি হতে হবে।

## ২. পরিচয়পত্র ফরম্যাট যাচাই:
- **জাতীয় পরিচয়পত্র (NID):** ১০, ১৩ অথবা ১৭ সংখ্যার হতে হবে।
- **জন্ম নিবন্ধন নম্বর (BRN):** ঠিক ১৭ সংখ্যার হতে হবে।
- *সতর্কতা: সংখ্যার মিল থাকলেই তা দাপ্তরিকভাবে বৈধ প্রমাণিত হয় না; মানব অপারেটরের ফিজিক্যাল চেক বাধ্যতামূলক।*

## ৩. নির্ধারিত বাংলা ত্রুটি বার্তাসমূহ (Exact Error Messages):
1. **অস্পষ্ট ছবি:** *"ছবিটি পরিষ্কার নয়। অনুগ্রহ করে আরও পরিষ্কার ছবি দিন।"*
2. **অসম্পূর্ণ তথ্য:** *"এই সনদ তৈরির জন্য আরও কিছু তথ্য প্রয়োজন।"*
3. **অননুমোদিত টেমপ্লেট:** *"এই ধরনের সনদের নির্ধারিত Template বর্তমানে Knowledge Base-এ পাওয়া যায়নি।"*
4. **তথ্যের গরমিল:** *"একাধিক উৎসে ভিন্ন তথ্য পাওয়া গেছে। অনুগ্রহ করে যাচাই করুন।"*
5. **ম্যানুয়াল রিভিউ:** *\`MANUAL_REVIEW_REQUIRED — মানব যাচাই প্রয়োজন।\`*
6. **অজানা ফি:** *[ফি যাচাই করুন] (AI কখনো মনগড়া ফি বসাবে না)*
`
  },
  {
    id: '06_workflow',
    filename: '06_WORKFLOW.md',
    title: '০৬. অফিসিয়াল এন্ড-টু-এন্ড কার্যপ্রণালী (Office Workflow)',
    category: 'core',
    description: 'নথি আপলোড ➔ এআই তথ্য নিষ্কাশন ➔ মানব যাচাই ➔ খসড়া প্রস্তুতি ➔ প্রিন্ট ও অনুমোদন চেইন।',
    content: `# ইউনিয়ন পরিষদ ডিজিটাল সেন্টার — এন্ড-টু-এন্ড কার্যপ্রণালী (Workflow)

\`\`\`
[১. NID/জন্মনিবন্ধন আপলোড]
         ↓
[২. Gemini Vision OCR ডেটা রিডিং]
         ↓
[৩. এডিটেবল ফর্মে তথ্যাবলি উপস্থাপন]
         ↓
[৪. মানব অপারেটর যাচাই (Human Verification Gate)]
         ↓
[৫. সনদ ক্যাটাগরি ও টেমপ্লেট নির্বাচন]
         ↓
[৬. Knowledge Base রুল অনুযায়ী খসড়া জেনারেশন]
         ↓
[৭. অটোমেটিক ভ্যালিডেশন ও DRAFT ওয়াটারমার্ক চেক]
         ↓
[৮. কপি টু Word / Google Docs / DOCX ডাউনলোড]
         ↓
[৯. অফিসিয়াল প্যাডে প্রিন্ট ➔ চেয়ারম্যান ও সচিবের স্বাক্ষর ও সিল]
\`\`\`

## মূল দায়িত্ব বিভাজন (Role Separation):
- **AI Assistant:** তথ্য নিষ্কাশন, সাজানো, খসড়া প্রস্তুত এবং অসঙ্গতি শনাক্তকরণ।
- **Computer Operator (MD. JUBAER HOSSEN):** তথ্য ইনপুট, ভুল যাচাই ও প্রস্তুতকরণ।
- **Authorized Official (চেয়ারম্যান/সচিব):** চূড়ান্ত পর্যালোচনা, অনুমোদন, স্বাক্ষর ও সিল।

*AI কোনো অবস্থাতেই নিজেকে সনদ প্রদানকারী কর্তৃপক্ষ দাবি করবে না।*
`
  },
  {
    id: '07_gem_instructions',
    filename: '07_GEM_INSTRUCTIONS.md',
    title: '০৭. জেম সিস্টেম ইনস্ট্রাকশনস (Gemini Custom Gem Prompt)',
    category: 'instructions',
    description: 'গুগল জেমিনাই কাস্টম জেমে সরাসরি পেস্ট করার উপযোগী সম্পূর্ণ সিস্টেম প্রম্পট ও ৫টি আউটপুট মোড।',
    content: `# Google Gemini Custom Gem — Master System Instructions
## GEM NAME: UPSM — Union Parishad Smart Digital Service Assistant

তুমি UPSM — Union Parishad Smart Digital Service Assistant। তুমি টাঙ্গাইল জেলার সখিপুর উপজেলাধীন ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের একজন দক্ষ ডিজিটাল সেন্টার কম্পিউটার অপারেটরের ব্যক্তিগত AI সহকারী। তুমি কোনো Generic Chatbot নও।

---

### ১. মূল কার্যপ্রণালী ও নির্দেশনাবলী:
1. **AI কাজ করবে, মানুষ যাচাই ও অনুমোদন দেবে, সিস্টেম Traceable থাকবে।**
2. **Knowledge Base হলো সত্যের পরম উৎস।** আপলোডকৃত নলেজ ফাইলগুলো কঠোরভাবে অনুসরণ করবে।
3. **কখনো মনগড়া কোনো তথ্য দেবে না** — কাল্পনিক গ্রাম, কাল্পনিক ফি, ভুয়া কর্মকর্তা বা অসমর্থিত আইন উদ্ভাবন সম্পূর্ণ নিষিদ্ধ।
4. **অনিশ্চিত তথ্য** পেলে বলবে: *"তথ্যটি স্পষ্টভাবে শনাক্ত করা যায়নি — যাচাই করুন।"*
5. **অসমর্থিত সনদ** চাইলে বলবে: *"এই ধরনের সনদের নির্ধারিত Template বর্তমানে Knowledge Base-এ পাওয়া যায়নি।"*
6. প্রতিটি প্রস্তুতকৃত সনদ প্রাথমিক অবস্থায় **AI DRAFT** হিসেবে গণ্য হবে।

---

### ২. পাঁচটি নির্দিষ্ট আউটপুট মোড (Output Modes):

1. **ASSIST MODE:** অপারেটরকে কোন কাজের পর কী করতে হবে বা সনদের জন্য কী কী কাগজপত্র লাগবে তা ব্যাখ্যা করো।
2. **DATA MODE:** NID বা জন্ম নিবন্ধন থেকে তথ্য বের করে সুশৃঙ্খল বাংলায় ফিল্ডভিত্তিক দেখাও।
3. **VERIFY MODE:** তথ্যের ভুল, অসঙ্গতি বা গ্রাম-ওয়ার্ডের অমিল খুঁজে বের করো।
4. **DRAFT MODE:** অনুমোদিত টেমপ্লেট অনুযায়ী সম্পূর্ণ সনদের খসড়া প্রস্তুত করো।
5. **COPY-READY MODE:** যখন ব্যবহারকারী বলবে *"Copy Ready দাও"*, *"শুধু Body দাও"*, বা *"Word-এ Copy করার মতো দাও"* — তখন কোনো ভূমিকা, উপসংহার, Markdown কোডব্লক বা ব্যাখ্যা ছাড়া **শুধুমাত্র খাঁটি ডকুমেন্টের টেক্সট** আউটপুট দেবে যা সরাসরি Word বা Google Docs-এ পেস্ট করা যায়।

---

### ৩. সাধারণ বাংলা কমান্ডসমূহ:
- "এই NID থেকে তথ্য বের করো" ➔ DATA MODE
- "তথ্যগুলো যাচাই করো" ➔ VERIFY MODE
- "জাতীয়তা সনদ তৈরি করো" ➔ DRAFT MODE
- "ভুলগুলো দেখাও" ➔ VERIFY MODE
- "Copy Ready দাও" ➔ COPY-READY MODE
- "এই সনদের জন্য কী কী লাগবে?" ➔ ASSIST MODE
`
  },
  {
    id: '08_privacy_security',
    filename: '08_PRIVACY_AND_SECURITY.md',
    title: '০৮. নিরাপত্তা ও ডাটা সুরক্ষা নীতিমালা (Privacy & Security)',
    category: 'security',
    description: 'নাগরিকের ব্যক্তিগত তথ্যের সুরক্ষা, ফ্রন্টএন্ডে সিক্রেট না রাখা এবং ডাটা লাইফসাইকেল নিয়ম।',
    content: `# নাগরিক তথ্যের গোপনীয়তা ও সিস্টেম নিরাপত্তা নির্দেশিকা

## ১. সংবেদনশীল তথ্যের সুরক্ষা:
- Gemini API Key, Firebase Service Account বা Google Workspace Secrets কখনো ক্লায়েন্ট সাইড বা ব্রাউজারে হার্ডকোড করা যাবে না।
- নাগরিকের NID নম্বর, মোবাইল নম্বর ও ব্যক্তিগত তথ্য কখনোই Gemini-এর স্থায়ী সিস্টেমে সংরক্ষণ করা হবে না।

## ২. সেশন ডাটা লাইফসাইকেল (Data Lifecycle):
- কাজ সম্পন্ন হওয়ার পর অপারেটর **"সব তথ্য Clear করুন"** বাটনে ক্লিক করে বর্তমান সেশনের আপলোডকৃত ইমেজ, নিষ্কাশিত ডাটা ও অস্থায়ী খসড়া মুছে ফেলতে পারবেন।
- ডাটাবেস রুলসে উন্মুক্ত \`allow read, write: if true\` ব্যবহার করা সম্পূর্ণ নিষিদ্ধ।

## ৩. কিউআর কোড ভেরিফিকেশন সুরক্ষা:
- অনলাইন কিউআর কোড স্ক্যান করলে শুধুমাত্র সনদের মৌলিক সত্যতা ও অনুমোদনের স্ট্যাটাস দেখা যাবে; কোনো অপ্রয়োজনীয় গোপনীয় নাগরিক তথ্য উন্মুক্ত হবে না।
`
  },
  {
    id: '09_workspace_automation',
    filename: '09_GOOGLE_WORKSPACE_AUTOMATION.md',
    title: '০৯. গুগল ওয়ার্কস্পেস অটোমেশন নকশা (Google Workspace & Apps Script)',
    category: 'automation',
    description: 'Google Forms ➔ Google Sheets ➔ Gemini Gem ➔ Google Docs ➔ Gmail নোটিফিকেশন পাইপলাইন।',
    content: `# Google Workspace + Gemini Gem অটোমেশন পাইপলাইন

## অটোমেশন স্থাপত্য (Architecture Flow):
\`\`\`
[১. Google Forms — নাগরিকের আবেদনপত্র ও ফাইল আপলোড]
                      ↓
[২. Google Sheets — স্বয়ংক্রিয় ডাটা সংরক্ষণ ও রো এন্ট্রি]
                      ↓
[৩. Google Apps Script / Ask a Gem — এআই খসড়া জেনারেশন]
                      ↓
[৪. Google Docs — অনুমোদিত টেমপ্লেটে প্রমিত সনদপত্র তৈরি]
                      ↓
[৫. Gmail Notification — দায়িত্বপ্রাপ্ত কর্মকর্তা ও নাগরিককে ইমেইল অ্যালার্ট]
\`\`\`

## Google Sheets কলাম কাঠামো (Schema):
- **Citizens Sheet:** \`CitizenID, NID, BirthReg, NameBn, NameEn, Father, Mother, Village, Ward, PostOffice, Mobile, CreatedAt\`
- **Certificates Sheet:** \`CertificateID, MemoNo, IssueDate, TypeKey, CitizenName, Status, DocLink, VerifiedBy\`
- **User_Preferences:** \`Key, Value, UpdatedAt\` (স্থায়ী অপারেটর পছন্দসমূহ)
`
  },
  {
    id: '10_trade_license',
    filename: '10_TRADE_LICENSE_SPECIFICATION.md',
    title: '১০. ট্রেড লাইসেন্স ও আদর্শ কর তফসিল ২০১৩ (Trade License Spec)',
    category: 'catalog',
    description: 'ইউনিয়ন পরিষদ আদর্শ কর তফসিল ২০১৩ মোতাবেক ট্রেড লাইসেন্স ফি, ভ্যাট ও ফরম্যাটের নিয়মাবলী।',
    content: `# ইউনিয়ন পরিষদ আদর্শ কর তফসিল ২০১৩ — ট্রেড লাইসেন্স স্পেসিফিকেশন

## ১. ট্রেড লাইসেন্স তথ্যাবলী:
- **আইনি ভিত্তি:** স্থানীয় সরকার (ইউনিয়ন পরিষদ) আইন ২০০৯ এবং ইউনিয়ন পরিষদ আদর্শ কর তফসিল ২০১৩।
- **মেয়াদ:** সাধারণত সংশ্লিষ্ট অর্থবছরের ১লা জুলাই হইতে ৩০শে জুন পর্যন্ত বলবৎ থাকে।
- **ফি কাঠামো:**
  - নতুন ট্রেড লাইসেন্স ফি: ৳ ২০০.০০
  - পেশা, ব্যবসা ও বৃত্তির উপর কর: ৳ ১০০.০০
  - ১৫% ভ্যাট (VAT): ৳ ৩০.০০
  - সাইনবোর্ড কর (যদি প্রযোজ্য): ৳ ৫০.০০
  - সর্বমোট প্রমিত নতুন ফি: ৳ ৩৩০.০০

## ২. আবশ্যকীয় ফিল্ডসমূহ:
১. ব্যবসা প্রতিষ্ঠানের নাম
২. মালিক / স্বত্বাধিকারীর নাম
৩. পিতার নাম ও মাতার নাম
৪. ব্যবসার প্রকৃতি (একক / যৌথ / লিমিটেড)
৫. ব্যবসার ধরন (যেমন: ইলেকট্রিক সামগ্রী, মুদি, অনলাইন সার্ভিস)
৬. প্রতিষ্ঠানের সঠিক ঠিকানা ও ওয়ার্ড নম্বর
৭. এনআইডি / জন্ম নিবন্ধন নম্বর ও মোবাইল নম্বর
৮. অর্থবছর (যেমন: ২০২৬ - ২০২৭)
`
  },
  {
    id: '10_core_db_logging',
    filename: '10_CORE_DATABASE_AND_EVENT_LOGGING.md',
    title: '১০. এআই সুপারভাইজার কোর ডাটাবেস ও ইভেন্ট লগিং আর্কিটেকচার (Google Sheets 6-Tab)',
    category: 'automation',
    description: 'সম্পূর্ণ ফ্রি Google Sheets ভিত্তিক ৬টি ডেডিকেটেড ট্যাব, ইভেন্ট লগিং স্কিমা এবং প্রাইভেসী ফিল্টার (PII Masking) মেকানিজম।',
    content: `# ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ — AI Supervisor কোর ডাটাবেস ও ইভেন্ট লগিং আর্কিটেকচার (ধাপ ১)

## ১. ডাটাবেস ওভারভিউ (Google Sheets 6-Tab Architecture)
AI Supervisor-এর সকল টেলিমেট্রি, লার্নিং প্যাটার্ন, স্বয়ংক্রিয় রিকমেন্ডেশন ও কনফিগারেশনের মূল ডেটা সোর্স হলো এই ৬টি স্প্রেডশিট ট্যাব:

### Tab 1: \`Applications\` (নাগরিকদের আবেদনের মূল ডাটাবেস)
নাগরিকদের জমা হওয়া আবেদনের সাধারণ রেকর্ড সংরক্ষিত থাকে।
- \`App_ID\` (Unique ID, যেমন: APP-26-001)
- \`Date_Time\` (আবেদনের সময়)
- \`Applicant_Name\` (আবেদনকারীর নাম)
- \`Phone_No\` (PII - AI-এর কাছে বিশ্লেষণকালে মাস্ক থাকবে)
- \`Service_Type\` (Trade License, Citizenship, Warish, etc.)
- \`Status\` (Pending, Processing, Approved, Rejected)

### Tab 2: \`Event_Logs\` (AI-এর বিশ্লেষণের মূল সোর্স)
সিস্টেমে ঘটিত প্রতিটি গুরুত্বপূর্ণ ইভেন্ট এখানে রেকর্ড হয়। AI Supervisor এই শিটটি সবচেয়ে বেশি বিশ্লেষণ করে।
- \`Log_ID\` (যেমন: LOG-105)
- \`Timestamp\` (কখন ঘটেছে)
- \`Event_Category\` (যেমন: App_Created, Status_Changed, Validation_Error, API_Failed)
- \`Module\` (কোন সার্ভিসে হয়েছে, যেমন: Trade License)
- \`Action_By\` (System, User, বা Officer ID - নাম থাকবে না)
- \`Description\` (যেমন: "NID format validation failed" বা "Application approved")
- \`Status\` (Success, Warning, Error)

### Tab 3: \`Corrections_Log\` (AI-এর লার্নিং ইঞ্জিন)
অপারেটর বা কর্মকর্তার করা সংশোধনগুলো বিশ্লেষণ করে AI প্যাটার্ন শেখে।
- \`Correction_ID\` (যেমন: COR-101)
- \`Timestamp\` (সংশোধনের সময়)
- \`Ref_App_ID\` (কোন আবেদনের ভুল)
- \`Field_Name\` (যেমন: Father's Name, Date of Birth, Village)
- \`Old_Value\` (ভুল ডেটা কী ছিল)
- \`New_Value\` (সঠিক ডেটা কী দেওয়া হলো)
- \`Correction_Reason\` (যেমন: Typo, Format Error, OCR Error)
- \`Corrected_By\` (অপারেটর কোড বা আইডি)

### Tab 4: \`AI_Recommendations\` (Human + AI Collaboration)
AI তার বুদ্ধিমত্তা দিয়ে যে আইডিয়া বা বাগ (Bug) বের করবে, তা এখানে জমা হবে এবং Admin অনুমোদন/প্রত্যাখ্যান করবেন।
- \`Rec_ID\` (যেমন: REC-001)
- \`Date_Generated\` (তারিখ)
- \`Category\` (Bug, UX Idea, Automation, Security)
- \`Title\` (যেমন: "Repeated NID Format Error")
- \`Root_Cause\` (সমস্যার মূল কারণ)
- \`Proposed_Fix\` (AI-এর প্রস্তাবিত সমাধান)
- \`Confidence_Score\` (যেমন: 92%)
- \`Priority\` (P0, P1, P2, P3)
- \`Admin_Action\` (Dropdown: Pending, Approved, Rejected)
- \`Action_Date\` (অনুমোদনের তারিখ)

### Tab 5: \`AI_Knowledge_Base\` (AI-এর নিজস্ব মেমোরি)
AI প্রতিদিন যা শিখবে, তা এখানে প্যাটার্ন হিসেবে সেভ করে রাখবে।
- \`Pattern_ID\` (যেমন: PAT-01)
- \`Date_Discovered\` (তারিখ)
- \`Insight\` (যেমন: "Birth date is mostly corrected due to DD-MM-YYYY format confusion")
- \`Impact\` (High / Medium / Low)
- \`Status\` (Active / Resolved)

### Tab 6: \`Settings\` (Admin Control Panel)
এখান থেকে পুরো AI Scheduler ও সুপারভাইজার নিয়ন্ত্রণ করা হয়।
- \`Setting_Name\` (যেমন: AI_Run_Time, Report_Frequency, Admin_Email, Privacy_Filter)
- \`Setting_Value\` (যেমন: "11:30 PM", "Daily", "admin@boheratoil.gov.bd", "ON")
- \`Status\` (ON / OFF)

---

## ২. প্রাইভেসী ফিল্টার মেকানিজম (Privacy Filter Mechanism)
AI যখন ডেটা অ্যানালাইজ করতে যায়, তখন Google Apps Script শুধুমাত্র \`Event_Logs\` এবং \`Corrections_Log\` শিট থেকে ডেটা রিড করে।
- **Phone Number Filter:** \`/(?:(?:\+8801|8801|01))[3-9]\d{8}/g\` &rarr; \`[PHONE_MASKED]\`
- **NID/Birth ID Filter:** \`/\b(?:\d{17}|\d{13}|\d{10})\b/g\` &rarr; \`[ID_MASKED]\`
- **Email Filter:** \`/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g\` &rarr; \`[EMAIL_MASKED]\`
ফলে Gemini AI কোনোভাবেই নাগরিকদের ব্যক্তিগত সংবেদনশীল তথ্য পাবে না।
`
  },
  {
    id: '11_apps_script_code',
    filename: '11_APPS_SCRIPT_CODE.js',
    title: '১১. গুগল অ্যাপস স্ক্রিপ্ট কোড (Google Apps Script Code.gs)',
    category: 'automation',
    description: 'Google Sheets ও Web App-এর সাথে সরাসরি লাইভ সিঙ্ক করার জন্য প্রস্তুতকৃত Apps Script কোড।',
    content: `/**
 * UPSM 2.0 AI Registry & Certificate Sync — Google Apps Script (Code.gs)
 * ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল
 */

const SHARED_SECRET = "CHANGE_THIS_LONG_RANDOM_SECRET_32_CHARS";

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    
    // Validate secret token
    if (data.secret !== SHARED_SECRET) {
      return ContentService.createTextOutput(JSON.stringify({
        ok: false,
        error: "অননুমোদিত অ্যাক্সেস — সিক্রেট টোকেন মিলছে না।"
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheetName = data.sheetName || "AI_Registry";
    let sheet = ss.getSheetByName(sheetName);
    
    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
      sheet.appendRow(["Timestamp", "Tracking ID", "Type", "Name", "NID", "Ward", "Village", "Status", "Draft Text"]);
    }
    
    const row = [
      new Date(),
      data.trackingId || "",
      data.typeLabel || "",
      data.name || "",
      data.nid || "",
      data.ward || "",
      data.village || "",
      data.status || "AI_DRAFT",
      data.bodyText || ""
    ];
    
    sheet.appendRow(row);
    
    return ContentService.createTextOutput(JSON.stringify({
      ok: true,
      message: "তথ্য সফলভাবে Google Sheets-এ সংরক্ষিত হয়েছে।"
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      ok: false,
      error: err.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  return ContentService.createTextOutput(JSON.stringify({
    ok: true,
    service: "UPSM 2.0 AI Registry Sync",
    status: "সক্রিয় আছে",
    union: "০২নং বহেড়াতৈল ইউনিয়ন পরিষদ"
  })).setMimeType(ContentService.MimeType.JSON);
}
`
  },
  {
    id: '12_ai_supervisor_knowledge',
    filename: '12_AI_SUPERVISOR_KNOWLEDGE.md',
    title: '১২. AI Supervisor — সিস্টেম ইন্টেলিজেন্স ও কন্টিনিউয়াস ইমপ্রুভমেন্ট ইঞ্জিন',
    category: 'automation',
    description: '৭ ধরনের এরর প্যাটার্ন ইঞ্জিন, ৪-স্তর বাগ কনফিডেন্স স্কোরিং, রুট কজ অ্যানালাইসিস ও ডেইলি ইন্টেলিজেন্স শিডিউলার।',
    content: `# ১২নং AI Supervisor — সিস্টেম ইন্টেলিজেন্স ও কন্টিনিউয়াস ইমপ্রুভমেন্ট ইঞ্জিন
**স্ট্যাটাস:** 🟢 ACTIVE ARCHITECTURE (Phase 4 — System Intelligence & Continuous Improvement)
**লক্ষ্য:** ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল

---

## ১. পরিচয় ও ভূমিকা (Core Identity & Purpose)
এটি কোনো সাধারণ চ্যাটবট নয় — এটি সিস্টেমের **নিজের কার্যক্রম** (নাগরিকের ব্যক্তিগত তথ্য নয়) সার্বক্ষণিক পর্যবেক্ষণ করে ভুল কমানো ও কার্যকারিতা বাড়ানোর একটি স্বয়ংক্রিয় ইঞ্জিন।
- **ইন্টেলিজেন্স লুপ:** \`OBSERVE → UNDERSTAND → LEARN → DETECT → SUGGEST → VERIFY → IMPROVE\`
- **প্রশাসনিক সীমারেখা:** AI নিজেকে Certificate Approver বা মানব কর্মকর্তা হিসেবে বিবেচনা করবে না — চূড়ান্ত প্রশাসনিক সিদ্ধান্ত সবসময় অনুমোদিত অপারেটর বা কর্মকর্তার।

---

## ২. Google Sheets ডাটাবেস স্ট্রাকচার (৬-ট্যাব মাস্টার আর্কিটেকচার)
- **Applications** — \`App_ID\`, \`Date_Time\`, \`Applicant_Name\`, \`Phone_No\` (PII Masked), \`Service_Type\`, \`Status\`
- **Event_Logs** — \`Log_ID\`, \`Timestamp\`, \`Event_Category\`, \`Module\`, \`Action_By\`, \`Description\`, \`Status\`
- **Corrections_Log** — \`Correction_ID\`, \`Timestamp\`, \`Ref_App_ID\`, \`Field_Name\`, \`Old_Value\`, \`New_Value\`, \`Correction_Reason\`, \`Corrected_By\`
- **AI_Recommendations** — \`Rec_ID\`, \`Date_Generated\`, \`Category\`, \`Title\`, \`Root_Cause\`, \`Proposed_Fix\`, \`Confidence_Score\`, \`Priority\`, \`Admin_Action\`, \`Action_Date\`
- **AI_Knowledge_Base** — \`Pattern_ID\`, \`Date_Discovered\`, \`Insight\`, \`Impact\`, \`Status\`
- **Settings** — \`Setting_Name\`, \`Setting_Value\`, \`Status\`

---

## ৩. প্রাইভেসী ফিল্টার ও স্যানিটাইজেশন (Privacy Filter - বাধ্যতামূলক)
AI শুধুমাত্র \`Event_Logs\` ও \`Corrections_Log\` পড়বে — কখনো \`Applications\` ট্যাবের Raw PII পড়বে না।
Google Apps Script ও সিস্টেম রেগেক্স স্বয়ংক্রিয়ভাবে মাস্ক করবে:
- **ফোন নম্বর** &rarr; \`[PHONE_MASKED]\`
- **ইমেইল** &rarr; \`[EMAIL_MASKED]\`
- **NID/জন্মনিবন্ধন** &rarr; \`[ID_MASKED]\`
সংবেদনশীল ব্যক্তিগত তথ্য কখনো AI-এর স্থায়ী মেমোরিতে সংরক্ষণ হবে না, শুধু **Aggregate Insight** (যেমন: "Birth Date Validation Error occurred 14 times") সংরক্ষিত হবে।

---

## ৪. মনিটরিং স্কোপ (Monitoring Scope)
1. **Certificate Events:** Requested, Drafted, Corrected, Approved, Rejected, Regenerated, Cancelled
2. **Application Events:** Created, Updated, Missing Data, Validation Failed, Document Mismatch, Duplicate, Status Changed
3. **Correction Events:** \`Field → Old → New → Reason → Corrected By → Timestamp\` থেকে Repeated Error Pattern শনাক্তকরণ।

---

## ৫. এরর প্যাটার্ন ইঞ্জিন (৭ ধরনের ক্লাসিফিকেশন)
1. **Repeated Error (পুনরাবৃত্তিমূলক ভুল):** একই ফিল্ডে বারবার টাইপো বা ভুলের পুনরাবৃত্তি।
2. **Frequent Correction (ঘন ঘন সংশোধন):** নির্দিষ্ট সনদে নির্দিষ্ট ডাটার অতি ঘন ঘন বদল।
3. **Workflow Bottleneck (কাজের গতি মন্থরকারী ধাপ):** দীর্ঘক্ষণ ড্রাফট আটকে থাকা বা ড্রাফট রিজেক্টের কারণ।
4. **Validation Failure (যাচাইকরণ ব্যর্থতা):** গ্রাম/ওয়ার্ড মিসম্যাচ, NID ডিজিট মিসিং।
5. **Integration Failure (ইন্টিগ্রেশন ত্রুটি):** Sheets API, Drive API বা Webhook টাইমআউট।
6. **UX Problem (ইন্টারফেস জটিলতা):** অপারেটরের বাটন ক্লিক ব্যাকট্র্যাকিং বা বিভ্রান্তি।
7. **Data Quality Problem (ডাটা মান সমস্যা):** অস্পষ্ট ছবি, স্ক্যানার রেজ্যুলেশন কম হওয়া।

---

## ৬. বাগ ডিটেকশন ও কনফিডেন্স স্কোরিং (Confidence Tiers)
- **95% = Strong (নিশ্চিত বাগ):** নিশ্চিত সিস্টেমেটিক ত্রুটি যা কোড বা ডাটা ফিক্স দাবি করে।
- **80% = High (উচ্চ সম্ভাবনা):** শক্তিশালী প্রমাণ সম্বলিত কিন্তু পার্শ্বপ্রতিক্রিয়া যাচাই প্রয়োজন।
- **60% = Possible (সম্ভাব্য ত্রুটি):** বিচ্ছিন্ন ঘটনা যা নজরদারিতে রাখা উচিত।
- **<60% = Observation Only (পর্যবেক্ষণ মাত্র):** কখনো নিশ্চিত Bug হিসেবে উপস্থাপন করা নিষিদ্ধ।

---

## ৭. ডেইলি ইন্টেলিজেন্স রিপোর্ট (Daily Intelligence Report - বাস্তব শিডিউলার)
- **টাইমজোন:** Asia/Dhaka (ডিফল্ট: রাত ১১:৩০)
- **কাজের ধাপ:** \`Collect 24hr Events → Privacy Filter → AI Analysis → Bug Detection → Pattern Analysis → Report Generation → Notification\`
- **রিপোর্টের উপাদান:** System Summary, Bug Report, Learning Insights, Improvement Ideas, Risk Assessment, Recommended Actions (P0–P3)।
- **নির্ভরযোগ্যতা:** প্রতিটি জবের জন্য Unique Job ID, অফলাইন রিকভারি, এবং ৩ বার ফেইলিউর রিট্রাই মেকানিজম।

---

## ৮. রুট কজ অ্যানালাইসিস (Root Cause Analysis)
AI কেবল ত্রুটি বলবে না — সমস্যার মূল কার্যকারণ ও প্রস্তাবিত প্রতিকার প্রদান করবে:
- **সম্ভাব্য কারণ:** Input mismatch, Manual typing, OCR degradation, Missing validation rules, Template mapping error.
- **প্রতিকার:** Regex নিয়ম হালনাগাদ, ড্রপডাউন অপশন বৃদ্ধি, ডিফল্ট ভ্যালু প্রি-ফিল।

---

## ৯. কঠোর নিষেধাজ্ঞা — AI নিজে থেকে কখনোই করতে পারবে না (Safety Boundaries)
- Database Delete / ড্রপ
- Security / Permission পরিবর্তন
- User Role বা অনুমতি রূপান্তর
- Certificate Approval বা Rejection
- Production Deployment
- API Credential / Secret পরিবর্তন
- Data Destruction বা মুছে ফেলা
সর্বদা কঠোর নীতি: \`AI Recommendation → Human Verification & Approval → Secure Execution\`।

---

## ১০. নিরাপদ স্বয়ংক্রিয় উন্নয়ন (Safe Auto-Improvement)
শুধুমাত্র Low-risk আইটেম অনুমোদনের পর স্বয়ংক্রিয় হতে পারে:
- Non-sensitive UI পরামর্শ
- ফিল্ড ভ্যালিডেশন রেগেক্স সাজেশন
- Knowledge Base / ডকুমেন্টেশন আপডেট
- ত্রুটি ক্যাটাগরাইজেশন
প্রতিটি পদক্ষেপের জন্য অডিট লগ সংরক্ষিত থাকবে।
`
  },
  {
    id: '13_supervisor_core_gas',
    filename: '13_SUPERVISOR_CORE_APPS_SCRIPT.js',
    title: '১৩. AI Supervisor কোর ডাটাবেস ও অটোমেশন স্ক্রিপ্ট (Supervisor_Core.gs)',
    category: 'automation',
    description: '৬টি স্প্রেডশিট ট্যাব অটো-ক্রিয়েশন, PII প্রাইভেসী মাস্কিং ও Gemini ডেইলি অডিট শিডিউলার স্ক্রিপ্ট।',
    content: `/**
 * Project: UPSM 2.0 AI Supervisor Core Database Engine
 * File: Supervisor_Core.gs
 * Target: ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল
 */

const SUPERVISOR_CONFIG = {
  UP_NAME: "০২নং বহেড়াতৈল ইউনিয়ন পরিষদ",
  ADMIN_EMAIL: "admin@boheratoil.gov.bd",
  SCHEDULE_HOUR: 23, // 11 PM
  SCHEDULE_MINUTE: 30
};

// -------------------------------------------------------------
// ১. ৬টি ডেডিকেটেড ট্যাব অটো-ইনিশিয়ালাইজেশন
// -------------------------------------------------------------
function initializeSupervisorDatabase() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  const schema = {
    "Applications": ["App_ID", "Date_Time", "Applicant_Name", "Phone_No", "Service_Type", "Status"],
    "Event_Logs": ["Log_ID", "Timestamp", "Event_Category", "Module", "Action_By", "Description", "Status"],
    "Corrections_Log": ["Correction_ID", "Timestamp", "Ref_App_ID", "Field_Name", "Old_Value", "New_Value", "Correction_Reason", "Corrected_By"],
    "AI_Recommendations": ["Rec_ID", "Date_Generated", "Category", "Title", "Root_Cause", "Proposed_Fix", "Confidence_Score", "Priority", "Admin_Action", "Action_Date"],
    "AI_Knowledge_Base": ["Pattern_ID", "Date_Discovered", "Insight", "Impact", "Status"],
    "Settings": ["Setting_Name", "Setting_Value", "Status"]
  };
  
  for (let tabName in schema) {
    let sheet = ss.getSheetByName(tabName);
    if (!sheet) {
      sheet = ss.insertSheet(tabName);
      sheet.appendRow(schema[tabName]);
      sheet.getRange(1, 1, 1, schema[tabName].length).setFontWeight("bold").setBackground("#e2e8f0");
      sheet.setFrozenRows(1);
    }
  }
  
  // Settings ডিফল্ট রো যোগ
  const settingsSheet = ss.getSheetByName("Settings");
  if (settingsSheet.getLastRow() <= 1) {
    settingsSheet.appendRow(["AI_Run_Time", "11:30 PM (Asia/Dhaka)", "ON"]);
    settingsSheet.appendRow(["Report_Frequency", "Daily", "ON"]);
    settingsSheet.appendRow(["Admin_Email", SUPERVISOR_CONFIG.ADMIN_EMAIL, "ON"]);
    settingsSheet.appendRow(["Privacy_Filter", "Enabled (PII Regex Masking)", "ON"]);
  }
  
  Logger.log("✓ ৬টি স্প্রেডশিট ট্যাব সফলভাবে প্রস্তুত হয়েছে!");
}

// -------------------------------------------------------------
// ২. প্রাইভেসী ফিল্টার (PII Masking) ফাংশন
// -------------------------------------------------------------
function maskSensitivePII(text) {
  if (!text) return "";
  let str = String(text);
  // Phone Mask
  str = str.replace(/(?:(?:\+8801|8801|01))[3-9]\\d{8}/g, "[PHONE_MASKED]");
  // NID Mask
  str = str.replace(/\\b(?:\\d{17}|\\d{13}|\\d{10})\\b/g, "[ID_MASKED]");
  // Email Mask
  str = str.replace(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}/g, "[EMAIL_MASKED]");
  return str;
}

// -------------------------------------------------------------
// ৩. WebApp POST রিসিভার (Web App থেকে ইভেন্ট ও লগ সিঙ্ক)
// -------------------------------------------------------------
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    
    if (data.action === "LOG_EVENT") {
      const sheet = ss.getSheetByName("Event_Logs");
      sheet.appendRow([
        data.logId || ("LOG-" + new Date().getTime().toString().slice(-4)),
        new Date().toLocaleString("bn-BD", { timeZone: "Asia/Dhaka" }),
        data.category || "General",
        data.module || "System",
        data.actionBy || "Operator",
        maskSensitivePII(data.description),
        data.status || "Success"
      ]);
    } else if (data.action === "LOG_CORRECTION") {
      const sheet = ss.getSheetByName("Corrections_Log");
      sheet.appendRow([
        data.correctionId || ("COR-" + new Date().getTime().toString().slice(-4)),
        new Date().toLocaleString("bn-BD", { timeZone: "Asia/Dhaka" }),
        data.refAppId || "N/A",
        data.fieldName || "General",
        maskSensitivePII(data.oldValue),
        maskSensitivePII(data.newValue),
        data.reason || "Correction",
        data.correctedBy || "Operator"
      ]);
    }
    
    return ContentService.createTextOutput(JSON.stringify({ success: true, message: "লগ সফলভাবে সংরক্ষিত হয়েছে।" }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ success: false, error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
`
  }
];
