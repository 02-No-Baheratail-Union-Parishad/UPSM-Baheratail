// ============================================================
// src/data/roleVisibility.ts
// রোলভিত্তিক মেনু ও সেটিংস দৃশ্যমানতা কনফিগারেশন (Role Visibility Engine)
// ডেভেলপার / সুপার এডমিন কর্তৃক নাগরিক, ইউডিজি, সচিব ও চেয়ারম্যানদের
// অপশন দৃশ্যমানতা ও হাইড করার মাস্টার কন্ট্রোল লজিক।
// ============================================================

import { UnionParishadConfig } from '../types';

export interface NavMenuDefinition {
  id: string;
  labelBn: string;
  labelEn: string;
  category: 'public' | 'operator' | 'admin' | 'developer';
  description: string;
  isPublicDefault: boolean;
}

export interface SettingsTabDefinition {
  id: string;
  labelBn: string;
  category: 'office' | 'sign_print' | 'integration' | 'security' | 'developer';
  description: string;
}

// All System Sidebar Menus
export const ALL_NAV_MENUS: NavMenuDefinition[] = [
  {
    id: 'home',
    labelBn: '১. ড্যাশবোর্ড ও সার্বিক চিত্র',
    labelEn: '1. Dashboard',
    category: 'public',
    description: 'ইউনিয়ন পরিষদের সারসংক্ষেপ, লাইভ নোটিশ ও দ্রুত সেবা উইজেট',
    isPublicDefault: true
  },
  {
    id: 'pending',
    labelBn: '২. চেয়ারম্যান ও সচিব অনুমোদন ডেক্স',
    labelEn: '2. Pending Approvals',
    category: 'admin',
    description: 'অপেক্ষমাণ খসড়া প্রত্যয়নপত্রের ৩-স্তর বিশিষ্ট অনুমোদন ও ই-স্বাক্ষর',
    isPublicDefault: false
  },
  {
    id: 'citizens',
    labelBn: '৩. নাগরিক একাউন্ট ও মাস্টার রেজিস্টার',
    labelEn: '3. Citizen Accounts',
    category: 'operator',
    description: 'ওয়ার্ডভিত্তিক নিবন্ধিত নাগরিক ডাটাবেস ও স্মার্ট প্রোফাইল তথ্য',
    isPublicDefault: false
  },
  {
    id: 'citizen_profile',
    labelBn: '৩.১ সিটিজেন প্রোফাইল জেনারেটর',
    labelEn: '3.1 Citizen Profile',
    category: 'public',
    description: 'নাগরিকের পাবলিক প্রোফাইল ও কিউআর শেয়ারিং পেজ',
    isPublicDefault: true
  },
  {
    id: 'holding_tax',
    labelBn: '৩.২ হোল্ডিং ট্যাক্স ও বকেয়া খতিয়ান',
    labelEn: '3.2 Holding Tax',
    category: 'operator',
    description: 'ওয়ার্ড ১-৯ এর হোল্ডিং কর হিসাব ও বকেয়া মনিটরিং ড্যাশবোর্ড',
    isPublicDefault: false
  },
  {
    id: 'create',
    labelBn: '৪. নতুন প্রত্যয়নপত্র আবেদন ও এআই ড্রাফট',
    labelEn: '4. New Certificate Application',
    category: 'operator',
    description: '৮০+ ধরনের অফিসিয়াল প্রত্যয়নপত্র ও সনদের স্মার্ট জেনারেটর',
    isPublicDefault: false
  },
  {
    id: 'logs',
    labelBn: '৫. সনদ পেজ ও রেকর্ড (সকল)',
    labelEn: '5. All Certificate Records',
    category: 'operator',
    description: 'ইস্যুকৃত ও অনুমোদিত সকল সনদের অফিসিয়াল ডিজিটাল আর্কাইভ',
    isPublicDefault: false
  },
  {
    id: 'search_reprint',
    labelBn: '৫.১ সনদ সার্চ ও রি-প্রিন্ট পোর্টাল',
    labelEn: '5.1 Search & Reprint',
    category: 'public',
    description: 'এনআইডি বা ট্র্যাকিং নম্বর দিয়ে ইস্যুকৃত সনদ দ্রুত অনুসন্ধান ও পুনঃমুদ্রণ',
    isPublicDefault: true
  },
  {
    id: 'verify',
    labelBn: '৬. সনদ অনলাইন যাচাই (QR Verification)',
    labelEn: '6. Online Verification',
    category: 'public',
    description: 'কিউআর কোড বা ট্র্যাকিং আইডি দিয়ে যেকোনো সনদের তাৎক্ষণিক সরকারি যাচাই',
    isPublicDefault: true
  },
  {
    id: 'members',
    labelBn: '৭. পরিষদ সদস্য ও কর্মকর্তা ডিরেক্টরি',
    labelEn: '7. Council Members & Staff',
    category: 'public',
    description: 'চেয়ারম্যান, মেম্বার ও কর্মকর্তা-কর্মচারীদের যোগাযোগ তালিকা',
    isPublicDefault: true
  },
  {
    id: 'heatmap',
    labelBn: '৮. উন্নয়ন হিটম্যাপ ও এনালাইটিক্স',
    labelEn: '8. Development Heatmap',
    category: 'public',
    description: 'ওয়ার্ডভিত্তিক সেবা গ্রহণ ও উন্নয়ন কার্যক্রমের ইন্টার-অ্যাক্টিভ ম্যাপ',
    isPublicDefault: true
  },
  {
    id: 'map',
    labelBn: '৯. জিআইএস ওয়ার্ড ম্যাপ',
    labelEn: '9. GIS Ward Map',
    category: 'public',
    description: 'ইউনিয়ন পরিষদের ভৌগোলিক সীমানা ও গ্রাম বিন্যাস',
    isPublicDefault: true
  },
  {
    id: 'notice',
    labelBn: '১০. ডিজিটাল নোটিশ বোর্ড',
    labelEn: '10. Notice Board',
    category: 'public',
    description: 'ইউপি’র সকল নোটিশ, সার্কুলার ও জরুরি ঘোষণা',
    isPublicDefault: true
  },
  {
    id: 'google_chat',
    labelBn: '১১. গুগল চ্যাট ও টিম স্পেস',
    labelEn: '11. Google Chat Portal',
    category: 'admin',
    description: 'দাপ্তরিক টিম মেসেজিং ও গুগল ওয়ার্কস্পেস অটোমেশন চ্যাট',
    isPublicDefault: false
  },
  {
    id: 'gem_studio',
    labelBn: '১২. গুগল জেম ও নলেজ ফাইল হাব',
    labelEn: '12. Gemini Gem Hub',
    category: 'operator',
    description: 'জেমিনি কাস্টম জেম প্রম্পট ও নলেজ ফাইল প্যাকেজ ডাউনলোড',
    isPublicDefault: false
  },
  {
    id: 'cloud_connectors',
    labelBn: '১৩. ক্লাউড কানেক্টরস ও অটোমেশন হাব',
    labelEn: '13. Cloud Connectors',
    category: 'developer',
    description: 'n8n, Apps Script, Make.com ও ১৪+ অটোমেশন সিস্টেম ইন্টিগ্রেশন',
    isPublicDefault: false
  },
  {
    id: 'audit_trail',
    labelBn: '১৪. অ্যাক্টিভিটি অডিট ট্রেইল ও লগ',
    labelEn: '14. Activity Audit Trail',
    category: 'admin',
    description: 'সকল লগইন, ড্রাফট পরিবর্তন ও অফিসিয়াল কার্যকলাপের ফরেনসিক অডিট',
    isPublicDefault: false
  },
  {
    id: 'admin_dashboard',
    labelBn: '১৫. ইউজার ও পারমিশন রোল ড্যাশবোর্ড',
    labelEn: '15. Admin Users & Roles',
    category: 'admin',
    description: 'এডমিন ডিরেক্টরি, বায়োমেট্রিক ইভেন্ট ও অ্যাক্সেস পারমিশন ম্যাট্রিক্স',
    isPublicDefault: false
  },
  {
    id: 'admin',
    labelBn: '১৬. মাস্টার সেটআপ ও এডমিন সেটিংস',
    labelEn: '16. Master Settings',
    category: 'admin',
    description: 'ইউপি মাস্টার কনফিগারেশন, প্রিন্ট লেআউট ও পলিসি শর্তাবলী',
    isPublicDefault: false
  },
  {
    id: 'developer_control',
    labelBn: '১৭. ডেভেলপার সিকিউরিটি অ্যান্ড কন্ট্রোল',
    labelEn: '17. Developer Security Control',
    category: 'developer',
    description: 'সিস্টেম ডেভেলপারদের মাস্টার সিকিউরিটি কনসোল ও ডেডিকেটেড রুলস',
    isPublicDefault: false
  },
  {
    id: 'developer',
    labelBn: '১৮. ডেভেলপার প্রোফাইল ও আর্কিটেকচার',
    labelEn: '18. Developer Profile',
    category: 'public',
    description: 'প্রধান সিস্টেম আর্কিটেক্ট ও ডেভেলপার পরিচিতি ও বায়ো',
    isPublicDefault: true
  },
  {
    id: 'ai_supervisor',
    labelBn: '১৯. ইন-বিল্ট এআই সুপারভাইজার',
    labelEn: '19. AI Supervisor Engine',
    category: 'admin',
    description: 'সিস্টেম ইন্টেলিজেন্স, ভুল শনাক্তকরণ, অটো-লার্নিং ও দৈনিক কোয়ালিটি রিপোর্ট',
    isPublicDefault: false
  }
];

// All System Settings Tabs
export const ALL_SETTINGS_TABS: SettingsTabDefinition[] = [
  {
    id: 'ai_supervisor',
    labelBn: '🧠 এআই সুপারভাইজার ও সিস্টেম ইন্টেলিজেন্স',
    category: 'security',
    description: 'স্বায়ত্তশাসিত কোয়ালিটি লার্নিং, এরর ট্র্যাকিং ও দৈনিক এক্সিকিউটিভ রিপোর্ট'
  },
  {
    id: 'pending',
    labelBn: 'চেয়ারম্যান ও সচিব অনুমোদন ডেক্স',
    category: 'office',
    description: 'অপেক্ষমাণ খসড়া প্রত্যয়নসমূহের চূড়ান্ত অনুমোদন ও সাইন'
  },
  {
    id: 'general',
    labelBn: '১. ইউপি সাধারণ তথ্য ও পরিষদ প্রোফাইল',
    category: 'office',
    description: 'ইউনিয়ন পরিষদের নাম, ঠিকানা, কর্মকর্তা পরিচিতি ও হেল্পলাইন'
  },
  {
    id: 'print',
    labelBn: '২. প্রিন্ট লেআউট, সিল ও ডিজিটাল স্বাক্ষর',
    category: 'sign_print',
    description: 'চেয়ারম্যান ও সচিবের ই-স্বাক্ষর, অফিসিয়াল সিল ও প্যাড লেআউট'
  },
  {
    id: 'types',
    labelBn: '৬. প্রত্যয়ন প্রকারভেদ ও সরকারি ফি তালিকা',
    category: 'office',
    description: '৮০+ প্রত্যয়নের সরকারি ফি ও প্রয়োজনীয় দলিলাদি কনফিগারেশন'
  },
  {
    id: 'system_policy',
    labelBn: '১৪. সিস্টেম পলিসি কন্ট্রোলার (System Policy Controller)',
    category: 'office',
    description: 'মেম্বার অনুমোদন, সচিব ভেরিফিকেশন, ট্যাক্স ক্লিয়ারেন্স ও ওয়ার্কফ্লো টগল সুইচ'
  },
  {
    id: 'system_rules',
    labelBn: '১৩. সিস্টেম শর্ত ও পলিসি রুলস ম্যানেজার',
    category: 'office',
    description: 'মেম্বার অনুমোদন, সচিব যাচাই ও হোল্ডিং ট্যাক্স বাধ্যতামূলক/ঐচ্ছিক শর্ত'
  },
  {
    id: 'council_members',
    labelBn: '১১. পরিষদ সদস্য ও কর্মকর্তা তালিকা',
    category: 'office',
    description: 'সংরক্ষিত মেম্বার, সাধারণ মেম্বার ও কর্মচারীদের প্রোফাইল আপডেট'
  },
  {
    id: 'role_management',
    labelBn: '১২. ডায়নামিক রোল ও মেনু পারমিশন কন্ট্রোল',
    category: 'security',
    description: 'কাদের কোন মেনু দেখানো হবে ও কাদের অপশন হাইড রাখা হবে তা নিয়ন্ত্রণ'
  },
  {
    id: 'multi_admin',
    labelBn: '১০. মাল্টি-এডমিন ইউজার ডিরেক্টরি',
    category: 'security',
    description: 'সিস্টেমে অনুমোদিত এডমিন, সচিব ও অপারেটরদের তালিকা'
  },
  {
    id: 'workspace',
    labelBn: '৩. গুগল ওয়ার্কস্পেস ও ড্রাইভ ক্লাউড',
    category: 'integration',
    description: 'গুগল ড্রাইভ ফোল্ডার, গুগল শিটস ও Apps Script ওয়েবহুক'
  },
  {
    id: 'r2',
    labelBn: '৪. ক্লাউডফ্লেয়ার R2 স্টোরেজ',
    category: 'integration',
    description: 'সংযুক্ত ডকুমেন্ট ও পিডিএফ স্থায়ী সংরক্ষণের জন্য ক্লাউড বাকেট'
  },
  {
    id: 'ai',
    labelBn: '৫. গুগল জেমিনি এআই কনফিগারেশন',
    category: 'integration',
    description: 'স্মার্ট ড্রাফটিং ও এনআইডি ওসিআরের জন্য জেমিনি মডেল ইঞ্জিন'
  },
  {
    id: 'backup',
    labelBn: '৭. ক্লাউড ব্যাকআপ ও রেস্টোর',
    category: 'security',
    description: 'ডাটাবেস ব্যাকআপ জেনারেশন ও ক্লাউড রিস্টোরেশন'
  },
  {
    id: 'maintenance',
    labelBn: '৮. সিস্টেম মেইনটেন্যান্স ও রিসেট',
    category: 'developer',
    description: 'ক্যাশ ক্লিয়ার, ডাটাবেস রিসেট ও কোর সিস্টেম ডায়াগনস্টিকস'
  },
  {
    id: 'api_webhook',
    labelBn: '৯. API কী ও ওয়েব হুক ইঞ্জিন',
    category: 'developer',
    description: 'বাহ্যিক অ্যাপ বা সার্ভারের জন্য সিকিউর API টোকেন ও ইভেন্ট হুক'
  }
];

// Default Menu Visibility Matrix per Role
export const DEFAULT_MENU_VISIBILITY: Record<string, Record<string, boolean>> = {
  // 1. সাধারণ নাগরিক / পাবলিক গেস্ট (Citizen/Public) -> শুধুমাত্র পাবলিক সেবা দেখতে পারবে
  citizen: {
    home: true,
    pending: false,
    citizens: false,
    citizen_profile: true,
    holding_tax: false,
    create: false,
    logs: false,
    search_reprint: true,
    verify: true,
    members: true,
    heatmap: true,
    map: true,
    notice: true,
    google_chat: false,
    gem_studio: false,
    cloud_connectors: false,
    audit_trail: false,
    admin_dashboard: false,
    admin: false,
    developer_control: false,
    developer: true,
    ai_supervisor: false
  },

  // 2. ইউডিজি উদ্যোক্তা / মেম্বার / ডাটা অপারেটর (UDC / Operator / Member)
  udc: {
    home: true,
    pending: false,
    citizens: true,
    citizen_profile: true,
    holding_tax: true,
    create: true,
    logs: true,
    search_reprint: true,
    verify: true,
    members: true,
    heatmap: true,
    map: true,
    notice: true,
    google_chat: true,
    gem_studio: true,
    cloud_connectors: false,
    audit_trail: false,
    admin_dashboard: false,
    admin: false,
    developer_control: false,
    developer: true,
    ai_supervisor: true
  },
  member: {
    home: true,
    pending: false,
    citizens: true,
    citizen_profile: true,
    holding_tax: true,
    create: true,
    logs: true,
    search_reprint: true,
    verify: true,
    members: true,
    heatmap: true,
    map: true,
    notice: true,
    google_chat: true,
    gem_studio: true,
    cloud_connectors: false,
    audit_trail: false,
    admin_dashboard: false,
    admin: false,
    developer_control: false,
    developer: true,
    ai_supervisor: true
  },

  // 3. ইউপি সচিব (Secretary) -> সচিব যাচাই, প্রত্যয়ন রেজিস্টার, ইউপি তথ্য
  secretary: {
    home: true,
    pending: true, // সচিবের স্টেজ-২ যাচাই ডেক্স
    citizens: true,
    citizen_profile: true,
    holding_tax: true,
    create: true,
    logs: true,
    search_reprint: true,
    verify: true,
    members: true,
    heatmap: true,
    map: true,
    notice: true,
    google_chat: true,
    gem_studio: true,
    cloud_connectors: false,
    audit_trail: true,
    admin_dashboard: true,
    admin: true,
    developer_control: false,
    developer: true,
    ai_supervisor: true
  },

  // 4. ইউপি চেয়ারম্যান (Chairman) -> চেয়ারম্যান চূড়ান্ত অনুমোদন, পরিষদ সেটিংস, অডিট
  chairman: {
    home: true,
    pending: true, // চেয়ারম্যান চূড়ান্ত অনুমোদন
    citizens: true,
    citizen_profile: true,
    holding_tax: true,
    create: true,
    logs: true,
    search_reprint: true,
    verify: true,
    members: true,
    heatmap: true,
    map: true,
    notice: true,
    google_chat: true,
    gem_studio: true,
    cloud_connectors: false,
    audit_trail: true,
    admin_dashboard: true,
    admin: true,
    developer_control: false,
    developer: true,
    ai_supervisor: true
  },

  // 5. সুপার এডমিন / ডেভেলপার (Super Admin / Developer) -> সর্বময় এক্সেস (১০০% উন্মুক্ত)
  super_admin: {
    home: true,
    pending: true,
    citizens: true,
    citizen_profile: true,
    holding_tax: true,
    create: true,
    logs: true,
    search_reprint: true,
    verify: true,
    members: true,
    heatmap: true,
    map: true,
    notice: true,
    google_chat: true,
    gem_studio: true,
    cloud_connectors: true,
    audit_trail: true,
    admin_dashboard: true,
    admin: true,
    developer_control: true,
    developer: true,
    ai_supervisor: true
  },
  developer: {
    home: true,
    pending: true,
    citizens: true,
    citizen_profile: true,
    holding_tax: true,
    create: true,
    logs: true,
    search_reprint: true,
    verify: true,
    members: true,
    heatmap: true,
    map: true,
    notice: true,
    google_chat: true,
    gem_studio: true,
    cloud_connectors: true,
    audit_trail: true,
    admin_dashboard: true,
    admin: true,
    developer_control: true,
    developer: true,
    ai_supervisor: true
  }
};

// Default Settings Tab Visibility per Role
export const DEFAULT_SETTINGS_TAB_VISIBILITY: Record<string, Record<string, boolean>> = {
  // Citizen cannot access Admin Settings at all
  citizen: {
    pending: false,
    general: false,
    print: false,
    types: false,
    system_rules: false,
    council_members: false,
    role_management: false,
    multi_admin: false,
    workspace: false,
    r2: false,
    ai: false,
    backup: false,
    maintenance: false,
    api_webhook: false
  },

  // UDC / Operator
  udc: {
    pending: false,
    general: false,
    print: false,
    types: true, // দেখতে পারবে
    system_rules: false,
    council_members: true,
    role_management: false,
    multi_admin: false,
    workspace: false,
    r2: false,
    ai: false,
    backup: false,
    maintenance: false,
    api_webhook: false
  },
  member: {
    pending: false,
    general: false,
    print: false,
    types: true,
    system_rules: false,
    council_members: true,
    role_management: false,
    multi_admin: false,
    workspace: false,
    r2: false,
    ai: false,
    backup: false,
    maintenance: false,
    api_webhook: false
  },

  // Secretary
  secretary: {
    pending: true,
    general: true,
    print: true,
    types: true,
    system_rules: true,
    council_members: true,
    role_management: false,
    multi_admin: false,
    workspace: true,
    r2: false,
    ai: false,
    backup: true,
    maintenance: false,
    api_webhook: false
  },

  // Chairman
  chairman: {
    pending: true,
    general: true,
    print: true,
    types: true,
    system_rules: true,
    council_members: true,
    role_management: true,
    multi_admin: true,
    workspace: true,
    r2: false,
    ai: false,
    backup: true,
    maintenance: false,
    api_webhook: false
  },

  // Super Admin & Developer -> All Tabs Visible
  super_admin: {
    pending: true,
    general: true,
    print: true,
    types: true,
    system_rules: true,
    council_members: true,
    role_management: true,
    multi_admin: true,
    workspace: true,
    r2: true,
    ai: true,
    backup: true,
    maintenance: true,
    api_webhook: true
  },
  developer: {
    pending: true,
    general: true,
    print: true,
    types: true,
    system_rules: true,
    council_members: true,
    role_management: true,
    multi_admin: true,
    workspace: true,
    r2: true,
    ai: true,
    backup: true,
    maintenance: true,
    api_webhook: true
  }
};

/**
 * Check whether a navigation menu is visible for a specific user role.
 * Developer / Super Admin can override this dynamically via config.menuVisibilityMatrix.
 */
export function isMenuVisibleForRole(
  menuId: string,
  role: string = 'citizen',
  config?: UnionParishadConfig | null
): boolean {
  const normalizedRole = (role || 'citizen').toLowerCase();

  // Developers and Super Admins always have master access
  if (normalizedRole === 'developer' || normalizedRole === 'super_admin') {
    return true;
  }

  // Check customized matrix in UP config if available
  if (config?.menuVisibilityMatrix && config.menuVisibilityMatrix[normalizedRole]) {
    const customRoleSetting = config.menuVisibilityMatrix[normalizedRole][menuId];
    if (typeof customRoleSetting === 'boolean') {
      return customRoleSetting;
    }
  }

  // Fallback to default matrix
  const roleDefaults = DEFAULT_MENU_VISIBILITY[normalizedRole] || DEFAULT_MENU_VISIBILITY.citizen;
  return roleDefaults[menuId] ?? false;
}

/**
 * Check whether an Admin Settings Tab is visible for a specific user role.
 * Developer / Super Admin can override this dynamically via config.settingsTabVisibilityMatrix.
 */
export function isSettingsTabVisibleForRole(
  tabId: string,
  role: string = 'citizen',
  config?: UnionParishadConfig | null
): boolean {
  const normalizedRole = (role || 'citizen').toLowerCase();

  // Developers and Super Admins always have master access
  if (normalizedRole === 'developer' || normalizedRole === 'super_admin') {
    return true;
  }

  // Check customized matrix in UP config if available
  if (config?.settingsTabVisibilityMatrix && config.settingsTabVisibilityMatrix[normalizedRole]) {
    const customRoleSetting = config.settingsTabVisibilityMatrix[normalizedRole][tabId];
    if (typeof customRoleSetting === 'boolean') {
      return customRoleSetting;
    }
  }

  // Fallback to default matrix
  const roleDefaults = DEFAULT_SETTINGS_TAB_VISIBILITY[normalizedRole] || DEFAULT_SETTINGS_TAB_VISIBILITY.citizen;
  return roleDefaults[tabId] ?? false;
}

/**
 * Get the full effective menu visibility matrix for all roles
 */
export function getEffectiveMenuMatrix(config?: UnionParishadConfig | null): Record<string, Record<string, boolean>> {
  const base = JSON.parse(JSON.stringify(DEFAULT_MENU_VISIBILITY));
  if (config?.menuVisibilityMatrix) {
    Object.keys(config.menuVisibilityMatrix).forEach(role => {
      if (!base[role]) base[role] = {};
      Object.keys(config.menuVisibilityMatrix![role]).forEach(menuId => {
        base[role][menuId] = config.menuVisibilityMatrix![role][menuId];
      });
    });
  }
  return base;
}

/**
 * Get the full effective settings tab visibility matrix for all roles
 */
export function getEffectiveSettingsTabMatrix(config?: UnionParishadConfig | null): Record<string, Record<string, boolean>> {
  const base = JSON.parse(JSON.stringify(DEFAULT_SETTINGS_TAB_VISIBILITY));
  if (config?.settingsTabVisibilityMatrix) {
    Object.keys(config.settingsTabVisibilityMatrix).forEach(role => {
      if (!base[role]) base[role] = {};
      Object.keys(config.settingsTabVisibilityMatrix![role]).forEach(tabId => {
        base[role][tabId] = config.settingsTabVisibilityMatrix![role][tabId];
      });
    });
  }
  return base;
}
