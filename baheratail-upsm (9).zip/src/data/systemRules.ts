import { SystemRuleItem, UnionParishadConfig, RuleRequirementLevel, RuleCategoryType } from '../types';

export const RULE_CATEGORIES: { key: RuleCategoryType; label: string; description: string }[] = [
  { key: 'approval', label: 'অনুমোদন ও স্বাক্ষর প্রক্রিয়া', description: 'মেম্বার, সচিব ও চেয়ারম্যান অনুমোদন লেভেল ও শর্ত' },
  { key: 'verification', label: 'তথ্য ও নাগরিকত্ব যাচাই', description: 'এনআইডি, জন্মনিবন্ধন ও ওয়ার্ড বাসিন্দা প্রামাণ্য শর্ত' },
  { key: 'fee_tax', label: 'সরকারি ফি ও ট্যাক্স ক্লিয়ারেন্স', description: 'হোল্ডিং ট্যাক্স ও সনদ ফি পরিশোধ শর্ত' },
  { key: 'draft_ai', label: 'এআই ড্রাফটিং ও ভাষা নির্দেশনা', description: 'খসড়া প্রস্তুতকরণ ও ভাষা গাম্ভীর্য শর্ত' },
  { key: 'delivery', label: 'মুদ্রণ ও ডেলিভারি মোড', description: 'লেটারহেড প্যাড, কিউআর সিল ও বিতরণ শর্ত' },
  { key: 'custom', label: 'কাস্টম ও বিশেষ দাপ্তরিক শর্ত', description: 'ইউজার কর্তৃক তৈরিকৃত নিজস্ব শর্ত ও পলিসি' },
];

export const REQUIREMENT_LEVEL_LABELS: Record<RuleRequirementLevel, { label: string; color: string; badge: string; desc: string }> = {
  mandatory: {
    label: 'বাধ্যতামূলক (Mandatory)',
    color: 'text-rose-700 bg-rose-50 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800',
    badge: 'bg-rose-600 text-white',
    desc: 'এই শর্ত পূরণ ব্যতিরেকে আবেদন অগ্রসর বা চূড়ান্ত অনুমোদন দেওয়া যাইবে না।'
  },
  optional: {
    label: 'ঐচ্ছিক (Optional / প্রযোজ্য নয়)',
    color: 'text-emerald-700 bg-emerald-50 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800',
    badge: 'bg-emerald-600 text-white',
    desc: 'শর্তটি পূরণ করা বাধ্যতামুলক নয়, নাগরিক সুবিধার্থে সরাসরি সেবা প্রদান করা যাইবে।'
  },
  advisory: {
    label: 'উপদেশমূলক / সতর্কবার্তা (Advisory)',
    color: 'text-amber-700 bg-amber-50 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800',
    badge: 'bg-amber-600 text-white',
    desc: 'অপারেটর ও নাগরিকের অবগতির জন্য সতর্কবার্তা প্রদর্শিত হইবে, তবে সেবা বাধাগ্রস্ত হইবে না।'
  },
  disabled: {
    label: 'বাতিল / স্থগিত (Disabled)',
    color: 'text-slate-600 bg-slate-100 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700',
    badge: 'bg-slate-500 text-white',
    desc: 'শর্তটি বর্তমানে অকার্যকর ও সাময়িকভাবে বাতিল রাখা হইয়াছে।'
  }
};

export const DEFAULT_SYSTEM_RULES: SystemRuleItem[] = [
  {
    id: 'rule_member_approval',
    code: 'MEMBER_APPROVAL_OPTIONAL_RULE',
    title: 'ইউপি সদস্য / মেম্বার সুপারিশ ও অনুমোদন শর্ত',
    category: 'approval',
    categoryLabel: 'অনুমোদন ও স্বাক্ষর প্রক্রিয়া',
    appliesTo: 'all',
    requirementLevel: 'optional', // Default as per user request: "যেমন মেম্বার এর অনুমোদন বাধ্যতামুলক নয়"
    instructionText: 'নাগরিকের সনদ প্রাপ্তিতে সংশ্লিষ্ট ওয়ার্ড মেম্বারের অনুমোদন বা সুপারিশ বাধ্যতামূলক নয়। মেম্বার অনুপলব্ধ থাকিলেও সচিবের তথ্য যাচাই ও চেয়ারম্যানের চূড়ান্ত স্বাক্ষরে সনদ কার্যকর হইবে। প্রয়োজনে যেকোনো সময় এই শর্তটি বাধ্যতামূলক বা বাতিল করা যাইবে।',
    enabled: true,
    isSystemDefault: true,
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-20T11:00:00.000Z',
    lastUpdatedBy: 'সিস্টেম অ্যাডমিন'
  },
  {
    id: 'rule_secretary_verification',
    code: 'SECRETARY_VERIFICATION_RULE',
    title: 'ইউপি প্রশাসনিক কর্মকর্তা / সচিবের প্রশাসনিক যাচাই',
    category: 'approval',
    categoryLabel: 'অনুমোদন ও স্বাক্ষর প্রক্রিয়া',
    appliesTo: 'all',
    requirementLevel: 'mandatory',
    instructionText: 'উদ্যোক্তা কর্তৃক প্রস্তুতকৃত খসড়াটি চেয়ারম্যানের চূড়ান্ত স্বাক্ষরের পূর্বে সচিবের প্রশাসনিক ডাটাবেজ ও রেজিস্টারের সাথে যাচাইপূর্বক সুপারিশ প্রদান বাধ্যতামূলক।',
    enabled: true,
    isSystemDefault: true,
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-20T11:00:00.000Z',
    lastUpdatedBy: 'সিস্টেম অ্যাডমিন'
  },
  {
    id: 'rule_chairman_final_signature',
    code: 'CHAIRMAN_FINAL_SIGNATURE_RULE',
    title: 'ইউপি চেয়ারম্যান / প্রশাসকের চূড়ান্ত ই-স্বাক্ষর অনুমোদন',
    category: 'approval',
    categoryLabel: 'অনুমোদন ও স্বাক্ষর প্রক্রিয়া',
    appliesTo: 'all',
    requirementLevel: 'mandatory',
    instructionText: 'সচিবের যাচাইকৃত খসড়াটি চেয়ারম্যানের চূড়ান্ত ডিজিটাল স্বাক্ষরের পরেই কেবল মাত্র কিউআর ভেরিফাইড সনদ হিসেবে গণ্য ও প্রিন্ট করা যাইবে।',
    enabled: true,
    isSystemDefault: true,
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-20T11:00:00.000Z',
    lastUpdatedBy: 'সিস্টেম অ্যাডমিন'
  },
  {
    id: 'rule_holding_tax_clearance',
    code: 'HOLDING_TAX_CLEARANCE_RULE',
    title: 'হোল্ডিং ট্যাক্স ও বাৎসরিক কর পরিশোধ শর্ত',
    category: 'fee_tax',
    categoryLabel: 'সরকারি ফি ও ট্যাক্স ক্লিয়ারেন্স',
    appliesTo: 'all',
    requirementLevel: 'advisory',
    instructionText: 'হোল্ডিং ট্যাক্স বকেয়া থাকিলেও জরুরি নাগরিক প্রত্যয়ন বন্ধ রাখা যাইবে না। তবে প্রিন্ট কপি বা ভেরিফিকেশনে হোল্ডিং কর পরিশোধের তথ্য প্রদর্শিত হইতে পারে।',
    enabled: true,
    isSystemDefault: true,
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-20T11:00:00.000Z',
    lastUpdatedBy: 'সিস্টেম অ্যাডমিন'
  },
  {
    id: 'rule_strict_nid_brn_digits',
    code: 'STRICT_NID_BRN_DIGITS_RULE',
    title: 'জাতীয় পরিচয়পত্র ও জন্ম নিবন্ধন সংখ্যা ফরম্যাট কঠোর যাচাই',
    category: 'verification',
    categoryLabel: 'তথ্য ও নাগরিকত্ব যাচাই',
    appliesTo: 'all',
    requirementLevel: 'mandatory',
    instructionText: 'জাতীয় পরিচয়পত্র ১০, ১৩ অথবা ১৭ সংখ্যা বিশিষ্ট এবং জন্ম নিবন্ধন সনদ আবশ্যিকভাবে ১৭ সংখ্যা বিশিষ্ট হইতে হইবে। অসম্পূর্ণ ডিজিটের ক্ষেত্রে মানব যাচাই (Manual Review) সতর্কবার্তা উঠিবে।',
    enabled: true,
    isSystemDefault: true,
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-20T11:00:00.000Z',
    lastUpdatedBy: 'সিস্টেম অ্যাডমিন'
  },
  {
    id: 'rule_warish_local_attestation',
    code: 'WARISH_LOCAL_ATTESTATION_RULE',
    title: 'ওয়ারিশান সনদে স্থানীয় পঞ্চায়েত ও মেম্বার সত্যতা ঘোষণা',
    category: 'approval',
    categoryLabel: 'অনুমোদন ও স্বাক্ষর প্রক্রিয়া',
    appliesTo: ['warish', 'family_certificate', 'family_partition'],
    requirementLevel: 'mandatory',
    instructionText: 'ওয়ারিশান ও উত্তরাধিকার সনদের ক্ষেত্রে কোনো জীবিত বৈধ ওয়ারিশের নাম বাদ না পড়ার প্রত্যয়ন নিশ্চিতকল্পে স্থানীয় গণ্যমান্য বা মেম্বারের ক্ষেত্রভিত্তিক প্রাথমিক তথ্য যাচাই আবশ্যক।',
    enabled: true,
    isSystemDefault: true,
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-20T11:00:00.000Z',
    lastUpdatedBy: 'সিস্টেম অ্যাডমিন'
  },
  {
    id: 'rule_freedom_fighter_gazette',
    code: 'FREEDOM_FIGHTER_GAZETTE_RULE',
    title: 'বীর মুক্তিযোদ্ধা পোষ্য প্রত্যয়নে গেজেট ও সনদ নম্বর বাধ্যতামূলক',
    category: 'verification',
    categoryLabel: 'তথ্য ও নাগরিকত্ব যাচাই',
    appliesTo: ['freedom_fighter_descendant', 'freedom_fighter_child'],
    requirementLevel: 'mandatory',
    instructionText: 'মুক্তিযোদ্ধা উত্তরাধিকার প্রত্যয়নে মুক্তিযোদ্ধার নাম, সরকারি গেজেট নম্বর বা লাল মুক্তিবার্তা নম্বর আবশ্যিকভাবে যাচাই করিতে হইবে।',
    enabled: true,
    isSystemDefault: true,
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-20T11:00:00.000Z',
    lastUpdatedBy: 'সিস্টেম অ্যাডমিন'
  },
  {
    id: 'rule_ai_fidelity_no_hallucination',
    code: 'AI_FIDELITY_NO_HALLUCINATION_RULE',
    title: 'এআই ড্রাফটে তথ্য অক্ষুণ্ণ রাখা ও কাল্পনিক তথ্য পরিহার',
    category: 'draft_ai',
    categoryLabel: 'এআই ড্রাফটিং ও ভাষা নির্দেশনা',
    appliesTo: 'all',
    requirementLevel: 'mandatory',
    instructionText: 'নাগরিকের নাম, পিতা-মাতা, গ্রাম, ওয়ার্ড ও এনআইডি নম্বর এআই ড্রাফটে শতভাগ অবিকল রাখিতে হইবে। এআই নিজ হইতে কোনো কাল্পনিক তথ্য বা আইনি নিশ্চয়তা যোগ করিতে পারিবে না।',
    enabled: true,
    isSystemDefault: true,
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-20T11:00:00.000Z',
    lastUpdatedBy: 'সিস্টেম অ্যাডমিন'
  },
  {
    id: 'rule_clean_qr_no_external_link',
    code: 'CLEAN_QR_NO_EXTERNAL_LINK_RULE',
    title: 'প্রিন্টআউটে শুধুমাত্র অফিশিয়াল কিউআর সিল ও লগো ব্যবহারের নিয়ম',
    category: 'delivery',
    categoryLabel: 'মুদ্রণ ও ডেলিভারি মোড',
    appliesTo: 'all',
    requirementLevel: 'mandatory',
    instructionText: 'প্রিন্ট কপিতে কোনো অপ্রয়োজনীয় এক্সটার্নাল টেক্সট লিংক না রেখে কেবল ইউনিয়ন পরিষদের অনুমোদিত লগো ও ইন-হাউস কিউআর ভেরিফিকেশন সিল প্রদর্শন করিতে হইবে।',
    enabled: true,
    isSystemDefault: true,
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-20T11:00:00.000Z',
    lastUpdatedBy: 'সিস্টেম অ্যাডমিন'
  }
];

/**
 * Get all active and configured rules for the Union Parishad
 */
export function getEffectiveSystemRules(config: UnionParishadConfig): SystemRuleItem[] {
  if (config.systemRules && Array.isArray(config.systemRules) && config.systemRules.length > 0) {
    return config.systemRules;
  }
  return DEFAULT_SYSTEM_RULES;
}

/**
 * Filter rules applying to a specific certificate type
 */
export function getRulesForCertificate(config: UnionParishadConfig, certTypeKey: string): SystemRuleItem[] {
  const allRules = getEffectiveSystemRules(config);
  return allRules.filter(rule => {
    if (!rule.enabled || rule.requirementLevel === 'disabled') return false;
    if (rule.appliesTo === 'all') return true;
    if (Array.isArray(rule.appliesTo)) {
      return rule.appliesTo.includes(certTypeKey);
    }
    return false;
  });
}

/**
 * Check if Member Approval is mandatory or optional
 */
export function isMemberApprovalMandatory(config: UnionParishadConfig, certTypeKey?: string): boolean {
  if (config.memberApprovalMandatory !== undefined) {
    return config.memberApprovalMandatory;
  }
  const rules = getEffectiveSystemRules(config);
  const memberRule = rules.find(r => r.id === 'rule_member_approval' || r.code === 'MEMBER_APPROVAL_OPTIONAL_RULE');
  if (memberRule) {
    if (memberRule.requirementLevel === 'mandatory') return true;
    if (memberRule.requirementLevel === 'optional' || memberRule.requirementLevel === 'disabled') return false;
  }
  // Check if specific certificate has mandatory rule (like warish)
  if (certTypeKey) {
    const certRules = getRulesForCertificate(config, certTypeKey);
    const hasMandatory = certRules.some(r => r.category === 'approval' && r.requirementLevel === 'mandatory' && r.id !== 'rule_member_approval');
    if (hasMandatory && certTypeKey === 'warish') return true;
  }
  return false;
}

/**
 * Check if Secretary Verification is mandatory
 */
export function isSecretaryVerificationMandatory(config: UnionParishadConfig): boolean {
  if (config.secretaryVerificationMandatory !== undefined) {
    return config.secretaryVerificationMandatory;
  }
  const rules = getEffectiveSystemRules(config);
  const rule = rules.find(r => r.id === 'rule_secretary_verification' || r.code === 'SECRETARY_VERIFICATION_RULE');
  if (rule) {
    return rule.enabled && rule.requirementLevel === 'mandatory';
  }
  return true;
}

/**
 * Check if Holding Tax clearance is mandatory
 */
export function isHoldingTaxClearanceMandatory(config: UnionParishadConfig): boolean {
  if (config.holdingTaxClearanceMandatory !== undefined) {
    return config.holdingTaxClearanceMandatory;
  }
  const rules = getEffectiveSystemRules(config);
  const rule = rules.find(r => r.id === 'rule_holding_tax_clearance');
  if (rule) {
    return rule.enabled && rule.requirementLevel === 'mandatory';
  }
  return false;
}

/**
 * Formulate AI Gem instructions prompt reflecting active conditions
 */
export function generateSystemRulesPromptSummary(config: UnionParishadConfig): string {
  const activeRules = getEffectiveSystemRules(config).filter(r => r.enabled && r.requirementLevel !== 'disabled');
  let prompt = '【ইউনিয়ন পরিষদ সিস্টেম শর্ত ও প্রশাসনিক নির্দেশনা】\n';
  activeRules.forEach((rule, idx) => {
    prompt += `${idx + 1}. [${rule.title}] (${REQUIREMENT_LEVEL_LABELS[rule.requirementLevel]?.label || rule.requirementLevel}): ${rule.instructionText}\n`;
  });
  return prompt;
}
