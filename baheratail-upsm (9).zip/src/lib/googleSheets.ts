import { CertificateRecord } from '../types';

export interface SheetsSyncResult {
  success: boolean;
  spreadsheetId: string;
  spreadsheetUrl: string;
  rowsSynced: number;
  message: string;
  tabsCreated?: string[];
}

// -------------------------------------------------------------
// 🗄️ Core Database & Event Logging (6-Tab Schema Definition)
// -------------------------------------------------------------

export const TAB_NAMES = {
  APPLICATIONS: 'Applications',
  EVENT_LOGS: 'Event_Logs',
  CORRECTIONS_LOG: 'Corrections_Log',
  AI_RECOMMENDATIONS: 'AI_Recommendations',
  AI_KNOWLEDGE_BASE: 'AI_Knowledge_Base',
  SETTINGS: 'Settings'
} as const;

export const APPLICATIONS_HEADERS = [
  'App_ID',
  'Date_Time',
  'Applicant_Name',
  'Phone_No',
  'Service_Type',
  'Status'
];

export const EVENT_LOGS_HEADERS = [
  'Log_ID',
  'Timestamp',
  'Event_Category',
  'Module',
  'Action_By',
  'Description',
  'Status'
];

export const CORRECTIONS_LOG_HEADERS = [
  'Correction_ID',
  'Timestamp',
  'Ref_App_ID',
  'Field_Name',
  'Old_Value',
  'New_Value',
  'Correction_Reason',
  'Corrected_By'
];

export const AI_RECOMMENDATIONS_HEADERS = [
  'Rec_ID',
  'Date_Generated',
  'Category',
  'Title',
  'Root_Cause',
  'Proposed_Fix',
  'Confidence_Score',
  'Priority',
  'Admin_Action',
  'Action_Date'
];

export const AI_KNOWLEDGE_BASE_HEADERS = [
  'Pattern_ID',
  'Date_Discovered',
  'Insight',
  'Impact',
  'Status'
];

export const SETTINGS_HEADERS = [
  'Setting_Name',
  'Setting_Value',
  'Status'
];

export const DEFAULT_SETTINGS_ROWS = [
  ['AI_Run_Time', '11:30 PM (Asia/Dhaka)', 'ON'],
  ['Report_Frequency', 'Daily', 'ON'],
  ['Admin_Email', 'admin@boheratoil.gov.bd', 'ON'],
  ['Privacy_Filter', 'Enabled (PII Regex Masking)', 'ON'],
  ['Auto_Feedback_Loop', 'Active', 'ON'],
  ['Telegram_Alerts', 'Disabled', 'OFF'],
  ['Google_Chat_Webhook', '', 'OFF']
];

// Legacy / Combined Sheet Headers
export const SHEETS_LOG_HEADERS = [
  'তারিখ',
  'স্মারক নম্বর',
  'সনদের শ্রেণি/ক্যাটাগরি',
  'সনদের ধরন',
  'আবেদনকারীর নাম',
  'পিতা / স্বামী',
  'মাতা',
  'গ্রাম',
  'ওয়ার্ড নং',
  'NID / জন্ম নিবন্ধন নং',
  'মোবাইল নম্বর',
  'ফি (টাকা)',
  'স্ট্যাটাস',
  'সিঙ্ক সময়'
];

// -------------------------------------------------------------
// 🛡️ Privacy Filter Mechanism (PII Sanitization & Regex Masking)
// -------------------------------------------------------------

/**
 * Mask PII (Personal Identifiable Information) such as phone numbers,
 * NID/Birth numbers, and email addresses with [MASKED] tags.
 */
export function maskSensitiveData(text: string): string {
  if (!text) return '';
  let sanitized = String(text);

  // Mask Phone numbers: +8801XXXXXXXXX or 01XXXXXXXXX
  sanitized = sanitized.replace(/(?:(?:\+8801|8801|01))[3-9]\d{8}/g, '[PHONE_MASKED]');

  // Mask 10, 13, 17 digit NID or Birth Registration numbers
  sanitized = sanitized.replace(/\b(?:\d{17}|\d{13}|\d{10})\b/g, '[ID_MASKED]');

  // Mask Email addresses
  sanitized = sanitized.replace(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g, '[EMAIL_MASKED]');

  return sanitized;
}

/**
 * Sanitize event descriptions for Event_Logs to ensure zero raw PII leaks to AI
 */
export function sanitizeLogDescription(description: string): string {
  return maskSensitiveData(description);
}

// -------------------------------------------------------------
// Row Formatting Helpers for 6 Tabs
// -------------------------------------------------------------

export function formatApplicationRow(log: CertificateRecord): string[] {
  const dt = log.createdAt || log.issueDate || new Date().toISOString();
  return [
    log.id || log.memoNo || `APP-${Date.now().toString().slice(-5)}`,
    dt,
    log.citizen?.name || (log as any).name || 'নাগরিক',
    log.citizen?.mobile || (log as any).mobile || '[NONE]',
    log.typeLabel || log.typeKey || 'নাগরিকত্ব সনদ',
    log.status === 'revoked' ? 'Rejected' : log.status === 'pending_approval' ? 'Pending' : 'Approved'
  ];
}

export function formatEventLogRow(event: {
  id?: string;
  timestamp?: string;
  category?: string;
  module?: string;
  actionBy?: string;
  description: string;
  status?: string;
}): string[] {
  return [
    event.id || `LOG-${Date.now().toString().slice(-4)}`,
    event.timestamp || new Date().toLocaleString('bn-BD', { timeZone: 'Asia/Dhaka' }),
    event.category || 'App_Event',
    event.module || 'Certificate_Module',
    event.actionBy || 'System',
    sanitizeLogDescription(event.description),
    event.status || 'Success'
  ];
}

export function formatCorrectionLogRow(correction: {
  id?: string;
  timestamp?: string;
  refAppId?: string;
  fieldName: string;
  oldValue: string;
  newValue: string;
  reason?: string;
  correctedBy?: string;
}): string[] {
  return [
    correction.id || `COR-${Date.now().toString().slice(-4)}`,
    correction.timestamp || new Date().toLocaleString('bn-BD', { timeZone: 'Asia/Dhaka' }),
    correction.refAppId || 'N/A',
    correction.fieldName,
    maskSensitiveData(correction.oldValue),
    maskSensitiveData(correction.newValue),
    correction.reason || 'Manual Correction',
    correction.correctedBy || 'Operator_01'
  ];
}

export function formatRecommendationRow(rec: {
  id?: string;
  dateGenerated?: string;
  category?: string;
  title: string;
  rootCause?: string;
  proposedFix?: string;
  confidenceScore?: number | string;
  priority?: string;
  adminAction?: string;
  actionDate?: string;
}): string[] {
  return [
    rec.id || `REC-${Date.now().toString().slice(-3)}`,
    rec.dateGenerated || new Date().toISOString().split('T')[0],
    rec.category || 'UX Idea',
    rec.title,
    rec.rootCause || 'Recurring pattern in logs',
    rec.proposedFix || 'Update UI or validation rule',
    typeof rec.confidenceScore === 'number' ? `${rec.confidenceScore}%` : rec.confidenceScore || '90%',
    rec.priority || 'P2',
    rec.adminAction || 'Pending',
    rec.actionDate || ''
  ];
}

export function formatKnowledgePatternRow(pattern: {
  id?: string;
  dateDiscovered?: string;
  insight: string;
  impact?: string;
  status?: string;
}): string[] {
  return [
    pattern.id || `PAT-${Date.now().toString().slice(-3)}`,
    pattern.dateDiscovered || new Date().toISOString().split('T')[0],
    pattern.insight,
    pattern.impact || 'Medium',
    pattern.status || 'Active'
  ];
}

/**
 * Format a CertificateRecord into legacy single sheet row array
 */
export function formatCertificateToSheetRow(log: CertificateRecord): string[] {
  const syncTime = new Date().toLocaleString('bn-BD', { timeZone: 'Asia/Dhaka' });
  return [
    log.issueDate || '',
    log.memoNo || '',
    log.category || 'নাগরিকত্ব ও পরিচয়',
    log.typeLabel || '',
    log.citizen?.name || '',
    log.citizen?.father || log.citizen?.spouseName || '',
    log.citizen?.mother || '',
    log.citizen?.village || '',
    log.citizen?.wardNo ? `ওয়ার্ড ${log.citizen.wardNo}` : '',
    log.citizen?.nid || log.citizen?.birthNo || '',
    log.citizen?.mobile || '',
    (log as any).fee || log.feeAmount ? `${(log as any).fee || log.feeAmount} ৳` : '৫০ ৳',
    log.status === 'revoked' ? 'বাতিলকৃত' : log.status === 'pending_approval' ? 'অপেক্ষমান' : 'ইস্যুকৃত',
    syncTime
  ];
}

// -------------------------------------------------------------
// Google Sheets API Integration (Full 6-Tab Spreadsheet Provisioning)
// -------------------------------------------------------------

/**
 * Create a complete 6-Tab Google Spreadsheet with standard headers & settings
 */
export async function createSupervisorGoogleSpreadsheet(
  accessToken: string,
  title: string = '০২নং বহেড়াতৈল ইউপি - AI Supervisor Core Database (2026)'
): Promise<{ spreadsheetId: string; spreadsheetUrl: string; tabs: string[] }> {
  const tabsList = [
    { name: TAB_NAMES.APPLICATIONS, headers: APPLICATIONS_HEADERS },
    { name: TAB_NAMES.EVENT_LOGS, headers: EVENT_LOGS_HEADERS },
    { name: TAB_NAMES.CORRECTIONS_LOG, headers: CORRECTIONS_LOG_HEADERS },
    { name: TAB_NAMES.AI_RECOMMENDATIONS, headers: AI_RECOMMENDATIONS_HEADERS },
    { name: TAB_NAMES.AI_KNOWLEDGE_BASE, headers: AI_KNOWLEDGE_BASE_HEADERS },
    { name: TAB_NAMES.SETTINGS, headers: SETTINGS_HEADERS }
  ];

  const sheetsConfig = tabsList.map(tab => ({
    properties: {
      title: tab.name,
      gridProperties: {
        frozenRowCount: 1,
        columnCount: Math.max(tab.headers.length + 2, 10)
      }
    }
  }));

  const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: { title },
      sheets: sheetsConfig
    })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Google Spreadsheet তৈরি করতে ব্যর্থ হয়েছে (${response.status})`);
  }

  const data = await response.json();
  const spreadsheetId = data.spreadsheetId;

  // Initialize all headers in a single batch update
  const valueData = tabsList.map(tab => {
    const values: string[][] = [tab.headers];
    if (tab.name === TAB_NAMES.SETTINGS) {
      values.push(...DEFAULT_SETTINGS_ROWS);
    }
    return {
      range: `${tab.name}!A1`,
      majorDimension: 'ROWS',
      values
    };
  });

  await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      valueInputOption: 'USER_ENTERED',
      data: valueData
    })
  });

  return {
    spreadsheetId,
    spreadsheetUrl: data.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`,
    tabs: tabsList.map(t => t.name)
  };
}

/**
 * Legacy single-sheet creator (Maintained for backwards compatibility)
 */
export async function createGoogleSpreadsheet(
  accessToken: string,
  title: string = '০২নং বহেড়াতৈল ইউপি - নাগরিক আবেদন রেজিস্টার (২০২৬)'
): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> {
  const result = await createSupervisorGoogleSpreadsheet(accessToken, title);
  return {
    spreadsheetId: result.spreadsheetId,
    spreadsheetUrl: result.spreadsheetUrl
  };
}

export interface SupervisorSyncData {
  applications?: CertificateRecord[];
  eventLogs?: any[];
  corrections?: any[];
  recommendations?: any[];
  knowledgePatterns?: any[];
  settings?: any[];
}

/**
 * Sync entire database across all 6 tabs in a single batch operation
 */
export async function syncSupervisorDatabase(
  arg1: string | SupervisorSyncData,
  arg2?: string,
  arg3?: SupervisorSyncData
): Promise<SheetsSyncResult> {
  // Check if called as syncSupervisorDatabase(data)
  if (typeof arg1 !== 'string') {
    const data = arg1;
    // Call server endpoint
    const res = await fetch('/api/admin/supervisor-sheets-sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const resData = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(resData.message || `সার্ভার সিঙ্ক ব্যর্থ হয়েছে (${res.status})`);
    }
    return resData;
  }

  const accessToken = arg1;
  const spreadsheetId = arg2 || '';
  const data = arg3 || {};

  const batchData: any[] = [];
  let totalRows = 0;

  if (data.applications && data.applications.length > 0) {
    const appRows = data.applications.map(formatApplicationRow);
    batchData.push({
      range: `${TAB_NAMES.APPLICATIONS}!A1`,
      majorDimension: 'ROWS',
      values: [APPLICATIONS_HEADERS, ...appRows]
    });
    totalRows += appRows.length;
  }

  if (data.eventLogs && data.eventLogs.length > 0) {
    const eventRows = data.eventLogs.map(formatEventLogRow);
    batchData.push({
      range: `${TAB_NAMES.EVENT_LOGS}!A1`,
      majorDimension: 'ROWS',
      values: [EVENT_LOGS_HEADERS, ...eventRows]
    });
    totalRows += eventRows.length;
  }

  if (data.corrections && data.corrections.length > 0) {
    const corrRows = data.corrections.map(formatCorrectionLogRow);
    batchData.push({
      range: `${TAB_NAMES.CORRECTIONS_LOG}!A1`,
      majorDimension: 'ROWS',
      values: [CORRECTIONS_LOG_HEADERS, ...corrRows]
    });
    totalRows += corrRows.length;
  }

  if (data.recommendations && data.recommendations.length > 0) {
    const recRows = data.recommendations.map(formatRecommendationRow);
    batchData.push({
      range: `${TAB_NAMES.AI_RECOMMENDATIONS}!A1`,
      majorDimension: 'ROWS',
      values: [AI_RECOMMENDATIONS_HEADERS, ...recRows]
    });
    totalRows += recRows.length;
  }

  if (data.knowledgePatterns && data.knowledgePatterns.length > 0) {
    const patRows = data.knowledgePatterns.map(formatKnowledgePatternRow);
    batchData.push({
      range: `${TAB_NAMES.AI_KNOWLEDGE_BASE}!A1`,
      majorDimension: 'ROWS',
      values: [AI_KNOWLEDGE_BASE_HEADERS, ...patRows]
    });
    totalRows += patRows.length;
  }

  if (batchData.length === 0) {
    return {
      success: true,
      spreadsheetId,
      spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`,
      rowsSynced: 0,
      message: 'সিঙ্ক করার মতো কোনো নতুন ডাটা পাওয়া যায়নি।'
    };
  }

  const updateUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`;
  const response = await fetch(updateUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      valueInputOption: 'USER_ENTERED',
      data: batchData
    })
  });

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error?.message || `Google Sheets ব্যাচ সিঙ্ক ব্যর্থ হয়েছে (${response.status})`);
  }

  return {
    success: true,
    spreadsheetId,
    spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`,
    rowsSynced: totalRows,
    message: `সফলভাবে ${totalRows} টি রেকর্ড 6-Tab AI Supervisor ডাটাবেসে সিঙ্ক হয়েছে!`
  };
}

/**
 * Sync / Write full array of citizen certificate logs into Google Spreadsheet (Legacy)
 */
export async function syncLogsToGoogleSpreadsheet(
  accessToken: string,
  spreadsheetId: string,
  logs: CertificateRecord[]
): Promise<SheetsSyncResult> {
  const range = 'Citizen_Logs!A1';
  const dataRows = logs.map(formatCertificateToSheetRow);
  const values = [SHEETS_LOG_HEADERS, ...dataRows];

  const updateUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}?valueInputOption=USER_ENTERED`;

  const response = await fetch(updateUrl, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      range: 'Citizen_Logs!A1',
      majorDimension: 'ROWS',
      values
    })
  });

  if (!response.ok) {
    // If Citizen_Logs tab doesn't exist, try syncSupervisorDatabase
    return syncSupervisorDatabase(accessToken, spreadsheetId, { applications: logs });
  }

  const spreadsheetUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

  return {
    success: true,
    spreadsheetId,
    spreadsheetUrl,
    rowsSynced: logs.length,
    message: `সফলভাবে ${logs.length} টি নাগরিক আবেদন ও সনদপত্র রেকর্ড Google Sheet-এ সিঙ্ক করা হয়েছে!`
  };
}

/**
 * Append a single log entry to the Google Spreadsheet
 */
export async function appendLogToGoogleSpreadsheet(
  accessToken: string,
  spreadsheetId: string,
  log: CertificateRecord
): Promise<boolean> {
  const range = `${TAB_NAMES.APPLICATIONS}!A1`;
  const row = formatApplicationRow(log);

  const appendUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}:append?valueInputOption=USER_ENTERED`;

  const response = await fetch(appendUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      values: [row]
    })
  });

  return response.ok;
}

