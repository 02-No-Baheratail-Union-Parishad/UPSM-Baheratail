import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import QRCode from 'qrcode';

/**
 * Generate a Verification QR Code Data URL for a holding tax receipt
 */
export async function generateTaxReceiptQRCode(receiptNo: string, holdingNo: string, amount: number): Promise<string> {
  try {
    const payload = JSON.stringify({
      docType: 'BUP_HOLDING_TAX_RECEIPT',
      receiptNo,
      holdingNo,
      amount,
      verifyUrl: `https://bup-gov.bd/tax/verify/${receiptNo}`,
      issuedAt: new Date().toISOString()
    });
    return await QRCode.toDataURL(payload, {
      width: 256,
      margin: 1,
      color: {
        dark: '#064e3b', // Deep emerald
        light: '#ffffff'
      }
    });
  } catch (err) {
    console.warn('QR code generation failed, fallback to standard url:', err);
    return await QRCode.toDataURL(`https://bup-gov.bd/tax/verify/${receiptNo}`);
  }
}

/**
 * Generate a Verification QR Code Data URL for a Ward Tax Summary Report
 */
export async function generateWardReportQRCode(wardNo: string, fiscalYear: string, totalDue: number): Promise<string> {
  try {
    const payload = JSON.stringify({
      docType: 'BUP_WARD_TAX_ARREARS_REPORT',
      wardNo,
      fiscalYear,
      totalDue,
      verifyUrl: `https://bup-gov.bd/tax/report/ward-${wardNo}`,
      generatedAt: new Date().toISOString()
    });
    return await QRCode.toDataURL(payload, {
      width: 256,
      margin: 1,
      color: {
        dark: '#064e3b',
        light: '#ffffff'
      }
    });
  } catch (err) {
    return await QRCode.toDataURL(`https://bup-gov.bd/tax/report/ward-${wardNo}`);
  }
}

/**
 * Export any DOM element (Receipt or Ward Report) to high-quality PDF with multi-page handling
 */
export async function downloadElementAsPDF(elementId: string, fileName: string): Promise<boolean> {
  const element = document.getElementById(elementId);
  if (!element) {
    console.error(`Element with id ${elementId} not found`);
    return false;
  }

  try {
    const canvas = await html2canvas(element, {
      scale: 2.2, // High resolution for crisp Bengali fonts
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff'
    });

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const pageWidth = 210;
    const pageHeight = 297;
    const margin = 10;
    const contentWidth = pageWidth - (margin * 2);
    const contentHeight = (canvas.height * contentWidth) / canvas.width;

    let heightLeft = contentHeight;
    let position = margin;

    // First page
    pdf.addImage(imgData, 'PNG', margin, position, contentWidth, contentHeight, undefined, 'FAST');
    heightLeft -= (pageHeight - (margin * 2));

    // Subsequent pages if long report
    while (heightLeft > 0) {
      position = heightLeft - contentHeight + margin;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', margin, position, contentWidth, contentHeight, undefined, 'FAST');
      heightLeft -= pageHeight;
    }

    pdf.save(`${fileName}.pdf`);
    return true;
  } catch (error) {
    console.error('Error generating PDF:', error);
    return false;
  }
}

/**
 * Alias for backward compatibility
 */
export const downloadReceiptAsPDF = downloadElementAsPDF;
