export interface CapacitorConfig {
  appId: string;
  appName: string;
  webDir: string;
  server?: {
    androidScheme?: string;
    url?: string;
    cleartext?: boolean;
  };
  plugins?: Record<string, any>;
}

const config: CapacitorConfig = {
  appId: 'com.baheratailunion.upsm',
  appName: '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: false
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      backgroundColor: '#006400',
      showSpinner: false,
      androidSplashResourceName: 'splash'
    },
    StatusBar: {
      backgroundColor: '#006400',
      style: 'DARK'
    }
  }
};

export default config;
