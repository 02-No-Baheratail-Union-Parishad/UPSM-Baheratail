const CACHE_NAME = 'bup-digital-v3';
const DB_NAME = 'bup_offline_db';
const DB_VERSION = 2;
const DRAFTS_STORE = 'draft_certificates';

const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon.svg',
  '/baheratail_seal.svg'
];

// Install Event - Precache core assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[Service Worker] Precaching static app shell assets');
      return cache.addAll(STATIC_ASSETS).catch((err) => {
        console.warn('[Service Worker] Precache warning:', err);
      });
    })
  );
  self.skipWaiting();
});

// Activate Event - Clean old caches and claim clients
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((name) => {
          if (name !== CACHE_NAME) {
            console.log('[Service Worker] Deleting old cache:', name);
            return caches.delete(name);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// ==========================================
// INDEXEDDB HELPER FOR SERVICE WORKER SCOPE
// ==========================================

function openDraftsDBInWorker() {
  return new Promise((resolve, reject) => {
    if (!self.indexedDB) {
      return reject(new Error('IndexedDB not supported in Service Worker scope'));
    }
    const request = self.indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(DRAFTS_STORE)) {
        const store = db.createObjectStore(DRAFTS_STORE, { keyPath: 'id' });
        store.createIndex('syncStatus', 'syncStatus', { unique: false });
        store.createIndex('createdAt', 'createdAt', { unique: false });
        store.createIndex('memoNo', 'memoNo', { unique: false });
        store.createIndex('certificateType', 'certificateType', { unique: false });
      }
    };
    request.onsuccess = (event) => resolve(event.target.result);
    request.onerror = (event) => reject(event.target.error);
  });
}

function getPendingDraftsFromWorkerDB(db) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([DRAFTS_STORE], 'readonly');
    const store = transaction.objectStore(DRAFTS_STORE);
    const request = store.getAll();

    request.onsuccess = () => {
      const allDrafts = request.result || [];
      const pending = allDrafts.filter(
        (d) => d.syncStatus === 'pending' || d.syncStatus === 'failed' || !d.syncStatus
      );
      resolve(pending);
    };
    request.onerror = () => reject(request.error);
  });
}

function markDraftAsSyncedInWorkerDB(db, draftId, syncedRecord) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([DRAFTS_STORE], 'readwrite');
    const store = transaction.objectStore(DRAFTS_STORE);
    const getReq = store.get(draftId);

    getReq.onsuccess = () => {
      const draft = getReq.result;
      if (draft) {
        draft.syncStatus = 'synced';
        draft.syncedAt = new Date().toISOString();
        draft.syncError = undefined;
        if (syncedRecord) {
          draft.fullRecord = syncedRecord;
        }
        store.put(draft);
      }
      resolve();
    };
    getReq.onerror = () => reject(getReq.error);
  });
}

/**
 * Background sync executor that reads IndexedDB pending drafts and syncs them to Firestore / Server
 */
async function syncDraftsToFirestoreFromWorker() {
  console.log('[Service Worker] Executing Background Sync for pending draft certificates...');
  try {
    const db = await openDraftsDBInWorker();
    const pendingDrafts = await getPendingDraftsFromWorkerDB(db);

    if (!pendingDrafts || pendingDrafts.length === 0) {
      console.log('[Service Worker] No pending draft certificates found in IndexedDB.');
      return;
    }

    console.log(`[Service Worker] Found ${pendingDrafts.length} pending draft certificates to sync.`);

    // 1. Send drafts to server API
    const response = await fetch('/api/certificates/sync-drafts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Service-Worker-Sync': 'true'
      },
      body: JSON.stringify({ drafts: pendingDrafts })
    });

    if (!response.ok) {
      throw new Error(`Sync HTTP error: ${response.status}`);
    }

    const result = await response.json();
    console.log('[Service Worker] Server sync completed successfully:', result);

    // 2. Mark drafts as synced in IndexedDB
    const syncedIds = result.syncedIds || [];
    for (const draft of pendingDrafts) {
      if (syncedIds.includes(draft.id) || result.status === 'success') {
        const correspondingCert = result.certificates?.find((c) => c.id === draft.id || c.memoNo === draft.memoNo);
        await markDraftAsSyncedInWorkerDB(db, draft.id, correspondingCert);
      }
    }

    // 3. Broadcast sync success message to all active app tabs
    const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    clients.forEach((client) => {
      client.postMessage({
        type: 'BACKGROUND_SYNC_COMPLETED',
        source: 'service-worker',
        syncedCount: pendingDrafts.length,
        syncedDrafts: pendingDrafts.map((d) => ({ id: d.id, memoNo: d.memoNo, name: d.citizen?.name })),
        timestamp: new Date().toISOString()
      });
    });

    console.log('[Service Worker] Background sync successfully broadcasted to', clients.length, 'clients.');
  } catch (error) {
    console.error('[Service Worker] Background sync error:', error);
    // Re-throw so the browser SyncManager can retry automatically if needed
    throw error;
  }
}

// ==========================================
// BACKGROUND SYNC EVENT LISTENER
// ==========================================
self.addEventListener('sync', (event) => {
  console.log('[Service Worker] Sync event received for tag:', event.tag);
  if (
    event.tag === 'sync-draft-certificates' || 
    event.tag === 'bup-draft-sync' || 
    event.tag === 'sync-drafts'
  ) {
    event.waitUntil(syncDraftsToFirestoreFromWorker());
  }
});

// Periodic Background Sync (when supported by browser)
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'bup-periodic-draft-sync') {
    console.log('[Service Worker] Periodic background sync triggered');
    event.waitUntil(syncDraftsToFirestoreFromWorker());
  }
});

// ==========================================
// FETCH EVENT LISTENER (OFFLINE CACHING)
// ==========================================
self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // 1. Only intercept GET requests
  if (req.method !== 'GET') {
    return;
  }

  // 2. Skip non-http(s) protocols
  if (!url.protocol.startsWith('http')) {
    return;
  }

  // 3. Skip cross-origin requests
  if (url.origin !== self.location.origin) {
    return;
  }

  // 4. Skip Vite dev server internal assets
  if (
    url.pathname.startsWith('/@') || 
    url.pathname.includes('/node_modules/') || 
    url.search.includes('v=') ||
    url.pathname.endsWith('.tsx') ||
    url.pathname.endsWith('.ts')
  ) {
    return;
  }

  // API requests (/api/*): Network-first with cached JSON fallback
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(req.clone())
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(req, responseToCache);
            });
          }
          return networkResponse;
        })
        .catch(async () => {
          const cachedResponse = await caches.match(req);
          if (cachedResponse) {
            return cachedResponse;
          }
          return new Response(
            JSON.stringify({
              offline: true,
              message: 'আপনি বর্তমানে অফলাইনে আছেন। ড্রাফট ও ডাউনলোডকৃত কপি সক্রিয় আছে।'
            }),
            {
              status: 200,
              headers: { 'Content-Type': 'application/json' }
            }
          );
        })
    );
    return;
  }

  // Static Assets / Page Navigation: Cache-First with Network Revalidation
  event.respondWith(
    caches.match(req).then((cachedResponse) => {
      const fetchPromise = fetch(req.clone())
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(req, responseToCache);
            });
          }
          return networkResponse;
        })
        .catch((err) => {
          console.log('[Service Worker] Offline fallback for asset:', req.url);
        });

      return cachedResponse || fetchPromise || caches.match('/index.html');
    })
  );
});

// ==========================================
// MESSAGE EVENT LISTENER
// ==========================================
self.addEventListener('message', (event) => {
  if (!event.data) return;

  if (event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }

  if (event.data.type === 'TRIGGER_DRAFT_SYNC' || event.data.type === 'SYNC_DRAFTS_NOW') {
    console.log('[Service Worker] Manual sync trigger message received from client tab');
    event.waitUntil(syncDraftsToFirestoreFromWorker());
  }
});
