import { initializeApp, getApps, getApp, cert, App } from 'firebase-admin/app';
import { getFirestore, Firestore } from 'firebase-admin/firestore';
import fs from 'fs';
import path from 'path';

let adminApp: App | null = null;

function loadFirebaseConfig() {
  try {
    const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
    if (fs.existsSync(configPath)) {
      return JSON.parse(fs.readFileSync(configPath, 'utf8'));
    }
  } catch (e) {
    console.warn('Could not read firebase-applet-config.json:', e);
  }
  return {};
}

export function getFirebaseAdminApp(): App | null {
  if (adminApp) return adminApp;

  try {
    const existingApps = getApps();
    if (existingApps.length > 0 && existingApps[0]) {
      adminApp = existingApps[0];
      return adminApp;
    }

    const firebaseConfig = loadFirebaseConfig();
    const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;

    if (serviceAccountJson) {
      try {
        const credentials = JSON.parse(serviceAccountJson);
        adminApp = initializeApp({
          credential: cert(credentials),
          projectId: credentials.project_id || firebaseConfig.projectId
        });
        return adminApp;
      } catch (err) {
        console.warn('Failed to parse FIREBASE_SERVICE_ACCOUNT_JSON:', err);
      }
    }

    const projectId = firebaseConfig.projectId || process.env.GOOGLE_CLOUD_PROJECT || 'baheratail-union-parishad';
    adminApp = initializeApp({
      projectId
    });
    return adminApp;
  } catch (error) {
    console.warn('Notice: Firebase Admin SDK auto-init fallback:', error);
    return null;
  }
}

export function getAdminFirestore(): Firestore | null {
  const app = getFirebaseAdminApp();
  if (!app) return null;
  try {
    const firebaseConfig = loadFirebaseConfig();
    const rawDbId = firebaseConfig.firestoreDatabaseId;
    const dbId = rawDbId && rawDbId !== '(default)' ? rawDbId : undefined;
    return dbId ? getFirestore(app, dbId) : getFirestore(app);
  } catch (err) {
    console.warn('Admin Firestore init notice:', err);
    return null;
  }
}
