import { getAdminFirestore } from './firebaseAdmin.js';
import type { CertificateRecord, ApiKeyRecord, WebhookConfig, WebhookLogRecord } from '../src/types.js';

const CERTIFICATES_COLLECTION = 'certificates';
const API_KEYS_COLLECTION = 'apiKeys';
const WEBHOOKS_COLLECTION = 'webhooks';
const WEBHOOK_LOGS_COLLECTION = 'webhookLogs';

/**
 * Load all stored certificates from Firestore
 */
export async function loadCertificatesFromFirestore(): Promise<CertificateRecord[]> {
  try {
    const db = getAdminFirestore();
    if (!db) return [];

    const snapshot = await db.collection(CERTIFICATES_COLLECTION).get();
    const records: CertificateRecord[] = [];
    snapshot.forEach((doc) => {
      const data = doc.data() as CertificateRecord;
      if (data && data.memoNo) {
        records.push(data);
      }
    });
    return records;
  } catch (error) {
    console.warn('Notice: Firestore certificates load fallback to memory store:', error);
    return [];
  }
}

/**
 * Persist or upsert certificate in Firestore
 */
export async function saveCertificateToFirestore(record: CertificateRecord): Promise<void> {
  try {
    const db = getAdminFirestore();
    if (!db || !record) return;

    const docId = (record.memoNo || record.id || `cert_${Date.now()}`).replace(/[^a-zA-Z0-9.-]/g, '_');
    const cleanData = JSON.parse(JSON.stringify(record));
    
    await db.collection(CERTIFICATES_COLLECTION).doc(docId).set({
      ...cleanData,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (error) {
    console.warn('Notice: Certificate Firestore sync failed:', error);
  }
}

/**
 * Update existing certificate in Firestore
 */
export async function updateCertificateInFirestore(id: string, updates: Partial<CertificateRecord>): Promise<void> {
  try {
    const db = getAdminFirestore();
    if (!db || !id) return;

    const docId = id.replace(/[^a-zA-Z0-9.-]/g, '_');
    const cleanUpdates = JSON.parse(JSON.stringify(updates));

    await db.collection(CERTIFICATES_COLLECTION).doc(docId).set({
      ...cleanUpdates,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (error) {
    console.warn('Notice: Certificate Firestore update failed:', error);
  }
}

/**
 * Load API Keys from Firestore
 */
export async function loadApiKeysFromFirestore(): Promise<ApiKeyRecord[]> {
  try {
    const db = getAdminFirestore();
    if (!db) return [];

    const snapshot = await db.collection(API_KEYS_COLLECTION).get();
    const records: ApiKeyRecord[] = [];
    snapshot.forEach((doc) => {
      const data = doc.data() as ApiKeyRecord;
      if (data && data.key) {
        records.push(data);
      }
    });
    return records;
  } catch (error) {
    console.warn('Notice: Firestore API keys load fallback:', error);
    return [];
  }
}

/**
 * Persist API Key in Firestore
 */
export async function saveApiKeyToFirestore(apiKey: ApiKeyRecord): Promise<void> {
  try {
    const db = getAdminFirestore();
    if (!db || !apiKey) return;

    const docId = (apiKey.id || `key_${Date.now()}`).replace(/[^a-zA-Z0-9.-]/g, '_');
    await db.collection(API_KEYS_COLLECTION).doc(docId).set({
      ...apiKey,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (error) {
    console.warn('Notice: API Key Firestore sync failed:', error);
  }
}

/**
 * Load Webhooks from Firestore
 */
export async function loadWebhooksFromFirestore(): Promise<WebhookConfig[]> {
  try {
    const db = getAdminFirestore();
    if (!db) return [];

    const snapshot = await db.collection(WEBHOOKS_COLLECTION).get();
    const records: WebhookConfig[] = [];
    snapshot.forEach((doc) => {
      const data = doc.data() as WebhookConfig;
      if (data && data.url) {
        records.push(data);
      }
    });
    return records;
  } catch (error) {
    console.warn('Notice: Firestore webhooks load fallback:', error);
    return [];
  }
}

/**
 * Persist Webhook in Firestore
 */
export async function saveWebhookToFirestore(webhook: WebhookConfig): Promise<void> {
  try {
    const db = getAdminFirestore();
    if (!db || !webhook) return;

    const docId = (webhook.id || `wh_${Date.now()}`).replace(/[^a-zA-Z0-9.-]/g, '_');
    await db.collection(WEBHOOKS_COLLECTION).doc(docId).set({
      ...webhook,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (error) {
    console.warn('Notice: Webhook Firestore sync failed:', error);
  }
}

/**
 * Log Webhook Execution in Firestore
 */
export async function logWebhookCallToFirestore(logEntry: WebhookLogRecord): Promise<void> {
  try {
    const db = getAdminFirestore();
    if (!db || !logEntry) return;

    const docId = (logEntry.id || `log_${Date.now()}`).replace(/[^a-zA-Z0-9.-]/g, '_');
    await db.collection(WEBHOOK_LOGS_COLLECTION).doc(docId).set({
      ...logEntry,
      timestamp: logEntry.timestamp || new Date().toISOString()
    }, { merge: true });
  } catch (error) {
    console.warn('Notice: Webhook log Firestore sync failed:', error);
  }
}
