import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldCheck,
  LogOut,
  AlertCircle,
  Sparkles,
  X,
  Lock,
  Shield,
  Fingerprint,
  Key,
  Laptop,
  Smartphone,
  CheckCircle2,
  Loader2,
  Check,
  Plus,
  Trash2,
  RefreshCw,
  ExternalLink,
  Copy,
  Info,
  Globe,
  MessageSquare,
  Send,
  QrCode
} from 'lucide-react';
import {
  auth,
  signInWithGooglePopup,
  signInWithGoogleRedirect,
  checkRedirectAuthResult,
  logoutUserFromFirebase,
  fetchAdminUsersFromFirebase,
  formatFirebaseAuthError,
  AdminUserRecord
} from '../firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import {
  isWebAuthnSupported,
  isPlatformBiometricAvailable,
  getWebAuthnDiagnostics,
  getStoredPasskeys,
  registerWebAuthnPasskey,
  verifyWebAuthnPasskey,
  verifySecurityPin,
  setBiometricSessionElevation,
  getBiometricSessionElevation,
  deletePasskeyFromStorage,
  WebAuthnDiagnostics
} from '../utils/webauthn';
import { WebAuthnPasskeyCredential } from '../types';
import { BiometricAuthToast, BiometricToastData } from './BiometricAuthToast';
import { recordBiometricLoginEvent } from '../services/biometricEventTracker';
import { whatsappAuthService } from '../services/whatsappAuthService';

interface AdminAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdminAuthenticated?: (user: AdminUserRecord | null) => void;
}

// Format timestamp with Bengali and English representations
export const formatBiometricTimestamp = (date: Date = new Date()): string => {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  const toBn = (n: number | string) => String(n).split('').map(d => bnDigits[parseInt(d, 10)] || d).join('');

  const day = toBn(date.getDate());
  const months = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
  const month = months[date.getMonth()];
  const year = toBn(date.getFullYear());

  const hours = date.getHours();
  const minutes = date.getMinutes();
  const seconds = date.getSeconds();
  const period = hours >= 12 ? 'বিকাল/রাত' : 'সকাল';
  const displayHours = hours % 12 || 12;

  const bnTime = `${toBn(displayHours)}:${toBn(minutes.toString().padStart(2, '0'))}:${toBn(seconds.toString().padStart(2, '0'))}`;
  const enFormatted = date.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  });

  return `${day} ${month} ${year}, ${period} ${bnTime} (${enFormatted})`;
};

// Subtle pleasant acoustic notification chime using Web Audio API
function playBiometricSuccessChime() {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
    osc.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.12); // G5
    osc.frequency.exponentialRampToValueAtTime(1046.50, ctx.currentTime + 0.25); // C6
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.42);
  } catch (e) {
    // safe fallback if audio context is blocked
  }
}

// ============================================================
// ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ — স্মার্ট এডমিন অথেন্টিকেশন
// ১. Google Firebase Auth (OAuth 2.0)
// ২. WebAuthn Biometric & Passkey Layer (FIDO2 / Touch ID / Face ID / Windows Hello)
// ৩. Master Security PIN Fallback
// ============================================================

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({
  isOpen,
  onClose,
  onAdminAuthenticated
}) => {
  const [activeAuthTab, setActiveAuthTab] = useState<'google' | 'whatsapp' | 'biometric' | 'passkeys' | 'pin'>('google');
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [adminRecord, setAdminRecord] = useState<AdminUserRecord | null>(null);
  const [adminList, setAdminList] = useState<AdminUserRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [biometricToast, setBiometricToast] = useState<BiometricToastData | null>(null);

  // WhatsApp Auth State
  const [waPhone, setWaPhone] = useState<string>('');
  const [waStep, setWaStep] = useState<'phone' | 'otp'>('phone');
  const [waOtpDigits, setWaOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [waOtpToken, setWaOtpToken] = useState<string>('');
  const [waCountdown, setWaCountdown] = useState<number>(60);
  const [waCanResend, setWaCanResend] = useState<boolean>(false);
  const [waDevOtp, setWaDevOtp] = useState<string | undefined>();
  const [waDirectUrl, setWaDirectUrl] = useState<string | undefined>();
  const [isWaLoading, setIsWaLoading] = useState<boolean>(false);
  const [twilioStatus, setTwilioStatus] = useState<{ isConfigured: boolean; provider: string; senderNumber: string } | null>(null);
  const waInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // WebAuthn state
  const [isWebAuthnReady, setIsWebAuthnReady] = useState<boolean>(false);
  const [isPlatformBiometric, setIsPlatformBiometric] = useState<boolean>(false);
  const [diagnostics, setDiagnostics] = useState<WebAuthnDiagnostics | null>(null);
  const [storedPasskeys, setStoredPasskeys] = useState<WebAuthnPasskeyCredential[]>([]);
  const [isBiometricScanning, setIsBiometricScanning] = useState<boolean>(false);
  const [isRegisteringPasskey, setIsRegisteringPasskey] = useState<boolean>(false);
  const [isBiometricElevated, setIsBiometricElevated] = useState<boolean>(false);
  const [selectedAdminForBiometric, setSelectedAdminForBiometric] = useState<string>('');
  const [pinInput, setPinInput] = useState<string>('');
  const [domainCopied, setDomainCopied] = useState<boolean>(false);
  const [isInsideIframe, setIsInsideIframe] = useState<boolean>(false);

  // WhatsApp OTP Countdown timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (waStep === 'otp' && waCountdown > 0) {
      timer = setInterval(() => {
        setWaCountdown(prev => {
          if (prev <= 1) {
            setWaCanResend(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [waStep, waCountdown]);

  // Fetch Twilio status when modal or tab is opened
  useEffect(() => {
    if (isOpen && activeAuthTab === 'whatsapp') {
      fetch('/api/messaging/whatsapp/status')
        .then(res => res.json())
        .then(data => {
          setTwilioStatus({
            isConfigured: data.isConfigured,
            provider: data.provider,
            senderNumber: data.senderNumber
          });
        })
        .catch(() => {});
    }
  }, [isOpen, activeAuthTab]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        setIsInsideIframe(window.self !== window.top);
      } catch (e) {
        setIsInsideIframe(true);
      }
    }
  }, []);

  // Resolve Admin record from Firebase Firestore Directory
  async function resolveAdminOrDeny(fbUser: FirebaseUser): Promise<AdminUserRecord | null> {
    const userEmail = (fbUser.email || '').toLowerCase().trim();

    // Primary system developer bootstrap check
    if (userEmail === 'inbox600900@gmail.com' || userEmail === 'baheratailunion@gmail.com') {
      const devRecord: AdminUserRecord = {
        email: userEmail,
        name: fbUser.displayName || 'প্রধান আইটি ডেভেলপার',
        role: 'developer',
        designation: 'প্রধান সিস্টেম আর্কিটেক্ট ও ডেভেলপার',
        addedAt: new Date().toISOString(),
        status: 'active'
      };
      return devRecord;
    }

    const admins = await fetchAdminUsersFromFirebase();
    setAdminList(admins);

    const matched = admins.find(
      (a) => a.email.toLowerCase().trim() === userEmail
    );

    if (!matched) {
      setAuthError(`আপনার Google একাউন্টটি (${fbUser.email}) অনুমোদিত এডমিন তালিকায় নেই। চেয়ারম্যান বা ডেভেলপারকে আপনার ইমেইলটি এডমিন তালিকায় যোগ করতে বলুন।`);
      await logoutUserFromFirebase();
      return null;
    }

    if (matched.status === 'suspended') {
      setAuthError('আপনার এডমিন একাউন্টটি সাময়িকভাবে স্থগিত (Suspended) রাখা হয়েছে।');
      await logoutUserFromFirebase();
      return null;
    }

    return matched;
  }

  // Load diagnostics, admin directory & existing passkeys on open
  useEffect(() => {
    if (!isOpen) return;

    setAuthError(null);
    setSuccessMessage(null);
    setPinInput('');

    // Check redirect auth result if user returned from redirect login
    checkRedirectAuthResult().then(async (redirectUser) => {
      if (redirectUser) {
        try {
          const matched = await resolveAdminOrDeny(redirectUser);
          if (matched) {
            setCurrentUser(redirectUser);
            setAdminRecord(matched);
            setSelectedAdminForBiometric(matched.email);
            localStorage.setItem('bup_active_admin_session', JSON.stringify(matched));
            window.dispatchEvent(new CustomEvent('adminAuthChanged', { detail: matched }));
            if (onAdminAuthenticated) onAdminAuthenticated(matched);
            setSuccessMessage(`✓ স্বাগতম ${matched.name}! আপনি সফলভাবে এডমিন প্যানেলে লগইন করেছেন।`);
            setTimeout(() => onClose(), 1500);
          }
        } catch (e) {
          console.warn('Error processing redirect result:', e);
        }
      }
    });

    // Check WebAuthn capabilities
    const supported = isWebAuthnSupported();
    setIsWebAuthnReady(supported);

    if (supported) {
      isPlatformBiometricAvailable().then((avail) => setIsPlatformBiometric(avail));
      getWebAuthnDiagnostics().then((diag) => setDiagnostics(diag));
    }

    // Load admins list for quick passkey selector
    fetchAdminUsersFromFirebase().then((admins) => {
      setAdminList(admins);
      if (admins.length > 0 && !selectedAdminForBiometric) {
        setSelectedAdminForBiometric(admins[0].email);
      }
    });

    // Check if existing session elevation exists
    const elevation = getBiometricSessionElevation();
    setIsBiometricElevated(Boolean(elevation?.isElevated));

    // Firebase Auth listener
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setIsLoading(true);
      if (fbUser) {
        try {
          const matched = await resolveAdminOrDeny(fbUser);
          if (matched) {
            setCurrentUser(fbUser);
            setAdminRecord(matched);
            setSelectedAdminForBiometric(matched.email);
            const passkeys = getStoredPasskeys(matched.email);
            setStoredPasskeys(passkeys);
            localStorage.setItem('bup_active_admin_session', JSON.stringify(matched));
            window.dispatchEvent(new CustomEvent('adminAuthChanged', { detail: matched }));
            if (onAdminAuthenticated) onAdminAuthenticated(matched);
          } else {
            setCurrentUser(null);
            setAdminRecord(null);
            localStorage.removeItem('bup_active_admin_session');
            window.dispatchEvent(new CustomEvent('adminAuthChanged', { detail: null }));
            if (onAdminAuthenticated) onAdminAuthenticated(null);
          }
        } catch (err) {
          console.warn('Admin verification error:', err);
          setAuthError('এডমিন যাচাই করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
          setCurrentUser(null);
          setAdminRecord(null);
          if (onAdminAuthenticated) onAdminAuthenticated(null);
        }
      } else {
        // Check if there is already a local session
        const saved = localStorage.getItem('bup_active_admin_session');
        if (saved) {
          try {
            const parsed = JSON.parse(saved);
            setAdminRecord(parsed);
            setSelectedAdminForBiometric(parsed.email);
            const passkeys = getStoredPasskeys(parsed.email);
            setStoredPasskeys(passkeys);
          } catch (e) {
            setAdminRecord(null);
          }
        } else {
          setAdminRecord(null);
        }
        setCurrentUser(null);
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [isOpen]);

  // Update passkeys whenever selected admin changes
  useEffect(() => {
    if (selectedAdminForBiometric) {
      const keys = getStoredPasskeys(selectedAdminForBiometric);
      setStoredPasskeys(keys);
    }
  }, [selectedAdminForBiometric]);

  // 1. Google OAuth Popup Sign-In Handler
  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setAuthError(null);
    setSuccessMessage(null);
    try {
      await signInWithGooglePopup();
    } catch (err: any) {
      if (err?.code === 'auth/popup-closed-by-user' || err?.message?.includes('popup-closed-by-user')) {
        setAuthError('সাইন-ইন পপআপ উইন্ডোটি বন্ধ করা হয়েছে।');
      } else {
        console.error('Google Sign-in error:', err);
        setAuthError(formatFirebaseAuthError(err));
      }
      setIsLoading(false);
    }
  };

  // 1.b Google OAuth Redirect Sign-In Handler
  const handleGoogleRedirectSignIn = async () => {
    setIsLoading(true);
    setAuthError(null);
    setSuccessMessage('গুগল লগইন পেজে রিডাইরেক্ট করা হচ্ছে...');
    try {
      await signInWithGoogleRedirect();
    } catch (err: any) {
      console.error('Google Redirect Sign-in error:', err);
      setAuthError(formatFirebaseAuthError(err));
      setIsLoading(false);
    }
  };

  // Standalone App Launcher in New Tab
  const handleOpenStandalone = () => {
    if (typeof window !== 'undefined') {
      window.open(window.location.href, '_blank', 'noopener,noreferrer');
    }
  };

  // Copy Hostname helper
  const handleCopyHostname = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard.writeText(window.location.hostname);
      setDomainCopied(true);
      setTimeout(() => setDomainCopied(false), 2500);
    }
  };

  // 2. WebAuthn Biometric / Passkey Login Handler (1-Touch Fast Sign-In)
  const handleTriggerBiometricLogin = async () => {
    const targetEmail = (adminRecord?.email || selectedAdminForBiometric || 'inbox600900@gmail.com').toLowerCase().trim();
    setIsBiometricScanning(true);
    setAuthError(null);
    setSuccessMessage('আপনার ডিভাইসের বায়োমেট্রিক ফিঙ্গারপ্রিন্ট সেন্সর / Touch ID / Face ID বা প্যাসকি স্পর্শ করুন...');

    try {
      const result = await verifyWebAuthnPasskey(targetEmail);
      if (result.success) {
        // Resolve Admin Record from directory or create elevated session
        let targetAdmin = adminList.find((a) => a.email.toLowerCase() === targetEmail);
        if (!targetAdmin && (targetEmail === 'inbox600900@gmail.com' || targetEmail === 'baheratailunion@gmail.com')) {
          targetAdmin = {
            email: targetEmail,
            name: 'প্রধান আইটি ডেভেলপার',
            role: 'developer',
            designation: 'প্রধান সিস্টেম আর্কিটেক্ট ও ডেভেলপার',
            addedAt: new Date().toISOString(),
            status: 'active'
          };
        }

        if (targetAdmin) {
          setAdminRecord(targetAdmin);
          setBiometricSessionElevation(targetAdmin.email, 'WebAuthn Passkey', result.credentialId);
          setIsBiometricElevated(true);
          localStorage.setItem('bup_active_admin_session', JSON.stringify(targetAdmin));
          window.dispatchEvent(new CustomEvent('adminAuthChanged', { detail: targetAdmin }));
          if (onAdminAuthenticated) onAdminAuthenticated(targetAdmin);

          // Build and trigger Biometric Login Successful Notification Toast
          const now = new Date();
          const toastData: BiometricToastData = {
            id: `bio-login-${Date.now()}`,
            title: 'Secure Login Successful',
            subtitle: 'বায়োমেট্রিক ও WebAuthn প্যাসকি নিরাপত্তা যাচাই সফল',
            timestamp: formatBiometricTimestamp(now),
            isoTimestamp: now.toISOString(),
            adminName: targetAdmin.name || 'অনুমোদিত এডমিন',
            adminEmail: targetAdmin.email,
            adminRole: targetAdmin.role,
            adminDesignation: targetAdmin.designation || 'সিস্টেম এডমিন',
            authMethod: diagnostics?.recommendedMethod || 'WebAuthn Platform Biometric (Touch ID / Face ID / Windows Hello)',
            credentialId: result.credentialId,
            hardwareDevice: diagnostics?.hardwareDeviceName || 'Device Hardware Biometric Sensor'
          };

          setBiometricToast(toastData);
          window.dispatchEvent(new CustomEvent('biometric-auth-success', { detail: toastData }));
          playBiometricSuccessChime();

          // Record in persistent chronological biometric audit trail
          recordBiometricLoginEvent({
            adminEmail: targetAdmin.email,
            adminName: targetAdmin.name || 'অনুমোদিত এডমিন',
            adminRole: targetAdmin.role,
            adminDesignation: targetAdmin.designation || 'সিস্টেম এডমিন',
            authMethod: toastData.authMethod,
            credentialId: result.credentialId,
            deviceName: diagnostics?.hardwareDeviceName,
            context: 'Admin Portal Login',
            status: 'SUCCESS'
          });

          setSuccessMessage('✓ Secure Login Successful — বায়োমেট্রিক প্যাসকি যাচাই সফল! আপনি এডমিন হিসেবে প্রবেশ করেছেন।');
          setTimeout(() => {
            onClose();
          }, 1800);
        } else {
          setAuthError('অনুমোদিত এডমিন তালিকায় এই ইমেইলটি পাওয়া যায়নি।');
        }
      } else {
        setAuthError(result.message);
      }
    } catch (err: any) {
      setAuthError('বায়োমেট্রিক স্ক্যানকালে ত্রুটি: ' + (err.message || 'অজানা ত্রুটি'));
    } finally {
      setIsBiometricScanning(false);
    }
  };

  // 3. Register New Device Passkey Handler
  const handleRegisterNewPasskey = async () => {
    const targetEmail = (adminRecord?.email || currentUser?.email || selectedAdminForBiometric).toLowerCase().trim();
    const targetName = adminRecord?.name || currentUser?.displayName || 'ইউপি এডমিন';

    if (!targetEmail) {
      setAuthError('প্যাসকি রেজিস্ট্রেশনের জন্য পূর্বে একটি এডমিন ইমেইল নির্বাচন বা সাইন ইন করুন।');
      return;
    }

    setIsRegisteringPasskey(true);
    setAuthError(null);
    setSuccessMessage('ডিভাইসের বায়োমেট্রিক সেন্সরে স্পর্শ করে প্যাসকি তৈরি করুন...');

    try {
      const result = await registerWebAuthnPasskey(targetEmail, targetName);
      if (result.success && result.passkey) {
        const updated = getStoredPasskeys(targetEmail);
        setStoredPasskeys(updated);
        setIsBiometricElevated(true);

        const now = new Date();
        const toastData: BiometricToastData = {
          id: `bio-reg-${Date.now()}`,
          title: 'Secure Login Successful',
          subtitle: 'নতুন বায়োমেট্রিক ডিভাইস প্যাসকি সফলভাবে সক্রিয় ও নিবন্ধিত হয়েছে',
          timestamp: formatBiometricTimestamp(now),
          isoTimestamp: now.toISOString(),
          adminName: targetName,
          adminEmail: targetEmail,
          adminRole: adminRecord?.role || 'admin',
          adminDesignation: adminRecord?.designation || 'নিবন্ধিত এডমিন ডিভাইস',
          authMethod: 'WebAuthn Passkey Registration',
          credentialId: result.passkey.id,
          hardwareDevice: result.passkey.deviceName
        };

        setBiometricToast(toastData);
        window.dispatchEvent(new CustomEvent('biometric-auth-success', { detail: toastData }));
        playBiometricSuccessChime();

        recordBiometricLoginEvent({
          adminEmail: targetEmail,
          adminName: targetName,
          adminRole: adminRecord?.role || 'admin',
          adminDesignation: adminRecord?.designation || 'নিবন্ধিত এডমিন ডিভাইস',
          authMethod: 'WebAuthn Passkey Registration',
          credentialId: result.passkey.id,
          deviceName: result.passkey.deviceName,
          context: 'Biometric Passkey Device Enrollment',
          status: 'SUCCESS'
        });

        setSuccessMessage('✓ সফলভাবে আপনার ডিভাইসের বায়োমেট্রিক ফিঙ্গারপ্রিন্ট / প্যাসকি নিবন্ধিত হয়েছে!');
      } else {
        setAuthError(result.message);
      }
    } catch (err: any) {
      setAuthError('প্যাসকি নিবন্ধনে ত্রুটি: ' + (err.message || 'অজানা সমস্যা'));
    } finally {
      setIsRegisteringPasskey(false);
    }
  };

  // 4. Delete Passkey Handler
  const handleDeletePasskey = (passkeyId: string) => {
    const targetEmail = (adminRecord?.email || selectedAdminForBiometric).toLowerCase().trim();
    deletePasskeyFromStorage(targetEmail, passkeyId);
    setStoredPasskeys(getStoredPasskeys(targetEmail));
    setSuccessMessage('প্যাসকি সফলভাবে মুছে ফেলা হয়েছে।');
  };

  // 5. Security PIN Fallback Handler
  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    if (verifySecurityPin(pinInput)) {
      const targetEmail = (adminRecord?.email || selectedAdminForBiometric || 'baheratailunion@gmail.com').toLowerCase().trim();
      let targetAdmin = adminList.find((a) => a.email.toLowerCase() === targetEmail);

      if (!targetAdmin) {
        targetAdmin = {
          email: targetEmail,
          name: 'ইউপি সিস্টেম এডমিন',
          role: 'secretary',
          designation: 'ইউপি সচিব / প্রশাসনিক কর্মকর্তা',
          addedAt: new Date().toISOString(),
          status: 'active'
        };
      }

      setAdminRecord(targetAdmin);
      setBiometricSessionElevation(targetAdmin.email, 'Master PIN');
      setIsBiometricElevated(true);
      localStorage.setItem('bup_active_admin_session', JSON.stringify(targetAdmin));
      window.dispatchEvent(new CustomEvent('adminAuthChanged', { detail: targetAdmin }));
      if (onAdminAuthenticated) onAdminAuthenticated(targetAdmin);

      setSuccessMessage('✓ অফিশিয়াল মাস্টার পিন যাচাই সফল! এডমিন সেশন সক্রিয় হয়েছে।');
      setTimeout(() => {
        onClose();
      }, 1000);
    } else {
      setAuthError('⚠️ ভুল সিকিউরিটি পিন নম্বর প্রদান করা হয়েছে। (চেয়ারম্যান/সচিব অফিসিয়াল পিন ব্যবহার করুন)');
    }
  };

  // 6. WhatsApp OTP Handlers
  const handleSendWhatsAppOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setAuthError(null);
    setSuccessMessage(null);

    const { isValid, formatted } = whatsappAuthService.formatBangladeshiPhone(waPhone);
    if (!isValid) {
      setAuthError('সঠিক ১১ ডিজিটের বাংলাদেশী মোবাইল নম্বর দিন (যেমন: 017XXXXXXXX)।');
      return;
    }

    setIsWaLoading(true);
    try {
      const res = await whatsappAuthService.sendOtp(waPhone, 'staff');
      if (res.success && res.token) {
        setWaOtpToken(res.token);
        setWaDirectUrl(res.directWaUrl);
        setWaDevOtp(res.devOtp);
        setWaStep('otp');
        setWaCountdown(60);
        setWaCanResend(false);
        setWaOtpDigits(['', '', '', '', '', '']);
        setSuccessMessage(res.message);
        setTimeout(() => {
          waInputRefs.current[0]?.focus();
        }, 100);
      } else {
        setAuthError(res.message || 'হোয়াটসঅ্যাপ ওটিপি পাঠানো যায়নি।');
      }
    } catch (err: any) {
      setAuthError(err.message || 'হোয়াটসঅ্যাপ ওটিপি নেটওয়ার্ক সমস্যা।');
    } finally {
      setIsWaLoading(false);
    }
  };

  const handleVerifyWhatsAppOtp = async (codeToVerify?: string) => {
    const finalCode = codeToVerify || waOtpDigits.join('');
    if (finalCode.length !== 6) {
      setAuthError('সম্পূর্ণ ৬ ডিজিটের ওটিপি কোড প্রবেশ করান।');
      return;
    }

    setAuthError(null);
    setIsWaLoading(true);
    try {
      const res = await whatsappAuthService.verifyOtp(waPhone, finalCode, waOtpToken);
      if (res.success && res.user) {
        const adminUser: AdminUserRecord = {
          email: res.user.email || `${res.user.phone.replace(/\D/g, '')}@whatsapp.upsm.gov.bd`,
          name: res.user.name,
          role: (res.user.role === 'citizen' ? 'udc' : res.user.role) as any,
          designation: res.user.designation || 'হোয়াটসঅ্যাপ ভেরিফাইড ইউজার',
          addedAt: new Date().toISOString(),
          status: 'active'
        };

        setAdminRecord(adminUser);
        localStorage.setItem('bup_active_admin_session', JSON.stringify(adminUser));
        window.dispatchEvent(new CustomEvent('adminAuthChanged', { detail: adminUser }));
        if (onAdminAuthenticated) onAdminAuthenticated(adminUser);

        playBiometricSuccessChime();
        setSuccessMessage('✓ হোয়াটসঅ্যাপ ওটিপি সফলভাবে যাচাইকৃত! এডমিন সেশন সক্রিয় হয়েছে।');
        setTimeout(() => {
          onClose();
        }, 1000);
      } else {
        setAuthError(res.message || 'ভুল ওটিপি কোড প্রদান করা হয়েছে।');
      }
    } catch (err: any) {
      setAuthError(err.message || 'ওটিপি যাচাইকরণ ব্যর্থ হয়েছে।');
    } finally {
      setIsWaLoading(false);
    }
  };

  const handleWaDigitChange = (index: number, value: string) => {
    const cleanVal = whatsappAuthService.convertBanglaToEnglishDigits(value).replace(/\D/g, '').slice(-1);
    const newCode = [...waOtpDigits];
    newCode[index] = cleanVal;
    setWaOtpDigits(newCode);

    if (cleanVal && index < 5) {
      waInputRefs.current[index + 1]?.focus();
    }

    if (newCode.every(d => d !== '') && cleanVal) {
      handleVerifyWhatsAppOtp(newCode.join(''));
    }
  };

  const handleWaKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !waOtpDigits[index] && index > 0) {
      waInputRefs.current[index - 1]?.focus();
    }
  };

  const handleWaPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pasted = whatsappAuthService.convertBanglaToEnglishDigits(e.clipboardData.getData('text')).replace(/\D/g, '').slice(0, 6);
    if (pasted) {
      const digits = pasted.split('');
      const newCode = [...waOtpDigits];
      digits.forEach((d, idx) => {
        if (idx < 6) newCode[idx] = d;
      });
      setWaOtpDigits(newCode);
      if (pasted.length === 6) {
        handleVerifyWhatsAppOtp(pasted);
      } else {
        waInputRefs.current[Math.min(pasted.length, 5)]?.focus();
      }
    }
  };

  // Sign Out Handler
  const handleSignOut = async () => {
    setIsLoading(true);
    try {
      await logoutUserFromFirebase();
      setAdminRecord(null);
      setCurrentUser(null);
      setIsBiometricElevated(false);
      localStorage.removeItem('bup_active_admin_session');
      window.dispatchEvent(new CustomEvent('adminAuthChanged', { detail: null }));
      if (onAdminAuthenticated) onAdminAuthenticated(null);
      setSuccessMessage('সফলভাবে লগআউট সম্পন্ন হয়েছে।');
    } catch (err: any) {
      setAuthError('লগআউট করতে ব্যর্থ: ' + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div id="admin-auth-modal" className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden relative space-y-0">

        {/* Modal Header Banner */}
        <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-teal-950 text-white p-6 relative overflow-hidden">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-400 text-emerald-950 rounded-2xl shrink-0 font-extrabold shadow-lg">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 bg-emerald-900/90 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-400/30 text-[10px] uppercase font-black tracking-wider">
                <Fingerprint className="w-3 h-3 text-amber-300" />
                <span>WebAuthn Biometric & OAuth 2.0 Security</span>
              </div>
              <h2 className="text-xl font-black text-white mt-0.5">
                এডমিন প্যানেল স্মার্ট লগইন
              </h2>
              <p className="text-xs text-emerald-100">
                চেয়ারম্যান, সচিব, ইউপি সদস্য ও সিস্টেম এডমিন যাচাইকরণ
              </p>
            </div>
          </div>
        </div>

        {/* Navigation Tabs for Auth Modes */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4 pt-3 gap-1 overflow-x-auto">
          <button
            type="button"
            onClick={() => { setActiveAuthTab('google'); setAuthError(null); }}
            className={`pb-2.5 px-3 text-xs font-bold rounded-t-xl transition flex items-center gap-1.5 cursor-pointer border-b-2 shrink-0 ${
              activeAuthTab === 'google'
                ? 'border-emerald-700 text-emerald-950 bg-white shadow-sm'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
            </svg>
            <span>গুগল লগইন</span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveAuthTab('whatsapp'); setAuthError(null); }}
            className={`pb-2.5 px-3 text-xs font-bold rounded-t-xl transition flex items-center gap-1.5 cursor-pointer border-b-2 shrink-0 ${
              activeAuthTab === 'whatsapp'
                ? 'border-emerald-700 text-emerald-950 bg-white shadow-sm'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
            <span>হোয়াটসঅ্যাপ ওটিপি</span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveAuthTab('biometric'); setAuthError(null); }}
            className={`pb-2.5 px-3 text-xs font-bold rounded-t-xl transition flex items-center gap-1.5 cursor-pointer border-b-2 shrink-0 ${
              activeAuthTab === 'biometric'
                ? 'border-emerald-700 text-emerald-950 bg-white shadow-sm'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Fingerprint className="w-3.5 h-3.5 text-emerald-700" />
            <span>বায়োমেট্রিক প্যাসকি</span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveAuthTab('passkeys'); setAuthError(null); }}
            className={`pb-2.5 px-3 text-xs font-bold rounded-t-xl transition flex items-center gap-1.5 cursor-pointer border-b-2 shrink-0 ${
              activeAuthTab === 'passkeys'
                ? 'border-emerald-700 text-emerald-950 bg-white shadow-sm'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-amber-600" />
            <span>প্যাসকি ডিভাইস ({storedPasskeys.length})</span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveAuthTab('pin'); setAuthError(null); }}
            className={`pb-2.5 px-3 text-xs font-bold rounded-t-xl transition flex items-center gap-1.5 cursor-pointer border-b-2 shrink-0 ${
              activeAuthTab === 'pin'
                ? 'border-emerald-700 text-emerald-950 bg-white shadow-sm'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Key className="w-3.5 h-3.5 text-slate-600" />
            <span>মাস্টার পিন</span>
          </button>
        </div>

        {/* Modal Main Content Area */}
        <div className="p-6 space-y-5">

          {/* Feedback Toasts */}
          {authError && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 p-3.5 rounded-2xl text-xs font-bold flex items-center gap-2 animate-shake">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          {successMessage && !authError && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 p-3.5 rounded-2xl text-xs font-bold flex items-center gap-2 animate-fade-in">
              <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Active Session Strip (If already signed in) */}
          {adminRecord && (
            <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-emerald-200/80 pb-2.5">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
                  <span className="text-xs font-extrabold text-emerald-950">
                    বর্তমানে সক্রিয় এডমিন সেশন
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  {isBiometricElevated && (
                    <span className="text-[10px] font-black text-amber-900 bg-amber-200 border border-amber-300 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Fingerprint className="w-2.5 h-2.5 text-amber-800" /> বায়োমেট্রিক ভেরিফাইড
                    </span>
                  )}
                  <span className="text-[10px] font-bold text-emerald-800 bg-emerald-200 px-2.5 py-0.5 rounded-full">
                    সক্রিয়
                  </span>
                </div>
              </div>

              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  {currentUser?.photoURL ? (
                    <img
                      src={currentUser.photoURL}
                      alt="Profile"
                      className="w-11 h-11 rounded-xl border border-emerald-600 object-cover shrink-0"
                    />
                  ) : (
                    <div className="w-11 h-11 rounded-xl bg-emerald-900 text-amber-300 font-black flex items-center justify-center text-sm shadow shrink-0">
                      {adminRecord.name ? adminRecord.name[0] : 'A'}
                    </div>
                  )}

                  <div className="min-w-0">
                    <h3 className="font-extrabold text-sm text-slate-900 truncate">
                      {adminRecord.name}
                    </h3>
                    <p className="text-xs text-slate-500 truncate">{adminRecord.email}</p>
                    <span className="inline-block mt-0.5 text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                      {adminRecord.designation || adminRecord.role}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleSignOut}
                  disabled={isLoading}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-1 cursor-pointer disabled:opacity-50 shrink-0"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>লগআউট</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 1: Google OAuth Sign-In */}
          {activeAuthTab === 'google' && !adminRecord && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 text-center space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto font-black shadow-sm">
                <Lock className="w-6 h-6 text-emerald-800" />
              </div>

              <div>
                <h3 className="font-extrabold text-slate-900 text-base">
                  গুগল একাউন্ট দিয়ে নিরাপদ এডমিন লগইন
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                  চেয়ারম্যান, সচিব, ইউডিসি উদ্যোক্তা বা ডেভেলপার হিসেবে সিস্টেমে প্রবেশ করতে আপনার গুগল একাউন্ট ব্যবহার করুন।
                </p>
              </div>

              {/* Main Google Popup Button */}
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isLoading}
                className="w-full py-3.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm rounded-2xl shadow-xl transition flex items-center justify-center gap-3 border border-slate-700 cursor-pointer active:scale-98 disabled:opacity-50"
              >
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                </svg>
                <span>Google-এর মাধ্যমে সাইন ইন করুন</span>
              </button>

              {/* Secondary Options for Iframe / Mobile / Popup Blocked scenarios */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleOpenStandalone}
                  className="py-2.5 px-3 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl border border-slate-300 shadow-sm transition flex items-center justify-center gap-1.5 cursor-pointer hover:border-slate-400"
                  title="নতুন ট্যাবে ফুল-স্ক্রিনে অ্যাপটি খুলুন যেখানে কোনো পপআপ ব্লক হবে না"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>নতুন ট্যাবে অ্যাপ খুলুন</span>
                </button>

                <button
                  type="button"
                  onClick={handleGoogleRedirectSignIn}
                  disabled={isLoading}
                  className="py-2.5 px-3 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl border border-slate-300 shadow-sm transition flex items-center justify-center gap-1.5 cursor-pointer hover:border-slate-400 disabled:opacity-50"
                  title="পপআপ কাজ না করলে সরাসরি পেজ রিডাইরেক্টের মাধ্যমে লগইন করুন"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>রিডাইরেক্ট লগইন</span>
                </button>
              </div>

              {/* Iframe Notice / Helper */}
              {isInsideIframe && (
                <div className="bg-amber-50 border border-amber-200/80 rounded-xl p-2.5 text-left flex items-start gap-2">
                  <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <p className="text-[11px] text-amber-900 leading-relaxed">
                    <strong>প্রিভিউ মোড টিপস:</strong> আইফ্রেমে ব্রাউজার পপআপ আটকে দিলে ওপরের <strong>'নতুন ট্যাবে অ্যাপ খুলুন'</strong> বাটনে ক্লিক করে ফুল-স্ক্রিন ট্যাবে লগইন সম্পন্ন করুন।
                  </p>
                </div>
              )}

              {/* Domain Helper if domain error occurred */}
              {authError && authError.includes('Authorized Domains') && (
                <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 text-left space-y-2">
                  <div className="text-xs font-bold text-rose-900 flex items-center gap-1.5">
                    <Globe className="w-3.5 h-3.5 text-rose-700" />
                    <span>Firebase Authorized Domain সমাধান:</span>
                  </div>
                  <p className="text-[11px] text-rose-800 leading-relaxed">
                    Firebase Console &gt; Authentication &gt; Settings &gt; Authorized domains-এ এই ডোমেইনটি যুক্ত করুন:
                  </p>
                  <div className="flex items-center gap-2 bg-white px-2.5 py-1.5 rounded-lg border border-rose-300 text-[11px] font-mono text-slate-800">
                    <span className="truncate select-all">{typeof window !== 'undefined' ? window.location.hostname : ''}</span>
                    <button
                      type="button"
                      onClick={handleCopyHostname}
                      className="ml-auto px-2 py-0.5 bg-rose-100 hover:bg-rose-200 text-rose-800 rounded font-sans text-[10px] font-bold shrink-0 transition"
                    >
                      {domainCopied ? 'কপি হয়েছে!' : 'কপি করুন'}
                    </button>
                  </div>
                </div>
              )}

              <div className="pt-1 text-[11px] text-slate-500 flex items-center justify-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-emerald-700" />
                <span>ফায়ারস্টোর ডিরেক্টরিতে তালিকাভুক্ত অনুমোদিত ইমেইল প্রবেশাধিকার পাবে।</span>
              </div>
            </div>
          )}

          {/* TAB 1-B: WhatsApp OTP & Verified Login */}
          {activeAuthTab === 'whatsapp' && (
            <div className="space-y-4 py-1">
              <div className="text-center space-y-2">
                <div className="w-16 h-16 rounded-2xl bg-emerald-50 border-2 border-emerald-300 flex items-center justify-center mx-auto text-emerald-700 shadow-sm">
                  <MessageSquare className="w-9 h-9" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-base">
                    হোয়াটসঅ্যাপ ওটিপি ভেরিফিকেশন
                  </h3>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto mt-0.5">
                    আপনার নিবন্ধিত মোবাইল নম্বরে ৬ ডিজিটের নিরাপত্তা কোড পাঠানো হবে।
                  </p>
                </div>
              </div>

              {/* Twilio WhatsApp Business API Gateway Connection Status */}
              <div className="flex items-center justify-between p-2.5 bg-emerald-50/80 border border-emerald-200/80 rounded-xl text-[11px]">
                <div className="flex items-center gap-1.5 font-bold text-emerald-950">
                  <span className={`w-2 h-2 rounded-full ${twilioStatus?.isConfigured ? 'bg-emerald-600 animate-ping' : 'bg-emerald-500'}`} />
                  <span>Twilio WhatsApp Business Gateway:</span>
                </div>
                <span className={`px-2 py-0.5 rounded-full font-extrabold text-[10px] ${twilioStatus?.isConfigured ? 'bg-emerald-200 text-emerald-900' : 'bg-emerald-100 text-emerald-800'}`}>
                  {twilioStatus?.isConfigured ? 'সক্রিয় (Live Twilio OTP)' : 'ক্লাউড ইন্টিগ্রেটেড'}
                </span>
              </div>

              {/* Step 1: Mobile Number Input */}
              {waStep === 'phone' && (
                <form onSubmit={handleSendWhatsAppOtp} className="space-y-3.5">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-700">
                      মোবাইল নম্বর লিখুন:
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 text-xs font-bold">
                        🇧🇩 +880
                      </div>
                      <input
                        type="tel"
                        value={waPhone}
                        onChange={(e) => setWaPhone(e.target.value)}
                        placeholder="01XXXXXXXXX"
                        className="w-full pl-20 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold text-slate-800 focus:bg-white focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 transition outline-none"
                        autoFocus
                      />
                    </div>

                    {/* Quick Number Selector Chips */}
                    <div className="space-y-1.5 pt-1">
                      <span className="text-[11px] font-bold text-slate-500 block">
                        দ্রুত টেস্ট ও কর্মকর্তা/ডেভেলপার নম্বর নির্বাচন:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        <button
                          type="button"
                          onClick={() => setWaPhone('01834333300')}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition flex items-center gap-1 border cursor-pointer ${
                            waPhone === '01834333300'
                              ? 'bg-amber-100 text-amber-900 border-amber-400 shadow-xs'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                          }`}
                        >
                          <span>👨‍💻 ডেভেলপার (01834333300)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setWaPhone('01712345678')}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition flex items-center gap-1 border cursor-pointer ${
                            waPhone === '01712345678'
                              ? 'bg-emerald-100 text-emerald-900 border-emerald-400 shadow-xs'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                          }`}
                        >
                          <span>🏛️ চেয়ারম্যান (01712345678)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setWaPhone('01711122233')}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition flex items-center gap-1 border cursor-pointer ${
                            waPhone === '01711122233'
                              ? 'bg-emerald-100 text-emerald-900 border-emerald-400 shadow-xs'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                          }`}
                        >
                          <span>📋 সচিব (01711122233)</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isWaLoading || !waPhone.trim()}
                    className="w-full py-3.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm rounded-2xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isWaLoading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>ওটিপি কোড পাঠানো হচ্ছে...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>হোয়াটসঅ্যাপ ওটিপি কোড পাঠান</span>
                      </>
                    )}
                  </button>
                </form>
              )}

              {/* Step 2: OTP Verification Code */}
              {waStep === 'otp' && (
                <div className="space-y-3.5">
                  <div className="text-center space-y-1">
                    <p className="text-xs text-slate-600">
                      <strong className="text-slate-900">{waPhone}</strong> নম্বরে প্রেরিত ৬ ডিজিটের কোডটি লিখুন:
                    </p>
                    <button
                      type="button"
                      onClick={() => setWaStep('phone')}
                      className="text-xs text-emerald-700 hover:underline font-bold"
                    >
                      নম্বর পরিবর্তন করুন
                    </button>
                  </div>

                  <div className="flex items-center justify-center gap-2 py-1" onPaste={handleWaPaste}>
                    {waOtpDigits.map((digit, idx) => (
                      <input
                        key={idx}
                        ref={(el) => (waInputRefs.current[idx] = el)}
                        type="text"
                        inputMode="numeric"
                        maxLength={1}
                        value={digit}
                        onChange={(e) => handleWaDigitChange(idx, e.target.value)}
                        onKeyDown={(e) => handleWaKeyDown(idx, e)}
                        className="w-11 h-12 text-center text-xl font-black bg-slate-50 border-2 border-slate-200 rounded-xl focus:border-emerald-600 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 outline-none transition"
                      />
                    ))}
                  </div>

                  {waDevOtp && (
                    <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between text-xs">
                      <span className="text-amber-900 font-medium">
                        টেস্ট ওটিপি কোড: <strong className="font-mono text-sm text-amber-950 font-black">{waDevOtp}</strong>
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          const digits = waDevOtp.split('');
                          setWaOtpDigits(digits);
                          handleVerifyWhatsAppOtp(waDevOtp);
                        }}
                        className="px-2.5 py-1 bg-amber-200 hover:bg-amber-300 text-amber-950 rounded-lg font-bold text-[11px] transition cursor-pointer"
                      >
                        স্বয়ংক্রিয় পূরণ
                      </button>
                    </div>
                  )}

                  {waDirectUrl && (
                    <a
                      href={waDirectUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 transition flex items-center justify-center gap-1.5"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>WhatsApp-এ সরাসরি মেসেজ দেখুন</span>
                    </a>
                  )}

                  <button
                    type="button"
                    onClick={() => handleVerifyWhatsAppOtp()}
                    disabled={isWaLoading || waOtpDigits.some(d => !d)}
                    className="w-full py-3.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm rounded-2xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isWaLoading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>যাচাই করা হচ্ছে...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>যাচাই করে লগইন সম্পন্ন করুন</span>
                      </>
                    )}
                  </button>

                  <div className="text-center pt-1">
                    {waCanResend ? (
                      <button
                        type="button"
                        onClick={() => handleSendWhatsAppOtp()}
                        className="text-xs text-emerald-700 hover:text-emerald-900 font-bold flex items-center justify-center gap-1 mx-auto"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>পুনরায় ওটিপি কোড পাঠান</span>
                      </button>
                    ) : (
                      <p className="text-xs text-slate-400">
                        {waCountdown} সেকেন্ড পর পুনরায় পাঠানো যাবে
                      </p>
                    )}
                  </div>
                </div>
              )}

              <div className="pt-1 text-[11px] text-slate-500 flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                <span>অফিশিয়াল হোয়াটসঅ্যাপ ক্লাউড ওটিপি প্রমাণীকরণ</span>
              </div>
            </div>
          )}

          {/* TAB 2: WebAuthn Biometric & Passkey Login (1-Touch) */}
          {activeAuthTab === 'biometric' && (
            <div className="space-y-4 py-1">
              <div className="text-center space-y-3">
                <div className="relative inline-block my-1">
                  <div className="w-20 h-20 rounded-2xl bg-emerald-50 border-2 border-emerald-300 flex items-center justify-center mx-auto relative overflow-hidden group">
                    <Fingerprint className={`w-12 h-12 text-emerald-800 transition-transform ${isBiometricScanning ? 'animate-pulse scale-110 text-amber-500' : 'group-hover:scale-105'}`} />
                    {isBiometricScanning && (
                      <div className="absolute inset-0 bg-amber-400/20 animate-ping rounded-2xl" />
                    )}
                  </div>
                </div>

                <div>
                  <h3 className="font-black text-slate-900 text-base">
                    ১-টাচ বায়োমেট্রিক প্যাসকি লগইন
                  </h3>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto mt-1">
                    ডিভাইসের Touch ID, Face ID, Windows Hello বা ফিঙ্গারপ্রিন্ট সেন্সরে স্পর্শ করে নিরাপদ প্রবেশ করুন।
                  </p>
                </div>
              </div>

              {/* Admin Email Selector if not logged in */}
              {!adminRecord && (
                <div className="space-y-1.5 bg-slate-50 p-3 rounded-2xl border border-slate-200">
                  <label className="block text-xs font-bold text-slate-700">
                    এডমিন ইমেইল অ্যাকাউন্ট নির্বাচন করুন:
                  </label>
                  <select
                    value={selectedAdminForBiometric}
                    onChange={(e) => setSelectedAdminForBiometric(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-700"
                  >
                    {adminList.map((adm) => (
                      <option key={adm.email} value={adm.email}>
                        {adm.name} ({adm.designation || adm.role}) — {adm.email}
                      </option>
                    ))}
                    <option value="inbox600900@gmail.com">প্রধান আইটি ডেভেলপার (inbox600900@gmail.com)</option>
                    <option value="baheratailunion@gmail.com">বহেড়াতৈল ইউপি অফিস (baheratailunion@gmail.com)</option>
                  </select>
                </div>
              )}

              {/* Device Hardware Readiness Status */}
              <div className="bg-emerald-50/60 p-3 rounded-2xl border border-emerald-200 text-xs flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Laptop className="w-4 h-4 text-emerald-800" />
                  <span className="font-bold text-slate-700">ডিভাইস সেন্সর:</span>
                </div>
                {isPlatformBiometric ? (
                  <span className="text-[11px] font-black text-emerald-900 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-full">
                    ✅ {diagnostics?.recommendedMethod || 'বায়োমেট্রিক প্রস্তুত'}
                  </span>
                ) : (
                  <span className="text-[10px] font-bold text-amber-900 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-full">
                    FIDO2 প্যাসকি প্রস্তুত
                  </span>
                )}
              </div>

              <button
                type="button"
                onClick={handleTriggerBiometricLogin}
                disabled={isBiometricScanning}
                className="w-full py-3.5 bg-emerald-900 hover:bg-emerald-800 text-amber-300 font-extrabold text-sm rounded-2xl shadow-xl transition flex items-center justify-center gap-2 cursor-pointer active:scale-98 disabled:opacity-50"
              >
                {isBiometricScanning ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin text-amber-300" />
                    <span>বায়োমেট্রিক স্ক্যান নেওয়া হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <Fingerprint className="w-5 h-5 text-amber-300" />
                    <span>বায়োমেট্রিক স্পর্শ করে লগইন করুন</span>
                  </>
                )}
              </button>
            </div>
          )}

          {/* TAB 3: Device Passkeys Manager */}
          {activeAuthTab === 'passkeys' && (
            <div className="space-y-4 py-1">
              <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl text-xs space-y-1.5">
                <div className="flex items-center gap-2 font-black text-amber-950">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>ডিভাইস প্যাসকি (WebAuthn Passkey) ব্যবস্থাপনা</span>
                </div>
                <p className="text-amber-900 leading-relaxed font-medium">
                  আপনার বর্তমান ল্যাপটপ বা মোবাইল ফোনের বায়োমেট্রিক সেন্সর প্যাসকি হিসেবে যুক্ত করে রাখলে পরবর্তীতে পাসওয়ার্ড ছাড়াই দ্রুত প্রবেশ ও প্রত্যয়ন অনুমোদন করতে পারবেন।
                </p>
              </div>

              {/* Registered Passkeys List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-bold text-slate-800">
                    নিবন্ধিত প্যাসকি সমূহ ({storedPasskeys.length}):
                  </p>
                  <span className="text-[10px] text-slate-500">
                    {selectedAdminForBiometric || adminRecord?.email}
                  </span>
                </div>

                {storedPasskeys.length === 0 ? (
                  <div className="p-4 bg-slate-50 border border-dashed border-slate-300 rounded-2xl text-center text-xs text-slate-500">
                    এই এডমিন একাউন্টে কোনো ডিভাইস প্যাসকি যুক্ত করা নেই। নিচের বাটনে ক্লিক করে ডিভাইস যুক্ত করুন।
                  </div>
                ) : (
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {storedPasskeys.map((pk) => (
                      <div
                        key={pk.id}
                        className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs flex items-center justify-between"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <Laptop className="w-4 h-4 text-emerald-800 shrink-0" />
                          <div className="min-w-0">
                            <p className="font-extrabold text-slate-900 truncate">{pk.deviceName}</p>
                            <p className="text-[10px] text-slate-500">
                              যুক্ত: {new Date(pk.registeredAt).toLocaleDateString('bn-BD')}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-md">
                            সক্রিয়
                          </span>
                          <button
                            type="button"
                            onClick={() => handleDeletePasskey(pk.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 transition cursor-pointer"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <button
                type="button"
                onClick={handleRegisterNewPasskey}
                disabled={isRegisteringPasskey}
                className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-2xl shadow transition flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                {isRegisteringPasskey ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                    <span>প্যাসকি তৈরি হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4 text-slate-950 stroke-[3]" />
                    <span>এই ডিভাইসের বায়োমেট্রিক প্যাসকি রেজিস্টার করুন</span>
                  </>
                )}
              </button>
            </div>
          )}

          {/* TAB 4: Master Security PIN Fallback */}
          {activeAuthTab === 'pin' && (
            <form onSubmit={handlePinSubmit} className="space-y-4 py-1">
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-800">
                  চেয়ারম্যান/সচিব অফিশিয়াল মাস্টার সিকিউরিটি পিন (Master PIN)
                </label>
                <p className="text-[11px] text-slate-500">
                  ডিভাইসে বায়োমেট্রিক হার্ডওয়্যার অনুপস্থিত থাকলে অফিশিয়াল সিকিউরিটি পিন দিয়ে প্রবেশ করুন।
                </p>
              </div>

              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="password"
                  maxLength={8}
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="যেমন: 786021"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono tracking-widest text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-amber-300 font-extrabold text-xs rounded-2xl shadow transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4 text-amber-300" />
                <span>সিকিউরিটি পিন যাচাই করে প্রবেশ করুন</span>
              </button>
            </form>
          )}

          {/* Authorized Admin Directory List (Directory View) */}
          <div className="space-y-2 pt-2 border-t border-slate-200">
            <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex items-center justify-between">
              <span>অনুমোদিত এডমিন তালিকা (Firebase Directory)</span>
              <span className="text-[10px] text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded font-bold">
                {adminList.length} জন সক্রিয়
              </span>
            </h4>

            <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1 border border-slate-200 rounded-2xl p-2 bg-slate-50">
              {adminList.map((adm, idx) => (
                <div
                  key={idx}
                  className={`p-2 rounded-xl border text-xs flex items-center justify-between transition ${
                    adminRecord && adminRecord.email?.toLowerCase() === adm.email.toLowerCase()
                      ? 'bg-emerald-100/80 border-emerald-400 font-extrabold text-emerald-950'
                      : 'bg-white border-slate-200 text-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-6 h-6 rounded-lg bg-emerald-800 text-white font-bold flex items-center justify-center shrink-0 text-[11px]">
                      {adm.name ? adm.name[0] : 'A'}
                    </div>
                    <div className="min-w-0">
                      <p className="font-extrabold truncate text-xs">{adm.name}</p>
                      <p className="text-[10px] text-slate-500 truncate">{adm.email}</p>
                    </div>
                  </div>

                  <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-100 text-emerald-950 border border-amber-300 rounded-md shrink-0">
                    {adm.designation || adm.role}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-100 p-3 rounded-2xl border border-slate-200 text-[11px] text-slate-600 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>গুগল অথেন্টিকেশন ও WebAuthn বায়োমেট্রিক প্যাসকি লেয়ারের সমন্বয়ে সর্বোচ্চ নিরাপত্তা স্তর নিশ্চিত করা হয়েছে।</span>
          </div>

        </div>

      </div>

      {/* Biometric Secure Login Successful Notification Toast */}
      <BiometricAuthToast
        toast={biometricToast}
        onClose={() => setBiometricToast(null)}
      />
    </div>
  );
};
