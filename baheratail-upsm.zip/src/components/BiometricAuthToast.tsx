import React, { useEffect, useState } from 'react';
import {
  ShieldCheck,
  Fingerprint,
  Clock,
  CheckCircle2,
  X,
  Copy,
  Check,
  Sparkles,
  Laptop,
  KeyRound
} from 'lucide-react';

export interface BiometricToastData {
  id: string;
  title: string; // 'Secure Login Successful'
  subtitle?: string;
  timestamp: string; // Formatted date and time
  isoTimestamp: string;
  adminName: string;
  adminEmail: string;
  adminRole: string;
  adminDesignation?: string;
  authMethod: string;
  credentialId?: string;
  hardwareDevice?: string;
}

interface BiometricAuthToastProps {
  toast: BiometricToastData | null;
  onClose: () => void;
  duration?: number; // default 6000ms
}

export const BiometricAuthToast: React.FC<BiometricAuthToastProps> = ({
  toast,
  onClose,
  duration = 6000
}) => {
  const [copied, setCopied] = useState(false);
  const [progress, setProgress] = useState(100);

  useEffect(() => {
    if (!toast) return;

    setProgress(100);
    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remaining = Math.max(0, 100 - (elapsed / duration) * 100);
      setProgress(remaining);
      if (remaining <= 0) {
        clearInterval(interval);
        onClose();
      }
    }, 50);

    return () => clearInterval(interval);
  }, [toast, duration, onClose]);

  if (!toast) return null;

  const handleCopyDetails = () => {
    const details = `[Secure Login Successful]
Timestamp: ${toast.timestamp} (${toast.isoTimestamp})
Admin: ${toast.adminName} (${toast.adminEmail})
Role: ${toast.adminDesignation || toast.adminRole}
Method: ${toast.authMethod}
Device: ${toast.hardwareDevice || 'Biometric Authenticator'}
Credential ID: ${toast.credentialId || 'N/A'}`;

    navigator.clipboard.writeText(details).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(() => {
      // fallback
    });
  };

  return (
    <div
      id="biometric-auth-success-toast"
      role="alert"
      aria-live="assertive"
      className="fixed top-5 right-5 z-[9999] max-w-md w-[calc(100vw-2.5rem)] bg-slate-950/95 text-white rounded-3xl shadow-2xl border border-emerald-500/50 backdrop-blur-xl overflow-hidden animate-fade-in transition-all duration-300 pointer-events-auto"
    >
      {/* Top Animated Security Strip */}
      <div className="bg-gradient-to-r from-emerald-600 via-teal-500 to-emerald-700 h-1.5 w-full relative">
        <div
          className="h-full bg-amber-400 transition-all duration-100 ease-linear"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="p-4 sm:p-5 space-y-3.5">
        {/* Header: Title, Status Badge & Close Button */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400 shadow-inner shrink-0">
                <Fingerprint className="w-6 h-6 animate-pulse text-emerald-400" />
              </div>
              <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-slate-950 flex items-center justify-center">
                <Check className="w-2.5 h-2.5 text-slate-950 stroke-[3]" />
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h4 className="text-sm sm:text-base font-black text-white tracking-tight flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>{toast.title}</span>
                </h4>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full text-[10px] font-extrabold uppercase tracking-wider">
                  Verified
                </span>
              </div>
              <p className="text-xs text-emerald-200/90 font-medium">
                {toast.subtitle || 'বায়োমেট্রিক ও WebAuthn প্যাসকি নিরাপত্তা যাচাই সফল'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close notification"
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-xl transition cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Timestamp Highlight Box */}
        <div className="bg-slate-900/90 rounded-2xl p-3 border border-slate-800 space-y-1.5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1.5 font-bold text-slate-300 text-[11px]">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>লগইন টাইমস্ট্যাম্প (Timestamp):</span>
            </span>
            <button
              type="button"
              onClick={handleCopyDetails}
              className="text-[10px] font-bold text-amber-400 hover:text-amber-300 transition flex items-center gap-1 cursor-pointer"
              title="টাইমস্ট্যাম্প ও লগইন বিবরণ কপি করুন"
            >
              {copied ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span className="text-emerald-400">কপি হয়েছে</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3 text-amber-400" />
                  <span>কপি করুন</span>
                </>
              )}
            </button>
          </div>

          <div className="font-mono text-xs sm:text-sm font-extrabold text-amber-300 tracking-wide select-all bg-slate-950/60 px-2.5 py-1.5 rounded-xl border border-slate-800/80 flex items-center justify-between gap-2">
            <span>{toast.timestamp}</span>
            <span className="text-[10px] text-slate-400 font-sans hidden sm:inline">
              ISO: {toast.isoTimestamp.split('T')[1]?.split('.')[0] || ''}
            </span>
          </div>
        </div>

        {/* Authenticated Admin & Hardware Metadata */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="bg-slate-900/60 rounded-xl p-2.5 border border-slate-800/80 space-y-0.5">
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">এডমিন ব্যবহারকারী</p>
            <p className="font-black text-white text-xs truncate">{toast.adminName}</p>
            <p className="text-[10px] text-emerald-400 truncate">{toast.adminDesignation || toast.adminRole}</p>
          </div>

          <div className="bg-slate-900/60 rounded-xl p-2.5 border border-slate-800/80 space-y-0.5">
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">ভেরিফিকেশন মেথড</p>
            <p className="font-black text-amber-300 text-xs truncate flex items-center gap-1">
              <Laptop className="w-3 h-3 text-amber-400 shrink-0" />
              <span className="truncate">{toast.authMethod}</span>
            </p>
            <p className="text-[10px] text-slate-400 truncate font-mono">
              {toast.credentialId ? `ID: ${toast.credentialId.slice(0, 10)}...` : 'FIDO2 / Biometric'}
            </p>
          </div>
        </div>

        {/* Bottom Verification Footer */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-[10px] text-slate-400">
          <span className="flex items-center gap-1 text-emerald-400 font-bold">
            <Sparkles className="w-3 h-3 text-emerald-400" />
            <span>সেশন সিকিউরিটি এলিভেশন সক্রিয়</span>
          </span>
          <span className="text-slate-400 font-mono">
            {toast.adminEmail}
          </span>
        </div>
      </div>
    </div>
  );
};
