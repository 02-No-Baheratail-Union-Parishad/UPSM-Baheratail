import React, { useState, useEffect, useMemo } from 'react';
import {
  Fingerprint,
  ShieldCheck,
  Clock,
  Laptop,
  Smartphone,
  Tablet,
  Search,
  Filter,
  Download,
  Trash2,
  RefreshCw,
  Eye,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  ArrowUpDown,
  FileSpreadsheet,
  FileCode,
  Sparkles,
  Shield,
  KeyRound,
  Sliders,
  X,
  User,
  Monitor,
  Activity
} from 'lucide-react';
import { BiometricLoginEventRecord } from '../types';
import {
  getBiometricLoginEvents,
  deleteBiometricLoginEvent,
  clearAllBiometricLoginEvents,
  exportBiometricEventsToCSV,
  exportBiometricEventsToJSON,
  recordBiometricLoginEvent
} from '../services/biometricEventTracker';

interface BiometricLoginEventsTabProps {
  currentUserEmail?: string;
  currentUserName?: string;
  currentUserRole?: string;
}

export const BiometricLoginEventsTab: React.FC<BiometricLoginEventsTabProps> = ({
  currentUserEmail,
  currentUserName,
  currentUserRole
}) => {
  const [events, setEvents] = useState<BiometricLoginEventRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [roleFilter, setRoleFilter] = useState<string>('ALL');
  const [platformFilter, setPlatformFilter] = useState<string>('ALL');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc'); // default chronologically newest first
  const [selectedEvent, setSelectedEvent] = useState<BiometricLoginEventRecord | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load events
  const loadEvents = () => {
    setIsLoading(true);
    try {
      const data = getBiometricLoginEvents();
      setEvents(data);
    } catch (err) {
      console.warn('Error loading biometric login events:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadEvents();

    const handleNewEvent = () => {
      loadEvents();
    };

    window.addEventListener('biometric-login-recorded', handleNewEvent);
    return () => {
      window.removeEventListener('biometric-login-recorded', handleNewEvent);
    };
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Copy helper
  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  // Delete event
  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('আপনি কি এই বায়োমেট্রিক লগইন রেকর্ডটি মুছে ফেলতে চান?')) {
      deleteBiometricLoginEvent(id);
      loadEvents();
      showToast('বায়োমেট্রিক ইভেন্ট সফলভাবে মুছে ফেলা হয়েছে।');
      if (selectedEvent?.id === id) setSelectedEvent(null);
    }
  };

  // Clear all
  const handleClearAll = () => {
    if (window.confirm('সতর্কতা: আপনি কি নিশ্চিত যে সমস্ত বায়োমেট্রিক লগইন হিস্টোরি মুছে ফেলবেন?')) {
      clearAllBiometricLoginEvents();
      loadEvents();
      showToast('সমস্ত বায়োমেট্রিক লগইন হিস্টোরি রিসেট করা হয়েছে।');
    }
  };

  // Filtered & Chronologically Sorted Events
  const filteredEvents = useMemo(() => {
    let result = [...events];

    if (roleFilter !== 'ALL') {
      result = result.filter(e => e.adminRole.toLowerCase() === roleFilter.toLowerCase());
    }

    if (platformFilter !== 'ALL') {
      result = result.filter(e => e.deviceInfo.platform.toLowerCase().includes(platformFilter.toLowerCase()));
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(e =>
        e.adminName.toLowerCase().includes(q) ||
        e.adminEmail.toLowerCase().includes(q) ||
        e.authMethod.toLowerCase().includes(q) ||
        e.deviceInfo.deviceName.toLowerCase().includes(q) ||
        e.deviceInfo.platform.toLowerCase().includes(q) ||
        e.deviceInfo.browser.toLowerCase().includes(q) ||
        (e.deviceInfo.credentialId && e.deviceInfo.credentialId.toLowerCase().includes(q))
      );
    }

    // Chronological Sort
    result.sort((a, b) => {
      const timeA = new Date(a.timestamp).getTime();
      const timeB = new Date(b.timestamp).getTime();
      return sortOrder === 'desc' ? timeB - timeA : timeA - timeB;
    });

    return result;
  }, [events, roleFilter, platformFilter, searchQuery, sortOrder]);

  // Statistics calculation
  const stats = useMemo(() => {
    const total = events.length;
    const uniqueDevices = new Set(events.map(e => e.deviceInfo.deviceName)).size;
    const desktopCount = events.filter(e => e.deviceInfo.deviceType === 'desktop').length;
    const mobileCount = events.filter(e => e.deviceInfo.deviceType === 'mobile' || e.deviceInfo.deviceType === 'tablet').length;
    const latestEvent = events.length > 0 ? events[0] : null;

    return {
      total,
      uniqueDevices,
      desktopCount,
      mobileCount,
      latestEvent
    };
  }, [events]);

  // Helper to format relative time
  const getRelativeTime = (isoString: string): string => {
    try {
      const diffMs = Date.now() - new Date(isoString).getTime();
      const diffMins = Math.floor(diffMs / (1000 * 60));
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      const toBn = (n: number) => {
        const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
        return String(n).split('').map(d => bnDigits[parseInt(d, 10)] || d).join('');
      };

      if (diffMins < 1) return 'এইমাত্র';
      if (diffMins < 60) return `${toBn(diffMins)} মিনিট আগে`;
      if (diffHours < 24) return `${toBn(diffHours)} ঘণ্টা আগে`;
      return `${toBn(diffDays)} দিন আগে`;
    } catch {
      return '';
    }
  };

  const getDeviceIcon = (deviceType: string) => {
    switch (deviceType) {
      case 'mobile':
        return <Smartphone className="w-4 h-4 text-emerald-600" />;
      case 'tablet':
        return <Tablet className="w-4 h-4 text-indigo-600" />;
      default:
        return <Laptop className="w-4 h-4 text-amber-600" />;
    }
  };

  return (
    <div id="biometric-login-events-tab" className="space-y-6 animate-fade-in">
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-emerald-950 to-slate-900 text-white p-6 md:p-8 rounded-3xl shadow-xl border border-emerald-800/60 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 rounded-full text-xs font-black uppercase tracking-wider">
              <Fingerprint className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span>WebAuthn & Biometric Security Audit Trail</span>
            </div>

            <h2 className="text-2xl md:text-3xl font-black text-white tracking-tight flex items-center gap-3">
              <span>বায়োমেট্রিক সফল লগইন ইভেন্টস ট্রেইল</span>
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-400 text-emerald-950">
                {events.length} টি ইভেন্ট
              </span>
            </h2>

            <p className="text-xs md:text-sm text-emerald-100/90 max-w-2xl leading-relaxed">
              সিস্টেমে টাচ আইডি (Touch ID), ফেস আইডি (Face ID), উইন্ডোজ হ্যালো (Windows Hello) ও এফআইডিও২ (FIDO2) প্যাসকির মাধ্যমে সফল হওয়া সকল এডমিন লগইন ইভেন্ট সময়ানুক্রমিক (Chronologically Sorted) ও হার্ডওয়্যার বিবরণসহ সংরক্ষিত।
            </p>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={() => exportBiometricEventsToCSV(filteredEvents)}
              className="px-4 py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl border border-emerald-600/70 shadow transition flex items-center gap-2 cursor-pointer active:scale-95"
              title="CSV ফাইলে ডাউনলোড করুন"
            >
              <FileSpreadsheet className="w-4 h-4 text-amber-300" />
              <span>CSV রপ্তানি</span>
            </button>

            <button
              onClick={() => exportBiometricEventsToJSON(filteredEvents)}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 shadow transition flex items-center gap-2 cursor-pointer active:scale-95"
              title="JSON ডাটা এক্সপোর্ট করুন"
            >
              <FileCode className="w-4 h-4 text-emerald-400" />
              <span>JSON এক্সপোর্ট</span>
            </button>

            <button
              onClick={loadEvents}
              className="p-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl border border-white/20 transition cursor-pointer active:scale-95"
              title="রিফ্রেশ করুন"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="bg-emerald-900 text-white px-4 py-3 rounded-2xl shadow-lg border border-emerald-700 flex items-center justify-between text-xs font-bold animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-amber-400" />
            <span>{toastMessage}</span>
          </div>
          <button onClick={() => setToastMessage(null)} className="text-emerald-300 hover:text-white cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 2. Top Summary Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-100 text-emerald-800 rounded-2xl font-black">
            <Fingerprint className="w-6 h-6 text-emerald-700" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500">মোট সফল বায়োমেট্রিক লগইন</p>
            <h3 className="text-2xl font-black text-slate-900">{stats.total} বার</h3>
            <p className="text-[10px] text-emerald-700 font-bold">WebAuthn Verified Sessions</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-indigo-100 text-indigo-800 rounded-2xl font-black">
            <Laptop className="w-6 h-6 text-indigo-700" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500">নিবন্ধিত ইউনিক ডিভাইস</p>
            <h3 className="text-2xl font-black text-slate-900">{stats.uniqueDevices} টি</h3>
            <p className="text-[10px] text-indigo-700 font-bold">Touch ID / Windows Hello</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-100 text-amber-800 rounded-2xl font-black">
            <Monitor className="w-6 h-6 text-amber-700" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500">ডিভাইস ধরন বিভাজন</p>
            <h3 className="text-lg font-black text-slate-900">
              {stats.desktopCount} ডেক্সটপ / {stats.mobileCount} মোবাইল
            </h3>
            <p className="text-[10px] text-amber-700 font-bold">Platform Sensor Breakdown</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-teal-100 text-teal-800 rounded-2xl font-black">
            <Clock className="w-6 h-6 text-teal-700" />
          </div>
          <div className="min-w-0">
            <p className="text-xs font-bold text-slate-500">সর্বশেষ সফল বায়োমেট্রিক</p>
            <h3 className="text-sm font-black text-slate-900 truncate">
              {stats.latestEvent ? stats.latestEvent.adminName : 'কোনো ইভেন্ট নেই'}
            </h3>
            <p className="text-[10px] text-teal-700 font-bold truncate">
              {stats.latestEvent ? getRelativeTime(stats.latestEvent.timestamp) : '—'}
            </p>
          </div>
        </div>
      </div>

      {/* 3. Search, Filter & Sort Controls */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {/* Search Box */}
          <div className="md:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="এডমিন নাম, ইমেইল, ডিভাইস নাম, ব্রাউজার বা ক্রেডেনশিয়াল আইডি দিয়ে খুঁজুন..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Role Filter */}
          <div>
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="w-full py-2.5 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              <option value="ALL">সকল এডমিন রোল (All Roles)</option>
              <option value="super_admin">সুপার এডমিন (Super Admin)</option>
              <option value="chairman">ইউপি চেয়ারম্যান (Chairman)</option>
              <option value="secretary">ইউপি সচিব (Secretary)</option>
              <option value="member">ইউপি সদস্য (Member)</option>
              <option value="developer">সিস্টেম ডেভেলপার (Developer)</option>
            </select>
          </div>

          {/* Platform Filter */}
          <div>
            <select
              value={platformFilter}
              onChange={(e) => setPlatformFilter(e.target.value)}
              className="w-full py-2.5 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              <option value="ALL">সকল প্ল্যাটফর্ম (All OS/Platforms)</option>
              <option value="macOS">Apple macOS (Touch ID)</option>
              <option value="Windows">Microsoft Windows (Hello)</option>
              <option value="Android">Google Android (Fingerprint)</option>
              <option value="iOS">Apple iOS (iPhone/iPad)</option>
            </select>
          </div>
        </div>

        {/* Sort and Count Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700">প্রদর্শিত ইভেন্ট:</span>
            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 font-black rounded-md text-[11px]">
              {filteredEvents.length} টি
            </span>
            {(searchQuery || roleFilter !== 'ALL' || platformFilter !== 'ALL') && (
              <span className="text-slate-400 text-[11px]">
                (ফিল্টারকৃত)
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setSortOrder(prev => prev === 'desc' ? 'asc' : 'desc')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-extrabold rounded-lg transition cursor-pointer"
            >
              <ArrowUpDown className="w-3.5 h-3.5 text-emerald-700" />
              <span>
                সাজানো ক্রম: {sortOrder === 'desc' ? 'নতুন হতে পুরাতন (Newest First)' : 'পুরাতন হতে নতুন (Oldest First)'}
              </span>
            </button>

            {events.length > 0 && (
              <button
                onClick={handleClearAll}
                className="text-[11px] text-rose-600 hover:text-rose-800 font-bold flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
                <span>লগ পরিষ্কার করুন</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 4. Chronological Events Timeline / List */}
      {filteredEvents.length === 0 ? (
        <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-4 shadow-sm">
          <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
            <Fingerprint className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-extrabold text-slate-800">কোনো বায়োমেট্রিক লগইন ইভেন্ট পাওয়া যায়নি</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              খোঁজার ফিল্টারে কোনো ফলাফল মিলেনি অথবা এখনো কোনো বায়োমেট্রিক যাচাই সম্পন্ন হয়নি।
            </p>
          </div>
          <button
            onClick={() => {
              setSearchQuery('');
              setRoleFilter('ALL');
              setPlatformFilter('ALL');
            }}
            className="px-4 py-2 bg-slate-800 text-white text-xs font-bold rounded-xl hover:bg-slate-700 cursor-pointer"
          >
            ফিল্টার রিসেট করুন
          </button>
        </div>
      ) : (
        <div className="space-y-3.5">
          {filteredEvents.map((evt, idx) => {
            const isLatest = idx === 0 && sortOrder === 'desc';
            return (
              <div
                key={evt.id}
                onClick={() => setSelectedEvent(evt)}
                className={`bg-white rounded-2xl border transition-all duration-200 p-4 sm:p-5 shadow-xs hover:shadow-md cursor-pointer relative overflow-hidden group ${
                  isLatest
                    ? 'border-emerald-500/80 ring-2 ring-emerald-500/20 bg-gradient-to-r from-emerald-50/30 to-white'
                    : 'border-slate-200 hover:border-emerald-400'
                }`}
              >
                {/* Accent Status Left Bar */}
                <div
                  className={`absolute left-0 top-0 bottom-0 w-1.5 ${
                    evt.status === 'SUCCESS' ? 'bg-emerald-600' : 'bg-amber-500'
                  }`}
                />

                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Left Column: Admin Info & Fingerprint Badge */}
                  <div className="flex items-start gap-3.5 min-w-0">
                    <div className="relative shrink-0">
                      <div className="w-12 h-12 rounded-2xl bg-emerald-100 border border-emerald-300 text-emerald-800 flex items-center justify-center font-black shadow-xs group-hover:scale-105 transition-transform">
                        <Fingerprint className="w-6 h-6 text-emerald-700" />
                      </div>
                      <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-600 rounded-full border-2 border-white flex items-center justify-center">
                        <Check className="w-2.5 h-2.5 text-white stroke-[3]" />
                      </span>
                    </div>

                    <div className="min-w-0 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm font-black text-slate-900 tracking-tight">
                          {evt.adminName}
                        </h4>
                        <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-full text-[10px] font-black uppercase">
                          {evt.adminDesignation || evt.adminRole}
                        </span>
                        {isLatest && (
                          <span className="px-2 py-0.5 bg-amber-400 text-emerald-950 rounded-full text-[10px] font-black uppercase flex items-center gap-1 shadow-2xs">
                            <Sparkles className="w-3 h-3 text-emerald-950" />
                            <span>সর্বশেষ লগইন (Latest)</span>
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-500 font-mono truncate">{evt.adminEmail}</p>

                      <div className="flex items-center gap-2 pt-0.5 flex-wrap">
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200/80">
                          <ShieldCheck className="w-3 h-3 text-amber-600" />
                          <span>{evt.authMethod}</span>
                        </span>
                        <span className="text-[11px] text-slate-500 font-medium">
                          প্রসঙ্গ: {evt.context || 'এডমিন পোর্টাল'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Middle Column: Hardware & Device Info */}
                  <div className="bg-slate-50/90 rounded-xl p-3 border border-slate-200/80 space-y-1 lg:max-w-xs w-full">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold text-slate-700 flex items-center gap-1.5">
                        {getDeviceIcon(evt.deviceInfo.deviceType)}
                        <span className="truncate">{evt.deviceInfo.platform}</span>
                      </span>
                      <span className="text-[10px] px-1.5 py-0.5 bg-white rounded border border-slate-200 font-semibold text-slate-600">
                        {evt.deviceInfo.browser}
                      </span>
                    </div>

                    <p className="text-xs font-extrabold text-slate-800 truncate" title={evt.deviceInfo.deviceName}>
                      {evt.deviceInfo.deviceName}
                    </p>

                    <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono pt-0.5">
                      <span>স্ক্রিন: {evt.deviceInfo.screenResolution || '1920x1080'}</span>
                      {evt.deviceInfo.credentialId && (
                        <span className="text-emerald-700 font-bold">
                          ID: {evt.deviceInfo.credentialId.slice(0, 10)}...
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Right Column: Precise Timestamp & Action Controls */}
                  <div className="flex lg:flex-col items-center lg:items-end justify-between gap-2 shrink-0">
                    <div className="text-left lg:text-right space-y-0.5">
                      <div className="inline-flex items-center gap-1 text-xs font-black text-slate-900 bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200">
                        <Clock className="w-3.5 h-3.5 text-amber-600" />
                        <span>{getRelativeTime(evt.timestamp)}</span>
                      </div>
                      <p className="text-[11px] text-slate-600 font-semibold max-w-[220px] lg:max-w-none">
                        {evt.formattedTimestamp}
                      </p>
                      <p className="text-[10px] text-slate-400 font-mono">
                        ISO: {evt.timestamp.split('T')[1]?.split('.')[0] || ''}
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedEvent(evt);
                        }}
                        className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold rounded-lg border border-emerald-200 transition flex items-center gap-1 cursor-pointer"
                        title="সম্পূর্ণ বিবরণ দেখুন"
                      >
                        <Eye className="w-3.5 h-3.5 text-emerald-700" />
                        <span>বিবরণ</span>
                      </button>

                      <button
                        type="button"
                        onClick={(e) => handleDelete(evt.id, e)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                        title="এই রেকর্ডটি মুছুন"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 5. Detailed Event Inspection Modal */}
      {selectedEvent && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in"
          onClick={() => setSelectedEvent(null)}
        >
          <div
            className="bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 md:p-7 space-y-5 animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 border border-emerald-300 flex items-center justify-center text-emerald-800 shadow-sm shrink-0">
                  <Fingerprint className="w-7 h-7 text-emerald-700" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-black text-slate-900 text-base md:text-lg">
                      বায়োমেট্রিক অথেন্টিকেশন ইভেন্ট বিবরণ
                    </h3>
                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-black rounded-full uppercase">
                      Verified FIDO2
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-mono">Event ID: {selectedEvent.id}</p>
                </div>
              </div>

              <button
                onClick={() => setSelectedEvent(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Timestamp Banner */}
            <div className="bg-slate-900 text-white p-4 rounded-2xl space-y-1.5 border border-slate-800">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1.5 text-amber-400 font-bold">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span>সফল লগইন টাইমস্ট্যাম্প (Timestamp)</span>
                </span>
                <button
                  onClick={() => handleCopy(selectedEvent.formattedTimestamp, selectedEvent.id)}
                  className="text-[11px] text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 cursor-pointer"
                >
                  {copiedId === selectedEvent.id ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">কপি হয়েছে</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-amber-400" />
                      <span>কপি করুন</span>
                    </>
                  )}
                </button>
              </div>
              <p className="font-mono text-sm md:text-base font-extrabold text-amber-300">
                {selectedEvent.formattedTimestamp}
              </p>
              <p className="text-[11px] text-slate-400 font-mono">
                ISO 8601: {selectedEvent.timestamp} ({getRelativeTime(selectedEvent.timestamp)})
              </p>
            </div>

            {/* Admin User Profile Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 text-xs">
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1">
                <p className="text-[10px] text-slate-400 font-bold uppercase">এডমিন ব্যবহারকারী</p>
                <p className="font-black text-slate-900 text-sm">{selectedEvent.adminName}</p>
                <p className="text-slate-600 font-mono text-[11px]">{selectedEvent.adminEmail}</p>
                <p className="text-[11px] text-emerald-700 font-bold pt-1">
                  পদবী: {selectedEvent.adminDesignation || selectedEvent.adminRole}
                </p>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1">
                <p className="text-[10px] text-slate-400 font-bold uppercase">যাচাইকরণ মেথড ও স্থিতি</p>
                <p className="font-black text-slate-900 text-sm flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>{selectedEvent.authMethod}</span>
                </p>
                <p className="text-slate-600 text-[11px]">প্রসঙ্গ: {selectedEvent.context || 'Admin Portal'}</p>
                <p className="text-[11px] text-slate-500 font-mono pt-1">
                  চেকসাম: {selectedEvent.checksum || 'SHA256-OK'}
                </p>
              </div>
            </div>

            {/* Hardware and Device Metadata */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3 text-xs">
              <h4 className="font-extrabold text-slate-900 flex items-center gap-2 text-xs">
                <Laptop className="w-4 h-4 text-emerald-700" />
                <span>ডিভাইস ও প্ল্যাটফর্ম হার্ডওয়্যার ডায়াগনস্টিকস</span>
              </h4>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-2.5 text-[11px]">
                <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                  <span className="text-slate-400 text-[10px] block">ডিভাইস নাম</span>
                  <span className="font-black text-slate-800 truncate block">
                    {selectedEvent.deviceInfo.deviceName}
                  </span>
                </div>

                <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                  <span className="text-slate-400 text-[10px] block">অপারেটিং সিস্টেম (OS)</span>
                  <span className="font-black text-slate-800 block">{selectedEvent.deviceInfo.platform}</span>
                </div>

                <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                  <span className="text-slate-400 text-[10px] block">ওয়েব ব্রাউজার</span>
                  <span className="font-black text-slate-800 block">{selectedEvent.deviceInfo.browser}</span>
                </div>

                <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                  <span className="text-slate-400 text-[10px] block">বায়োমেট্রিক সেন্সর টাইপ</span>
                  <span className="font-bold text-emerald-700 block truncate">
                    {selectedEvent.deviceInfo.authenticatorType}
                  </span>
                </div>

                <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                  <span className="text-slate-400 text-[10px] block">স্ক্রিন রেজোলিউশন</span>
                  <span className="font-mono font-bold text-slate-700 block">
                    {selectedEvent.deviceInfo.screenResolution || '1920x1080'}
                  </span>
                </div>

                <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                  <span className="text-slate-400 text-[10px] block">টাচ স্ক্রিন সাপোর্ট</span>
                  <span className="font-bold text-slate-700 block">
                    {selectedEvent.deviceInfo.touchSupport ? 'হ্যাঁ (Touch Active)' : 'না (Workstation)'}
                  </span>
                </div>
              </div>

              {selectedEvent.deviceInfo.credentialId && (
                <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                  <span className="text-slate-400 text-[10px] block font-bold">FIDO2 Credential ID</span>
                  <p className="font-mono text-[11px] text-slate-800 break-all select-all">
                    {selectedEvent.deviceInfo.credentialId}
                  </p>
                </div>
              )}

              {selectedEvent.deviceInfo.userAgent && (
                <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1">
                  <span className="text-slate-400 text-[10px] block font-bold">User Agent String</span>
                  <p className="font-mono text-[10px] text-slate-600 break-all select-all leading-relaxed">
                    {selectedEvent.deviceInfo.userAgent}
                  </p>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setSelectedEvent(null)}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition cursor-pointer"
              >
                বন্ধ করুন (Close)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
