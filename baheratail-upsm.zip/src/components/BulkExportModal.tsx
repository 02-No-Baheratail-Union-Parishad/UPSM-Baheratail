import React, { useState, useMemo } from 'react';
import {
  Download,
  FileSpreadsheet,
  FileText,
  Copy,
  Check,
  X,
  Filter,
  Layers,
  Sparkles,
  Table as TableIcon,
  HelpCircle,
  ExternalLink,
  ChevronRight,
  Database,
  ArrowRight
} from 'lucide-react';
import {
  bulkExportService,
  CITIZEN_EXPORT_COLUMNS,
  CERTIFICATE_EXPORT_COLUMNS,
  ExportFormat,
  BulkExportOptions
} from '../services/BulkExportService';
import { CitizenAccountRecord, CertificateRecord, UnionParishadConfig } from '../types';

interface BulkExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'citizens' | 'certificates';
  data: CitizenAccountRecord[] | CertificateRecord[];
  allData?: CitizenAccountRecord[] | CertificateRecord[];
  config: UnionParishadConfig;
  initialFiltersSummary?: string;
}

export const BulkExportModal: React.FC<BulkExportModalProps> = ({
  isOpen,
  onClose,
  mode,
  data,
  allData,
  config,
  initialFiltersSummary
}) => {
  if (!isOpen) return null;

  const isCitizens = mode === 'citizens';
  const availableColumns = isCitizens ? CITIZEN_EXPORT_COLUMNS : CERTIFICATE_EXPORT_COLUMNS;

  // Selected Scope: 'filtered' (current filtered view) or 'all' (entire database)
  const [exportScope, setExportScope] = useState<'filtered' | 'all'>('filtered');
  
  // Selected Export Format
  const [selectedFormat, setSelectedFormat] = useState<ExportFormat>('csv');

  // Selected Columns
  const [selectedColumnKeys, setSelectedColumnKeys] = useState<string[]>(() =>
    availableColumns.filter((c) => c.defaultSelected).map((c) => c.key)
  );

  // Active Tab: 'export' | 'columns' | 'preview' | 'instructions'
  const [activeTab, setActiveTab] = useState<'export' | 'columns' | 'preview' | 'instructions'>('export');

  // Copy success feedback state
  const [copied, setCopied] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  // Target records based on scope
  const targetRecords = useMemo(() => {
    if (exportScope === 'all' && allData && allData.length > 0) {
      return allData;
    }
    return data;
  }, [exportScope, data, allData]);

  // Handle Select All / Deselect All Columns
  const handleSelectAllColumns = () => {
    setSelectedColumnKeys(availableColumns.map((c) => c.key));
  };

  const handleSelectDefaultColumns = () => {
    setSelectedColumnKeys(availableColumns.filter((c) => c.defaultSelected).map((c) => c.key));
  };

  const handleToggleColumn = (key: string) => {
    setSelectedColumnKeys((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  // Execute Export
  const handleTriggerExport = async () => {
    setIsExporting(true);
    try {
      const options: BulkExportOptions = {
        selectedColumns: selectedColumnKeys,
        config
      };

      if (isCitizens) {
        const citizensList = targetRecords as CitizenAccountRecord[];
        if (selectedFormat === 'csv') {
          bulkExportService.exportCitizensToCsvFile(citizensList, config, options);
        } else if (selectedFormat === 'tsv') {
          bulkExportService.exportCitizensToTsvFile(citizensList, config, options);
        } else if (selectedFormat === 'json') {
          bulkExportService.exportCitizensToJsonFile(citizensList, config, options);
        } else if (selectedFormat === 'google-sheets-clipboard') {
          const success = await bulkExportService.copyCitizensForGoogleSheets(citizensList, config, options);
          if (success) {
            setCopied(true);
            setTimeout(() => setCopied(false), 3000);
          }
        }
      } else {
        const certsList = targetRecords as CertificateRecord[];
        if (selectedFormat === 'csv') {
          bulkExportService.exportCertificatesToCsvFile(certsList, config, options);
        } else if (selectedFormat === 'tsv') {
          bulkExportService.exportCertificatesToTsvFile(certsList, config, options);
        } else if (selectedFormat === 'json') {
          bulkExportService.exportCertificatesToJsonFile(certsList, config, options);
        } else if (selectedFormat === 'google-sheets-clipboard') {
          const success = await bulkExportService.copyCertificatesForGoogleSheets(certsList, config, options);
          if (success) {
            setCopied(true);
            setTimeout(() => setCopied(false), 3000);
          }
        }
      }
    } catch (err) {
      console.error('Export error:', err);
      alert('এক্সপোর্ট প্রক্রিয়াটিতে ত্রুটি হয়েছে।');
    } finally {
      setIsExporting(false);
    }
  };

  // Preview data (First 5 records with selected columns)
  const previewData = useMemo(() => {
    const records = targetRecords.slice(0, 5);
    const activeCols = availableColumns.filter((c) => selectedColumnKeys.includes(c.key));

    return {
      headers: activeCols.map((c) => c.label),
      rows: records.map((r, idx) =>
        activeCols.map((col) => String(col.accessor(r as any, idx, config)))
      )
    };
  }, [targetRecords, availableColumns, selectedColumnKeys, config]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6 flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 text-white p-5 sm:p-6 flex items-center justify-between shrink-0 border-b border-emerald-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 p-0.5 shadow-lg flex items-center justify-center">
              <div className="w-full h-full bg-slate-900 rounded-[14px] flex items-center justify-center">
                <FileSpreadsheet className="w-6 h-6 text-emerald-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black text-white">
                  {isCitizens ? 'নাগরিক মাস্টার রেজিস্টার বাল্ক এক্সপোর্ট' : 'প্রত্যয়নপত্র রেজিস্টার ও লগ বাল্ক এক্সপোর্ট'}
                </h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-400/30">
                  Bulk Export Engine v4.2
                </span>
              </div>
              <p className="text-xs text-slate-300">
                {config.upName} — মাইক্রোসফট এক্সেল ও গুগল শিট সামঞ্জস্যপূর্ণ ফরম্যাটে এক্সপোর্ট
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
            aria-label="বন্ধ করুন"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex items-center gap-1 px-6 pt-3 bg-slate-100/80 border-b border-slate-200 text-xs font-bold overflow-x-auto shrink-0">
          <button
            onClick={() => setActiveTab('export')}
            className={`px-4 py-2.5 rounded-t-xl border-b-2 flex items-center gap-2 transition cursor-pointer whitespace-nowrap ${
              activeTab === 'export'
                ? 'bg-white text-emerald-900 border-emerald-600 font-black shadow-sm'
                : 'text-slate-600 hover:text-slate-900 border-transparent'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>১. ফরম্যাট ও এক্সপোর্ট</span>
          </button>

          <button
            onClick={() => setActiveTab('columns')}
            className={`px-4 py-2.5 rounded-t-xl border-b-2 flex items-center gap-2 transition cursor-pointer whitespace-nowrap ${
              activeTab === 'columns'
                ? 'bg-white text-emerald-900 border-emerald-600 font-black shadow-sm'
                : 'text-slate-600 hover:text-slate-900 border-transparent'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>২. কলাম কাস্টমাইজেশন ({selectedColumnKeys.length}/{availableColumns.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('preview')}
            className={`px-4 py-2.5 rounded-t-xl border-b-2 flex items-center gap-2 transition cursor-pointer whitespace-nowrap ${
              activeTab === 'preview'
                ? 'bg-white text-emerald-900 border-emerald-600 font-black shadow-sm'
                : 'text-slate-600 hover:text-slate-900 border-transparent'
            }`}
          >
            <TableIcon className="w-3.5 h-3.5" />
            <span>৩. লাইভ প্রিভিউ ({targetRecords.length} টি রেকর্ড)</span>
          </button>

          <button
            onClick={() => setActiveTab('instructions')}
            className={`px-4 py-2.5 rounded-t-xl border-b-2 flex items-center gap-2 transition cursor-pointer whitespace-nowrap ${
              activeTab === 'instructions'
                ? 'bg-white text-emerald-900 border-emerald-600 font-black shadow-sm'
                : 'text-slate-600 hover:text-slate-900 border-transparent'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>গুগল শিট গাইড</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: FORMAT & EXPORT */}
          {activeTab === 'export' && (
            <div className="space-y-6">
              {/* Record Scope Selector */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <label className="block text-xs font-extrabold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-700" />
                  <span>এক্সপোর্টের আওতা (Record Scope)</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setExportScope('filtered')}
                    className={`p-3.5 rounded-xl border text-left flex items-start justify-between gap-3 transition cursor-pointer ${
                      exportScope === 'filtered'
                        ? 'bg-emerald-50/80 border-emerald-600 shadow-sm ring-2 ring-emerald-500/20'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                        <span>বর্তমান ফিল্টারকৃত তালিকা</span>
                        <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 rounded-md text-[10px] font-black">
                          {data.length} টি
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">
                        {initialFiltersSummary || 'স্ক্রিনে প্রদর্শিত বর্তমান সার্চ ও ওয়ার্ড ফিল্টারের রেকর্ডসমূহ'}
                      </p>
                    </div>
                    {exportScope === 'filtered' && <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />}
                  </button>

                  <button
                    type="button"
                    onClick={() => setExportScope('all')}
                    disabled={!allData || allData.length === 0}
                    className={`p-3.5 rounded-xl border text-left flex items-start justify-between gap-3 transition cursor-pointer ${
                      exportScope === 'all'
                        ? 'bg-emerald-50/80 border-emerald-600 shadow-sm ring-2 ring-emerald-500/20'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    } ${!allData || allData.length === 0 ? 'opacity-60 cursor-not-allowed' : ''}`}
                  >
                    <div>
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                        <span>ডাটাবেসের সম্পূর্ণ রেজিস্টার</span>
                        <span className="px-2 py-0.5 bg-slate-200 text-slate-800 rounded-md text-[10px] font-black">
                          {allData?.length || data.length} টি
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">
                        ফিল্টার নির্বিশেষে সকল ওয়ার্ড ও ক্যাটাগরির সমস্ত সংরক্ষিত রেকর্ড
                      </p>
                    </div>
                    {exportScope === 'all' && <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />}
                  </button>
                </div>
              </div>

              {/* Format Options Grid */}
              <div>
                <label className="block text-xs font-extrabold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
                  <span>এক্সপোর্ট ফরম্যাট নির্বাচন করুন</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* CSV Option */}
                  <div
                    onClick={() => setSelectedFormat('csv')}
                    className={`p-4 rounded-2xl border cursor-pointer transition flex flex-col justify-between ${
                      selectedFormat === 'csv'
                        ? 'bg-emerald-50/60 border-emerald-600 shadow-md ring-2 ring-emerald-500/20'
                        : 'bg-white border-slate-200 hover:border-emerald-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">
                          CSV
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-slate-900">ফরম্যাটেড CSV (Excel / Sheets)</h4>
                          <span className="text-[10px] text-emerald-700 font-semibold">UTF-8 BOM সহ বাংলা অক্ষরের নিখুঁত সাপোর্ট</span>
                        </div>
                      </div>
                      {selectedFormat === 'csv' && <Check className="w-4 h-4 text-emerald-600" />}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-2">
                      সরাসরি Microsoft Excel, LibreOffice বা Google Sheets-এ ওপেন বা ইমপোর্ট করার জন্য সেরা।
                    </p>
                  </div>

                  {/* Google Sheets Clipboard TSV */}
                  <div
                    onClick={() => setSelectedFormat('google-sheets-clipboard')}
                    className={`p-4 rounded-2xl border cursor-pointer transition flex flex-col justify-between ${
                      selectedFormat === 'google-sheets-clipboard'
                        ? 'bg-emerald-50/60 border-emerald-600 shadow-md ring-2 ring-emerald-500/20'
                        : 'bg-white border-slate-200 hover:border-emerald-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs">
                          <Copy className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-slate-900">Google Sheets কপি ফরম্যাট (TSV)</h4>
                          <span className="text-[10px] text-teal-700 font-semibold">১-ক্লিক ক্লিপবোর্ডে কপি ও পেস্ট</span>
                        </div>
                      </div>
                      {selectedFormat === 'google-sheets-clipboard' && <Check className="w-4 h-4 text-emerald-600" />}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-2">
                      ফাইল ডাউনলোড ছাড়া সরাসরি গুগল শিট বা এক্সেলে গিয়ে <kbd className="px-1 py-0.5 bg-slate-200 text-slate-800 rounded font-mono text-[9px]">Ctrl+V</kbd> চাপলেই সুন্দর টেবিল পেস্ট হবে।
                    </p>
                  </div>

                  {/* TSV File */}
                  <div
                    onClick={() => setSelectedFormat('tsv')}
                    className={`p-4 rounded-2xl border cursor-pointer transition flex flex-col justify-between ${
                      selectedFormat === 'tsv'
                        ? 'bg-emerald-50/60 border-emerald-600 shadow-md ring-2 ring-emerald-500/20'
                        : 'bg-white border-slate-200 hover:border-emerald-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-xs">
                          TSV
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-slate-900">ট্যাব সেপারেটেড (TSV) ফাইল</h4>
                          <span className="text-[10px] text-blue-700 font-semibold">ট্যাব বিভাজিত ডাটা ফাইল (.tsv)</span>
                        </div>
                      </div>
                      {selectedFormat === 'tsv' && <Check className="w-4 h-4 text-emerald-600" />}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-2">
                      গুগল ড্রাইভ ও ক্লাউড স্প্রেডশিটে বড় ডাটা শিট ইমপোর্টের জন্য আদর্শ।
                    </p>
                  </div>

                  {/* JSON Backup */}
                  <div
                    onClick={() => setSelectedFormat('json')}
                    className={`p-4 rounded-2xl border cursor-pointer transition flex flex-col justify-between ${
                      selectedFormat === 'json'
                        ? 'bg-emerald-50/60 border-emerald-600 shadow-md ring-2 ring-emerald-500/20'
                        : 'bg-white border-slate-200 hover:border-emerald-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center font-bold text-xs">
                          JSON
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-slate-900">স্ট্রাকচার্ড JSON ব্যাকআপ</h4>
                          <span className="text-[10px] text-purple-700 font-semibold">মেটাডাটা ও সম্পুর্ণ স্কিমা ব্যাকআপ</span>
                        </div>
                      </div>
                      {selectedFormat === 'json' && <Check className="w-4 h-4 text-emerald-600" />}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-2">
                      ডাটাবেস মাইগ্রেশন, ব্যাকআপ ও সার্ভার রিস্টোরেশনের জন্য উপযুক্ত সম্পূর্ণ ডেটা ফাইল।
                    </p>
                  </div>
                </div>
              </div>

              {/* Action Summary Card */}
              <div className="p-4 bg-gradient-to-r from-slate-900 to-emerald-950 rounded-2xl text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black shrink-0">
                    <Sparkles className="w-5 h-5 text-slate-950" />
                  </div>
                  <div>
                    <div className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                      <span>মোট রেকর্ড: {targetRecords.length} টি</span>
                      <span>•</span>
                      <span>নির্বাচিত কলাম: {selectedColumnKeys.length} টি</span>
                    </div>
                    <p className="text-[11px] text-slate-300">
                      ফরম্যাট: {selectedFormat.toUpperCase()} ({config.upName})
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  {selectedFormat === 'google-sheets-clipboard' ? (
                    <button
                      type="button"
                      onClick={handleTriggerExport}
                      disabled={isExporting || targetRecords.length === 0}
                      className="w-full sm:w-auto px-5 py-2.5 bg-teal-400 hover:bg-teal-300 text-slate-950 font-black text-xs rounded-xl shadow transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {copied ? <Check className="w-4 h-4 text-slate-950" /> : <Copy className="w-4 h-4" />}
                      <span>{copied ? 'সফলভাবে ক্লিপবোর্ডে কপি হয়েছে!' : 'ক্লিপবোর্ডে কপি করুন'}</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleTriggerExport}
                      disabled={isExporting || targetRecords.length === 0}
                      className="w-full sm:w-auto px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl shadow transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Download className="w-4 h-4 text-slate-950" />
                      <span>{isExporting ? 'প্রসেসিং হচ্ছে...' : `${selectedFormat.toUpperCase()} ফাইল ডাউনলোড`}</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: COLUMNS CUSTOMIZATION */}
          {activeTab === 'columns' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-200">
                <div>
                  <h4 className="text-xs font-bold text-slate-800">
                    এক্সপোর্টে অন্তর্ভুক্ত করার জন্য কলামসমূহ নির্বাচন করুন
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    আপনার প্রয়োজন অনুযায়ী অপ্রয়োজনীয় কলামের টিক উঠিয়ে দিন।
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleSelectAllColumns}
                    className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition"
                  >
                    সকল কলাম সিলেক্ট
                  </button>
                  <button
                    type="button"
                    onClick={handleSelectDefaultColumns}
                    className="px-3 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 text-xs font-bold rounded-lg transition"
                  >
                    ডিফল্ট কলাম
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                {availableColumns.map((col) => {
                  const isChecked = selectedColumnKeys.includes(col.key);
                  return (
                    <label
                      key={col.key}
                      onClick={() => handleToggleColumn(col.key)}
                      className={`p-3 rounded-xl border flex items-center justify-between gap-2 cursor-pointer transition select-none ${
                        isChecked
                          ? 'bg-emerald-50/70 border-emerald-500 text-emerald-950 font-bold'
                          : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}}
                          className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300"
                        />
                        <span className="text-xs">{col.label}</span>
                      </div>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 uppercase font-mono">
                        {col.category || 'col'}
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: LIVE PREVIEW */}
          {activeTab === 'preview' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-800">
                    এক্সপোর্ট প্রিভিউ (প্রথম ৫টি রো প্রদর্শিত)
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    মোট {targetRecords.length} টি রেকর্ডের মধ্যে নির্বাচিত {selectedColumnKeys.length} টি কলামের নমুনা দেখুন।
                  </p>
                </div>
                <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full">
                  মোট রো: {targetRecords.length}
                </span>
              </div>

              <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                <div className="overflow-x-auto max-h-72">
                  <table className="w-full text-xs text-left text-slate-800 whitespace-nowrap">
                    <thead className="bg-slate-800 text-white font-bold sticky top-0">
                      <tr>
                        {previewData.headers.map((h, i) => (
                          <th key={i} className="p-2.5 border-r border-slate-700 font-semibold text-[11px]">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 bg-white">
                      {previewData.rows.length === 0 ? (
                        <tr>
                          <td colSpan={previewData.headers.length || 1} className="text-center py-6 text-slate-400">
                            কোনো ডাটা পাওয়া যায়নি।
                          </td>
                        </tr>
                      ) : (
                        previewData.rows.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-slate-50">
                            {row.map((cell, cIdx) => (
                              <td key={cIdx} className="p-2.5 border-r border-slate-100 text-[11px]">
                                {cell}
                              </td>
                            ))}
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: GOOGLE SHEETS INSTRUCTIONS */}
          {activeTab === 'instructions' && (
            <div className="space-y-4 text-xs text-slate-700">
              <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200 space-y-2">
                <h4 className="font-extrabold text-emerald-950 text-sm flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
                  <span>Google Sheets-এ ১-ক্লিকে ডাটা ইমপোর্ট করার নিয়মাবলী</span>
                </h4>
                <p className="text-emerald-900 text-xs">
                  ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের সকল বাংলা ডাটা ফন্ট না ভেঙে অক্ষত রাখতে নিচের যেকোনো একটি পদ্ধতি ব্যবহার করুন:
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Method 1 */}
                <div className="p-4 bg-white rounded-2xl border border-slate-200 space-y-2 shadow-sm">
                  <span className="px-2 py-0.5 bg-teal-100 text-teal-900 rounded-md font-bold text-[10px]">
                    পদ্ধতি ১: সবচেয়ে সহজ (১-ক্লিক কপি ও পেস্ট)
                  </span>
                  <ol className="list-decimal list-inside space-y-1.5 text-[11px] text-slate-600 pt-1">
                    <li>ফরম্যাট অপশন থেকে <strong>"Google Sheets কপি ফরম্যাট (TSV)"</strong> নির্বাচন করে "ক্লিপবোর্ডে কপি করুন" বাটনে ক্লিক করুন।</li>
                    <li>আপনার ব্রাউজারে একটি নতুন <a href="https://sheets.new" target="_blank" rel="noreferrer" className="text-emerald-700 underline font-bold">Google Sheets (sheets.new)</a> খুলুন।</li>
                    <li>প্রথম সেল <code className="bg-slate-100 px-1 rounded font-mono">A1</code>-এ ক্লিক করে কীবোর্ডের <kbd className="bg-slate-200 px-1 py-0.5 rounded font-mono text-[10px]">Ctrl + V</kbd> (Mac এ <kbd className="bg-slate-200 px-1 py-0.5 rounded font-mono text-[10px]">Cmd + V</kbd>) চাপুন।</li>
                    <li>সকল কলাম ও রো স্বয়ংক্রিয়ভাবে নির্ভুলভাবে বসে যাবে।</li>
                  </ol>
                </div>

                {/* Method 2 */}
                <div className="p-4 bg-white rounded-2xl border border-slate-200 space-y-2 shadow-sm">
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 rounded-md font-bold text-[10px]">
                    পদ্ধতি ২: CSV ফাইল সরাসরি ইমপোর্ট
                  </span>
                  <ol className="list-decimal list-inside space-y-1.5 text-[11px] text-slate-600 pt-1">
                    <li><strong>"CSV ফাইল ডাউনলোড"</strong> করে ফাইলটি সংরক্ষণ করুন।</li>
                    <li>Google Sheets খুলে মেনু থেকে <strong>File &gt; Import</strong> এ ক্লিক করুন।</li>
                    <li><strong>Upload</strong> ট্যাবে গিয়ে ডাউনলোডকৃত CSV ফাইলটি ড্রপ করুন।</li>
                    <li><strong>Import location</strong> হিসেবে <em>Replace current sheet</em> সিলেক্ট করে <strong>Import data</strong> দিন।</li>
                  </ol>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="text-[11px] text-slate-500 hidden sm:block">
            নির্বাচিত ডাটা: <strong>{targetRecords.length}</strong> টি রেকর্ড • <strong>{selectedColumnKeys.length}</strong> টি কলাম
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl transition cursor-pointer"
            >
              বন্ধ করুন
            </button>

            {activeTab !== 'export' && (
              <button
                type="button"
                onClick={() => setActiveTab('export')}
                className="px-4 py-2 bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
              >
                <span>এক্সপোর্টে ফিরে যান</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
