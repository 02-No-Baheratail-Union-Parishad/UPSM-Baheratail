import React, { useState, useEffect, useMemo } from 'react';
import { 
  Search, 
  Printer, 
  FileText, 
  User, 
  CreditCard, 
  Calendar, 
  MapPin, 
  Eye, 
  RefreshCw, 
  CheckCircle2, 
  Share2, 
  ExternalLink, 
  Copy, 
  Check, 
  Sparkles, 
  ArrowLeft, 
  Filter, 
  Phone, 
  AlertCircle,
  Clock,
  Layers,
  X
} from 'lucide-react';
import { CertificateRecord, UnionParishadConfig } from '../types';
import { fetchCertificatesFromFirebase } from '../firebase';
import { CERTIFICATE_CATEGORIES, CERTIFICATE_TYPES } from '../data/certificateTypes';
import { WARDS } from '../data/villages';
import { CertificateView } from './CertificateView';
import { WhatsAppDispatchModal } from './WhatsAppDispatchModal';

interface CertificateSearchReprintProps {
  config: UnionParishadConfig;
  onBackToDashboard?: () => void;
  initialQuery?: string;
}

export const CertificateSearchReprint: React.FC<CertificateSearchReprintProps> = ({
  config,
  onBackToDashboard,
  initialQuery = ''
}) => {
  const [allCertificates, setAllCertificates] = useState<CertificateRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>(initialQuery);
  const [searchMode, setSearchMode] = useState<'all' | 'nid' | 'name' | 'memo' | 'mobile'>('all');
  const [selectedWard, setSelectedWard] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('সব ধরন');
  const [selectedCertType, setSelectedCertType] = useState<string>('সকল সনদের ধরন');
  
  // Selected certificate for reprint / full view
  const [reprintCert, setReprintCert] = useState<CertificateRecord | null>(null);
  const [whatsAppCert, setWhatsAppCert] = useState<CertificateRecord | null>(null);
  const [copiedMemo, setCopiedMemo] = useState<string | null>(null);

  // Quick recent sample searches for Union Parishad staff
  const quickSearchTags = [
    { label: 'আতিকুর রহমান', query: 'আতিকুর', mode: 'name' as const },
    { label: 'ফাতেমা বেগম', query: 'ফাতেমা', mode: 'name' as const },
    { label: 'NID: 19859382...', query: '19859382', mode: 'nid' as const },
    { label: 'NID: 19929382...', query: '19929382', mode: 'nid' as const },
    { label: 'স্মারক: UP02-CHAR', query: 'UP02', mode: 'memo' as const },
    { label: 'ওয়ার্ড নং ০৪', query: '', ward: '০৪' }
  ];

  const loadAllCertificates = async () => {
    setLoading(true);
    try {
      // 1. Fetch from server API
      const res = await fetch('/api/admin/logs');
      const data = await res.json();
      const serverLogs: CertificateRecord[] = data.logs || [];

      // 2. Fetch from Firebase
      const fbLogs = await fetchCertificatesFromFirebase();

      // 3. Fallback mock initial logs if empty
      const defaultSamples: CertificateRecord[] = [
        {
          id: 'cert_sample_01',
          memoNo: 'UP02-CHAR-2026-00104',
          typeKey: 'character',
          typeLabel: 'চারিত্রিক সনদপত্র',
          category: 'নাগরিক ও চারিত্রিক',
          issueDate: '২০২৬-০২-১০',
          issueDateEn: '2026-02-10',
          createdAt: '2026-02-10T10:00:00Z',
          verificationUrl: 'https://baheratailup.gov.bd/verify/UP02-CHAR-2026-00104',
          status: 'issued',
          issuedBy: 'ইউপি ডিজিটাল সেন্টার',
          feeAmount: 50,
          paymentStatus: 'paid',
          extra: { simpleFields: {}, tables: {} },
          citizen: {
            name: 'মোঃ আতিকুর রহমান',
            father: 'হাজী আব্দুল গণি',
            mother: 'আয়েশা খাতুন',
            nid: '19859382011234567',
            village: 'বহেড়াতৈল',
            wardNo: '০৪',
            postOffice: 'বহেড়াতৈল',
            holdingNo: 'এইচ-১০৪',
            mobile: '01712345678',
            gender: 'পুরুষ'
          },
          bodyText: 'এই মর্মে প্রত্যয়ন করা যাইতেছে যে, মোঃ আতিকুর রহমান, পিতা: হাজী আব্দুল গণি, মাতা: আয়েশা খাতুন, গ্রাম: বহেড়াতৈল, ওয়ার্ড নং: ০৪, ডাকঘর: বহেড়াতৈল, উপজেলা: সখিপুর, জেলা: টাঙ্গাইল-এর একজন স্থায়ী বাসিন্দা। তিনি কোনো প্রকার রাষ্ট্রবিরোধী বা অসামাজিক কার্যকলাপে জড়িত নহেন। তাঁহার নৈতিক চরিত্র উত্তম।'
        },
        {
          id: 'cert_sample_02',
          memoNo: 'UP02-CITI-2026-00052',
          typeKey: 'citizenship',
          typeLabel: 'নাগরিকত্ব সনদপত্র',
          category: 'নাগরিক ও চারিত্রিক',
          issueDate: '২০২৬-০২-১২',
          issueDateEn: '2026-02-12',
          createdAt: '2026-02-12T11:30:00Z',
          verificationUrl: 'https://baheratailup.gov.bd/verify/UP02-CITI-2026-00052',
          status: 'issued',
          issuedBy: 'ইউপি ডিজিটাল সেন্টার',
          feeAmount: 50,
          paymentStatus: 'paid',
          extra: { simpleFields: {}, tables: {} },
          citizen: {
            name: 'মোছাঃ ফাতেমা বেগম',
            father: 'মোঃ মজিবর রহমান',
            mother: 'আমেনা বেগম',
            spouseName: 'মোঃ শফিকুল ইসলাম',
            nid: '19929382019876543',
            village: 'গোহাইলবাড়ী',
            wardNo: '০১',
            postOffice: 'নাগবাড়ী',
            holdingNo: 'এইচ-৫২',
            mobile: '01823456789',
            gender: 'মহিলা'
          },
          bodyText: 'এই মর্মে প্রত্যয়ন করা যাইতেছে যে, মোছাঃ ফাতেমা বেগম, পিতা: মোঃ মজিবর রহমান, স্বামী: মোঃ শফিকুল ইসলাম, গ্রাম: গোহাইলবাড়ী, ওয়ার্ড নং: ০১, ডাকঘর: নাগবাড়ী, উপজেলা: সখিপুর, জেলা: টাঙ্গাইল-এর একজন স্থায়ী নাগরিক ও জন্মসূত্রে বাংলাদেশের নাগরিক।'
        },
        {
          id: 'cert_sample_03',
          memoNo: 'UP02-TRADE-2026-00017',
          typeKey: 'trade_license',
          typeLabel: 'ট্রেড লাইসেন্স (ব্যবসা সনদ)',
          category: 'ব্যবসা ও বাণিজ্য',
          issueDate: '২০২৬-০২-১৫',
          issueDateEn: '2026-02-15',
          createdAt: '2026-02-15T09:15:00Z',
          verificationUrl: 'https://baheratailup.gov.bd/verify/UP02-TRADE-2026-00017',
          status: 'issued',
          issuedBy: 'ইউপি ডিজিটাল সেন্টার',
          feeAmount: 200,
          paymentStatus: 'paid',
          extra: { simpleFields: {}, tables: {} },
          citizen: {
            name: 'তানভীর আহমেদ রিফাত',
            father: 'মোঃ রফিকুল ইসলাম',
            mother: 'নাছিমা আক্তার',
            nid: '19989382014561234',
            village: 'আমতৈল',
            wardNo: '০৫',
            postOffice: 'বেতুয়া',
            holdingNo: 'এইচ-১৭',
            mobile: '01934567890',
            gender: 'পুরুষ'
          },
          bodyText: 'এতদ্বারা মেসার্স রিফাত এন্টারপ্রাইজ-এর অনুকূলে ব্যবসা পরিচালনার জন্য এই ট্রেড লাইসেন্স ইস্যু করা হইল। স্বত্বাধিকারী: তানভীর আহমেদ রিফাত, গ্রাম: আমতৈল, ওয়ার্ড নং: ০৫।'
        },
        {
          id: 'cert_sample_04',
          memoNo: 'UP02-WARIS-2026-00003',
          typeKey: 'warish',
          typeLabel: 'ওয়ারিশান সনদপত্র',
          category: 'উত্তরাধিকার ও পারিবারিক',
          issueDate: '২০২৬-০২-১৬',
          issueDateEn: '2026-02-16',
          createdAt: '2026-02-16T14:20:00Z',
          verificationUrl: 'https://baheratailup.gov.bd/verify/UP02-WARIS-2026-00003',
          status: 'issued',
          issuedBy: 'ইউপি ডিজিটাল সেন্টার',
          feeAmount: 100,
          paymentStatus: 'paid',
          extra: { simpleFields: {}, tables: {} },
          citizen: {
            name: 'মোঃ জহিরুল হক',
            father: 'মরহুম আফসার উদ্দিন',
            mother: 'মরহুমা জাহানারা খাতুন',
            nid: '19629382011122334',
            village: 'ঘাটেশ্বরী',
            wardNo: '০৩',
            postOffice: 'বহেড়াতৈল',
            holdingNo: 'এইচ-০৩',
            mobile: '01756789012',
            gender: 'পুরুষ'
          },
          bodyText: 'এই মর্মে ওয়ারিশান সনদ প্রদান করা যাইতেছে যে, মরহুম আফসার উদ্দিন মৃত্যুর পূর্বে নিম্নবর্ণিত ওয়ারিশগণ রাখিয়া মৃত্যুবরণ করিয়াছেন।'
        }
      ];

      // Merge and deduplicate by memoNo or id
      const map = new Map<string, CertificateRecord>();
      [...defaultSamples, ...serverLogs, ...fbLogs].forEach(item => {
        const key = item.memoNo || item.id;
        if (key && !map.has(key)) {
          map.set(key, item);
        }
      });

      setAllCertificates(Array.from(map.values()));
    } catch (err) {
      console.error('Error fetching certificates for search/reprint:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllCertificates();
  }, []);

  // Filter and search certificates
  const filteredCertificates = useMemo(() => {
    let result = [...allCertificates];

    // Ward filter
    if (selectedWard) {
      result = result.filter(c => c.citizen && c.citizen.wardNo === selectedWard);
    }

    // Category filter
    if (selectedCategory && selectedCategory !== 'সব ধরন') {
      result = result.filter(c => c.category === selectedCategory || c.typeLabel === selectedCategory);
    }

    // Cert Type filter
    if (selectedCertType && selectedCertType !== 'সকল সনদের ধরন') {
      result = result.filter(c => c.typeLabel === selectedCertType);
    }

    // Search query with specific modes (NID, Name, Memo, Mobile, or All)
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      result = result.filter(c => {
        const citizen = c.citizen || ({} as any);
        const name = (citizen.name || '').toLowerCase();
        const nid = (citizen.nid || '').toLowerCase();
        const birthNo = (citizen.birthNo || '').toLowerCase();
        const mobile = (citizen.mobile || '').toLowerCase();
        const memo = (c.memoNo || '').toLowerCase();
        const village = (citizen.village || '').toLowerCase();
        const father = (citizen.father || '').toLowerCase();
        const spouse = (citizen.spouseName || '').toLowerCase();
        const typeLabel = (c.typeLabel || '').toLowerCase();

        switch (searchMode) {
          case 'nid':
            return nid.includes(q) || birthNo.includes(q);
          case 'name':
            return name.includes(q) || father.includes(q) || spouse.includes(q);
          case 'memo':
            return memo.includes(q);
          case 'mobile':
            return mobile.includes(q);
          case 'all':
          default:
            return (
              name.includes(q) ||
              nid.includes(q) ||
              birthNo.includes(q) ||
              memo.includes(q) ||
              mobile.includes(q) ||
              village.includes(q) ||
              father.includes(q) ||
              typeLabel.includes(q)
            );
        }
      });
    }

    return result;
  }, [allCertificates, searchQuery, searchMode, selectedWard, selectedCategory, selectedCertType]);

  const handleCopyMemo = (memo: string) => {
    navigator.clipboard.writeText(memo);
    setCopiedMemo(memo);
    setTimeout(() => setCopiedMemo(null), 2000);
  };

  // If a certificate is selected for reprint, show the full CertificateView with print controls
  if (reprintCert) {
    return (
      <div className="space-y-4 max-w-5xl mx-auto">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 print:hidden">
          <button
            onClick={() => setReprintCert(null)}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" /> সার্চ তালিকায় ফিরে যান
          </button>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-bold rounded-full">
              পুনরায় প্রিন্ট মোড (Reprint Mode)
            </span>
          </div>
        </div>

        <CertificateView
          certificate={reprintCert}
          config={config}
          onBack={() => setReprintCert(null)}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Top Hero Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-950 text-white p-6 md:p-8 rounded-3xl shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 transform translate-x-12 -translate-y-8 opacity-10 pointer-events-none">
          <Printer className="w-64 h-64 text-white" />
        </div>

        <div className="relative z-10 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-400 text-emerald-950 font-black text-xs rounded-full">
              <Sparkles className="w-3.5 h-3.5" /> সনদ দ্রুত অনুসন্ধান ও পুনরায় প্রিন্ট (Instant Certificate Search & Reprint)
            </div>
            {onBackToDashboard && (
              <button
                onClick={onBackToDashboard}
                className="px-3.5 py-1.5 bg-emerald-950/80 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition border border-emerald-700 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> ড্যাশবোর্ডে ফিরুন
              </button>
            )}
          </div>

          <h1 className="text-xl md:text-3xl font-black tracking-tight">
            জাতীয় পরিচয়পত্র (NID), নাম বা স্মারক নম্বর দিয়ে সনদ খুঁজুন ও প্রিন্ট করুন
          </h1>
          <p className="text-xs md:text-sm text-emerald-200 max-w-3xl leading-relaxed">
            যে কোনো নাগরিকের নাম, ১৭/১০ ডিজিটের জাতীয় পরিচয়পত্র (NID) নম্বর, জন্ম সনদ নম্বর, মোবাইল নম্বর অথবা পূর্বে ইস্যুকৃত স্মারক নম্বর লিখে মুহূর্তেই সনদটি খুঁজে বের করুন এবং ১-ক্লিকে পুনরায় প্রিন্ট বা PDF ডাউনলোড করুন।
          </p>
        </div>
      </div>

      {/* Main Search Controls & Filter Card */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-md border border-slate-200 dark:border-slate-800 space-y-5">
        
        {/* Search Mode Selector Tabs */}
        <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-bold text-slate-500 mr-1">সার্চ ফিল্টার:</span>
            {[
              { id: 'all', label: 'সব ফিল্ডে খুঁজুন (All)', icon: Search },
              { id: 'nid', label: 'NID / জন্ম নম্বর', icon: CreditCard },
              { id: 'name', label: 'নাগরিকের নাম', icon: User },
              { id: 'memo', label: 'স্মারক নম্বর', icon: FileText },
              { id: 'mobile', label: 'মোবাইল নম্বর', icon: Phone }
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = searchMode === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setSearchMode(tab.id as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
                    isActive
                      ? 'bg-emerald-800 text-white shadow'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          <button
            onClick={loadAllCertificates}
            className="p-2 text-slate-500 hover:text-emerald-700 dark:text-slate-400 dark:hover:text-emerald-400 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer flex items-center gap-1 text-xs font-bold"
            title="ডাটাবেজ রিফ্রেশ করুন"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">রিফ্রেশ</span>
          </button>
        </div>

        {/* Primary Search Input Field */}
        <div className="relative">
          <Search className="w-6 h-6 text-emerald-700 dark:text-emerald-400 absolute left-4 top-3.5" />
          <input
            type="text"
            placeholder={
              searchMode === 'nid' ? 'নাগরিকের ১০ বা ১৭ ডিজিটের NID / ১৭ ডিজিটের জন্ম নিবন্ধন নম্বর লিখুন...' :
              searchMode === 'name' ? 'নাগরিকের নাম, পিতার নাম বা স্বামীর নাম লিখুন...' :
              searchMode === 'memo' ? 'পূর্বে ইস্যুকৃত স্মারক নম্বর লিখুন (যেমন: UP02-CHAR-2026-00104)...' :
              searchMode === 'mobile' ? '১১ ডিজিটের মোবাইল নম্বর লিখুন (যেমন: 01712345678)...' :
              'নাগরিকের নাম, NID নম্বর, জন্ম সনদ, স্মারক নং, গ্রাম বা মোবাইল নম্বর লিখুন...'
            }
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-12 py-3.5 bg-slate-50 dark:bg-slate-800/80 border-2 border-emerald-600/30 focus:border-emerald-600 rounded-2xl text-sm md:text-base font-semibold text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 transition shadow-inner"
            autoFocus
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-4 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Quick Search Tag Chips */}
        <div className="flex items-center gap-2 flex-wrap text-xs">
          <span className="text-slate-500 font-bold flex items-center gap-1">
            <Clock className="w-3 h-3 text-amber-500" /> দ্রুত সার্চ নমুনা:
          </span>
          {quickSearchTags.map((tag, idx) => (
            <button
              key={idx}
              onClick={() => {
                if (tag.query) setSearchQuery(tag.query);
                if (tag.mode) setSearchMode(tag.mode);
                if (tag.ward) setSelectedWard(tag.ward);
              }}
              className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:hover:bg-emerald-900 text-emerald-800 dark:text-emerald-300 rounded-lg text-[11px] font-bold border border-emerald-200 dark:border-emerald-800/70 transition cursor-pointer"
            >
              {tag.label}
            </button>
          ))}
          {(searchQuery || selectedWard || selectedCategory !== 'সব ধরন' || selectedCertType !== 'সকল সনদের ধরন') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedWard('');
                setSelectedCategory('সব ধরন');
                setSelectedCertType('সকল সনদের ধরন');
                setSearchMode('all');
              }}
              className="px-2.5 py-1 bg-red-50 hover:bg-red-100 dark:bg-red-950/60 text-red-700 dark:text-red-300 rounded-lg text-[11px] font-bold border border-red-200 dark:border-red-800 transition cursor-pointer"
            >
              সব ফিল্টার মুছুন
            </button>
          )}
        </div>

        {/* Secondary Detailed Dropdown Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1">ওয়ার্ড নির্বাচন (০১-০৯):</label>
            <select
              value={selectedWard}
              onChange={(e) => setSelectedWard(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="">সকল ওয়ার্ড (০১ - ০৯)</option>
              {WARDS.map(w => (
                <option key={w} value={w}>ওয়ার্ড নং {w}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1">ক্যাটাগরি:</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              {CERTIFICATE_CATEGORIES.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1">সনদের ধরন (৪০+ প্রকার):</label>
            <select
              value={selectedCertType}
              onChange={(e) => setSelectedCertType(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="সকল সনদের ধরন">সকল সনদের ধরন (৪০+)</option>
              {CERTIFICATE_TYPES.map(type => (
                <option key={type.key} value={type.label}>{type.label}</option>
              ))}
            </select>
          </div>
        </div>

      </div>

      {/* Results Header Bar */}
      <div className="flex items-center justify-between flex-wrap gap-2 px-2">
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold text-slate-800 dark:text-slate-200">
            অনুসন্ধান ফলাফল:
          </span>
          <span className="px-2.5 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-extrabold text-xs rounded-full border border-emerald-300 dark:border-emerald-800">
            {filteredCertificates.length} টি রেকর্ড পাওয়া গেছে
          </span>
        </div>

        {filteredCertificates.length > 0 && (
          <span className="text-xs text-slate-500 dark:text-slate-400">
            যেকোনো সনদের পাশে থাকা <strong>"পুনরায় প্রিন্ট"</strong> বাটনে ক্লিক করে সাথে সাথে প্রিন্ট করুন
          </span>
        )}
      </div>

      {/* Results List: Cards & Table */}
      {loading ? (
        <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl text-center space-y-3 border border-slate-200 dark:border-slate-800">
          <RefreshCw className="w-10 h-10 text-emerald-700 animate-spin mx-auto" />
          <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
            ডিজিটাল ডাটাবেজ হইতে সনদ রেকর্ডসমূহ অনুসন্ধান করা হইতেছে...
          </p>
        </div>
      ) : filteredCertificates.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl text-center space-y-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <AlertCircle className="w-12 h-12 text-amber-500 mx-auto" />
          <div className="space-y-1">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              কোনো ম্যাচিং প্রত্যয়নপত্র বা সনদপত্র পাওয়া যায় নাই
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
              "{searchQuery}" দিয়ে কোনো সনদ রেকর্ড খুঁজে পাওয়া যায় নাই। বানান সঠিক আছে কি না অথবা অন্য কোনো তথ্য (যেমন: NID বা মোবাইল নম্বর) দিয়ে পুনরায় সার্চ করুন।
            </p>
          </div>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedWard('');
              setSelectedCategory('সব ধরন');
              setSelectedCertType('সকল সনদের ধরন');
              setSearchMode('all');
            }}
            className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl transition shadow cursor-pointer inline-flex items-center gap-1.5"
          >
            সকল সনদ তালিকা দেখুন
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredCertificates.map((cert) => {
            const cit = cert.citizen || ({} as any);
            return (
              <div
                key={cert.id || cert.memoNo}
                className="bg-white dark:bg-slate-900 p-5 rounded-3xl border-2 border-slate-200 dark:border-slate-800 hover:border-emerald-600 dark:hover:border-emerald-500 transition shadow-sm space-y-4 group relative overflow-hidden"
              >
                {/* Card Header: Category & Memo */}
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1">
                    <span className="px-2.5 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[10px] font-black rounded-md border border-emerald-300 dark:border-emerald-800 uppercase">
                      {cert.category || 'নাগরিক সেবা'}
                    </span>
                    <h3 className="font-bold text-base text-slate-900 dark:text-white group-hover:text-emerald-700 dark:group-hover:text-emerald-400 transition">
                      {cert.typeLabel}
                    </h3>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 text-[11px] font-bold rounded-full border border-emerald-200 dark:border-emerald-800 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> বৈধ সনদ
                    </span>
                  </div>
                </div>

                {/* Citizen Details Summary */}
                <div className="bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-2xl space-y-2 text-xs border border-slate-100 dark:border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-medium">নাগরিকের নাম:</span>
                    <strong className="text-slate-900 dark:text-white text-sm font-bold">{cit.name || 'N/A'}</strong>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-medium">পিতা / স্বামী:</span>
                    <span className="text-slate-800 dark:text-slate-200 font-medium">{cit.father || cit.spouseName || 'N/A'}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-medium">NID / জন্ম সনদ:</span>
                    <strong className="font-mono text-emerald-800 dark:text-emerald-300 font-bold">
                      {cit.nid || cit.birthNo || 'যাচাইকৃত'}
                    </strong>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-medium">ঠিকানা ও ওয়ার্ড:</span>
                    <span className="text-slate-800 dark:text-slate-200">
                      {cit.village || 'বহেড়াতৈল'}, ওয়ার্ড নং <strong>{cit.wardNo || '০৪'}</strong>
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-200 dark:border-slate-700 text-[11px]">
                    <span className="text-slate-500">স্মারক নং:</span>
                    <div className="flex items-center gap-1 font-mono font-bold text-slate-800 dark:text-slate-200">
                      <span>{cert.memoNo}</span>
                      <button
                        onClick={() => handleCopyMemo(cert.memoNo)}
                        className="text-slate-400 hover:text-emerald-600 p-0.5 rounded transition cursor-pointer"
                        title="স্মারক কপি করুন"
                      >
                        {copiedMemo === cert.memoNo ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-500">ইস্যুর তারিখ:</span>
                    <span className="text-slate-700 dark:text-slate-300 font-semibold">{cert.issueDate}</span>
                  </div>
                </div>

                {/* Primary Action Buttons: Instant Reprint / Preview / WhatsApp */}
                <div className="flex items-center gap-2 pt-1 flex-wrap">
                  <button
                    onClick={() => setReprintCert(cert)}
                    className="flex-1 py-2.5 px-3 bg-emerald-800 hover:bg-emerald-900 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 transition shadow cursor-pointer border border-emerald-700"
                    title="সনদপত্রটি খুলুন এবং ১-ক্লিকে পুনরায় প্রিন্ট করুন"
                  >
                    <Printer className="w-4 h-4 text-amber-300" />
                    <span>পুনরায় প্রিন্ট (Reprint)</span>
                  </button>

                  <button
                    onClick={() => setReprintCert(cert)}
                    className="py-2.5 px-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs rounded-xl flex items-center justify-center gap-1 transition cursor-pointer"
                    title="প্রিভিউ দেখুন"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>প্রিভিউ</span>
                  </button>

                  <button
                    onClick={() => setWhatsAppCert(cert)}
                    className="p-2.5 bg-[#25D366]/20 hover:bg-[#25D366]/30 text-emerald-950 font-bold text-xs rounded-xl border border-[#25D366]/50 transition cursor-pointer"
                    title="নাগরিকের হোয়াটসঅ্যাপে সনদ পাঠান"
                  >
                    <Share2 className="w-4 h-4 text-emerald-700" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* WhatsApp Modal */}
      <WhatsAppDispatchModal
        isOpen={!!whatsAppCert}
        onClose={() => setWhatsAppCert(null)}
        certificate={whatsAppCert}
        config={config}
      />

    </div>
  );
};
