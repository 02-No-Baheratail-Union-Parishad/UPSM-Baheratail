import React, { useRef, useState } from 'react';
import { 
  Printer, 
  Download, 
  ExternalLink, 
  Sparkles, 
  FileText, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  Share2, 
  ArrowLeft,
  Sliders,
  Maximize2,
  QrCode,
  ShieldCheck,
  CreditCard,
  Check,
  Send,
  Copy,
  MessageSquare,
  Phone,
  X,
  FileCheck,
  Globe,
  Droplet,
  Image as ImageIcon,
  Layers,
  Palette
} from 'lucide-react';
import { CertificateRecord, UnionParishadConfig } from '../types';
import { formatBanglaDate, convertEnglishDateToBanglaFormatted, generateSecurityChecksum, toBengaliNumeral } from '../lib/utils';
import { StyledQrCode } from './StyledQrCode';
import { QrColorScheme, QR_COLOR_PRESETS } from '../utils/qrCodeGenerator';
import { 
  LogoStylePreset, 
  LOGO_PRESETS, 
  WATERMARK_INTENSITY_PRESETS, 
  WatermarkIntensityPreset 
} from '../utils/logoPresets';
import { WhatsAppDispatchModal } from './WhatsAppDispatchModal';
import { downloadCertificateAsDoc, copyCertificateForGoogleDocs } from '../utils/googleDocExporter';

interface CertificateViewProps {
  certificate: CertificateRecord;
  config: UnionParishadConfig;
  onBack?: () => void;
  onShareToGoogleChat?: (cert: CertificateRecord) => void;
}

export const CertificateView: React.FC<CertificateViewProps> = ({ certificate, config, onBack, onShareToGoogleChat }) => {
  const [showHeaderInPrint, setShowHeaderInPrint] = useState(config.enableHeaderInPrint !== false);
  const [fontSize, setFontSize] = useState<number>(config.bodyFontSize || 16);
  const [headerStyle, setHeaderStyle] = useState<'tri-column' | 'classic' | 'centered'>(config.templateHeaderStyle || 'tri-column');
  const [borderStyle, setBorderStyle] = useState<'double-green-red' | 'double-green' | 'single-green' | 'none'>(config.borderStyle || 'double-green-red');
  const [blankSealSize, setBlankSealSize] = useState<number>(config.blankSealSize ?? 96);
  const [dateFormatStyle, setDateFormatStyle] = useState<'numeric' | 'full' | 'long' | 'banglaSan' | 'both'>('full');
  const [showDigitalSig, setShowDigitalSig] = useState<boolean>(config.enableDigitalSignature !== false);
  const [showSecretarySig, setShowSecretarySig] = useState<boolean>(config.showSecretarySignature !== false);
  
  // Bottom Footer (Signatures, Official Seal, QR Code) Toggles
  const [showBottomSection, setShowBottomSection] = useState<boolean>(true);
  const [showSignatures, setShowSignatures] = useState<boolean>(true);
  const [showBlankSeal, setShowBlankSeal] = useState<boolean>(true);
  const [showQrCode, setShowQrCode] = useState<boolean>(true);

  // Google Doc Export States
  const [isGoogleDocModalOpen, setIsGoogleDocModalOpen] = useState<boolean>(false);
  const [googleDocNotice, setGoogleDocNotice] = useState<string | null>(null);
  const [isCopyingDoc, setIsCopyingDoc] = useState<boolean>(false);

  const [showCustomizer, setShowCustomizer] = useState(true);
  
  // Dynamic Logo Styles & Watermark Intensity States
  const [logoStyle, setLogoStyle] = useState<LogoStylePreset>('up-seal');
  const [watermarkIntensity, setWatermarkIntensity] = useState<number>(config.watermarkOpacity ?? 0.08);
  const [watermarkStyle, setWatermarkStyle] = useState<'single-centered' | 'dual-emblem' | 'security-pattern' | 'corner-crest'>('single-centered');
  const [applyLogoTo, setApplyLogoTo] = useState<'all' | 'qr-only' | 'header-only' | 'watermark-only'>('all');

  const [isEditingText, setIsEditingText] = useState(false);
  const [editableBodyText, setEditableBodyText] = useState(certificate.bodyText);

  // QR Code Advanced Customization State
  const [qrColorScheme, setQrColorScheme] = useState<QrColorScheme>(config.qrColorScheme || 'govt-emerald');
  const [qrCustomDarkColor, setQrCustomDarkColor] = useState<string>(config.qrCustomDarkColor || '#064e3b');
  const [qrCustomLightColor, setQrCustomLightColor] = useState<string>(config.qrCustomLightColor || '#ffffff');
  const [qrEmbedLogo, setQrEmbedLogo] = useState<boolean>(config.qrEmbedLogo !== false);
  const [qrLogoShape, setQrLogoShape] = useState<'circle' | 'rounded'>('circle');
  const [qrFrameStyle, setQrFrameStyle] = useState<'clean' | 'badge' | 'double' | 'minimal'>(config.qrFrameStyle || 'clean');

  // A4 Print Optimization & Compact Mode State
  const [isCompactMode, setIsCompactMode] = useState<boolean>(true);
  const [pageOrientation, setPageOrientation] = useState<'portrait' | 'landscape'>('portrait');
  const [printScale, setPrintScale] = useState<number>(100);
  const [isPrintPreviewOpen, setIsPrintPreviewOpen] = useState<boolean>(false);

  // WhatsApp Modal State
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);

  const printRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    setIsPrintPreviewOpen(true);
  };

  const triggerActualPrint = () => {
    if (pageOrientation === 'landscape') {
      document.body.classList.add('print-landscape-mode');
      document.body.classList.remove('print-portrait-mode');
    } else {
      document.body.classList.add('print-portrait-mode');
      document.body.classList.remove('print-landscape-mode');
    }
    window.print();
  };

  // Google Doc Action Handlers
  const handleOpenInGoogleDocs = async () => {
    setIsCopyingDoc(true);
    const success = await copyCertificateForGoogleDocs(certificate, config, {
      includeHeader: showHeaderInPrint,
      includeQrCode: showQrCode && showBottomSection,
      includeSignatures: showSignatures && showBottomSection,
      includeSeal: showBlankSeal && showBottomSection,
    });
    setIsCopyingDoc(false);
    
    // Open docs.new in new window/tab
    window.open('https://docs.new', '_blank');
    setGoogleDocNotice('✅ সনদটি সফলভাবে ফরম্যাটসহ কপি করা হয়েছে! নতুন খোলা Google Docs পেজে Ctrl+V (Paste) করে যেকোনো সময় প্রিন্ট (Ctrl+P) করতে পারেন।');
    setTimeout(() => {
      setGoogleDocNotice(null);
    }, 9000);
  };

  const handleDownloadDocFile = () => {
    downloadCertificateAsDoc(certificate, config, {
      includeHeader: showHeaderInPrint,
      includeQrCode: showQrCode && showBottomSection,
      includeSignatures: showSignatures && showBottomSection,
      includeSeal: showBlankSeal && showBottomSection,
    });
    setGoogleDocNotice('💾 Google Doc (.doc) ফাইল ডাউনলোড হয়েছে। এটি Google Drive অথবা Microsoft Word-এ খুলে সরাসরি প্রিন্ট করতে পারবেন।');
    setTimeout(() => {
      setGoogleDocNotice(null);
    }, 7000);
  };

  const handleCopyForGoogleDocs = async () => {
    setIsCopyingDoc(true);
    const success = await copyCertificateForGoogleDocs(certificate, config, {
      includeHeader: showHeaderInPrint,
      includeQrCode: showQrCode && showBottomSection,
      includeSignatures: showSignatures && showBottomSection,
      includeSeal: showBlankSeal && showBottomSection,
    });
    setIsCopyingDoc(false);
    if (success) {
      setGoogleDocNotice('📋 সম্পূর্ণ সনদটি কপি হয়েছে! Google Docs বা Word-এ গিয়ে Ctrl+V দিয়ে পেস্ট করুন।');
    } else {
      setGoogleDocNotice('⚠️ কপি সম্পন্ন হয়নি। টেক্সট এডিটর থেকে সরাসরি কপি করুন।');
    }
    setTimeout(() => {
      setGoogleDocNotice(null);
    }, 6000);
  };

  const c = certificate.citizen;
  const extraTables = certificate.extra?.tables || {};

  // Helper to resolve logo URL based on target component (header, qr, watermark)
  const getResolvedLogoUrl = (target: 'header' | 'qr' | 'watermark') => {
    const isTargetSelected = 
      applyLogoTo === 'all' || 
      (applyLogoTo === 'header-only' && target === 'header') ||
      (applyLogoTo === 'qr-only' && target === 'qr') ||
      (applyLogoTo === 'watermark-only' && target === 'watermark');

    if (isTargetSelected && LOGO_PRESETS[logoStyle]) {
      return LOGO_PRESETS[logoStyle].url;
    }
    
    // Default fallbacks
    if (target === 'watermark') return config.watermarkUrl || config.logoUrl || '/baheratail_seal.svg';
    return config.logoUrl || '/baheratail_seal.svg';
  };

  // Quick cycle watermark intensity
  const cycleWatermarkIntensity = () => {
    const steps = [0, 0.05, 0.08, 0.14, 0.20, 0.28];
    const currentIndex = steps.findIndex(s => Math.abs(s - watermarkIntensity) < 0.02);
    const nextIndex = (currentIndex + 1) % steps.length;
    setWatermarkIntensity(steps[nextIndex]);
  };

  // Build real verification URL for QR code
  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://baheratailup.gov.bd';
  const realVerifyUrl = `${origin}/verify/${certificate.memoNo}`;
  const qrImageUrl = certificate.qrCodeUrl || `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(realVerifyUrl)}`;

  return (
    <div className="space-y-6">
      {/* Toast Notice for Google Doc & Export Notifications */}
      {googleDocNotice && (
        <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white p-3.5 rounded-xl shadow-lg border border-blue-400/40 flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top-3 print:hidden">
          <div className="flex items-center gap-2.5">
            <FileCheck className="w-5 h-5 text-amber-300 shrink-0" />
            <span className="text-xs sm:text-sm font-semibold">{googleDocNotice}</span>
          </div>
          <button
            onClick={() => setGoogleDocNotice(null)}
            className="p-1 hover:bg-white/10 rounded-lg text-slate-300 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Action & Customizer Toolbar */}
      <div className="bg-white p-4 rounded-xl shadow-md border border-slate-200 flex flex-wrap items-center justify-between gap-3 print:hidden">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              onClick={onBack}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition flex items-center gap-1 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>ফিরে যান</span>
            </button>
          )}
          <div className="flex items-center gap-1.5 bg-emerald-50 text-emerald-800 px-3 py-1 rounded-full text-xs font-bold border border-emerald-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>স্মারক নং: {certificate.memoNo}</span>
          </div>

          {certificate.feeAmount && (
            <span className="px-2.5 py-1 bg-amber-100 text-amber-900 text-xs font-bold rounded-full flex items-center gap-1">
              <CreditCard className="w-3.5 h-3.5 text-amber-700" />
              <span>ফি: ৳{certificate.feeAmount} ({certificate.paymentMethod || 'ক্যাশ'})</span>
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Quick Watermark Intensity Cycler */}
          <button
            onClick={cycleWatermarkIntensity}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition flex items-center gap-1.5 cursor-pointer shadow-sm ${
              watermarkIntensity > 0
                ? 'bg-blue-50 hover:bg-blue-100 text-blue-900 border-blue-300'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-500 border-slate-300'
            }`}
            title="ক্লিক করে জলছাপ ইনটেনসিটি পরিবর্তন করুন (০% ➔ ৫% ➔ ৮% ➔ ১৪% ➔ ২০% ➔ ২৮%)"
          >
            <Droplet className={`w-3.5 h-3.5 ${watermarkIntensity > 0 ? 'text-blue-600 fill-blue-500/20' : 'text-slate-400'}`} />
            <span>জলছাপ: {watermarkIntensity === 0 ? 'বন্ধ (০%)' : `${Math.round(watermarkIntensity * 100)}%`}</span>
          </button>

          {/* Quick Logo Style Selector Dropdown */}
          <div className="relative inline-block">
            <select
              value={logoStyle}
              onChange={(e) => setLogoStyle(e.target.value as LogoStylePreset)}
              className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-950 font-bold text-xs rounded-lg border border-emerald-300 transition cursor-pointer outline-none"
              title="লোগো ও সিকিউরিটি সিল পরিবর্তন করুন"
            >
              <option value="up-seal">🏛️ বহেড়াতৈল ইউপি সিল</option>
              <option value="govt-seal">🇧🇩 বাংলাদেশ সরকার সিল</option>
              <option value="digital-shield">🛡️ ডিজিটাল শিল্ড সিল</option>
              <option value="smart-emblem">🌐 স্মার্ট সেবা প্রতীক</option>
              <option value="golden-crest">👑 গোল্ডেন রয়্যাল ক্রেস্ট</option>
            </select>
          </div>

          {/* Google Chat Share Button */}
          {onShareToGoogleChat && (
            <button
              onClick={() => onShareToGoogleChat(certificate)}
              className="px-3.5 py-2 bg-gradient-to-r from-teal-800 to-emerald-900 hover:from-teal-700 hover:to-emerald-800 text-white font-bold text-xs rounded-lg shadow transition flex items-center gap-1.5 cursor-pointer border border-emerald-500/40"
              title="ইউপি গুগল চ্যাট টিম স্পেসে সনদের অফিশিয়াল বিজ্ঞপ্তি পোস্ট করুন"
            >
              <MessageSquare className="w-3.5 h-3.5 text-amber-300" />
              <span>গুগল চ্যাটে শেয়ার</span>
            </button>
          )}

          {/* WhatsApp Share Button */}
          <button
            id="share-via-whatsapp-btn"
            onClick={() => setIsWhatsAppModalOpen(true)}
            className="px-3.5 py-2 bg-[#25D366] hover:bg-[#20bd5a] text-slate-950 font-black text-xs rounded-lg shadow-sm hover:shadow transition flex items-center gap-1.5 cursor-pointer border border-emerald-600/30"
            title="নাগরিকের হোয়াটসঅ্যাপ নম্বরে সনদের ভেরিফিকেশন লিংক ও প্রি-ফিল্ড মেসেজ পাঠান"
          >
            <Share2 className="w-3.5 h-3.5 text-slate-950 stroke-[2.5]" />
            <span>Share via WhatsApp</span>
          </button>

          {/* Compact Mode Toggle for 1-Page Guarantee */}
          <button
            onClick={() => setIsCompactMode(!isCompactMode)}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition flex items-center gap-1.5 cursor-pointer shadow-sm ${
              isCompactMode
                ? 'bg-amber-400 text-slate-950 border-amber-500 font-black'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300'
            }`}
            title="A4 ১ পাতায় সম্পূর্ণ সনদ ফিট নিশ্চিত করার জন্য কমপ্যাক্ট মোড"
          >
            <Maximize2 className="w-3.5 h-3.5 text-emerald-950" />
            <span>{isCompactMode ? '📄 ১ পাতায় ফিট (Compact ON)' : '📄 সাধারণ সাইজ'}</span>
          </button>

          {/* Edit AI Text Toggle */}
          <button
            onClick={() => setIsEditingText(!isEditingText)}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition flex items-center gap-1.5 cursor-pointer shadow-sm ${
              isEditingText
                ? 'bg-amber-400 text-slate-950 border-amber-500'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300'
            }`}
            title="AI এর ভুল সংশোধন বা সনদের বিবরণী সরাসরি এডিট করুন"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>{isEditingText ? 'এডিটর বন্ধ করুন' : 'সনদের টেক্সট এডিট'}</span>
          </button>

          {/* Header Toggle */}
          <button
            onClick={() => setShowHeaderInPrint(!showHeaderInPrint)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition flex items-center gap-1.5 cursor-pointer ${
              showHeaderInPrint
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                : 'bg-amber-50 text-amber-800 border-amber-300'
            }`}
            title="সরকারি প্যাডে প্রিন্ট করার জন্য হেডার অন/অফ করুন"
          >
            {showHeaderInPrint ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>{showHeaderInPrint ? 'হেডার অন' : 'হেডার লুকানো'}</span>
          </button>

          {/* Bottom Signatures, Seal & QR Code Toggle */}
          <button
            id="toggle-bottom-section-btn"
            onClick={() => setShowBottomSection(!showBottomSection)}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition flex items-center gap-1.5 cursor-pointer shadow-sm ${
              showBottomSection
                ? 'bg-emerald-50 text-emerald-900 border-emerald-300 hover:bg-emerald-100'
                : 'bg-rose-50 text-rose-800 border-rose-300 font-black hover:bg-rose-100'
            }`}
            title="ম্যানুয়াল প্যাডে প্রিন্ট বা সিল দেওয়ার জন্য নিচের সিল, স্বাক্ষর ও QR কোড দেখান বা লুকান"
          >
            {showBottomSection ? <Eye className="w-3.5 h-3.5 text-emerald-700" /> : <EyeOff className="w-3.5 h-3.5 text-rose-600" />}
            <span>{showBottomSection ? 'সিল ও QR অন' : '🚫 সিল, সাইন ও QR লুকানো'}</span>
          </button>

          {/* Google Doc Export Button */}
          <button
            id="google-doc-export-btn"
            onClick={() => setIsGoogleDocModalOpen(true)}
            className="px-3.5 py-2 bg-blue-700 hover:bg-blue-600 text-white font-bold text-xs rounded-lg shadow transition flex items-center gap-1.5 cursor-pointer border border-blue-500"
            title="Google Doc বা Word ফাইলে সনদ প্রিন্ট ও এডিট করুন"
          >
            <FileText className="w-3.5 h-3.5 text-blue-200" />
            <span>Google Doc প্রিন্ট</span>
          </button>

          {/* Live Customizer Toggle */}
          <button
            onClick={() => setShowCustomizer(!showCustomizer)}
            className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-amber-300 font-bold text-xs rounded-lg transition flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>কাস্টমাইজার</span>
          </button>

          {/* Print Button */}
          <button
            onClick={handlePrint}
            className="px-4 py-2 bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow transition flex items-center gap-2 cursor-pointer"
          >
            <Printer className="w-4 h-4 text-amber-300" />
            <span>প্রিন্ট করুন</span>
          </button>
        </div>
      </div>

      {/* Live Customizer Panel */}
      {showCustomizer && (
        <div className="bg-slate-900 text-white p-4 rounded-xl border border-slate-800 space-y-4 print:hidden">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold text-amber-300 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              <span>সনদের টেমপ্লেট, A4 সাইজ ও লেআউট কাস্টমাইজার</span>
            </h3>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setIsCompactMode(true);
                  setFontSize(15);
                  setBlankSealSize(72);
                  setPrintScale(95);
                }}
                className="px-2.5 py-1 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-[11px] rounded transition cursor-pointer"
              >
                ⚡ ১-পাতা অটো-ফিট সেট করুন
              </button>
              <span className="text-[10px] bg-emerald-900 text-emerald-200 px-2 py-0.5 rounded font-mono">
                REAL-TIME PREVIEW
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            {/* Header Style */}
            <div>
              <label className="block text-slate-400 font-semibold mb-1">হেডার লেআউট:</label>
              <select
                value={headerStyle}
                onChange={(e) => setHeaderStyle(e.target.value as any)}
                className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 text-white rounded focus:border-amber-400 font-semibold"
              >
                <option value="tri-column">১. ত্রিমুখী ৩-কলাম হেডার (ছবি অনুযায়ী)</option>
                <option value="centered">২. সেন্টার্ড লোগো ও টাইটেল</option>
                <option value="classic">৩. ক্লাসিকাল সরকারি প্যাড</option>
              </select>
            </div>

            {/* Font Size */}
            <div>
              <label className="block text-slate-400 font-semibold mb-1">ফন্ট সাইজ (পিটি): {fontSize}px</label>
              <input
                type="range"
                min={12}
                max={20}
                value={fontSize}
                onChange={(e) => setFontSize(Number(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer"
              />
            </div>

            {/* Page Orientation Selector */}
            <div>
              <label className="block text-slate-400 font-semibold mb-1">সনদের ওরিয়েন্টেশন (Page Orientation):</label>
              <select
                value={pageOrientation}
                onChange={(e) => setPageOrientation(e.target.value as any)}
                className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 text-amber-300 rounded focus:border-amber-400 font-bold"
              >
                <option value="portrait">📱 পোর্ট্রেট - Portrait (খাড়া A4 - সেরা)</option>
                <option value="landscape">🖥️ ল্যান্ডস্কেপ - Landscape (আড়াআড়ি ওয়াইড)</option>
              </select>
            </div>
            {/* Date Format Style */}
            <div>
              <label className="block text-slate-400 font-semibold mb-1">তারিখ ফরম্যাট (Bangla Date):</label>
              <select
                value={dateFormatStyle}
                onChange={(e) => setDateFormatStyle(e.target.value as any)}
                className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 text-white rounded focus:border-amber-400 font-semibold"
              >
                <option value="full">১. পূর্ণাঙ্গ বাংলা (০৫ আগস্ট, ২০২৬ খ্রি.)</option>
                <option value="numeric">২. নিউমেরিক সংখ্যা (০৫/০৮/২০২৬ খ্রি.)</option>
                <option value="long">৩. বিস্তারিত অর্ডিনাল (৫ই আগস্ট, ২০২৬ খ্রিস্টাব্দ)</option>
                <option value="banglaSan">৪. স্থানীয় বাংলা সন (২০ শ্রাবণ, ১৪৩৩ বঙ্গাব্দ)</option>
                <option value="both">৫. যৌথ উভয় তারিখ (ইংরেজি + বঙ্গাব্দ)</option>
              </select>
            </div>

            {/* Print Scale Selection */}
            <div>
              <label className="block text-slate-400 font-semibold mb-1">প্রিন্ট স্কেল (%) (A4 ফিটিং):</label>
              <select
                value={printScale}
                onChange={(e) => setPrintScale(Number(e.target.value))}
                className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 text-amber-300 rounded focus:border-amber-400 font-bold"
              >
                <option value={100}>১০০% (স্বাভাবিক সাইজ)</option>
                <option value={95}>৯৫% (A4 ১ পাতায় উপযুক্ত)</option>
                <option value={90}>৯০% (কমপ্যাক্ট ফিট)</option>
                <option value={85}>৮৫% (দীর্ঘ আবেদনের জন্য)</option>
                <option value={80}>৮০% (অতিরিক্ত বড় টেবিলের জন্য)</option>
              </select>
            </div>

            {/* 1. Official Logo Style Presets & Scope Section */}
            <div className="pt-3 border-t border-slate-800 col-span-full space-y-3 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-amber-300 font-bold text-xs flex items-center gap-1.5">
                  <ImageIcon className="w-4 h-4 text-amber-400" />
                  <span>🏛️ অফিসিয়াল লোগো ও সিকিউরিটি প্রতীক স্টাইল (Logo Style Presets)</span>
                </span>
                <span className="text-[10px] text-slate-400 font-medium">
                  হেডার, QR কোড ও ব্যাকগ্রাউন্ডের জন্য ৫টি স্ট্যান্ডার্ড শৈলী
                </span>
              </div>

              {/* Logo Style Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
                {(Object.keys(LOGO_PRESETS) as LogoStylePreset[]).map((key) => {
                  const preset = LOGO_PRESETS[key];
                  const isSelected = logoStyle === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setLogoStyle(key)}
                      className={`p-2.5 rounded-lg border text-left transition flex flex-col items-center justify-between gap-2 cursor-pointer ${
                        isSelected
                          ? 'bg-amber-950/40 border-amber-400 ring-2 ring-amber-400/30'
                          : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700 text-slate-300'
                      }`}
                    >
                      <div className="w-10 h-10 rounded-full bg-white p-1 flex items-center justify-center shadow-sm shrink-0">
                        <img 
                          src={preset.url} 
                          alt={preset.labelBn} 
                          className="w-full h-full object-contain"
                        />
                      </div>
                      <div className="text-center w-full min-w-0">
                        <div className={`text-[11px] font-bold truncate ${isSelected ? 'text-amber-300' : 'text-slate-200'}`}>
                          {preset.labelBn}
                        </div>
                        <div className="text-[9px] text-slate-400 line-clamp-1">
                          {preset.description}
                        </div>
                      </div>
                      {isSelected && (
                        <span className="text-[9px] font-black bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded-full mt-0.5">
                          ✓ সক্রিয়
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Logo Scope Selector */}
              <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="text-slate-300 font-semibold">লোগো পরিবর্তনের প্রয়োগক্ষেত্র (Apply Scope):</span>
                <div className="flex flex-wrap items-center gap-3">
                  {[
                    { id: 'all', label: '🌐 সম্পূর্ণ সনদে (সবখানে)' },
                    { id: 'qr-only', label: '🔍 শুধু QR কোডে' },
                    { id: 'header-only', label: '🏛️ শুধু হেডারে' },
                    { id: 'watermark-only', label: '💧 শুধু জলছাপে' }
                  ].map((scope) => (
                    <label key={scope.id} className="inline-flex items-center gap-1.5 text-[11px] text-slate-300 font-semibold cursor-pointer">
                      <input
                        type="radio"
                        name="applyLogoTo"
                        value={scope.id}
                        checked={applyLogoTo === scope.id}
                        onChange={(e) => setApplyLogoTo(e.target.value as any)}
                        className="accent-amber-400 cursor-pointer"
                      />
                      <span>{scope.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>

            {/* 2. Watermark Intensity & Security Layout Section */}
            <div className="pt-3 border-t border-slate-800 col-span-full space-y-3 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-blue-300 font-bold text-xs flex items-center gap-1.5">
                  <Droplet className="w-4 h-4 text-blue-400" />
                  <span>💧 জলছাপ / ওয়াটারমার্ক ইনটেনসিটি ও স্টাইল (Watermark Intensity)</span>
                </span>
                <span className="text-[10px] font-mono text-amber-300 font-bold bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                  বর্তমান ইনটেনসিটি: {watermarkIntensity === 0 ? 'বন্ধ (০%)' : `${Math.round(watermarkIntensity * 100)}%`}
                </span>
              </div>

              {/* Watermark Intensity Preset Buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                {WATERMARK_INTENSITY_PRESETS.map((preset) => {
                  const isSelected = Math.abs(watermarkIntensity - preset.value) < 0.01;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => setWatermarkIntensity(preset.value)}
                      className={`px-2.5 py-2 rounded-lg border text-center transition flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                        isSelected
                          ? 'bg-blue-950/50 border-blue-400 text-blue-200 ring-2 ring-blue-400/30'
                          : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700 text-slate-300'
                      }`}
                    >
                      <span className="text-xs font-bold">{preset.labelBn}</span>
                      <span className="text-[9px] text-slate-400">{preset.description}</span>
                    </button>
                  );
                })}
              </div>

              {/* Smooth Range Slider & Pattern Layout Style */}
              <div className="pt-2 border-t border-slate-800/80 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div>
                  <div className="flex items-center justify-between text-slate-300 font-semibold mb-1">
                    <span>ইনটেনসিটি স্লাইডার (Custom %):</span>
                    <span className="text-amber-300 font-bold">{Math.round(watermarkIntensity * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={0.35}
                    step={0.01}
                    value={watermarkIntensity}
                    onChange={(e) => setWatermarkIntensity(Number(e.target.value))}
                    className="w-full accent-blue-400 cursor-pointer"
                  />
                  <div className="flex justify-between text-[9px] text-slate-500 mt-0.5">
                    <span>০% (সম্পূর্ণ বন্ধ)</span>
                    <span>৮% (অফিসিয়াল স্ট্যান্ডার্ড)</span>
                    <span>৩৫% (গাঢ় সিকিউরিটি)</span>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">জলছাপ বিন্যাস শৈলী (Watermark Layout):</label>
                  <select
                    value={watermarkStyle}
                    disabled={watermarkIntensity === 0}
                    onChange={(e) => setWatermarkStyle(e.target.value as any)}
                    className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 text-slate-200 rounded focus:border-amber-400 font-bold disabled:opacity-40"
                  >
                    <option value="single-centered">১. একক কেন্দ্রস্থ সিল (Single Centered Seal)</option>
                    <option value="dual-emblem">২. দ্বিমুখী রাষ্ট্রীয় ও ইউপি মনোগ্রাম (Dual Emblem)</option>
                    <option value="security-pattern">৩. ডায়াগোনাল সিকিউরিটি রিপিটেশন (Security Matrix)</option>
                    <option value="corner-crest">৪. ৪-কোণা কর্নার গার্ড ক্রেস্ট (Corner Crest Guard)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* QR Code Styling & Logo Embedding Options */}
            <div className="pt-3 border-t border-slate-800 col-span-full space-y-3 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-amber-300 font-bold text-xs flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>🔍 QR কোড স্টাইলিং ও ক্রিপ্টোগ্রাফিক ভেরিফিকেশন (QR Code Styling)</span>
                </span>
                <span className="text-[10px] text-slate-400 font-medium">
                  ক্রিপ্টোগ্রাফিক ভেরিফিকেশন ও অফিসিয়াল প্যাটার্ন
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                {/* QR Color Scheme Preset */}
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">রঙের স্কিম (Color Scheme):</label>
                  <select
                    value={qrColorScheme}
                    onChange={(e) => setQrColorScheme(e.target.value as QrColorScheme)}
                    className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 text-slate-200 rounded focus:border-amber-400 font-bold"
                  >
                    <option value="govt-emerald">সবুজ (Govt Emerald)</option>
                    <option value="classic-black">ক্লাসিক কালো (Monochrome Black)</option>
                    <option value="emerald-gold">রয়্যাল গোল্ড ও এমারেল্ড (Emerald & Gold)</option>
                    <option value="govt-crimson">লাল ও সাদা (Govt Crimson Red)</option>
                    <option value="navy-slate">নেভি ব্লু (Deep Navy)</option>
                    <option value="teal-cyan">ডিজিটাল টিল (Digital Teal)</option>
                    <option value="custom">কাস্টম কালার (Custom Colors)</option>
                  </select>
                </div>

                {/* QR Frame Style */}
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">ফ্রেম ও বর্ডার স্টাইল:</label>
                  <select
                    value={qrFrameStyle}
                    onChange={(e) => setQrFrameStyle(e.target.value as any)}
                    className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 text-slate-200 rounded focus:border-amber-400 font-bold"
                  >
                    <option value="clean">১. ক্লিন বর্ডার (Clean Border)</option>
                    <option value="double">২. ডাবল সিল ফ্রেম (Double Frame)</option>
                    <option value="badge">৩. ডিজিটাল ভেরিফায়েড ব্যাজ (Badge)</option>
                    <option value="minimal">৪. মিনিমাল নো-বর্ডার (Minimal)</option>
                  </select>
                </div>

                {/* Logo Embed Toggle */}
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">সেন্টার লোগো এমবেড:</label>
                  <div className="flex items-center gap-2 mt-1">
                    <label className="inline-flex items-center gap-1.5 text-xs text-amber-300 font-bold cursor-pointer">
                      <input
                        type="checkbox"
                        checked={qrEmbedLogo}
                        onChange={(e) => setQrEmbedLogo(e.target.checked)}
                        className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
                      />
                      <span>ইউপি সিল / লোগো এমবেড</span>
                    </label>
                  </div>
                </div>

                {/* Logo Shape (if embed enabled) */}
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">এমবেডেড লোগোর শেপ:</label>
                  <select
                    value={qrLogoShape}
                    disabled={!qrEmbedLogo}
                    onChange={(e) => setQrLogoShape(e.target.value as any)}
                    className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 text-slate-200 rounded focus:border-amber-400 font-bold disabled:opacity-50"
                  >
                    <option value="circle">গোলাকার সিল (Circle)</option>
                    <option value="rounded">রাউন্ডেড স্কয়ার (Rounded Square)</option>
                  </select>
                </div>
              </div>

              {/* Custom Color Pickers if 'custom' is selected */}
              {qrColorScheme === 'custom' && (
                <div className="pt-2 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="flex items-center justify-between bg-slate-800/80 px-3 py-2 rounded-lg border border-slate-700">
                    <span className="text-slate-300 font-semibold">QR প্যাটার্ন কালার (Dark):</span>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={qrCustomDarkColor}
                        onChange={(e) => setQrCustomDarkColor(e.target.value)}
                        className="w-7 h-7 rounded border border-slate-600 bg-transparent cursor-pointer"
                      />
                      <span className="font-mono text-[11px] text-amber-300 font-bold">{qrCustomDarkColor}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between bg-slate-800/80 px-3 py-2 rounded-lg border border-slate-700">
                    <span className="text-slate-300 font-semibold">QR ব্যাকগ্রাউন্ড কালার (Light):</span>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={qrCustomLightColor}
                        onChange={(e) => setQrCustomLightColor(e.target.value)}
                        className="w-7 h-7 rounded border border-slate-600 bg-transparent cursor-pointer"
                      />
                      <span className="font-mono text-[11px] text-amber-300 font-bold">{qrCustomLightColor}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Signature, Seal, QR Code & Compact Mode Display Toggles */}
            <div className="pt-3 border-t border-slate-800 col-span-full space-y-3">
              <div className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
                ⚙️ নিচের সিল, সাইন ও ভেরিফিকেশন উপাদান দৃশ্যমানতা নিয়ন্ত্রণ (Print Visibility)
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 text-xs">
                <label className="text-amber-300 font-bold cursor-pointer flex items-center gap-2 bg-slate-800/60 p-2 rounded-lg border border-slate-700">
                  <input
                    type="checkbox"
                    checked={isCompactMode}
                    onChange={(e) => setIsCompactMode(e.target.checked)}
                    className="w-4 h-4 accent-amber-400 cursor-pointer"
                  />
                  <span>📄 ১-পাতা কমপ্যাক্ট মোড</span>
                </label>

                <label className="text-emerald-300 font-bold cursor-pointer flex items-center gap-2 bg-slate-800/60 p-2 rounded-lg border border-slate-700">
                  <input
                    type="checkbox"
                    checked={showBottomSection}
                    onChange={(e) => setShowBottomSection(e.target.checked)}
                    className="w-4 h-4 accent-emerald-400 cursor-pointer"
                  />
                  <span>🟢 সম্পূর্ণ নিচের সেকশন দৃশ্যমান</span>
                </label>

                <label className="text-slate-300 font-semibold cursor-pointer flex items-center gap-2 bg-slate-800/60 p-2 rounded-lg border border-slate-700">
                  <input
                    type="checkbox"
                    checked={showQrCode}
                    disabled={!showBottomSection}
                    onChange={(e) => setShowQrCode(e.target.checked)}
                    className="w-4 h-4 accent-emerald-400 cursor-pointer disabled:opacity-40"
                  />
                  <span>QR কোড ভেরিফিকেশন ব্লক</span>
                </label>

                <label className="text-slate-300 font-semibold cursor-pointer flex items-center gap-2 bg-slate-800/60 p-2 rounded-lg border border-slate-700">
                  <input
                    type="checkbox"
                    checked={showBlankSeal}
                    disabled={!showBottomSection}
                    onChange={(e) => setShowBlankSeal(e.target.checked)}
                    className="w-4 h-4 accent-emerald-400 cursor-pointer disabled:opacity-40"
                  />
                  <span>ম্যানুয়াল সিল মোহরের স্থান</span>
                </label>

                <label className="text-slate-300 font-semibold cursor-pointer flex items-center gap-2 bg-slate-800/60 p-2 rounded-lg border border-slate-700">
                  <input
                    type="checkbox"
                    checked={showSignatures}
                    disabled={!showBottomSection}
                    onChange={(e) => setShowSignatures(e.target.checked)}
                    className="w-4 h-4 accent-emerald-400 cursor-pointer disabled:opacity-40"
                  />
                  <span>চেয়ারম্যান স্বাক্ষর ব্লক</span>
                </label>

                <label className="text-slate-300 font-semibold cursor-pointer flex items-center gap-2 bg-slate-800/60 p-2 rounded-lg border border-slate-700">
                  <input
                    type="checkbox"
                    checked={showSecretarySig}
                    disabled={!showBottomSection || !showSignatures}
                    onChange={(e) => setShowSecretarySig(e.target.checked)}
                    className="w-4 h-4 accent-emerald-400 cursor-pointer disabled:opacity-40"
                  />
                  <span>সচিবের স্বাক্ষর ব্লক</span>
                </label>

                <label className="text-slate-300 font-semibold cursor-pointer flex items-center gap-2 bg-slate-800/60 p-2 rounded-lg border border-slate-700">
                  <input
                    type="checkbox"
                    checked={showDigitalSig}
                    disabled={!showBottomSection || !showSignatures}
                    onChange={(e) => setShowDigitalSig(e.target.checked)}
                    className="w-4 h-4 accent-amber-400 cursor-pointer disabled:opacity-40"
                  />
                  <span>ডিজিটাল ই-স্বাক্ষর ইমেজ এমবেড</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Certificate Print Paper Canvas */}
      <div 
        ref={printRef} 
        id="certificate-print-area"
        className={`print-paper bg-white p-6 md:p-10 rounded-2xl shadow-xl border border-slate-300 mx-auto relative overflow-hidden text-slate-900 print:shadow-none print:p-2 print:border-none print:m-0 print:w-full print:max-w-none print:rounded-none ${
          pageOrientation === 'landscape' ? 'is-landscape max-w-5xl' : 'is-portrait max-w-4xl'
        } ${
          isCompactMode ? 'is-compact-mode' : ''
        }`}
        style={{ 
          minHeight: pageOrientation === 'landscape' ? (isCompactMode ? '600px' : '720px') : (isCompactMode ? '820px' : '960px'),
          transform: printScale !== 100 ? `scale(${printScale / 100})` : undefined,
          transformOrigin: 'top center'
        }}
      >
        {/* Dynamic Background Watermark based on watermarkIntensity, watermarkStyle & selected logo */}
        {watermarkIntensity > 0 && (
          <div 
            className="absolute inset-0 flex items-center justify-center pointer-events-none select-none overflow-hidden z-0"
            style={{ opacity: watermarkIntensity }}
          >
            {watermarkStyle === 'single-centered' && (
              <img 
                src={getResolvedLogoUrl('watermark')} 
                alt="Watermark Seal" 
                className="w-80 h-80 md:w-96 md:h-96 object-contain"
                onError={(e) => {
                  const target = e.currentTarget as HTMLImageElement;
                  if (target.src !== window.location.origin + '/baheratail_seal.svg') {
                    target.src = '/baheratail_seal.svg';
                  }
                }}
              />
            )}

            {watermarkStyle === 'dual-emblem' && (
              <div className="flex items-center justify-center gap-12 w-full max-w-2xl px-6">
                <img 
                  src={LOGO_PRESETS['govt-seal'].url} 
                  alt="Govt Seal" 
                  className="w-48 h-48 md:w-56 md:h-56 object-contain"
                />
                <img 
                  src={LOGO_PRESETS['up-seal'].url} 
                  alt="UP Seal" 
                  className="w-48 h-48 md:w-56 md:h-56 object-contain"
                />
              </div>
            )}

            {watermarkStyle === 'security-pattern' && (
              <div className="w-full h-full flex flex-col items-center justify-center rotate-[-22deg] scale-125 opacity-80">
                <div className="grid grid-cols-3 gap-14 items-center justify-items-center">
                  {[...Array(9)].map((_, i) => (
                    <div key={i} className="flex flex-col items-center justify-center">
                      <img 
                        src={getResolvedLogoUrl('watermark')} 
                        alt="Security Watermark Pattern" 
                        className="w-20 h-20 md:w-24 md:h-24 object-contain"
                      />
                      <span className="text-[9px] font-black tracking-widest text-emerald-950 font-mono mt-1 select-none">
                        OFFICIAL VERIFIED UPMS
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {watermarkStyle === 'corner-crest' && (
              <div className="w-full h-full relative">
                <img src={getResolvedLogoUrl('watermark')} alt="Corner Crest Top Left" className="absolute top-6 left-6 w-24 h-24 object-contain" />
                <img src={getResolvedLogoUrl('watermark')} alt="Corner Crest Top Right" className="absolute top-6 right-6 w-24 h-24 object-contain" />
                <img src={getResolvedLogoUrl('watermark')} alt="Corner Crest Center" className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 object-contain" />
                <img src={getResolvedLogoUrl('watermark')} alt="Corner Crest Bottom Left" className="absolute bottom-6 left-6 w-24 h-24 object-contain" />
                <img src={getResolvedLogoUrl('watermark')} alt="Corner Crest Bottom Right" className="absolute bottom-6 right-6 w-24 h-24 object-contain" />
              </div>
            )}
          </div>
        )}

        {/* Outer Frame Border matching chosen borderStyle */}
        <div 
          className={`cert-inner-frame p-5 md:p-7 h-full flex flex-col justify-between relative z-10 ${
            pageOrientation === 'landscape' ? 'min-h-[540px]' : 'min-h-[800px]'
          } print:min-h-full print:h-full flex-1 ${
            borderStyle === 'double-green-red'
              ? 'border-4 border-emerald-950 outline-2 outline-red-700 outline-offset-2'
              : borderStyle === 'double-green'
              ? 'border-4 border-double border-emerald-900'
              : borderStyle === 'single-green'
              ? 'border-2 border-emerald-800'
              : ''
          }`}
        >
          
          {/* Header Section */}
          <div>
            {showHeaderInPrint && (
              <header className="cert-header pb-2 border-b-2 border-emerald-900">
                {/* Header Style 1: Tri-Column (User Requested Layout) */}
                {headerStyle === 'tri-column' && (
                  <div className="flex justify-between items-start w-full gap-2 my-1">
                    {/* Left Column (Width: ~32%): Chairman Information (5 Lines, pushed down below address level) */}
                    <div className="w-[32%] min-w-0 text-left space-y-0.5 break-words pt-11">
                      <p className="text-xs md:text-sm font-extrabold text-slate-950 leading-snug">{config.chairmanName}</p>
                      <p className="text-[11px] md:text-xs font-bold text-emerald-900 leading-snug">{config.chairmanTitle}</p>
                      <p className="text-[10px] md:text-[11px] text-slate-800 font-semibold leading-snug">
                        {config.upName ? config.upName.replace(/পরিষদ/g, '').trim() : '০২নং বহেড়াতৈল ইউনিয়ন'}
                      </p>
                      <p className="text-[10px] md:text-[11px] text-slate-600 font-medium leading-snug">{config.upazila}, {config.district}।</p>
                      <p className="text-[10px] md:text-[11px] text-slate-700 font-medium leading-snug">মোবাইল: {config.chairmanPhone}</p>
                    </div>

                    {/* Middle Column (Width: ~36%, text-align: center): Govt Title, UP Heading, Address, Logo */}
                    <div className="w-[36%] min-w-0 text-center flex flex-col items-center justify-center break-words px-1">
                      <p className="text-center text-xs md:text-sm font-extrabold text-emerald-950 tracking-wide mb-0.5 leading-snug whitespace-nowrap">
                        গণপ্রজাতন্ত্রী বাংলাদেশ সরকার
                      </p>
                      <h2 className="text-base md:text-xl font-black text-emerald-950 leading-tight whitespace-nowrap">
                        {config.upName}
                      </h2>
                      <p className="text-[11px] md:text-xs font-bold text-emerald-900 leading-tight whitespace-nowrap my-0.5">
                        {config.upazila}, {config.district}।
                      </p>
                      <img 
                        src={getResolvedLogoUrl('header')} 
                        alt={config?.upName || "Government / UP Logo"} 
                        className="cert-logo w-11 h-11 md:w-13 md:h-13 object-contain my-1 mx-auto"
                        onError={(e) => {
                          const target = e.currentTarget as HTMLImageElement;
                          if (target.src !== window.location.origin + '/baheratail_seal.svg') {
                            target.src = '/baheratail_seal.svg';
                          }
                        }}
                      />
                    </div>

                    {/* Right Column (Width: ~32%): Chairman Details (5 Lines, pushed down below address level) */}
                    <div className="w-[32%] min-w-0 text-right space-y-0.5 break-words pt-11">
                      <p className="text-xs md:text-sm font-extrabold text-slate-950 leading-snug">{config.chairmanName}</p>
                      <p className="text-[11px] md:text-xs font-bold text-emerald-900 leading-snug">{config.chairmanTitle}</p>
                      <p className="text-[10px] md:text-[11px] text-slate-800 font-semibold leading-snug">
                        {config.upName ? config.upName.replace(/পরিষদ/g, '').trim() : '০২নং বহেড়াতৈল ইউনিয়ন'}
                      </p>
                      <p className="text-[10px] md:text-[11px] text-slate-600 font-medium leading-snug">{config.upazila}, {config.district}।</p>
                      <p className="text-[10px] md:text-[11px] text-slate-700 font-medium leading-snug">মোবাইল: {config.chairmanPhone}</p>
                    </div>
                  </div>
                )}

                {/* Header Style 2: Centered */}
                {headerStyle === 'centered' && (
                  <div className="text-center flex flex-col items-center justify-center my-2">
                    <p className="text-xs md:text-sm font-extrabold text-emerald-950 tracking-wide mb-0.5">
                      গণপ্রজাতন্ত্রী বাংলাদেশ সরকার
                    </p>
                    <h2 className="text-xl md:text-2xl font-black text-emerald-950 leading-tight">
                      {config.upName}
                    </h2>
                    <img 
                      src={getResolvedLogoUrl('header')} 
                      alt={config?.upName || "Logo"} 
                      className="w-14 h-14 md:w-16 md:h-16 object-contain my-1" 
                      onError={(e) => {
                        const target = e.currentTarget as HTMLImageElement;
                        if (target.src !== window.location.origin + '/baheratail_seal.svg') {
                          target.src = '/baheratail_seal.svg';
                        }
                      }}
                    />
                    <p className="text-xs font-bold text-emerald-900">{config.address}</p>
                  </div>
                )}

                {/* Header Style 3: Classic */}
                {headerStyle === 'classic' && (
                  <div className="flex items-center justify-between my-2">
                    <div className="text-left text-xs space-y-0.5">
                      <p className="font-extrabold text-slate-950">{config.chairmanName}</p>
                      <p className="text-emerald-800 font-bold">{config.chairmanTitle}</p>
                      <p className="text-slate-700 font-semibold">{config.upName}</p>
                      <p className="text-slate-600">{config.upazila}, {config.district}</p>
                    </div>
                    <div className="text-center flex flex-col items-center">
                      <p className="text-xs font-extrabold text-emerald-950">গণপ্রজাতন্ত্রী বাংলাদেশ সরকার</p>
                      <h2 className="text-lg md:text-xl font-black text-emerald-950">{config.upName}</h2>
                      <img 
                        src={getResolvedLogoUrl('header')} 
                        alt={config?.upName || "Logo"} 
                        className="w-12 h-12 object-contain my-1" 
                        onError={(e) => {
                          const target = e.currentTarget as HTMLImageElement;
                          if (target.src !== window.location.origin + '/baheratail_seal.svg') {
                            target.src = '/baheratail_seal.svg';
                          }
                        }}
                      />
                      <p className="text-[11px] font-bold text-emerald-900">{config.address}</p>
                    </div>
                    <div className="text-right text-xs space-y-0.5">
                      <p className="font-extrabold text-slate-950">{config.chairmanName}</p>
                      <p className="text-emerald-800 font-bold">{config.chairmanTitle}</p>
                      <p className="text-slate-700 font-semibold">{config.upName}</p>
                      <p className="text-slate-600">{config.upazila}, {config.district}</p>
                    </div>
                  </div>
                )}

                <div className="h-0.5 bg-emerald-900 w-full my-1" />
              </header>
            )}

            {/* Metadata Bar: Memo No & Date */}
            <div className="flex justify-between items-center my-4 font-bold text-xs text-slate-900 border-b border-slate-300 pb-2">
              <div>
                <span>স্মারক নং: </span>
                <span className="text-emerald-900 font-mono text-sm">{certificate.memoNo}</span>
              </div>
              <div>
                <span>তারিখ: </span>
                <span className="text-emerald-900 font-bold">
                  {formatBanglaDate(certificate.issueDateEn || certificate.issueDate, dateFormatStyle)}
                </span>
              </div>
            </div>

            {/* Certificate Title Badge */}
            <div className="cert-title-badge text-center my-5 print:my-2">
              <span className="inline-block bg-emerald-950 text-white font-extrabold text-lg md:text-xl px-8 py-1.5 rounded-md shadow-sm border border-emerald-900 tracking-wider">
                {certificate.typeLabel}
              </span>
            </div>

            {/* Main Bureaucratic Body Text with Dynamic Font Size & AI Correction Mode */}
            {isEditingText ? (
              <div className="my-4 p-4 bg-amber-50 rounded-xl border-2 border-amber-300 space-y-2 print:hidden">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-700" />
                    <span>এআই জেনারেটেড সনদের বিবরণী সরাসরি এডিট / সংশোধন করুন:</span>
                  </span>
                  <button
                    onClick={() => setIsEditingText(false)}
                    className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded transition cursor-pointer"
                  >
                    সেভ ও সম্পন্ন
                  </button>
                </div>
                <textarea
                  rows={6}
                  value={editableBodyText}
                  onChange={(e) => setEditableBodyText(e.target.value)}
                  className="w-full p-3 bg-white border border-amber-300 rounded-lg text-sm text-slate-900 leading-relaxed focus:border-amber-600 focus:outline-none"
                  style={{ fontSize: `${fontSize}px` }}
                />
              </div>
            ) : (
              <div 
                className="cert-body-text my-5 print:my-2 text-justify leading-relaxed font-medium text-slate-900 whitespace-pre-line px-2 indent-8"
                style={{ fontSize: `${fontSize}px` }}
              >
                {editableBodyText}
              </div>
            )}

            {/* Dynamic Tables (Warish / Family List / Additional Statement) */}
            {Object.keys(extraTables).length > 0 && (
              <div className="my-4 space-y-3">
                {Object.entries(extraTables).map(([tableKey, rows]) => (
                  <div key={tableKey} className="space-y-1.5">
                    <p className="font-bold text-xs text-black border-b-2 border-black pb-1">
                      অতিরিক্ত সংযুক্ত বিবরণী (উত্তরাধিকার / পরিবার সদস্য তালিকা):
                    </p>
                    <table className="w-full text-xs text-left border-collapse border border-black bg-white text-black" style={{ color: '#000000', backgroundColor: '#ffffff', borderColor: '#000000' }}>
                      <thead>
                        <tr className="bg-white text-black font-bold" style={{ color: '#000000', backgroundColor: '#ffffff' }}>
                          <th className="border border-black p-2 text-center w-12 text-black bg-white" style={{ color: '#000000', backgroundColor: '#ffffff', borderColor: '#000000' }}>ক্রমিক নং</th>
                          <th className="border border-black p-2 text-black bg-white" style={{ color: '#000000', backgroundColor: '#ffffff', borderColor: '#000000' }}>নাম</th>
                          <th className="border border-black p-2 text-center text-black bg-white" style={{ color: '#000000', backgroundColor: '#ffffff', borderColor: '#000000' }}>জাতীয় পরিচয় পত্র নং</th>
                          <th className="border border-black p-2 text-center text-black bg-white" style={{ color: '#000000', backgroundColor: '#ffffff', borderColor: '#000000' }}>জন্ম তারিখ</th>
                          <th className="border border-black p-2 text-center text-black bg-white" style={{ color: '#000000', backgroundColor: '#ffffff', borderColor: '#000000' }}>সম্পর্ক</th>
                          <th className="border border-black p-2 text-center text-black bg-white" style={{ color: '#000000', backgroundColor: '#ffffff', borderColor: '#000000' }}>মন্তব্য</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white text-black" style={{ color: '#000000', backgroundColor: '#ffffff' }}>
                        {(rows as string[][]).map((row, rIdx) => {
                          let sl = row[0] || toBengaliNumeral(rIdx + 1);
                          let name = row[1] || '';
                          let nid = '';
                          let dob = '';
                          let relation = '';
                          let comment = '';

                          const c2 = (row[2] || '').trim();
                          const c3 = (row[3] || '').trim();
                          const c4 = (row[4] || '').trim();
                          const c5 = (row[5] || '').trim();

                          const isRelationWord = (val: string): boolean => {
                            if (!val) return false;
                            const s = val.trim();
                            const rels = ['স্ত্রী', 'স্বামী', 'পুত্র', 'মেয়ে', 'মেয়ে', 'কন্যা', 'সন্তান', 'পিতা', 'মাতা', 'ভাই', 'বোন', 'নাতি', 'নাতনী', 'নাতনি', 'ভাতিজা', 'ভাগ্নে', 'ছেলে', 'নিজ', 'স্বয়ং', 'আবেদনকারী', 'মৃত', 'ওয়ারিশ', 'ওয়ারিশ'];
                            return rels.some(r => s.includes(r));
                          };

                          const isDateOrAge = (val: string): boolean => {
                            if (!val) return false;
                            const s = val.trim();
                            if (/[\/\.-]/.test(s) && /\d/.test(s)) return true;
                            if (s.includes('বছর') || s.includes('মাস') || s.includes('দিন') || s.includes('বয়স') || s.includes('বয়স')) return true;
                            return false;
                          };

                          const isNidNum = (val: string): boolean => {
                            if (!val) return false;
                            const digits = val.replace(/[^0-9০-৯]/g, '');
                            return digits.length >= 7;
                          };

                          // Check if row is in OLD format: [sl, name, DOB/Age, Relation, NID, Comment]
                          const isOldFormat = isRelationWord(c3) || (isDateOrAge(c2) && !isDateOrAge(c3)) || (isNidNum(c4) && !isNidNum(c2));

                          if (isOldFormat) {
                            dob = c2;
                            relation = c3;
                            nid = c4;
                            comment = c5;
                          } else {
                            // NEW format: [sl, name, NID, DOB, Relation, Comment]
                            nid = c2;
                            dob = c3;
                            relation = c4;
                            comment = c5;
                          }

                          // Fail-safe relocation pass: ensure no column holds incorrect data types
                          if (isRelationWord(nid) && !relation) {
                            relation = nid;
                            nid = '';
                          }
                          if (isRelationWord(dob) && !relation) {
                            relation = dob;
                            dob = '';
                          }
                          if (isDateOrAge(nid) && !dob) {
                            dob = nid;
                            nid = '';
                          }
                          if (isNidNum(relation) && !nid) {
                            nid = relation;
                            relation = '';
                          }
                          if (isNidNum(dob) && !nid) {
                            nid = dob;
                            dob = '';
                          }

                          return (
                            <tr key={rIdx} className="bg-white text-black" style={{ color: '#000000', backgroundColor: '#ffffff' }}>
                              <td className="border border-black p-2 text-center font-bold text-black" style={{ color: '#000000', backgroundColor: '#ffffff', borderColor: '#000000' }}>{toBengaliNumeral(sl)}</td>
                              <td className="border border-black p-2 font-bold text-black" style={{ color: '#000000', backgroundColor: '#ffffff', borderColor: '#000000' }}>{name}</td>
                              <td className="border border-black p-2 text-center font-mono font-bold text-black" style={{ color: '#000000', backgroundColor: '#ffffff', borderColor: '#000000' }}>{toBengaliNumeral(nid)}</td>
                              <td className="border border-black p-2 text-center font-bold text-black" style={{ color: '#000000', backgroundColor: '#ffffff', borderColor: '#000000' }}>{toBengaliNumeral(dob)}</td>
                              <td className="border border-black p-2 text-center font-bold text-black" style={{ color: '#000000', backgroundColor: '#ffffff', borderColor: '#000000' }}>{relation}</td>
                              <td className="border border-black p-2 text-center font-bold text-black" style={{ color: '#000000', backgroundColor: '#ffffff', borderColor: '#000000' }}>{comment}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ))}
              </div>
            )}

            {/* Dynamic Custom Declaration / Wishing Statement */}
            <div className="mt-4 text-xs md:text-sm font-semibold text-slate-900 leading-relaxed whitespace-pre-line">
              {config?.certificateCustomizations?.[certificate.typeKey]?.declaration?.trim() || 
               (config?.certificateCustomizations?.[certificate.typeKey] as any)?.customDeclaration?.trim() || 
               'আমি তাহার সর্বাঙ্গীন মঙ্গল ও উত্তরোত্তর সাফল্য কামনা করি।'}
            </div>
          </div>

          {/* Footer Signatures, QR Verification & Blank Round Seal */}
          <div className="cert-footer mt-10 print:mt-4 pt-4 border-t border-slate-300">
            {/* Optional Type-Specific Footer Contact / Information Banner */}
            {(config?.certificateCustomizations?.[certificate.typeKey]?.footerContact?.trim() ||
              (config?.certificateCustomizations?.[certificate.typeKey] as any)?.customFooter?.trim()) && (
              <div className="mb-3 p-2 bg-slate-50 print:bg-transparent rounded-lg border border-slate-200 text-center text-[10px] md:text-[11px] font-semibold text-slate-800 whitespace-pre-line">
                {config?.certificateCustomizations?.[certificate.typeKey]?.footerContact?.trim() ||
                 (config?.certificateCustomizations?.[certificate.typeKey] as any)?.customFooter?.trim()}
              </div>
            )}

            {!showBottomSection ? (
              <div className="py-4 print:hidden text-center text-xs font-bold text-amber-700 bg-amber-50 rounded-lg border border-amber-300">
                🚫 নিচের সাইন, সিল ও QR কোড লুকানো রয়েছে (ম্যানুয়াল প্যাডে প্রিন্ট করার জন্য প্রস্তুত)। পুনরায় দেখাতে উপরের 'সিল ও QR অন' বাটনে ক্লিক করুন।
              </div>
            ) : (
              <div className="grid grid-cols-12 items-end justify-between gap-2">
                
                {/* Left Column: Secretary Signature Block & QR Code */}
                <div className="col-span-4 flex flex-col items-start justify-end space-y-2">
                  {showSignatures && showSecretarySig && (
                    <div className="space-y-0.5 text-left w-full">
                      <div className="cert-signature-space min-h-[40px] flex items-end justify-start">
                        {showDigitalSig && config.secretarySignatureUrl ? (
                          <img 
                            src={config.secretarySignatureUrl} 
                            alt="Secretary Digital Signature" 
                            className="max-h-12 max-w-[140px] object-contain filter contrast-125 mb-1"
                          />
                        ) : (
                          <span className="font-serif italic text-slate-800 font-bold text-xs border-b border-slate-700 px-3 mb-1">
                            {config.secretaryName}
                          </span>
                        )}
                      </div>
                      <p className="text-xs font-bold text-slate-950">{config.secretaryName}</p>
                      <p className="text-[11px] font-semibold text-emerald-900">{config.secretaryTitle}</p>
                      <p className="text-[10px] text-slate-600 font-medium">{config.upName}</p>
                    </div>
                  )}

                  {/* QR Code linked directly to Certificate Verification */}
                  {showQrCode && (
                    <div className="flex items-center gap-2 pt-1 shrink-0">
                      <a
                        href={realVerifyUrl}
                        target="_blank"
                        rel="noreferrer"
                        title="অনলাইন সত্যতা যাচাই করতে ক্লিক বা স্ক্যান করুন"
                        className="block group shrink-0"
                      >
                        <StyledQrCode
                          value={realVerifyUrl}
                          colorScheme={qrColorScheme}
                          customDarkColor={qrCustomDarkColor}
                          customLightColor={qrCustomLightColor}
                          embedLogo={qrEmbedLogo}
                          logoUrl={getResolvedLogoUrl('qr')}
                          logoStyle={applyLogoTo === 'all' || applyLogoTo === 'qr-only' ? logoStyle : undefined}
                          watermarkIntensity={watermarkIntensity}
                          logoShape={qrLogoShape}
                          frameStyle={qrFrameStyle}
                          size={isCompactMode ? 44 : 52}
                          className="group-hover:scale-105 transition-transform shrink-0"
                        />
                      </a>
                      <div className="leading-tight">
                        <p className="text-[9px] font-bold text-emerald-950 flex items-center gap-0.5 whitespace-nowrap">
                          <ShieldCheck className="w-2.5 h-2.5 text-emerald-700 inline shrink-0" />
                          <span>ডিজিটাল সিকিউরিটি</span>
                        </p>
                        <p className="text-[8px] font-mono text-slate-800 font-bold bg-slate-100 px-1 py-0.5 rounded border border-slate-300 inline-block my-0.5">
                          {generateSecurityChecksum(certificate.memoNo, certificate.citizen?.nid || certificate.citizen?.birthNo, certificate.issueDateEn || certificate.issueDate)}
                        </p>
                        <p className="text-[7.5px] text-slate-500 font-semibold whitespace-nowrap">জালিয়াতি প্রতিরোধী ক্রিপ্টোগ্রাফিক সিগনেচার</p>
                        
                        {/* Quick WhatsApp Share Pill */}
                        <button
                          type="button"
                          onClick={() => setIsWhatsAppModalOpen(true)}
                          className="mt-1 print:hidden inline-flex items-center gap-1 px-2 py-0.5 bg-[#25D366]/15 hover:bg-[#25D366]/25 text-emerald-900 border border-emerald-500/40 rounded-full text-[9px] font-bold transition cursor-pointer"
                          title="হোয়াটসঅ্যাপে ভেরিফিকেশন লিংক পাঠান"
                        >
                          <Share2 className="w-2.5 h-2.5 text-emerald-700" />
                          <span>হোয়াটসঅ্যাপে শেয়ার</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Center Column: Blank Round Seal Area for Manual Rubber Stamp */}
                <div className="col-span-4 text-center flex flex-col items-center justify-end">
                  {showBlankSeal && blankSealSize > 0 && (
                    <div 
                      className="rounded-full border-2 border-dashed border-slate-400 flex flex-col items-center justify-center text-center p-1 bg-slate-50/50 print:bg-transparent"
                      style={{ width: `${blankSealSize}px`, height: `${blankSealSize}px` }}
                    >
                      <span className="text-[9px] font-bold text-slate-400 leading-tight select-none">
                        গোল সিল মোহরের স্থান
                      </span>
                    </div>
                  )}
                  {showBlankSeal && (
                    <p className="text-[10px] font-semibold text-slate-500 mt-0.5">
                      (অফিশিয়াল ম্যানুয়াল সিল)
                    </p>
                  )}
                </div>

                {/* Right Column: Chairman Digital Signature Block */}
                <div className="col-span-4 text-right space-y-0.5">
                  {showSignatures && (
                    <>
                      <div className="cert-signature-space min-h-[44px] flex items-end justify-end">
                        {showDigitalSig && config.chairmanSignatureUrl ? (
                          <img 
                            src={config.chairmanSignatureUrl} 
                            alt="Chairman Digital Signature" 
                            className="max-h-14 max-w-[150px] object-contain filter contrast-125 mb-1"
                          />
                        ) : (
                          <span className="font-serif italic text-emerald-950 font-extrabold text-sm border-b-2 border-emerald-950 px-4 mb-1">
                            {config.chairmanName}
                          </span>
                        )}
                      </div>
                      <p className="text-xs font-bold text-slate-950">{config.chairmanName}</p>
                      <p className="text-[11px] font-semibold text-emerald-900">{config.chairmanTitle}</p>
                      <p className="text-[10px] text-slate-700 font-medium">{config.upName}</p>
                      <p className="text-[10px] text-slate-600">{config.upazila}, {config.district}</p>
                    </>
                  )}
                </div>

              </div>
            )}
          </div>

        </div>
      </div>

      {/* WhatsApp Dispatch & Automated Twilio Notification Modal */}
      <WhatsAppDispatchModal
        isOpen={isWhatsAppModalOpen}
        onClose={() => setIsWhatsAppModalOpen(false)}
        certificate={certificate}
        config={config}
      />

      {/* Interactive A4 Print Preview Modal */}
      {isPrintPreviewOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto print:hidden"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-slate-900 border border-slate-700 text-white rounded-2xl shadow-2xl w-full max-w-5xl overflow-hidden flex flex-col max-h-[95vh] animate-in fade-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="p-4 bg-slate-800/90 border-b border-slate-700 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-900/60 text-emerald-300 rounded-xl border border-emerald-700/50">
                  <Printer className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-extrabold text-white">
                      A4 প্রিন্ট প্রিভিউ & লেআউট ভেরিফিকেশন (Print Preview)
                    </h3>
                    <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-black flex items-center gap-1 ${
                      isCompactMode 
                        ? 'bg-amber-400 text-slate-950 shadow-sm' 
                        : 'bg-slate-700 text-slate-300 border border-slate-600'
                    }`}>
                      {isCompactMode ? '📄 ১-পাতা অটো-ফিট অন' : '📄 সাধারণ মোড'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    প্রিন্টারে পেপার পাঠাবার আগে A4 ১-পাতার সীমানা ও কমপ্যাক্ট মোড লেআউট স্বচক্ষে যাচাই করুন।
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsPrintPreviewOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition cursor-pointer"
                title="বন্ধ করুন"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Real-time Control Bar */}
            <div className="p-3 bg-slate-950/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                {/* Compact Mode Switch */}
                <button
                  onClick={() => setIsCompactMode(!isCompactMode)}
                  className={`px-3 py-1.5 rounded-lg border font-black transition flex items-center gap-1.5 cursor-pointer shadow-sm ${
                    isCompactMode
                      ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 border-amber-500'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-600'
                  }`}
                  title="A4 ১ পাতায় সব লেখা ফিট করানোর জন্য কমপ্যাক্ট মোড অন/অফ করুন"
                >
                  <Maximize2 className="w-3.5 h-3.5 text-slate-950" />
                  <span>{isCompactMode ? '⚡ কমপ্যাক্ট মোড: অন (১-পাতা অটো-ফিট)' : '⚪ কমপ্যাক্ট মোড: অফ'}</span>
                </button>

                {/* Page Orientation Selector Buttons */}
                <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-lg border border-slate-700">
                  <button
                    onClick={() => setPageOrientation('portrait')}
                    className={`px-2.5 py-1 text-xs font-bold rounded transition cursor-pointer flex items-center gap-1 ${
                      pageOrientation === 'portrait'
                        ? 'bg-emerald-600 text-white font-extrabold shadow-sm'
                        : 'text-slate-300 hover:text-white'
                    }`}
                    title="খাড়া A4 পোর্ট্রেট লেআউট"
                  >
                    <span>📱 পোর্ট্রেট (Portrait)</span>
                  </button>
                  <button
                    onClick={() => setPageOrientation('landscape')}
                    className={`px-2.5 py-1 text-xs font-bold rounded transition cursor-pointer flex items-center gap-1 ${
                      pageOrientation === 'landscape'
                        ? 'bg-emerald-600 text-white font-extrabold shadow-sm'
                        : 'text-slate-300 hover:text-white'
                    }`}
                    title="আড়াআড়ি A4 ল্যান্ডস্কেপ লেআউট"
                  >
                    <span>🖥️ ল্যান্ডস্কেপ (Landscape)</span>
                  </button>
                </div>

                {/* Print Scale Selector */}
                <div className="flex items-center gap-1.5 bg-slate-800/80 px-2.5 py-1 rounded-lg border border-slate-700">
                  <span className="text-slate-400 font-semibold">প্রিন্ট স্কেল:</span>
                  <select
                    value={printScale}
                    onChange={(e) => setPrintScale(Number(e.target.value))}
                    className="bg-slate-900 text-amber-300 font-bold border border-slate-600 rounded px-1.5 py-0.5 text-xs focus:ring-1 focus:ring-amber-400 cursor-pointer"
                  >
                    <option value={100}>১০০% (সাধারণ)</option>
                    <option value={95}>৯৫% (A4 এর জন্য উপযুক্ত)</option>
                    <option value={90}>৯০% (কমপ্যাক্ট)</option>
                    <option value={85}>৮৫% (দীর্ঘ আবেদনের জন্য)</option>
                    <option value={80}>৮০% (অতিরিক্ত বড় টেবিল)</option>
                  </select>
                </div>

                {/* Font Size Selector */}
                <div className="flex items-center gap-1.5 bg-slate-800/80 px-2.5 py-1 rounded-lg border border-slate-700">
                  <span className="text-slate-400 font-semibold">ফন্ট:</span>
                  <select
                    value={fontSize}
                    onChange={(e) => setFontSize(Number(e.target.value))}
                    className="bg-slate-900 text-white font-bold border border-slate-600 rounded px-1.5 py-0.5 text-xs cursor-pointer"
                  >
                    <option value={13}>১৩px (ক্ষুদ্র)</option>
                    <option value={14}>১৪px (ছোট)</option>
                    <option value={15}>১৫px (কমপ্যাক্ট)</option>
                    <option value={16}>১৬px (স্ট্যান্ডার্ড)</option>
                    <option value={18}>১৮px (বড়)</option>
                  </select>
                </div>

                {/* Header Mode Toggle */}
                <button
                  onClick={() => setShowHeaderInPrint(!showHeaderInPrint)}
                  className={`px-2.5 py-1 rounded-lg border text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                    showHeaderInPrint
                      ? 'bg-emerald-900/50 text-emerald-300 border-emerald-700'
                      : 'bg-amber-900/50 text-amber-300 border-amber-700'
                  }`}
                >
                  {showHeaderInPrint ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                  <span>{showHeaderInPrint ? 'ডিজিটাল হেডার' : 'প্যাড (হেডার লুকানো)'}</span>
                </button>

                {/* Bottom Section Toggle */}
                <button
                  onClick={() => setShowBottomSection(!showBottomSection)}
                  className={`px-2.5 py-1 rounded-lg border text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                    showBottomSection
                      ? 'bg-emerald-900/50 text-emerald-300 border-emerald-700'
                      : 'bg-rose-900/60 text-rose-300 border-rose-700'
                  }`}
                  title="সনদের নিচের সাইন, সিল ও QR লুকান বা দেখান"
                >
                  {showBottomSection ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                  <span>{showBottomSection ? 'সিল ও QR অন' : 'সিল ও QR লুকানো'}</span>
                </button>
              </div>

              {/* Reset to 1-Page Recommended */}
              <button
                onClick={() => {
                  setIsCompactMode(true);
                  setFontSize(15);
                  setPrintScale(95);
                }}
                className="px-2.5 py-1 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs rounded-lg transition cursor-pointer shadow"
              >
                ⚡ ১-পাতা ফিট অটো-সেট
              </button>
            </div>

            {/* A4 Interactive Mock-Up Viewport */}
            <div className="p-4 sm:p-6 bg-slate-950/80 overflow-y-auto flex flex-col items-center justify-start min-h-[420px] max-h-[62vh] border-b border-slate-800 relative shadow-inner">
              <div className="mb-2 flex items-center justify-between w-full max-w-4xl text-[11px] text-slate-400 px-2">
                <span className="flex items-center gap-1 font-mono text-emerald-400 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>
                    {pageOrientation === 'landscape' 
                      ? 'A4 Landscape Canvas (297mm × 210mm) — Wide 1 Page Sheet' 
                      : 'A4 Portrait Canvas (210mm × 297mm) — 1 Page Bound'}
                  </span>
                </span>
                <span className="text-amber-300 font-semibold">
                  {isCompactMode ? '✅ কমপ্যাক্ট মোড সক্রিয় - ১ পাতায় প্রিন্ট গ্যারান্টি' : '⚠️ সাধারণ মোড - বিবরণী দীর্ঘ হলে ২য় পাতায় যেতে পারে'}
                </span>
              </div>

              {/* Scaled A4 Mockup Sheet Canvas */}
              <div className={`w-full bg-slate-900 p-2 sm:p-4 rounded-xl border border-slate-800 shadow-2xl relative transition-all duration-300 ${
                pageOrientation === 'landscape' ? 'max-w-4xl' : 'max-w-3xl'
              }`}>
                {/* Visual A4 Page Marker */}
                <div className="absolute top-2 right-2 z-20 px-2 py-0.5 bg-emerald-950/90 text-emerald-300 border border-emerald-700 text-[10px] font-mono rounded font-bold">
                  A4 {pageOrientation.toUpperCase()} PAGE 1
                </div>

                <div 
                  className={`bg-white text-slate-900 rounded-lg p-4 md:p-6 shadow-xl border border-slate-300 transition-all duration-200 ${
                    pageOrientation === 'landscape' ? 'is-landscape' : 'is-portrait'
                  } ${
                    isCompactMode ? 'is-compact-mode' : ''
                  }`}
                  style={{
                    transform: printScale !== 100 ? `scale(${printScale / 100})` : undefined,
                    transformOrigin: 'top center',
                    minHeight: pageOrientation === 'landscape' 
                      ? (isCompactMode ? '540px' : '640px') 
                      : (isCompactMode ? '720px' : '880px')
                  }}
                >
                  {/* Miniature Live Preview of Certificate Layout */}
                  <div className={`p-4 border-2 border-emerald-900 rounded ${borderStyle === 'double-green-red' ? 'outline-2 outline-red-700 outline-offset-2' : ''}`}>
                    {showHeaderInPrint && (
                      <div className="text-center pb-2 border-b border-emerald-900 mb-3">
                        <p className="text-xs font-bold text-emerald-950">গণপ্রজাতন্ত্রী বাংলাদেশ সরকার</p>
                        <h4 className="text-sm font-black text-emerald-950">{config.upName}</h4>
                        <p className="text-[10px] text-slate-600">{config.address}</p>
                      </div>
                    )}

                    <div className="flex justify-between items-center text-[10px] font-bold text-slate-700 mb-3">
                      <span>স্মারক নং: {certificate.memoNo}</span>
                      <span>তারিখ: {certificate.issueDate}</span>
                    </div>

                    <div className="text-center my-3">
                      <span className="inline-block bg-emerald-950 text-white font-bold text-xs px-4 py-1 rounded">
                        {certificate.typeLabel}
                      </span>
                    </div>

                    <div 
                      className="text-justify text-xs font-medium text-slate-900 leading-relaxed my-3 px-1 indent-4"
                      style={{ fontSize: `${Math.max(12, fontSize - 2)}px` }}
                    >
                      {editableBodyText.length > 350 
                        ? editableBodyText.substring(0, 350) + '...' 
                        : editableBodyText}
                    </div>

                    {Object.keys(extraTables).length > 0 && (
                      <div className="my-2 p-1.5 bg-slate-50 border border-slate-300 rounded text-[10px]">
                        <p className="font-bold text-emerald-950 border-b pb-0.5 mb-1">সংযুক্ত তথ্য / ওয়ারিশ বিবরণী টেবিল (সক্রিয়)</p>
                        <div className="text-slate-600 italic">মোট সদস্য / সারি: {(Object.values(extraTables)[0] as Array<any>)?.length || 0} টি</div>
                      </div>
                    )}

                    {showBottomSection ? (
                      <div className="mt-8 pt-3 border-t border-slate-300 flex justify-between items-end text-[10px]">
                        {showQrCode ? (
                          <div className="space-y-1">
                            <StyledQrCode
                              value={realVerifyUrl}
                              colorScheme={qrColorScheme}
                              customDarkColor={qrCustomDarkColor}
                              customLightColor={qrCustomLightColor}
                              embedLogo={qrEmbedLogo}
                              logoUrl={getResolvedLogoUrl('qr')}
                              logoStyle={applyLogoTo === 'all' || applyLogoTo === 'qr-only' ? logoStyle : undefined}
                              watermarkIntensity={watermarkIntensity}
                              logoShape={qrLogoShape}
                              frameStyle={qrFrameStyle}
                              size={44}
                            />
                            <p className="text-[9px] text-slate-500">অনলাইন যাচাইকৃত</p>
                          </div>
                        ) : (
                          <div className="text-[9px] text-slate-400 italic">QR কোড লুকানো</div>
                        )}

                        {showBlankSeal && (
                          <div className="text-center">
                            <div className="w-12 h-12 rounded-full border border-dashed border-slate-400 flex items-center justify-center text-[7px] text-slate-400 mx-auto">
                              সিল স্থান
                            </div>
                          </div>
                        )}

                        {showSignatures ? (
                          <div className="text-center space-y-0.5">
                            {showDigitalSig && config.chairmanSignatureUrl && (
                              <img 
                                src={config.chairmanSignatureUrl} 
                                alt="Chairman Digital Signature" 
                                className="h-7 max-w-[100px] object-contain mx-auto mb-0.5 filter contrast-125" 
                              />
                            )}
                            <p className="font-bold text-slate-950">{config.chairmanName}</p>
                            <p className="text-[9px] text-emerald-900">{config.chairmanTitle}</p>
                          </div>
                        ) : (
                          <div className="text-[9px] text-slate-400 italic">স্বাক্ষর ব্লক লুকানো</div>
                        )}
                      </div>
                    ) : (
                      <div className="mt-6 pt-2 border-t border-dashed border-slate-300 text-center text-[9px] text-amber-700 bg-amber-50/70 p-1.5 rounded">
                        🚫 নিচের সাইন, সিল ও QR লুকানো রয়েছে (ম্যানুয়াল প্যাড মোড)
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-900 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <span className="text-amber-400 font-bold">💡 টিপস:</span>
                <span>প্রিন্ট আউট ১ পাতায় নিশ্চিত করতে "কমপ্যাক্ট মোড অন" সিলেক্ট রেখে প্রিন্টারে পাঠান।</span>
              </div>

              <div className="flex items-center gap-2.5 w-full sm:w-auto">
                <button
                  onClick={() => setIsPrintPreviewOpen(false)}
                  className="w-1/2 sm:w-auto px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl border border-slate-700 transition cursor-pointer"
                >
                  ফিরে যান
                </button>

                <button
                  onClick={() => {
                    setIsPrintPreviewOpen(false);
                    setTimeout(() => {
                      triggerActualPrint();
                    }, 100);
                  }}
                  className="w-1/2 sm:w-auto px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-lg hover:shadow-emerald-900/30 transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Printer className="w-4 h-4 text-amber-300" />
                  <span>প্রিন্টারে পাঠান (Confirm Print)</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Google Doc Export & Print Modal */}
      {isGoogleDocModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto print:hidden"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-slate-900 border border-slate-700 text-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="p-4 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 border-b border-slate-700 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-blue-600/30 text-blue-300 rounded-xl border border-blue-500/40">
                  <FileText className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    <span>Google Doc ও Word ফাইলে প্রিন্ট / এক্সপোর্ট</span>
                    <span className="text-[10px] bg-blue-500/30 text-blue-200 px-2 py-0.5 rounded-full border border-blue-400/40">
                      Auto-Formatted
                    </span>
                  </h3>
                  <p className="text-xs text-blue-200">
                    স্মারক নং: <span className="font-bold text-amber-300">{certificate.memoNo}</span> ({certificate.typeLabel})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsGoogleDocModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: Options */}
            <div className="p-5 sm:p-6 space-y-4">
              <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700 text-xs text-slate-300 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>বর্তমান সেটিংস অনুযায়ী এক্সপোর্ট হবে:</span>
                </div>
                <div className="flex items-center gap-2 text-[11px] font-bold">
                  <span className={showHeaderInPrint ? 'text-emerald-400' : 'text-slate-400'}>
                    {showHeaderInPrint ? '✓ হেডার' : '✗ হেডার অফ'}
                  </span>
                  <span>•</span>
                  <span className={showBottomSection ? 'text-emerald-400' : 'text-amber-400'}>
                    {showBottomSection ? '✓ সাইন/সিল/QR' : '🚫 সিল/QR লুকানো'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                
                {/* Option 1: Direct Google Docs.new */}
                <button
                  onClick={() => {
                    handleOpenInGoogleDocs();
                    setIsGoogleDocModalOpen(false);
                  }}
                  disabled={isCopyingDoc}
                  className="p-4 bg-gradient-to-br from-blue-800/90 to-indigo-900 hover:from-blue-700 hover:to-indigo-800 border border-blue-500/50 rounded-xl text-left transition group cursor-pointer shadow-md hover:shadow-blue-900/30 flex flex-col justify-between"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="p-2 bg-blue-500/30 rounded-lg text-blue-300 group-hover:scale-110 transition-transform">
                      <Globe className="w-5 h-5 text-blue-300" />
                    </div>
                    <span className="text-[10px] font-bold bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full">
                      সুপারফাস্ট 🚀
                    </span>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white mb-1">Google Docs-এ খুলুন ও প্রিন্ট করুন</h4>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      ক্লিপবোর্ডে কপি হয়ে সাথে সাথে একটি নতুন Google Docs ট্যাব খুলবে। শুধু <b>Ctrl+V</b> চেপে পেস্ট করে সরাসরি প্রিন্ট করুন।
                    </p>
                  </div>
                </button>

                {/* Option 2: Download .doc File */}
                <button
                  onClick={() => {
                    handleDownloadDocFile();
                    setIsGoogleDocModalOpen(false);
                  }}
                  className="p-4 bg-slate-800/90 hover:bg-slate-800 border border-slate-700 hover:border-emerald-500/50 rounded-xl text-left transition group cursor-pointer shadow-md flex flex-col justify-between"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="p-2 bg-emerald-500/20 rounded-lg text-emerald-300 group-hover:scale-110 transition-transform">
                      <Download className="w-5 h-5 text-emerald-400" />
                    </div>
                    <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
                      .doc ফাইল
                    </span>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white mb-1">Word / Doc ফাইল ডাউনলোড</h4>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      অফিসিয়াল ফরম্যাটসহ .doc ফাইল ডাউনলোড হবে। এটি Google Drive বা MS Word দিয়ে খুলে এডিট ও প্রিন্ট করা যাবে।
                    </p>
                  </div>
                </button>

                {/* Option 3: Copy Formatted HTML */}
                <button
                  onClick={() => {
                    handleCopyForGoogleDocs();
                    setIsGoogleDocModalOpen(false);
                  }}
                  disabled={isCopyingDoc}
                  className="p-4 bg-slate-800/90 hover:bg-slate-800 border border-slate-700 hover:border-amber-500/50 rounded-xl text-left transition group cursor-pointer shadow-md flex flex-col justify-between"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="p-2 bg-amber-500/20 rounded-lg text-amber-300 group-hover:scale-110 transition-transform">
                      <Copy className="w-5 h-5 text-amber-400" />
                    </div>
                    <span className="text-[10px] font-bold bg-slate-700 text-slate-300 px-2 py-0.5 rounded-full">
                      ক্লিপবোর্ড
                    </span>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white mb-1">ফরম্যাটসহ কপি করুন</h4>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      সম্পূর্ণ টেবিল, সিল ও টেক্সট ফরম্যাটসহ কপি হবে। যেকোনো জায়গায় পেস্ট করতে পারবেন।
                    </p>
                  </div>
                </button>

                {/* Option 4: Open UP Master Template */}
                <a
                  href={`https://docs.google.com/document/d/${config.templateDocId}/edit`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-4 bg-slate-800/90 hover:bg-slate-800 border border-slate-700 hover:border-blue-500/50 rounded-xl text-left transition group cursor-pointer shadow-md flex flex-col justify-between"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="p-2 bg-indigo-500/20 rounded-lg text-indigo-300 group-hover:scale-110 transition-transform">
                      <ExternalLink className="w-5 h-5 text-indigo-300" />
                    </div>
                    <span className="text-[10px] font-bold bg-slate-700 text-slate-300 px-2 py-0.5 rounded-full">
                      Drive লিঙ্ক
                    </span>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white mb-1">ইউপি মাস্টার Doc টেমপ্লেট</h4>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      ড্রাইভে থাকা কেন্দ্রীয় ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের মাস্টার টেমপ্লেট ফাইলে সরাসরি যান।
                    </p>
                  </div>
                </a>

              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Google Docs প্রিন্টিংয়ে টেবিল ও বাংলা ফন্ট নিখুঁতভাবে রেন্ডার হয়।</span>
              </span>
              <button
                onClick={() => setIsGoogleDocModalOpen(false)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-lg transition cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
};
