import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Search, 
  QrCode, 
  ExternalLink, 
  Copy, 
  Check, 
  Share2, 
  Printer, 
  ShieldCheck, 
  FileText, 
  UserCheck, 
  MapPin, 
  Phone, 
  CheckCircle2, 
  Download, 
  Sparkles, 
  ArrowRight,
  Eye,
  RefreshCw,
  SlidersHorizontal,
  Building2
} from 'lucide-react';
import { UnionParishadConfig, CitizenAccountRecord, CertificateRecord } from '../types';
import { generateStyledQrDataUrl } from '../utils/qrGenerator';
import { fetchCertificatesFromFirebase } from '../firebase';
import { CitizenPublicProfileView } from './CitizenPublicProfileView';

interface CitizenProfileGeneratorProps {
  config: UnionParishadConfig;
  onApplyForCitizen?: (citizen: CitizenAccountRecord) => void;
  onNavigateTab?: (tab: string) => void;
}

export const CitizenProfileGenerator: React.FC<CitizenProfileGeneratorProps> = ({
  config,
  onApplyForCitizen,
  onNavigateTab
}) => {
  const [citizens, setCitizens] = useState<CitizenAccountRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedWard, setSelectedWard] = useState<string>('');
  const [selectedCitizen, setSelectedCitizen] = useState<CitizenAccountRecord | null>(null);
  const [activePublicViewCitizen, setActivePublicViewCitizen] = useState<CitizenAccountRecord | null>(null);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [maskMobileOption, setMaskMobileOption] = useState<boolean>(false);

  // Pre-seed and load master citizens
  useEffect(() => {
    loadCitizens();
  }, []);

  const loadCitizens = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/logs');
      const data = await res.json();
      const serverCerts: CertificateRecord[] = data.logs || [];
      const fbCerts = await fetchCertificatesFromFirebase();
      const combined = [...serverCerts, ...fbCerts];

      const citizenMap = new Map<string, CitizenAccountRecord>();

      // Pre-seed defaults
      const defaultCitizens: CitizenAccountRecord[] = [
        {
          id: 'cit_101',
          nid: '19859382011234567',
          holdingNo: 'এইচ-১০৪',
          name: 'মোঃ আতিকুর রহমান',
          father: 'হাজী আব্দুল গণি',
          mother: 'আয়েশা খাতুন',
          gender: 'পুরুষ',
          age: 41,
          dateOfBirth: '1985-03-12',
          occupation: 'ব্যবসা / ট্রেডার্স',
          mobile: '01712345678',
          village: 'বহেড়াতৈল',
          wardNo: '০৪',
          postOffice: 'বহেড়াতৈল',
          postCode: '১৯৫০',
          totalCertificates: 3,
          registeredAt: '2025-01-10'
        },
        {
          id: 'cit_102',
          nid: '19929382019876543',
          holdingNo: 'এইচ-৫২',
          name: 'মোছাঃ ফাতেমা বেগম',
          father: 'মোঃ মজিবর রহমান',
          mother: 'আমেনা বেগম',
          spouseName: 'মোঃ শফিকুল ইসলাম',
          gender: 'মহিলা',
          age: 34,
          dateOfBirth: '1992-07-22',
          occupation: 'গৃহিণী',
          mobile: '01823456789',
          village: 'গোহাইলবাড়ী',
          wardNo: '০১',
          postOffice: 'নাগবাড়ী',
          postCode: '১৯৭২',
          totalCertificates: 2,
          registeredAt: '2025-02-15'
        },
        {
          id: 'cit_103',
          nid: '19989382014561234',
          holdingNo: 'এইচ-১৭',
          name: 'তানভীর আহমেদ রিফাত',
          father: 'মোঃ রফিকুল ইসলাম',
          mother: 'নাছিমা আক্তার',
          gender: 'পুরুষ',
          age: 28,
          dateOfBirth: '1998-11-05',
          occupation: 'চাকরিজীবী / আইটি',
          mobile: '01934567890',
          village: 'আমতৈল',
          wardNo: '০৫',
          postOffice: 'বেতুয়া',
          postCode: '১৯৫০',
          totalCertificates: 4,
          registeredAt: '2025-03-01'
        },
        {
          id: 'cit_104',
          birthNo: '20089382019876543',
          holdingNo: 'এইচ-৮৯',
          name: 'মোছাঃ সাদিয়া আক্তার',
          father: 'মোঃ সোলাইমান মিয়া',
          mother: 'রহিমা বেগম',
          gender: 'মহিলা',
          age: 18,
          dateOfBirth: '2008-05-14',
          occupation: 'শিক্ষার্থী / ছাত্র',
          mobile: '01645678901',
          village: 'ডাবাইল',
          wardNo: '০১',
          postOffice: 'নাগবাড়ী',
          postCode: '১৯৭২',
          totalCertificates: 1,
          registeredAt: '2025-04-10'
        },
        {
          id: 'cit_105',
          nid: '19629382011122334',
          holdingNo: 'এইচ-০৩',
          name: 'মোঃ জহিরুল হক',
          father: 'মরহুম আফসার উদ্দিন',
          mother: 'মরহুমা জাহানারা খাতুন',
          gender: 'পুরুষ',
          age: 64,
          dateOfBirth: '1962-09-18',
          occupation: 'অবসরপ্রাপ্ত / প্রবীণ',
          mobile: '01756789012',
          village: 'ঘাটেশ্বরী',
          wardNo: '০৩',
          postOffice: 'বহেড়াতৈল',
          postCode: '১৯৫০',
          totalCertificates: 2,
          registeredAt: '2024-11-20'
        },
        {
          id: 'cit_106',
          nid: '19889382013344556',
          holdingNo: 'এইচ-২৩',
          name: 'সঞ্জয় কুমার ভৌমিক',
          father: 'সুশীল কুমার ভৌমিক',
          mother: 'মায়া রানী ভৌমিক',
          gender: 'পুরুষ',
          age: 38,
          dateOfBirth: '1988-02-28',
          occupation: 'কৃষি ও খামার',
          mobile: '01867890123',
          village: 'কালিয়ান',
          wardNo: '০৮',
          postOffice: 'বেতুয়া',
          postCode: '১৯৫০',
          totalCertificates: 1,
          registeredAt: '2025-05-12'
        }
      ];

      defaultCitizens.forEach(c => citizenMap.set(c.id, c));

      // Extract unique citizens from certificates
      combined.forEach(cert => {
        if (!cert.citizen || !cert.citizen.name) return;
        const key = cert.citizen.nid || cert.citizen.birthNo || cert.citizen.name;
        const existing = citizenMap.get(key);

        if (existing) {
          existing.totalCertificates = (existing.totalCertificates || 0) + 1;
        } else {
          citizenMap.set(key, {
            id: `cit_${cert.citizen.nid || cert.citizen.birthNo || Math.random().toString(36).substring(2, 8)}`,
            nid: cert.citizen.nid,
            birthNo: cert.citizen.birthNo,
            holdingNo: cert.citizen.holdingNo || 'এইচ-০',
            name: cert.citizen.name,
            father: cert.citizen.father || cert.citizen.spouseName || 'N/A',
            mother: cert.citizen.mother || 'N/A',
            spouseName: cert.citizen.spouseName,
            gender: cert.citizen.gender || 'পুরুষ',
            mobile: cert.citizen.mobile,
            village: cert.citizen.village || 'বহেড়াতৈল',
            wardNo: cert.citizen.wardNo || '০৪',
            postOffice: cert.citizen.postOffice || 'বহেড়াতৈল',
            postCode: cert.citizen.postCode || '১৯৫০',
            totalCertificates: 1,
            registeredAt: cert.issueDate || '২০২৬-০১-০১'
          });
        }
      });

      const list = Array.from(citizenMap.values());
      setCitizens(list);
      if (list.length > 0) {
        setSelectedCitizen(list[0]);
      }
    } catch (err) {
      console.error('Error loading citizens:', err);
    } finally {
      setLoading(false);
    }
  };

  // Generate QR code when selectedCitizen changes
  useEffect(() => {
    if (selectedCitizen) {
      const publicLink = getPublicProfileLink(selectedCitizen);
      generateStyledQrDataUrl(publicLink, {
        width: 280,
        includeGoldBorder: true,
        headerText: `${selectedCitizen.name} — ভেরিফাইড প্রোফাইল`
      }).then(url => setQrCodeDataUrl(url)).catch(() => {});
    }
  }, [selectedCitizen]);

  const getPublicProfileLink = (c: CitizenAccountRecord) => {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'https://upsm-baheratail.vercel.app';
    const path = typeof window !== 'undefined' ? window.location.pathname : '/';
    return `${origin}${path}?citizen=${encodeURIComponent(c.id || c.nid || c.name)}`;
  };

  const handleCopyLink = (c: CitizenAccountRecord) => {
    const link = getPublicProfileLink(c);
    navigator.clipboard.writeText(link);
    setCopiedId(c.id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleShareWhatsApp = (c: CitizenAccountRecord) => {
    const link = getPublicProfileLink(c);
    const text = `🏛️ *০২নং বহেড়াতৈল ইউনিয়ন পরিষদ — ডিজিটাল নাগরিক প্রোফাইল ও সনদ ভেরিফিকেশন লিংক*\n\n` +
      `👤 *নাগরিকের নাম:* ${c.name}\n` +
      `🏡 *গ্রাম ও ওয়ার্ড:* ${c.village}, ওয়ার্ড নং ${c.wardNo}\n` +
      `📜 *অনুমোদিত সনদসমূহ:* ${c.totalCertificates || 1} টি\n\n` +
      `🌐 *সরাসরি পাবলিক প্রোফাইল ও সনদপত্র দেখুন (কোনো ট্র্যাকিং কোড লাগবে না):*\n${link}`;
    
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, '_blank');
  };

  const filteredCitizens = citizens.filter(c => {
    if (selectedWard && c.wardNo !== selectedWard) return false;
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      (c.nid && c.nid.includes(q)) ||
      (c.birthNo && c.birthNo.includes(q)) ||
      (c.mobile && c.mobile.includes(q)) ||
      c.village.toLowerCase().includes(q) ||
      (c.holdingNo && c.holdingNo.toLowerCase().includes(q))
    );
  });

  if (activePublicViewCitizen) {
    return (
      <CitizenPublicProfileView
        config={config}
        citizenId={activePublicViewCitizen.id}
        initialCitizen={activePublicViewCitizen}
        onBackToPortal={() => setActivePublicViewCitizen(null)}
      />
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white p-6 md:p-8 rounded-3xl shadow-xl relative overflow-hidden">
        <div className="absolute -right-8 -bottom-8 opacity-10 pointer-events-none">
          <QrCode className="w-64 h-64 text-white" />
        </div>

        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-400 text-emerald-950 font-black text-xs rounded-full">
            <Sparkles className="w-3.5 h-3.5" /> সিটিজেন পাবলিক প্রোফাইল জেনারেটর (Citizen Profile Generator)
          </div>
          <h1 className="text-xl md:text-3xl font-black tracking-tight">
            প্রত্যেক নাগরিকের জন্য ইউনিক পাবলিক ভেরিফিকেশন লিঙ্ক ও সনদ পোর্টফোলিও
          </h1>
          <p className="text-xs md:text-sm text-emerald-200 max-w-3xl leading-relaxed">
            এই জেনারেটরের মাধ্যমে যে কোনো নাগরিকের জন্য একটি স্থায়ী, সুরক্ষিত পাবলিক ওয়েব লিঙ্ক তৈরি করা যায়। ব্যাংক, পাসপোর্ট অধিদপ্তর, দূতাবাস বা নিয়োগকারী কর্তৃপক্ষ কোনো প্রকার ট্র্যাকিং কোড টাইপ করা ছাড়াই নাগরিকের যাচাইকৃত তথ্যাবলী ও সকল ইস্যুকৃত সনদপত্র এক ক্লিকেই অনলাইন যাচাই করতে পারবেন।
          </p>
        </div>
      </div>

      {/* Main 2-Column Studio Grid: Left Citizen Directory, Right Generated Profile Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Citizen Selector & Search (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                নাগরিক নির্বাচন করুন ({filteredCitizens.length} জন)
              </h3>
              <button
                onClick={loadCitizens}
                className="p-1.5 text-slate-500 hover:text-emerald-700 dark:text-slate-400 dark:hover:text-emerald-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                title="রিফ্রেশ করুন"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {/* Search Input & Ward Filter */}
            <div className="space-y-2">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="নাম, NID, জন্ম সনদ বা মোবাইল..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={selectedWard}
                  onChange={(e) => setSelectedWard(e.target.value)}
                  className="flex-1 px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">সকল ওয়ার্ড (০১-০৯)</option>
                  {['০১', '০২', '০৩', '০৪', '০৫', '০৬', '০৭', '০৮', '০৯'].map(w => (
                    <option key={w} value={w}>ওয়ার্ড নং {w}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Scrollable Citizen List */}
            <div className="max-h-[520px] overflow-y-auto space-y-2 pr-1 custom-scrollbar">
              {filteredCitizens.map(citizen => {
                const isSelected = selectedCitizen?.id === citizen.id;
                return (
                  <div
                    key={citizen.id}
                    onClick={() => setSelectedCitizen(citizen)}
                    className={`p-3.5 rounded-2xl border-2 transition cursor-pointer text-xs space-y-2 ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/80 dark:bg-emerald-950/40 shadow-sm'
                        : 'border-slate-200 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5 truncate">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                        <span className="truncate">{citizen.name}</span>
                      </div>
                      <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[10px] font-bold rounded-md shrink-0">
                        ওয়ার্ড {citizen.wardNo}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                      <span>গ্রাম: {citizen.village}</span>
                      <span>NID: {citizen.nid ? citizen.nid.substring(0, 7) + '...' : 'জন্ম সনদ'}</span>
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800 text-[10px]">
                      <span className="text-emerald-700 dark:text-emerald-400 font-bold flex items-center gap-1">
                        <FileText className="w-3 h-3" /> {citizen.totalCertificates || 1}টি সনদ ইস্যুকৃত
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCopyLink(citizen);
                        }}
                        className="text-slate-600 hover:text-emerald-700 dark:text-slate-400 dark:hover:text-emerald-300 flex items-center gap-1 font-bold"
                      >
                        {copiedId === citizen.id ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                        লিংক
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Generated Public Profile Link & Interactive Preview (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {selectedCitizen ? (
            <div className="space-y-4">
              
              {/* Unique Generated Link Card */}
              <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-md border-2 border-emerald-700/50 dark:border-emerald-600/60 space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <span className="px-2.5 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[10px] font-black rounded-full border border-emerald-300 dark:border-emerald-800 uppercase">
                      ✓ স্বয়ংক্রিয়ভাবে প্রস্তুতকৃত পাবলিক লিঙ্ক
                    </span>
                    <h3 className="text-base font-black text-slate-900 dark:text-white">
                      {selectedCitizen.name}-এর পাবলিক প্রোফাইল লিংক
                    </h3>
                  </div>
                  <button
                    onClick={() => setActivePublicViewCitizen(selectedCitizen)}
                    className="px-3.5 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow cursor-pointer"
                  >
                    <Eye className="w-4 h-4" /> পূর্ণাঙ্গ পেজ দেখুন
                  </button>
                </div>

                {/* URL Display Bar */}
                <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2">
                  <span className="font-mono text-xs text-emerald-800 dark:text-emerald-300 truncate select-all">
                    {getPublicProfileLink(selectedCitizen)}
                  </span>
                  <button
                    onClick={() => handleCopyLink(selectedCitizen)}
                    className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1 shrink-0 transition cursor-pointer shadow-sm"
                  >
                    {copiedId === selectedCitizen.id ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedId === selectedCitizen.id ? 'কপি হয়েছে' : 'কপি লিঙ্ক'}
                  </button>
                </div>

                {/* Action Buttons Row */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
                  <button
                    onClick={() => handleShareWhatsApp(selectedCitizen)}
                    className="py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition shadow cursor-pointer"
                  >
                    <Share2 className="w-4 h-4" /> হোয়াটসঅ্যাপে পাঠান
                  </button>

                  <a
                    href={getPublicProfileLink(selectedCitizen)}
                    target="_blank"
                    rel="noreferrer"
                    className="py-2 px-3 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition shadow cursor-pointer text-center"
                  >
                    <ExternalLink className="w-4 h-4" /> নতুন ট্যাবে খুলুন
                  </a>

                  {onApplyForCitizen && (
                    <button
                      onClick={() => onApplyForCitizen(selectedCitizen)}
                      className="py-2 px-3 bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition shadow cursor-pointer col-span-2 sm:col-span-1"
                    >
                      <FileText className="w-4 h-4" /> নতুন সনদ আবেদন
                    </button>
                  )}
                </div>
              </div>

              {/* Digital Citizen Verification Pass & QR Card */}
              <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-md border border-slate-200 dark:border-slate-800 space-y-6">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-700" />
                    ডিজিটাল সিটিজেন ভেরিফিকেশন পাস (Live Preview)
                  </h4>
                  <span className="text-[11px] text-slate-500 font-mono">
                    ID: {selectedCitizen.id}
                  </span>
                </div>

                <div className="bg-gradient-to-br from-emerald-50 via-teal-50 to-emerald-100/50 dark:from-slate-800 dark:via-slate-850 dark:to-slate-800 p-6 rounded-2xl border-2 border-emerald-200 dark:border-emerald-800/60 relative overflow-hidden">
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
                    <div className="space-y-3 text-center sm:text-left flex-1">
                      <div className="space-y-0.5">
                        <span className="text-[10px] uppercase tracking-wider font-extrabold text-emerald-800 dark:text-emerald-300">
                          {config.upName || "০২নং বহেড়াতৈল ইউনিয়ন পরিষদ"}
                        </span>
                        <h3 className="text-xl font-black text-slate-900 dark:text-white">
                          {selectedCitizen.name}
                        </h3>
                        <p className="text-xs text-slate-600 dark:text-slate-400">
                          পিতা: {selectedCitizen.father} | মাতা: {selectedCitizen.mother}
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs pt-1 text-left">
                        <div className="bg-white/80 dark:bg-slate-900/80 p-2 rounded-lg">
                          <span className="text-[10px] text-slate-400 block">ঠিকানা</span>
                          <strong>{selectedCitizen.village}, ওয়ার্ড {selectedCitizen.wardNo}</strong>
                        </div>
                        <div className="bg-white/80 dark:bg-slate-900/80 p-2 rounded-lg">
                          <span className="text-[10px] text-slate-400 block">NID / জন্ম সনদ</span>
                          <strong className="font-mono text-emerald-800 dark:text-emerald-400">{selectedCitizen.nid || selectedCitizen.birthNo || 'যাচাইকৃত'}</strong>
                        </div>
                      </div>

                      <div className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 dark:text-emerald-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        অনুমোদিত সনদ সংখ্যা: {selectedCitizen.totalCertificates || 1} টি
                      </div>
                    </div>

                    {/* QR Code */}
                    {qrCodeDataUrl && (
                      <div className="bg-white p-2.5 rounded-2xl shadow border border-amber-300 text-center shrink-0 flex flex-col items-center">
                        <img src={qrCodeDataUrl} alt="Citizen QR Code" className="w-28 h-28 object-contain rounded-lg" />
                        <span className="text-[9px] font-bold text-slate-800 mt-1 uppercase">
                          স্ক্যান করে প্রোফাইল খুলুন
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl text-xs text-slate-600 dark:text-slate-400 leading-relaxed flex items-start gap-2.5">
                  <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-900 dark:text-white block font-bold">সহজ বাহ্যিক ভেরিফিকেশন সুবিধা:</strong>
                    পাবলিক প্রোফাইল লিংকে প্রবেশ করলে এই নাগরিকের প্রাথমিক তথ্যাবলীর পাশাপাশি পরিষদ কর্তৃক ইস্যুকৃত সকল নাগরিকত্ব, চারিত্রিক, ওয়ারিশান, ট্রেড লাইসেন্স বা অনাপত্তিপত্র সরাসরি দৃশ্যমান হবে। আলাদা কোনো ট্র্যাকিং স্মারক কোড মনে রাখা বা ইনপুট করার প্রয়োজন হবে না।
                  </div>
                </div>
              </div>

            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 text-center space-y-3">
              <Users className="w-12 h-12 text-slate-400 mx-auto" />
              <h3 className="font-bold text-base text-slate-800 dark:text-slate-200">নাগরিক নির্বাচন করুন</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                বাম পাশের তালিকা থেকে যেকোনো নাগরিক সিলেক্ট করুন অথবা নাম/NID দিয়ে সার্চ করে তার ইউনিক পাবলিক লিঙ্ক ও ভেরিফিকেশন প্রোফাইল জেনারেট করুন।
              </p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
