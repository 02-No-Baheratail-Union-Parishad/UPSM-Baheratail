import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  User, 
  MapPin, 
  Phone, 
  Calendar, 
  FileText, 
  CheckCircle2, 
  Copy, 
  Check, 
  Share2, 
  Printer, 
  ExternalLink, 
  QrCode, 
  Download, 
  ArrowLeft, 
  Building2, 
  Briefcase, 
  CreditCard, 
  Layers, 
  AlertCircle, 
  Loader2,
  Sparkles,
  Eye,
  X
} from 'lucide-react';
import { UnionParishadConfig, CertificateRecord, CitizenAccountRecord } from '../types';
import { generateStyledQrDataUrl } from '../utils/qrGenerator';
import { CertificateView } from './CertificateView';
import { fetchCertificatesFromFirebase } from '../firebase';

interface CitizenPublicProfileViewProps {
  config: UnionParishadConfig;
  citizenId?: string;
  initialCitizen?: CitizenAccountRecord | null;
  onBackToPortal?: () => void;
}

export const CitizenPublicProfileView: React.FC<CitizenPublicProfileViewProps> = ({
  config,
  citizenId,
  initialCitizen,
  onBackToPortal
}) => {
  const [citizen, setCitizen] = useState<any>(initialCitizen || null);
  const [certificates, setCertificates] = useState<CertificateRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(!initialCitizen);
  const [error, setError] = useState<string | null>(null);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [selectedCertForView, setSelectedCertForView] = useState<CertificateRecord | null>(null);
  const [searchCertQuery, setSearchCertQuery] = useState<string>('');

  // Extract ID from URL if not passed in props
  const resolvedId = citizenId || (() => {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('citizen') || urlParams.get('profile') || (initialCitizen?.id || initialCitizen?.nid);
  })();

  const publicUrl = typeof window !== 'undefined'
    ? `${window.location.origin}${window.location.pathname}?citizen=${encodeURIComponent(resolvedId || citizen?.id || citizen?.nid || '')}`
    : '';

  useEffect(() => {
    const loadProfileData = async () => {
      if (!resolvedId && !initialCitizen) {
        setError('নাগরিকের সঠিক তথ্য বা আইডি পাওয়া যায় নাই।');
        setLoading(false);
        return;
      }

      setLoading(true);
      setError(null);

      try {
        const queryTarget = resolvedId || initialCitizen?.id || initialCitizen?.nid || initialCitizen?.name;
        const res = await fetch(`/api/citizen/public-profile/${encodeURIComponent(queryTarget || '')}`);
        
        if (res.ok) {
          const data = await res.json();
          if (data.success && data.citizen) {
            setCitizen(data.citizen);
            setCertificates(data.certificates || []);
            setLoading(false);
            return;
          }
        }

        // Fallback: If API returns 404 or fails, search Firebase certificates directly
        const fbCerts = await fetchCertificatesFromFirebase();
        const cleanQuery = (queryTarget || '').toString().toLowerCase();
        
        const matched = fbCerts.filter(c => 
          (c.citizen?.nid && c.citizen.nid.toLowerCase() === cleanQuery) ||
          (c.citizen?.birthNo && c.citizen.birthNo.toLowerCase() === cleanQuery) ||
          (c.citizen?.name && c.citizen.name.toLowerCase().includes(cleanQuery)) ||
          (c.citizen?.mobile && c.citizen.mobile === cleanQuery) ||
          (c.id && c.id.toLowerCase() === cleanQuery)
        );

        if (matched.length > 0) {
          const latest = matched[0];
          setCitizen({
            ...latest.citizen,
            id: `cit_${latest.citizen.nid || latest.citizen.birthNo || '001'}`,
            registeredAt: latest.issueDate
          });
          setCertificates(matched);
        } else if (initialCitizen) {
          setCitizen(initialCitizen);
          setCertificates([]);
        } else {
          setError('উক্ত আইডি বা NID নম্বরে কোনো যাচাইকৃত নাগরিকের রেকর্ড পাওয়া যায় নাই।');
        }
      } catch (err: any) {
        console.error('Error loading public citizen profile:', err);
        if (initialCitizen) {
          setCitizen(initialCitizen);
        } else {
          setError('নাগরিক প্রোফাইল সার্ভার হইতে লোড করিতে ত্রুটি ঘটিয়াছে।');
        }
      } finally {
        setLoading(false);
      }
    };

    loadProfileData();
  }, [resolvedId, initialCitizen]);

  // Generate QR Code for this public profile
  useEffect(() => {
    if (publicUrl) {
      generateStyledQrDataUrl(publicUrl, {
        width: 260,
        includeGoldBorder: true,
        headerText: '০২নং বহেড়াতৈল ইউপি — ভেরিফাইড প্রোফাইল'
      }).then(url => setQrCodeDataUrl(url)).catch(() => {});
    }
  }, [publicUrl]);

  const handleCopyLink = () => {
    if (!publicUrl) return;
    navigator.clipboard.writeText(publicUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleShareWhatsApp = () => {
    if (!citizen) return;
    const shareText = `🏛️ *০২নং বহেড়াতৈল ইউনিয়ন পরিষদ — ডিজিটাল নাগরিক প্রোফাইল*\n\n` +
      `👤 *নাম:* ${citizen.name}\n` +
      `🏡 *গ্রাম ও ওয়ার্ড:* ${citizen.village}, ওয়ার্ড নং ${citizen.wardNo}\n` +
      `📜 *অনুমোদিত সনদ সংখ্যা:* ${certificates.length} টি\n\n` +
      `🔗 *সরাসরি পাবলিক ভেরিফিকেশন লিঙ্ক (কোনো ট্র্যাকিং কোডের প্রয়োজন নেই):*\n${publicUrl}`;
    
    const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handlePrint = () => {
    window.print();
  };

  const filteredCertificates = certificates.filter(c => {
    if (!searchCertQuery) return true;
    const q = searchCertQuery.toLowerCase();
    return (
      c.typeLabel.toLowerCase().includes(q) ||
      c.memoNo.toLowerCase().includes(q) ||
      (c.category && c.category.toLowerCase().includes(q)) ||
      c.issueDate.includes(q)
    );
  });

  if (loading) {
    return (
      <div className="min-h-[500px] flex flex-col items-center justify-center p-8 space-y-4">
        <Loader2 className="w-12 h-12 text-emerald-700 animate-spin" />
        <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
          ডিজিটাল ইউনিয়ন পরিষদ ডাটাবেজ হইতে নাগরিক প্রোফাইল ও ইস্যুকৃত সনদসমূহ যাচাই করা হইতেছে...
        </p>
      </div>
    );
  }

  if (error || !citizen) {
    return (
      <div className="max-w-2xl mx-auto my-8 p-8 bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-red-200 dark:border-red-900/50 text-center space-y-6">
        <div className="w-16 h-16 bg-red-100 dark:bg-red-950 text-red-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
          <AlertCircle className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">নাগরিক প্রোফাইল পাওয়া যায় নাই</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 max-w-md mx-auto">
            {error || 'উক্ত লিংকে কোনো অনুমোদিত নাগরিক তথ্য পাওয়া যায় নাই। অনুগ্রহ করে সঠিক লিংক বা আইডি দিয়ে পুনরায় চেষ্টা করুন।'}
          </p>
        </div>
        {onBackToPortal && (
          <button
            onClick={onBackToPortal}
            className="inline-flex items-center gap-2 px-6 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-sm rounded-xl transition shadow cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" /> ইউনিয়ন পোর্টালে ফিরুন
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6 print:space-y-4 print:p-0">
      {/* Top Navigation & Action Controls Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 print:hidden">
        <div className="flex items-center gap-3">
          {onBackToPortal && (
            <button
              onClick={onBackToPortal}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> ইউনিয়ন পোর্টালে ফিরুন
            </button>
          )}
          <span className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 text-xs font-black rounded-full border border-emerald-300 dark:border-emerald-800">
            <CheckCircle2 className="w-3.5 h-3.5" /> পাবলিক ভেরিফাইড প্রোফাইল লিংক
          </span>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleCopyLink}
            className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950 dark:hover:bg-emerald-900 text-emerald-800 dark:text-emerald-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition border border-emerald-200 dark:border-emerald-800 cursor-pointer"
            title="ইউনিক পাবলিক লিঙ্ক কপি করুন"
          >
            {copiedLink ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
            {copiedLink ? 'লিঙ্ক কপি হয়েছে!' : 'পাবলিক লিঙ্ক কপি'}
          </button>

          <button
            onClick={handleShareWhatsApp}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow cursor-pointer"
            title="হোয়াটসঅ্যাপে নাগরিক প্রোফাইল পাঠান"
          >
            <Share2 className="w-4 h-4" /> হোয়াটসঅ্যাপে শেয়ার
          </button>

          <button
            onClick={handlePrint}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow cursor-pointer"
            title="নাগরিক ভেরিফিকেশন সারসংক্ষেপ প্রিন্ট করুন"
          >
            <Printer className="w-4 h-4" /> প্রিন্ট / PDF
          </button>
        </div>
      </div>

      {/* Main Official Government Verified Profile Card */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-xl border-2 border-emerald-800/40 dark:border-emerald-700/50 overflow-hidden relative print:border-2 print:border-emerald-900 print:shadow-none">
        
        {/* Top Official Union Crest Banner */}
        <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-950 text-white p-6 md:p-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 transform translate-x-12 -translate-y-8 opacity-10 pointer-events-none">
            <Building2 className="w-64 h-64 text-white" />
          </div>

          <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-6 relative z-10">
            <div className="flex items-center gap-4 text-center md:text-left">
              <div className="w-20 h-20 bg-white p-1 rounded-2xl shadow-lg border-2 border-amber-400 shrink-0 flex items-center justify-center">
                <img 
                  src={config.logoUrl || "/baheratail_seal.svg"} 
                  alt="Union Parishad Seal" 
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1.5 px-3 py-0.5 bg-amber-400 text-emerald-950 font-black text-[11px] rounded-full uppercase tracking-wider">
                  <ShieldCheck className="w-3.5 h-3.5" /> সরকারি অনুমোদিত ডাটাবেজ ভেরিফাইড প্রোফাইল
                </div>
                <h1 className="text-xl md:text-2xl font-black text-white tracking-tight">
                  {config.upName || "০২নং বহেড়াতৈল ইউনিয়ন পরিষদ"}
                </h1>
                <p className="text-xs text-emerald-200">
                  ডাকঘর: বহেড়াতৈল (১৯৫০), উপজেলা: {config.upazila || "সখিপুর"}, জেলা: {config.district || "টাঙ্গাইল"}
                </p>
                <p className="text-[11px] text-amber-300 font-semibold">
                  নাগরিক ডিজিটাল আইডেন্টিটি ও প্রত্যয়নপত্র যাচাইকরণ পোর্টাল
                </p>
              </div>
            </div>

            {/* Live QR Code on Profile Header */}
            {qrCodeDataUrl && (
              <div className="bg-white p-2 rounded-2xl shadow-lg border border-amber-300 text-center shrink-0 flex flex-col items-center">
                <img src={qrCodeDataUrl} alt="Citizen Profile QR Code" className="w-24 h-24 object-contain rounded-lg" />
                <span className="text-[9px] font-bold text-slate-800 mt-1 uppercase tracking-tighter">
                  স্ক্যান করে যাচাই করুন
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Verification Status Banner */}
        <div className="bg-emerald-50 dark:bg-emerald-950/40 border-y border-emerald-200 dark:border-emerald-800/80 px-6 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-emerald-900 dark:text-emerald-200 font-bold">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>নাগরিক মর্যাদা: <span className="text-emerald-700 dark:text-emerald-400 font-black">যাচাইকৃত স্থায়ী অধিবাসী ও ভোটার</span></span>
          </div>
          <div className="flex items-center gap-4 text-slate-600 dark:text-slate-400 text-[11px]">
            <span>ইউনিক নাগরিক ট্র্যাকিং আইডি: <strong className="text-slate-900 dark:text-white font-mono">{citizen.id || 'UP02-CITIZEN-MASTER'}</strong></span>
            <span>সর্বশেষ যাচাই: <strong className="text-slate-900 dark:text-white font-mono">{new Date().toLocaleDateString('bn-BD')}</strong></span>
          </div>
        </div>

        {/* Profile Details Grid */}
        <div className="p-6 md:p-8 space-y-8">
          
          {/* Top Identity Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
            
            {/* Left: Citizen Photo & Primary Badges */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 text-center space-y-4">
              <div className="relative inline-block">
                <div className="w-28 h-28 mx-auto bg-gradient-to-tr from-emerald-700 to-teal-800 rounded-full flex items-center justify-center text-white text-3xl font-black shadow-md border-4 border-white dark:border-slate-800">
                  <User className="w-14 h-14 text-white/90" />
                </div>
                <div className="absolute bottom-0 right-0 p-1.5 bg-emerald-600 text-white rounded-full shadow border-2 border-white dark:border-slate-800" title="যাচাইকৃত নাগরিক">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
              </div>

              <div className="space-y-1">
                <h3 className="text-lg font-black text-slate-900 dark:text-white leading-snug">
                  {citizen.name}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                  পেশা: {citizen.occupation || 'নাগরিক'}
                </p>
                <div className="pt-2 flex flex-wrap items-center justify-center gap-1.5">
                  <span className="px-2.5 py-1 bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 text-[11px] font-bold rounded-lg border border-emerald-300 dark:border-emerald-700">
                    লিঙ্গ: {citizen.gender || 'পুরুষ'}
                  </span>
                  {citizen.age && (
                    <span className="px-2.5 py-1 bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200 text-[11px] font-bold rounded-lg border border-amber-300 dark:border-amber-700">
                      বয়স: {citizen.age} বছর
                    </span>
                  )}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-700 text-[11px] text-slate-500 dark:text-slate-400 space-y-1 text-left">
                <div className="flex justify-between">
                  <span>হোল্ডিং নং:</span>
                  <strong className="text-slate-800 dark:text-slate-200">{citizen.holdingNo || 'এইচ-N/A'}</strong>
                </div>
                <div className="flex justify-between">
                  <span>নিবন্ধন তারিখ:</span>
                  <strong className="text-slate-800 dark:text-slate-200">{citizen.registeredAt || '২০২৫-০১-১০'}</strong>
                </div>
              </div>
            </div>

            {/* Right: Verified Particulars & Address Cards */}
            <div className="md:col-span-2 space-y-4">
              <div className="bg-slate-50 dark:bg-slate-800/60 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-4">
                <h4 className="font-bold text-sm text-emerald-900 dark:text-emerald-300 flex items-center gap-2 border-b border-slate-200 dark:border-slate-700 pb-2">
                  <CreditCard className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                  মৌলিক ও পারিবারিক তথ্যাবলী (Verified Identity)
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-bold">পিতার নাম</span>
                    <span className="font-bold text-slate-800 dark:text-slate-100 text-sm">{citizen.father || 'N/A'}</span>
                  </div>

                  <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-bold">মাতার নাম</span>
                    <span className="font-bold text-slate-800 dark:text-slate-100 text-sm">{citizen.mother || 'N/A'}</span>
                  </div>

                  {citizen.spouseName && (
                    <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                      <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-bold">স্বামী / স্ত্রীর নাম</span>
                      <span className="font-bold text-slate-800 dark:text-slate-100 text-sm">{citizen.spouseName}</span>
                    </div>
                  )}

                  <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-bold">জাতীয় পরিচয়পত্র (NID) / জন্ম সনদ</span>
                    <span className="font-bold font-mono text-emerald-800 dark:text-emerald-300 text-sm">
                      {citizen.nid || citizen.birthNo || 'যাচাইকৃত'}
                    </span>
                  </div>

                  <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-bold">মোবাইল নম্বর</span>
                    <span className="font-bold font-mono text-slate-800 dark:text-slate-200 text-sm">
                      {citizen.mobileMasked || citizen.mobile || '০১৭****৩০০'}
                    </span>
                  </div>

                  <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-bold">জন্ম তারিখ</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200 text-sm">
                      {citizen.dateOfBirth || 'N/A'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Residential Jurisdiction & Address */}
              <div className="bg-slate-50 dark:bg-slate-800/60 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-4">
                <h4 className="font-bold text-sm text-emerald-900 dark:text-emerald-300 flex items-center gap-2 border-b border-slate-200 dark:border-slate-700 pb-2">
                  <MapPin className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                  স্থায়ী ঠিকানা ও নির্বাচনী অধিক্ষেত্র
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-center">
                  <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 text-[10px] block font-semibold">গ্রাম</span>
                    <strong className="text-slate-900 dark:text-slate-100 font-bold">{citizen.village}</strong>
                  </div>
                  <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 text-[10px] block font-semibold">ওয়ার্ড নং</span>
                    <strong className="text-emerald-800 dark:text-emerald-400 font-bold">{citizen.wardNo}</strong>
                  </div>
                  <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 text-[10px] block font-semibold">ডাকঘর</span>
                    <strong className="text-slate-900 dark:text-slate-100 font-bold">{citizen.postOffice || 'বহেড়াতৈল'}</strong>
                  </div>
                  <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 text-[10px] block font-semibold">উপজেলা ও জেলা</span>
                    <strong className="text-slate-900 dark:text-slate-100 font-bold">সখিপুর, টাঙ্গাইল</strong>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Issued Certificates Portfolio (Facilitating Direct External Verification Without Tracking Codes) */}
          <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
                  ইস্যুকৃত প্রত্যয়নপত্র ও সনদ পোর্টফোলিও (Issued Certificates)
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  উক্ত নাগরিকের নামে পরিষদ কর্তৃক ইস্যুকৃত সকল বৈধ সনদপত্র নিচে তালিকাভুক্ত করা হয়েছে। কোনো ট্র্যাকিং কোড ছাড়াই যে কোনো কর্তৃপক্ষ সরাসরি যাচাই ও সনদ দেখতে পারবেন।
                </p>
              </div>

              {certificates.length > 3 && (
                <div className="relative">
                  <input
                    type="text"
                    placeholder="সনদ খুঁজুন..."
                    value={searchCertQuery}
                    onChange={(e) => setSearchCertQuery(e.target.value)}
                    className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 w-40"
                  />
                </div>
              )}
            </div>

            {certificates.length === 0 ? (
              <div className="bg-slate-50 dark:bg-slate-800/40 p-8 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 text-center space-y-2">
                <FileText className="w-10 h-10 text-slate-400 mx-auto" />
                <h4 className="font-bold text-sm text-slate-700 dark:text-slate-300">এখনো কোনো প্রত্যয়নপত্র ইস্যু করা হয় নাই</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
                  এই নাগরিকের তথ্য ডাটাবেজে যাচাইকৃত অবস্থায় সংরক্ষিত আছে। নতুন কোনো প্রত্যয়নপত্র তৈরি হইলে এই তালিকায় স্বয়ংক্রিয়ভাবে যুক্ত হইবে।
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredCertificates.map((cert, idx) => (
                  <div
                    key={cert.id || idx}
                    className="bg-white dark:bg-slate-900 p-5 rounded-2xl border-2 border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-600 transition shadow-sm space-y-3 group"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-1">
                        <span className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[10px] font-black rounded-md border border-emerald-300 dark:border-emerald-800 uppercase">
                          {cert.category || 'নাগরিক সেবা'}
                        </span>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white group-hover:text-emerald-700 dark:group-hover:text-emerald-400 transition">
                          {cert.typeLabel}
                        </h4>
                      </div>
                      <span className="px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 text-[10px] font-bold rounded-full border border-emerald-300 dark:border-emerald-800 flex items-center gap-1 shrink-0">
                        <CheckCircle2 className="w-3 h-3" /> সক্রিয় ও বৈধ
                      </span>
                    </div>

                    <div className="text-xs text-slate-600 dark:text-slate-400 space-y-1 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl">
                      <div className="flex justify-between">
                        <span>স্মারক নম্বর:</span>
                        <strong className="font-mono text-slate-800 dark:text-slate-200">{cert.memoNo}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>ইস্যুর তারিখ:</span>
                        <strong className="text-slate-800 dark:text-slate-200">{cert.issueDate}</strong>
                      </div>
                      {cert.paymentStatus && (
                        <div className="flex justify-between">
                          <span>ফি ও পরিশোধ:</span>
                          <strong className="text-emerald-700 dark:text-emerald-400 font-bold">{cert.feeAmount || 50} ৳ (পরিশোধিত)</strong>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => setSelectedCertForView(cert)}
                        className="flex-1 py-2 px-3 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition shadow cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" /> সনদপত্র দেখুন ও প্রিন্ট
                      </button>

                      <a
                        href={cert.verificationUrl || `/?verify=${encodeURIComponent(cert.memoNo)}`}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl transition cursor-pointer"
                        title="পৃথক অনলাইন ভেরিফিকেশন লিঙ্ক"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section 3: Official Verification Statement & Government Seal */}
          <div className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-slate-800/60 dark:to-slate-800/40 p-6 rounded-2xl border border-emerald-200 dark:border-emerald-800/60 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-2 text-center md:text-left">
              <div className="inline-flex items-center gap-1.5 text-xs font-black text-emerald-900 dark:text-emerald-300">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                দাপ্তরিক ঘোষণা ও সতত্যা প্রত্যয়ন
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed max-w-xl">
                এই ডিজিটাল প্রোফাইলে প্রদর্শিত সকল তথ্যাবলী ও ইস্যুকৃত সনদপত্রসমূহ ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের কেন্দ্রীয় ডাটাবেজ হইতে সরাসরি সংরক্ষিত ও অনুমোদিত। ব্যাংক, পাসপোর্ট অধিদপ্তর, দূতাবাস, শিক্ষা প্রতিষ্ঠান বা যেকোনো সরকারি/বেসরকারি প্রতিষ্ঠান এই লিংকের মাধ্যমে নাগরিকের তথ্যের সত্যতা নিশ্চিন্তে গ্রহণ করিতে পারিবেন।
              </p>
            </div>

            <div className="flex items-center gap-6 shrink-0 text-center text-xs">
              <div className="space-y-1">
                <div className="w-16 h-12 border-b-2 border-emerald-800 dark:border-emerald-400 flex items-center justify-center font-cursive text-slate-700 dark:text-slate-300 font-bold text-xs italic">
                  স্বাক্ষরিত
                </div>
                <p className="font-bold text-slate-800 dark:text-slate-200 text-[11px]">{config.secretaryName || "মোঃ সাইদুজ্জামান"}</p>
                <p className="text-[10px] text-slate-500">প্রশাসনিক কর্মকর্তা</p>
              </div>

              <div className="space-y-1">
                <div className="w-16 h-12 border-b-2 border-emerald-800 dark:border-emerald-400 flex items-center justify-center font-cursive text-slate-700 dark:text-slate-300 font-bold text-xs italic">
                  স্বাক্ষরিত
                </div>
                <p className="font-bold text-slate-800 dark:text-slate-200 text-[11px]">{config.chairmanName || "মোশারফ হোসেন (হিরো মিয়া)"}</p>
                <p className="text-[10px] text-slate-500">চেয়ারম্যান</p>
              </div>
            </div>
          </div>

        </div>

        {/* Official Footer Banner */}
        <div className="bg-slate-900 text-slate-400 px-6 py-4 text-[11px] flex flex-wrap items-center justify-between gap-2 border-t border-slate-800">
          <span>© ২০২৬ {config.upName || "০২নং বহেড়াতৈল ইউনিয়ন পরিষদ"}। ডিজিটাল ট্র্যাকিং ও পাবলিক ভেরিফিকেশন সিস্টেম।</span>
          <span>কারিগরি সহায়তায়: MD JUBAER HOSSEN (Computer and Data Operator)</span>
        </div>
      </div>

      {/* Interactive Modal to View Selected Certificate Directly */}
      {selectedCertForView && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-700" />
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  সনদপত্র প্রিভিউ: {selectedCertForView.typeLabel}
                </h3>
              </div>
              <button
                onClick={() => setSelectedCertForView(null)}
                className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <CertificateView
              certificate={selectedCertForView}
              config={config}
              onBack={() => setSelectedCertForView(null)}
            />
          </div>
        </div>
      )}
    </div>
  );
};
