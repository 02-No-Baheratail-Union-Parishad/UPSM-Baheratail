import React, { useState, useEffect } from 'react';
import { 
  Workflow, 
  Layers, 
  Zap, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  RefreshCw, 
  ExternalLink, 
  Copy, 
  Check, 
  ShieldCheck, 
  Key, 
  Database, 
  Globe, 
  Send, 
  CreditCard, 
  FileText, 
  Code2, 
  Settings, 
  Play, 
  Terminal, 
  Activity,
  Search,
  Filter,
  CheckCheck,
  ChevronRight,
  ArrowUpRight,
  Cloud,
  Cpu,
  Server,
  Sparkles
} from 'lucide-react';
import { CloudConnectorConfig, CloudConnectorKey, ConnectorSyncLog, UnionParishadConfig } from '../types';

interface CloudConnectorsHubProps {
  config: UnionParishadConfig;
  onUpdateConfig?: (newConfig: UnionParishadConfig) => void;
}

interface ConnectorMetadata {
  key: CloudConnectorKey;
  name: string;
  nameBn: string;
  tagline: string;
  taglineBn: string;
  category: 'Automation & AI' | 'Deployment & Hosting' | 'Database & Storage' | 'Productivity & Docs' | 'Payments & Messaging' | 'Website & CMS';
  badgeColor: string;
  bgGradient: string;
  iconBg: string;
  fields: {
    key: string;
    label: string;
    labelBn: string;
    type: 'text' | 'password' | 'url';
    placeholder: string;
    description: string;
  }[];
  supportedEvents: string[];
  docsUrl: string;
  sampleCodeSnippet: string;
}

const CONNECTORS_REGISTRY: ConnectorMetadata[] = [
  {
    key: 'linear',
    name: 'Linear',
    nameBn: 'লিনিয়ার (Linear Issue Tracker)',
    tagline: 'Automated issue creation for certificate reviews & flagged applications',
    taglineBn: 'সনদ রিভিউ ও ফ্ল্যাগ হওয়া আবেদনের জন্য স্বয়ংক্রিয় লিনিয়ার টিকিট তৈরি',
    category: 'Automation & AI',
    badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    bgGradient: 'from-indigo-950/40 via-slate-900 to-slate-950',
    iconBg: 'bg-indigo-600',
    fields: [
      { key: 'apiKey', label: 'Linear API Key', labelBn: 'Linear API Key', type: 'password', placeholder: 'lin_api_xxxxxxxxxxxxxxxx', description: 'Settings > API > Personal API Keys হতে সংগ্রহ করুন' },
      { key: 'teamId', label: 'Team ID / Key', labelBn: 'টিম আইডি / কী (Team Key)', type: 'text', placeholder: 'UP-ADMIN বা BUP', description: 'যে টিমে স্বয়ংক্রিয়ভাবে টাস্ক বা ইস্যু তৈরি হইবে' },
      { key: 'webhookUrl', label: 'Linear Webhook URL (Optional)', labelBn: 'ওয়েবহুক লিংক', type: 'url', placeholder: 'https://api.linear.app/webhooks/...', description: 'দ্বিমুখী স্ট্যাটাস আপডেটের জন্য' }
    ],
    supportedEvents: ['certificate.flagged', 'certificate.rejected', 'audit.discrepancy', 'sla.breached'],
    docsUrl: 'https://linear.app/docs/api',
    sampleCodeSnippet: `// Linear Issue Creation on Flagged Certificate
const linearClient = new LinearClient({ apiKey: process.env.LINEAR_API_KEY });
await linearClient.createIssue({
  teamId: "UP_ADMIN",
  title: "[Citizen Verification Required] " + cert.memoNo,
  description: \`Applicant: \${cert.citizen.name}\\nNID: \${cert.citizen.nid}\\nWard: \${cert.citizen.wardNo}\`,
  priority: 1
});`
  },
  {
    key: 'lovable',
    name: 'Lovable',
    nameBn: 'লাভেবল (Lovable AI Sandbox)',
    tagline: 'Instant UI generation, code export, and live frontend preview sync',
    taglineBn: 'লাইভ ফ্রন্টএন্ড প্রিভিউ সিঙ্ক ও ইউআই কম্পোনেন্ট অটো-জেনারেটর',
    category: 'Automation & AI',
    badgeColor: 'bg-pink-500/20 text-pink-300 border-pink-500/30',
    bgGradient: 'from-pink-950/40 via-slate-900 to-slate-950',
    iconBg: 'bg-pink-600',
    fields: [
      { key: 'apiKey', label: 'Lovable Project Token', labelBn: 'Lovable প্রজেক্ট টোকেন', type: 'password', placeholder: 'lov_proj_xxxxxxxxxxxxxxxx', description: 'Lovable Project Settings > API Access' },
      { key: 'endpointUrl', label: 'Preview Sync URL', labelBn: 'প্রিভিউ সিঙ্ক ইউআরএল', type: 'url', placeholder: 'https://lovable.dev/projects/...', description: 'লাইভ প্রিভিউ সিঙ্ক করার ঠিকানা' }
    ],
    supportedEvents: ['ui.template_updated', 'theme.changed', 'certificate.layout_customized'],
    docsUrl: 'https://lovable.dev',
    sampleCodeSnippet: `// Lovable Live Preview Trigger
fetch("https://api.lovable.dev/v1/sync", {
  method: "POST",
  headers: { "Authorization": "Bearer " + LOVABLE_TOKEN, "Content-Type": "application/json" },
  body: JSON.stringify({ project: "UPSM-Baheratail", components: ["CertificateView", "AdminSettings"] })
});`
  },
  {
    key: 'make',
    name: 'Make (Integromat)',
    nameBn: 'মেক / ইন্টিগ্রোম্যাট (Make Automation)',
    tagline: 'Visual multi-branch automation scenarios for government workflows',
    taglineBn: 'ভিজুয়াল অটোমেশন সিনারিও ও মাল্টি-স্টেপ ডাটা পাইপলাইন',
    category: 'Automation & AI',
    badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    bgGradient: 'from-purple-950/40 via-slate-900 to-slate-950',
    iconBg: 'bg-purple-600',
    fields: [
      { key: 'webhookUrl', label: 'Make Custom Webhook URL', labelBn: 'Make কাস্টম ওয়েবহুক লিংক', type: 'url', placeholder: 'https://hook.eu1.make.com/xxxxxxxxxxxxxxxx', description: 'Make.com Scenario এর Webhook মডিউল হতে URL টি কপি করুন' },
      { key: 'apiKey', label: 'Make API Token (Optional)', labelBn: 'Make API টোকেন', type: 'password', placeholder: 'make_api_xxxxxxxxxxxxxxxx', description: 'সিনারিও স্বয়ংক্রিয়ভাবে চালু করার জন্য' }
    ],
    supportedEvents: ['certificate.created', 'certificate.approved', 'citizen.registered', 'backup.completed'],
    docsUrl: 'https://www.make.com/en/help',
    sampleCodeSnippet: `// Make.com Multi-Step Trigger Payload
fetch(MAKE_WEBHOOK_URL, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    event: "certificate.approved",
    memoNo: "BUP-2026-8941",
    citizen: { name: "মোঃ জলিল শেখ", mobile: "01712345678" },
    downloadUrl: "https://union.gov.bd/verify/BUP-2026-8941"
  })
});`
  },
  {
    key: 'notion',
    name: 'Notion',
    nameBn: 'নোশন (Notion Knowledge & DB Sync)',
    tagline: 'Bi-directional sync of citizen certificates, resolutions & union logs',
    taglineBn: 'নাগরিক সনদ, সিদ্ধান্ত ও ইউপি রেজোলিউশন নোশন ডাটাবেসে স্বয়ংক্রিয় সিঙ্ক',
    category: 'Productivity & Docs',
    badgeColor: 'bg-slate-400/20 text-slate-200 border-slate-400/30',
    bgGradient: 'from-slate-800/40 via-slate-900 to-slate-950',
    iconBg: 'bg-slate-700',
    fields: [
      { key: 'apiKey', label: 'Notion Internal Integration Secret', labelBn: 'Notion ইন্টিগ্রেশন সিক্রেট কী', type: 'password', placeholder: 'secret_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', description: 'notion.so/my-integrations হতে ক্রিয়েট করুন' },
      { key: 'databaseId', label: 'Notion Master Database ID', labelBn: 'নোশন ডাটাবেস আইডি (Database ID)', type: 'text', placeholder: '32-character Notion database UUID', description: 'ডাটাবেস পেজ লিংকের ৩২ ডিজিটের কোড' }
    ],
    supportedEvents: ['certificate.created', 'certificate.approved', 'citizen.registered', 'council.resolution'],
    docsUrl: 'https://developers.notion.com',
    sampleCodeSnippet: `// Sync Certificate to Notion Database Page
const response = await notion.pages.create({
  parent: { database_id: NOTION_DATABASE_ID },
  properties: {
    "স্মারক নং": { title: [{ text: { content: cert.memoNo } }] },
    "নাম": { rich_text: [{ text: { content: cert.citizen.name } }] },
    "সনদের ধরন": { select: { name: cert.typeLabel } },
    "স্ট্যাটাস": { status: { name: "ইস্যুকৃত" } }
  }
});`
  },
  {
    key: 'send',
    name: 'Send (Resend / SMS Gateway)',
    nameBn: 'সেন্ড সার্ভিস (Citizen SMS & Email Notifications)',
    tagline: 'Instant transactional SMS & PDF download emails for citizens',
    taglineBn: 'আবেদনকারী নাগরিকদের মোবাইল এসএমএস ও ইমেইলে স্বয়ংক্রিয় নোটিফিকেশন',
    category: 'Payments & Messaging',
    badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    bgGradient: 'from-emerald-950/40 via-slate-900 to-slate-950',
    iconBg: 'bg-emerald-600',
    fields: [
      { key: 'apiKey', label: 'Resend / SMS Gateway API Key', labelBn: 'API Key (Resend / SMS)', type: 'password', placeholder: 're_xxxxxxxxxxxxxxxxx বা sms_api_key', description: 'ট্রানজেকশনাল এসএমএস ও ইমেইল সার্ভিস' },
      { key: 'endpointUrl', label: 'SMS Gateway Endpoint URL (Optional)', labelBn: 'বাংলাদেশী SMS গেটওয়ে এন্ডপয়েন্ট', type: 'url', placeholder: 'https://api.sms-gateway.bd/v2/send', description: 'বিটিআরসি অনুমোদিত বাল্ক এসএমএস এপিআই' }
    ],
    supportedEvents: ['sms.certificate_ready', 'sms.otp_verification', 'email.pdf_attachment', 'sms.payment_received'],
    docsUrl: 'https://resend.com/docs',
    sampleCodeSnippet: `// Send SMS to Citizen with Direct QR Verification Link
await resend.emails.send({
  from: "ইউনিয়ন পরিষদ <noreply@union.gov.bd>",
  to: [citizen.email],
  subject: "আপনার প্রত্যয়নপত্র প্রস্তুত হইয়াছে - " + cert.memoNo,
  html: \`<p>সম্মানিত নাগরিক \${citizen.name}, আপনার \${cert.typeLabel} অনুমোদিত হইয়াছে। ডাউনলোড করুন: \${cert.verificationUrl}</p>\`
});`
  },
  {
    key: 'twilio',
    name: 'Twilio WhatsApp & Messaging',
    nameBn: 'টুইলিও হোয়াটসঅ্যাপ ও এসএমএস গেটওয়ে (Twilio WhatsApp API)',
    tagline: 'Automated citizen certificate notification & direct verification QR dispatch',
    taglineBn: 'নাগরিকের মোবাইলে স্বয়ংক্রিয় হোয়াটসঅ্যাপ নোটিফিকেশন ও ভেরিফিকেশন QR কোড লিংক প্রেরণ',
    category: 'Payments & Messaging',
    badgeColor: 'bg-green-500/20 text-green-300 border-green-500/30',
    bgGradient: 'from-green-950/40 via-slate-900 to-slate-950',
    iconBg: 'bg-emerald-600',
    fields: [
      { key: 'teamId', label: 'Twilio Account SID', labelBn: 'Twilio Account SID', type: 'text', placeholder: 'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', description: 'Twilio Console Dashboard হতে সংগ্রহ করুন' },
      { key: 'apiKey', label: 'Twilio Auth Token', labelBn: 'Twilio Auth Token', type: 'password', placeholder: 'your_auth_token_here', description: 'সিক্রেট অথেনটিকেশন টোকেন' },
      { key: 'endpointUrl', label: 'WhatsApp Sender Number', labelBn: 'হোয়াটসঅ্যাপ সেন্ডার নম্বর', type: 'text', placeholder: 'whatsapp:+14155238886', description: 'Twilio Sandbox বা ভেরিফাইড Business WhatsApp Sender' }
    ],
    supportedEvents: ['whatsapp.certificate_ready', 'whatsapp.verification_qr', 'whatsapp.fee_receipt', 'sms.otp'],
    docsUrl: 'https://www.twilio.com/docs/whatsapp/api',
    sampleCodeSnippet: `// Send Official Certificate Notification via Twilio WhatsApp API
const message = await twilioClient.messages.create({
  from: 'whatsapp:+14155238886',
  to: 'whatsapp:+8801712345678',
  body: \`🏛️ \${upName}\\nসম্মানিত \${citizen.name}, আপনার \${cert.typeLabel} অনুমোদিত হইয়াছে।\\nভেরিফিকেশন লিংক: \${cert.verificationUrl}\\nQR কোড: \${cert.qrCodeUrl}\`
});`
  },
  {
    key: 'stripe',
    name: 'Stripe',
    nameBn: 'স্ট্রাইপ পেমেন্ট গেটওয়ে (Stripe Fee Collection)',
    tagline: 'International & card payment processing for official UP certificates & taxes',
    taglineBn: 'ইউপি ট্যাক্স ও সনদের সরকারি ফি আদায়ে নিরাপদ অনলাইন পেমেন্ট গেটওয়ে',
    category: 'Payments & Messaging',
    badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
    bgGradient: 'from-cyan-950/40 via-slate-900 to-slate-950',
    iconBg: 'bg-cyan-600',
    fields: [
      { key: 'publicKey', label: 'Stripe Publishable Key', labelBn: 'পাবলিশেবল কী (Publishable Key)', type: 'text', placeholder: 'pk_live_xxxxxxxxxxxxxxxxxxxxxxxx', description: 'Stripe Dashboard > Developers > API Keys' },
      { key: 'secretKey', label: 'Stripe Secret Key', labelBn: 'সিক্রেট কী (Secret Key)', type: 'password', placeholder: 'sk_live_xxxxxxxxxxxxxxxxxxxxxxxx', description: 'সার্ভার-সাইড পেমেন্ট ভেরিফিকেশনের জন্য' },
      { key: 'webhookUrl', label: 'Stripe Webhook Secret (whsec_...)', labelBn: 'ওয়েবহুক সিক্রেট সাইনিং কী', type: 'password', placeholder: 'whsec_xxxxxxxxxxxxxxxxxxxxxxxx', description: 'পেমেন্ট সফল হলে স্বয়ংক্রিয় সনদ ইস্যুর জন্য' }
    ],
    supportedEvents: ['checkout.session.completed', 'payment_intent.succeeded', 'charge.refunded'],
    docsUrl: 'https://stripe.com/docs/api',
    sampleCodeSnippet: `// Create Stripe Checkout Session for UP Certificate Fee
const session = await stripe.checkout.sessions.create({
  payment_method_types: ['card'],
  line_items: [{
    price_data: {
      currency: 'bdt',
      product_data: { name: 'নাগরিক সনদপত্র ফি - ' + certType.label },
      unit_amount: 10000 // 100 BDT
    },
    quantity: 1
  }],
  mode: 'payment',
  success_url: 'https://union.gov.bd/verify/' + cert.memoNo + '?payment=success'
});`
  },
  {
    key: 'supabase',
    name: 'Supabase',
    nameBn: 'সুপাবেস (Supabase Realtime DB & Storage)',
    tagline: 'PostgreSQL database sync, realtime streaming, and cloud file storage',
    taglineBn: 'রিয়েলটাইম পোস্টগ্রেস ডাটাবেস ও ক্লাউড ফাইল স্টোরেজ ব্যাকআপ',
    category: 'Database & Storage',
    badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    bgGradient: 'from-emerald-950/40 via-slate-900 to-slate-950',
    iconBg: 'bg-emerald-700',
    fields: [
      { key: 'endpointUrl', label: 'Supabase Project URL', labelBn: 'Supabase প্রজেক্ট URL', type: 'url', placeholder: 'https://xyzcompany.supabase.co', description: 'Project Settings > API > Project URL' },
      { key: 'apiKey', label: 'Supabase Anon / Service Role Key', labelBn: 'সার্ভিস রোল কী (Service Key)', type: 'password', placeholder: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...', description: 'সার্ভার সাইড ব্যাকআপ ও ডাটাবেস রাইট পারমিশন' },
      { key: 'databaseId', label: 'Storage Bucket Name (Optional)', labelBn: 'স্টোরেজ বাকেট নাম', type: 'text', placeholder: 'union-certificates-pdf', description: 'পিডিএফ ও সিল সংরক্ষণের বাকেট' }
    ],
    supportedEvents: ['db.sync_record', 'storage.upload_pdf', 'realtime.broadcast'],
    docsUrl: 'https://supabase.com/docs',
    sampleCodeSnippet: `// Direct Realtime Insert to Supabase PostgreSQL
const { data, error } = await supabase
  .from('certificates')
  .insert([{
    memo_no: cert.memoNo,
    citizen_name: cert.citizen.name,
    nid: cert.citizen.nid,
    issued_date: cert.issueDateEn,
    status: 'issued'
  }]);`
  },
  {
    key: 'superhuman',
    name: 'Superhuman Docs',
    nameBn: 'সুপারহিউম্যান ডক্স ও গুগল ডক ভল্ট (Official Docs Vault)',
    tagline: 'Instant document synthesis, markdown sync & executive summaries',
    taglineBn: 'সরকারি সারসংক্ষেপ ও স্বয়ংক্রিয় ক্লাউড ডকুমেন্ট ভল্ট সিঙ্ক',
    category: 'Productivity & Docs',
    badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    bgGradient: 'from-amber-950/40 via-slate-900 to-slate-950',
    iconBg: 'bg-amber-600',
    fields: [
      { key: 'apiKey', label: 'Docs API Access Token', labelBn: 'ডক্স API এক্সেস টোকেন', type: 'password', placeholder: 'sh_doc_xxxxxxxxxxxxxxxxxxxxxxxx', description: 'ডকুমেন্ট ভল্ট এপিআই অনুমোদন' },
      { key: 'databaseId', label: 'Master Drive Folder ID', labelBn: 'মাস্টার ড্রাইভ ফোল্ডার আইডি', type: 'text', placeholder: '1A2b3C4d5E6f7G8h9I0jKlMnOpQrStUvW', description: 'যেখানে স্বয়ংক্রিয়ভাবে ওয়ার্ড/ডক ফাইল জমা হইবে' }
    ],
    supportedEvents: ['doc.generated', 'doc.archived', 'gazette.published'],
    docsUrl: 'https://workspace.google.com/products/docs',
    sampleCodeSnippet: `// Superhuman Document Auto-Archival
await docsVault.publish({
  title: "ইউনিয়ন কার্যবিবরণী ও সনদ রিপোর্ট: " + cert.memoNo,
  content: cert.bodyText,
  folderId: MASTER_FOLDER_ID,
  metadata: { ward: cert.citizen.wardNo, date: cert.issueDate }
});`
  },
  {
    key: 'vercel',
    name: 'Vercel',
    nameBn: 'ভার্সেল (Vercel Edge Cloud)',
    tagline: 'High-speed edge deployment, serverless functions & global CDN',
    taglineBn: 'হাই-স্পিড এজ হোস্টিং ও স্বয়ংক্রিয় প্রোডাকশন ডিপ্লয়মেন্ট হুক',
    category: 'Deployment & Hosting',
    badgeColor: 'bg-slate-200/20 text-white border-white/20',
    bgGradient: 'from-slate-900 via-slate-950 to-black',
    iconBg: 'bg-slate-900',
    fields: [
      { key: 'webhookUrl', label: 'Vercel Deploy Hook URL', labelBn: 'Vercel Deploy Hook URL', type: 'url', placeholder: 'https://api.vercel.com/v1/integrations/deploy/prj_.../hook_...', description: 'Vercel Project Settings > Git > Deploy Hooks' },
      { key: 'apiKey', label: 'Vercel Personal Access Token', labelBn: 'Vercel টোকেন (Token)', type: 'password', placeholder: 'ver_xxxxxxxxxxxxxxxxxxxx', description: 'অটোমেটিক এজ ভ্যারিয়েবল সিঙ্কের জন্য' }
    ],
    supportedEvents: ['deploy.triggered', 'config.rebuilt', 'edge.cache_purged'],
    docsUrl: 'https://vercel.com/docs',
    sampleCodeSnippet: `// Trigger Instant Production Rebuild via Vercel Deploy Hook
fetch(VERCEL_DEPLOY_HOOK, { method: "POST" })
  .then(res => res.json())
  .then(data => console.log("Deployment dispatched to Vercel Edge:", data.job.id));`
  },
  {
    key: 'netlify',
    name: 'Netlify',
    nameBn: 'নেটলিফাই (Netlify Edge Hosting)',
    tagline: 'One-click builds, edge routing & custom domain SSL certificate management',
    taglineBn: 'ওয়ান-ক্লিক বিল্ড, এজ রাউটিং ও কাস্টম ডোমেইন ম্যানেজমেন্ট',
    category: 'Deployment & Hosting',
    badgeColor: 'bg-teal-500/20 text-teal-300 border-teal-500/30',
    bgGradient: 'from-teal-950/40 via-slate-900 to-slate-950',
    iconBg: 'bg-teal-600',
    fields: [
      { key: 'webhookUrl', label: 'Netlify Build Hook URL', labelBn: 'Netlify Build Hook URL', type: 'url', placeholder: 'https://api.netlify.com/build_hooks/xxxxxxxxxxxxxxxx', description: 'Netlify Site Settings > Build & Deploy > Build hooks' },
      { key: 'apiKey', label: 'Netlify Personal Access Token', labelBn: 'Netlify এক্সেস টোকেন', type: 'password', placeholder: 'nfp_xxxxxxxxxxxxxxxxxxxx', description: 'Netlify User Settings > Applications > Personal Access Tokens' }
    ],
    supportedEvents: ['build.dispatched', 'cache.invalidated'],
    docsUrl: 'https://docs.netlify.com',
    sampleCodeSnippet: `// Dispatched Netlify Production Rebuild
fetch("https://api.netlify.com/build_hooks/YOUR_HOOK_ID", {
  method: "POST",
  body: JSON.stringify({ trigger_title: "Union Parishad Master Data Updated" })
});`
  },
  {
    key: 'webflow',
    name: 'Webflow',
    nameBn: 'ওয়েবফ্লো (Webflow CMS & Public Portal)',
    tagline: 'Public portal CMS synchronization & embedded citizen verification widget',
    taglineBn: 'পাবলিক পোর্টাল CMS কালেকশন সিঙ্ক ও ভেরিফিকেশন উইজেট এমবেড',
    category: 'Website & CMS',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    bgGradient: 'from-blue-950/40 via-slate-900 to-slate-950',
    iconBg: 'bg-blue-600',
    fields: [
      { key: 'apiKey', label: 'Webflow API V2 Token', labelBn: 'Webflow API V2 টোকেন', type: 'password', placeholder: 'webflow_token_xxxxxxxxxxxxxxxxxxxxxxxx', description: 'Webflow Site Settings > Integrations > API Access' },
      { key: 'databaseId', label: 'Webflow CMS Collection ID', labelBn: 'CMS কালেকশন আইডি', type: 'text', placeholder: '64d2a1b3c9e8f7a6b5c4d3e2', description: 'নোটিশ বোর্ড বা পাবলিক ভেরিফিকেশন কালেকশন' }
    ],
    supportedEvents: ['cms.item_created', 'notice.published', 'citizen_portal.synced'],
    docsUrl: 'https://developers.webflow.com',
    sampleCodeSnippet: `// Auto-Publish Approved Certificate to Webflow Public CMS
await webflow.collections.items.createItem(WEBFLOW_COLLECTION_ID, {
  fieldData: {
    name: cert.citizen.name,
    slug: cert.memoNo.toLowerCase().replace(/[^a-z0-9]/g, '-'),
    'memo-no': cert.memoNo,
    'certificate-type': cert.typeLabel,
    'issued-date': cert.issueDate
  }
});`
  },
  {
    key: 'wix',
    name: 'Wix & Wix Studio',
    nameBn: 'উইক্স / উইক্স স্টুডিও (Wix Velo CMS Connector)',
    tagline: 'Wix Velo backend webhooks & citizen application submission form sync',
    taglineBn: 'উইক্স ভেলো ব্যাকএন্ড ইন্টিগ্রেশন ও সিটিজেন সার্ভিস পোর্টাল সিঙ্ক',
    category: 'Website & CMS',
    badgeColor: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
    bgGradient: 'from-amber-950/30 via-slate-900 to-slate-950',
    iconBg: 'bg-amber-600',
    fields: [
      { key: 'apiKey', label: 'Wix API Key', labelBn: 'Wix API Key', type: 'password', placeholder: 'wix_api_key_xxxxxxxxxxxxxxxx', description: 'Wix Developers > API Keys' },
      { key: 'projectId', label: 'Wix Account ID / Site ID', labelBn: 'Wix সাইট আইডি (Site ID)', type: 'text', placeholder: 'xxxx-xxxx-xxxx-xxxx', description: 'Wix ড্যাশবোর্ড হতে সাইট আইডি' },
      { key: 'webhookUrl', label: 'Wix HTTP Functions Webhook URL', labelBn: 'Wix HTTP Functions URL', type: 'url', placeholder: 'https://mysite.wixsite.com/_functions/upCertificateHook', description: 'Velo backend http-functions.js' }
    ],
    supportedEvents: ['wix.form_submitted', 'wix.certificate_verified', 'wix.member_synced'],
    docsUrl: 'https://dev.wix.com/docs',
    sampleCodeSnippet: `// Wix Velo backend/http-functions.js Receiver
import { ok, badRequest } from 'wix-http-functions';
export async function post_upCertificateHook(request) {
  const body = await request.body.json();
  // Sync to Wix Data Collection 'UnionCertificates'
  await wixData.insert('UnionCertificates', {
    title: body.data.memoNo,
    citizenName: body.data.citizen.name,
    verified: true
  });
  return ok({ body: { status: "saved" } });
}`
  },
  {
    key: 'replit',
    name: 'Replit',
    nameBn: 'রেপ্লিট (Replit Cloud Agent & Runtime)',
    tagline: 'Continuous cloud agent runner, environment sync, and port bridge',
    taglineBn: 'ক্লাউড এজেন্ট রানিং, এআই কোডিং ব্রিজ ও ডেভ সার্ভার হোস্ট',
    category: 'Deployment & Hosting',
    badgeColor: 'bg-red-500/20 text-red-300 border-red-500/30',
    bgGradient: 'from-red-950/40 via-slate-900 to-slate-950',
    iconBg: 'bg-red-600',
    fields: [
      { key: 'apiKey', label: 'Replit API Token (Optional)', labelBn: 'Replit API Token', type: 'password', placeholder: 'rep_xxxxxxxxxxxxxxxxxxxx', description: 'Replit Account Settings > Developers' },
      { key: 'endpointUrl', label: 'Replit Dev URL / Bridge', labelBn: 'Replit Dev URL', type: 'url', placeholder: 'https://upsm-baheratail.replit.app', description: 'হোস্টেড রেপ্লিট এপ্লিকেশন ইউআরএল' }
    ],
    supportedEvents: ['replit.keep_alive', 'replit.agent_action', 'env.sync'],
    docsUrl: 'https://docs.replit.com',
    sampleCodeSnippet: `// Replit Environment Keep-Alive & Health Check
fetch("https://upsm-baheratail.replit.app/api/health")
  .then(res => res.json())
  .then(data => console.log("Replit Container Status:", data.status));`
  }
];

export const CloudConnectorsHub: React.FC<CloudConnectorsHubProps> = ({
  config,
  onUpdateConfig
}) => {
  const [connectors, setConnectors] = useState<CloudConnectorConfig[]>([]);
  const [syncLogs, setSyncLogs] = useState<ConnectorSyncLog[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeModalConnector, setActiveModalConnector] = useState<ConnectorMetadata | null>(null);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [selectedEvents, setSelectedEvents] = useState<string[]>([]);
  const [isTesting, setIsTesting] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'connectors' | 'logs' | 'embeds'>('connectors');

  // Fetch connectors and sync logs from server
  const fetchConnectors = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/admin/connectors');
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setConnectors(data.connectors || []);
          setSyncLogs(data.logs || []);
        }
      }
    } catch (err) {
      console.warn("Failed to fetch connectors from server:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchConnectors();
  }, []);

  const categories = ['All', 'Automation & AI', 'Deployment & Hosting', 'Database & Storage', 'Productivity & Docs', 'Payments & Messaging', 'Website & CMS'];

  const filteredMetadata = CONNECTORS_REGISTRY.filter(item => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.nameBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.tagline.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const getConnectorState = (key: CloudConnectorKey): CloudConnectorConfig | undefined => {
    return connectors.find(c => c.key === key);
  };

  const handleOpenConfigModal = (meta: ConnectorMetadata) => {
    setActiveModalConnector(meta);
    const existing = getConnectorState(meta.key);
    if (existing) {
      setFormData({
        apiKey: existing.apiKey || '',
        webhookUrl: existing.webhookUrl || '',
        endpointUrl: existing.endpointUrl || '',
        databaseId: existing.databaseId || '',
        teamId: existing.teamId || '',
        projectId: existing.projectId || '',
        publicKey: existing.publicKey || '',
        secretKey: existing.secretKey || ''
      });
      setSelectedEvents(existing.enabledEvents || meta.supportedEvents);
    } else {
      setFormData({});
      setSelectedEvents(meta.supportedEvents);
    }
    setTestResult(null);
  };

  const handleSaveConnector = async () => {
    if (!activeModalConnector) return;
    setIsTesting(true);
    try {
      const payload = {
        key: activeModalConnector.key,
        name: activeModalConnector.name,
        nameBn: activeModalConnector.nameBn,
        tagline: activeModalConnector.tagline,
        category: activeModalConnector.category,
        ...formData,
        enabledEvents: selectedEvents,
        status: Object.values(formData).some(v => typeof v === 'string' && v.trim().length > 0) ? 'connected' : 'disconnected'
      };

      const res = await fetch('/api/admin/connectors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (data.success) {
        setTestResult({ success: true, message: `${activeModalConnector.name} কানেক্টর সফলভাবে সংরক্ষিত ও কনফিগার করা হইয়াছে!` });
        await fetchConnectors();
        setTimeout(() => {
          setActiveModalConnector(null);
          setTestResult(null);
        }, 1200);
      } else {
        setTestResult({ success: false, message: data.message || "সংরক্ষণ ব্যর্থ হইয়াছে।" });
      }
    } catch (err: any) {
      setTestResult({ success: false, message: "সার্ভার এরর: " + (err.message || String(err)) });
    } finally {
      setIsTesting(false);
    }
  };

  const handleTestPing = async (meta: ConnectorMetadata) => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await fetch('/api/admin/connectors/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          key: meta.key,
          ...formData
        })
      });
      const data = await res.json();
      setTestResult({
        success: data.success,
        message: data.message || (data.success ? "টেস্ট কানেকশন সফল!" : "কানেকশন ব্যর্থ")
      });
      await fetchConnectors();
    } catch (err: any) {
      setTestResult({
        success: false,
        message: "টেস্ট রিকোয়েস্ট ব্যর্থ: " + (err.message || String(err))
      });
    } finally {
      setIsTesting(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const connectedCount = connectors.filter(c => c.status === 'connected').length;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 border border-emerald-700/60 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-500/20 border border-emerald-400/40 rounded-full text-emerald-300 text-xs font-bold">
              <Zap className="w-3.5 h-3.5 animate-pulse text-amber-300" />
              <span>Enterprise Cloud Integration Hub</span>
              <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-1.5 py-0.2 rounded-full">13 কানেক্টরস</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <span>ক্লাউড কানেক্টরস ও এন্টারপ্রাইজ অটোমেশন হাব</span>
            </h2>
            <p className="text-slate-300 text-sm max-w-3xl leading-relaxed">
              Linear, Lovable, Make, Netlify, Notion, Replit, Send, Stripe, Supabase, Superhuman Docs, Vercel, Webflow ও Wix — সকল আধুনিক ক্লাউড প্ল্যাটফর্মের সাথে ইউনিয়ন পরিষদের ডিজিটাল সনদ সিস্টেমকে স্বয়ংক্রিয়ভাবে সংযুক্ত করুন।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 bg-slate-950/70 p-4 rounded-2xl border border-slate-800 shrink-0">
            <div className="text-center px-3 border-r border-slate-800">
              <div className="text-2xl font-black text-amber-400">{connectedCount} / {CONNECTORS_REGISTRY.length}</div>
              <div className="text-[11px] text-slate-400 font-bold">সংযুক্ত কানেক্টরস</div>
            </div>
            <div className="text-center px-3">
              <div className="text-2xl font-black text-emerald-400">{syncLogs.length}</div>
              <div className="text-[11px] text-slate-400 font-bold">অটো-সিঙ্ক ইভেন্টস</div>
            </div>
            <button
              onClick={fetchConnectors}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl transition cursor-pointer"
              title="রিফ্রেশ করুন"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-emerald-400' : ''}`} />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-4 border-t border-slate-800/80 text-xs font-bold">
          <button
            onClick={() => setActiveTab('connectors')}
            className={`px-4 py-2 rounded-xl transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'connectors'
                ? 'bg-emerald-500 text-slate-950 shadow-md font-black'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>১. সকল ক্লাউড কানেক্টরস ({CONNECTORS_REGISTRY.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`px-4 py-2 rounded-xl transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'logs'
                ? 'bg-emerald-500 text-slate-950 shadow-md font-black'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>২. লাইভ সিঙ্ক অডিট লগ ({syncLogs.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('embeds')}
            className={`px-4 py-2 rounded-xl transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'embeds'
                ? 'bg-emerald-500 text-slate-950 shadow-md font-black'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>৩. এমবেড উইজেট ও কোড স্নাইপেট</span>
          </button>
        </div>
      </div>

      {/* TAB 1: CONNECTORS GRID */}
      {activeTab === 'connectors' && (
        <div className="space-y-6">
          {/* Filters & Search */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {cat === 'All' ? 'সব কানেক্টরস' : cat}
                </button>
              ))}
            </div>

            <div className="relative min-w-[240px]">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="কানেক্টর বা প্ল্যাটফর্ম খুঁজুন..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Connectors Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredMetadata.map((meta) => {
              const state = getConnectorState(meta.key);
              const isConnected = state?.status === 'connected';

              return (
                <div
                  key={meta.key}
                  className={`bg-slate-900 border ${
                    isConnected ? 'border-emerald-500/50 shadow-emerald-950/20' : 'border-slate-800'
                  } rounded-2xl p-5 flex flex-col justify-between transition hover:shadow-lg hover:border-slate-700 relative overflow-hidden group`}
                >
                  {/* Subtle Top Accent */}
                  <div className={`h-1.5 w-full absolute top-0 left-0 ${isConnected ? 'bg-gradient-to-r from-emerald-400 to-teal-400' : 'bg-slate-800'}`} />

                  <div className="space-y-3 pt-1">
                    {/* Header */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl ${meta.iconBg} flex items-center justify-center text-white font-black text-sm shadow-md shrink-0`}>
                          {meta.name.substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                            <span>{meta.name}</span>
                          </h3>
                          <span className="text-[11px] text-slate-400 font-medium block">
                            {meta.nameBn}
                          </span>
                        </div>
                      </div>

                      <span
                        className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold border flex items-center gap-1 ${
                          isConnected
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                            : 'bg-slate-800 text-slate-400 border-slate-700'
                        }`}
                      >
                        {isConnected ? (
                          <>
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            <span>সংযুক্ত</span>
                          </>
                        ) : (
                          <>
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-500"></span>
                            <span>অসংযুক্ত</span>
                          </>
                        )}
                      </span>
                    </div>

                    {/* Tagline */}
                    <p className="text-slate-300 text-xs leading-relaxed min-h-[36px]">
                      {meta.taglineBn}
                    </p>

                    {/* Category & Supported Events Pills */}
                    <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-800/80">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${meta.badgeColor}`}>
                        {meta.category}
                      </span>
                      {meta.supportedEvents.slice(0, 2).map((ev) => (
                        <span key={ev} className="px-1.5 py-0.5 bg-slate-800 text-slate-400 text-[9px] font-mono rounded">
                          {ev}
                        </span>
                      ))}
                      {meta.supportedEvents.length > 2 && (
                        <span className="px-1.5 py-0.5 bg-slate-800 text-slate-500 text-[9px] rounded">
                          +{meta.supportedEvents.length - 2}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between gap-2">
                    <a
                      href={meta.docsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 transition"
                    >
                      <ExternalLink className="w-3 h-3" />
                      <span>ডকুমেন্টেশন</span>
                    </a>

                    <button
                      onClick={() => handleOpenConfigModal(meta)}
                      className={`px-3.5 py-1.5 rounded-xl font-bold text-xs transition flex items-center gap-1.5 cursor-pointer ${
                        isConnected
                          ? 'bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md'
                      }`}
                    >
                      <Settings className="w-3.5 h-3.5" />
                      <span>{isConnected ? 'সেটিংস পরিবর্তন' : 'কানেক্ট করুন'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: LIVE SYNC LOGS */}
      {activeTab === 'logs' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 text-white">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div>
              <h3 className="font-extrabold text-base text-white flex items-center gap-2">
                <Activity className="w-5 h-5 text-emerald-400" />
                <span>ক্লাউড কানেক্টর সিঙ্ক ও ইভেন্ট হিস্টোরি (Sync Audit Trail)</span>
              </h3>
              <p className="text-xs text-slate-400">
                সকল কানেক্টরে প্রেরিত স্বয়ংক্রিয় রিকোয়েস্ট, পে-লোড এবং স্ট্যাটাস কোড।
              </p>
            </div>
            <button
              onClick={fetchConnectors}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer w-fit"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>লগ রিফ্রেশ</span>
            </button>
          </div>

          {syncLogs.length === 0 ? (
            <div className="py-12 text-center text-slate-500 space-y-2">
              <Activity className="w-8 h-8 mx-auto opacity-40 text-slate-400" />
              <p className="text-sm font-semibold">কোনো সিঙ্ক লগ পাওয়া যায় নাই।</p>
              <p className="text-xs">কানেক্টরে টেস্ট পিং পাঠালে বা সনদ তৈরি হলে এখানে হিস্টোরি দেখা যাইবে।</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-2.5 px-3">সময়</th>
                    <th className="py-2.5 px-3">কানেক্টর</th>
                    <th className="py-2.5 px-3">ইভেন্ট</th>
                    <th className="py-2.5 px-3">বিবরণ / পে-লোড</th>
                    <th className="py-2.5 px-3">HTTP Status</th>
                    <th className="py-2.5 px-3 text-right">স্ট্যাটাস</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {syncLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-800/40 transition">
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleString('bn-BD')}
                      </td>
                      <td className="py-2.5 px-3 font-bold text-white whitespace-nowrap">
                        {log.connectorName}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-[11px] text-amber-300 whitespace-nowrap">
                        {log.event}
                      </td>
                      <td className="py-2.5 px-3 text-slate-300 max-w-xs truncate">
                        {log.payloadSummary}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-400">
                        {log.httpStatus || '-'}
                      </td>
                      <td className="py-2.5 px-3 text-right whitespace-nowrap">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${
                            log.status === 'success'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-red-500/20 text-red-300 border border-red-500/30'
                          }`}
                        >
                          {log.status === 'success' ? 'সফল (Success)' : 'ব্যর্থ (Failed)'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: EMBED WIDGETS & INTEGRATION CODE */}
      {activeTab === 'embeds' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Webflow / Wix / HTML Embed Widget */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 text-white">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-base text-amber-300 flex items-center gap-2">
                  <Globe className="w-5 h-5 text-emerald-400" />
                  <span>১. Webflow / Wix / WordPress ভেরিফিকেশন উইজেট</span>
                </h3>
                <p className="text-xs text-slate-400">যেকোনো ইউনিয়ন বা সরকারি ওয়েবসাইটে এই কোডটি বসিয়ে সরাসরি সত্যতা যাচাই সার্চ বক্স যুক্ত করুন।</p>
              </div>
              <button
                onClick={() => copyToClipboard(`<iframe src="${window.location.origin}/verify" width="100%" height="600" frameborder="0" style="border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,0.1);"></iframe>`, 'iframe_code')}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
              >
                {copiedKey === 'iframe_code' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'iframe_code' ? 'কপি হয়েছে' : 'কপি করুন'}</span>
              </button>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-[11px] font-mono text-emerald-300 overflow-x-auto">
              <code>{`<iframe 
  src="${window.location.origin}/verify" 
  width="100%" 
  height="600" 
  frameborder="0" 
  style="border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,0.1);"
  title="ইউনিয়ন পরিষদ অনলাইন সনদ যাচাই"
></iframe>`}</code>
            </div>
          </div>

          {/* Make (Integromat) & Zapier Webhook JSON Payload */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 text-white">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-base text-amber-300 flex items-center gap-2">
                  <Zap className="w-5 h-5 text-purple-400" />
                  <span>২. Make / Zapier / Linear Webhook Payload Schema</span>
                </h3>
                <p className="text-xs text-slate-400">সিনারিও বা ওয়ার্কফ্লো তৈরি করতে নিচের স্ট্যান্ডার্ড JSON কাঠামোটি ব্যবহার করুন।</p>
              </div>
              <button
                onClick={() => copyToClipboard(JSON.stringify({
                  event: "certificate.approved",
                  timestamp: "2026-08-13T20:00:00.000Z",
                  unionParishad: config.upName,
                  data: {
                    memoNo: "BUP-2026-1002",
                    issueDate: "১৩/০৮/২০২৬ খ্রি.",
                    typeKey: "citizenship",
                    typeLabel: "নাগরিকত্ব সনদপত্র",
                    citizen: { name: "মোছাঃ পারভীন আক্তার", nid: "1990428192", wardNo: "০১", village: "ডাবাইল" },
                    verificationUrl: `${window.location.origin}/verify/BUP-2026-1002`
                  }
                }, null, 2), 'webhook_schema')}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
              >
                {copiedKey === 'webhook_schema' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'webhook_schema' ? 'কপি হয়েছে' : 'কপি করুন'}</span>
              </button>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-[11px] font-mono text-purple-300 overflow-x-auto max-h-56">
              <pre>{JSON.stringify({
                event: "certificate.approved",
                timestamp: "2026-08-13T20:00:00.000Z",
                unionParishad: config.upName,
                data: {
                  memoNo: "BUP-2026-1002",
                  issueDate: "১৩/০৮/২০২৬ খ্রি.",
                  typeLabel: "নাগরিকত্ব সনদপত্র",
                  citizen: { name: "মোছাঃ পারভীন আক্তার", nid: "1990428192", wardNo: "০১" },
                  verificationUrl: `${window.location.origin}/verify/BUP-2026-1002`
                }
              }, null, 2)}</pre>
            </div>
          </div>
        </div>
      )}

      {/* CONNECTOR CONFIGURATION MODAL */}
      {activeModalConnector && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-2xl w-full p-6 sm:p-7 text-white shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-2xl ${activeModalConnector.iconBg} flex items-center justify-center text-white font-black text-lg shadow-lg`}>
                  {activeModalConnector.name.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-extrabold text-lg text-white">
                    {activeModalConnector.name} ইন্টিগ্রেশন কনফিগারেশন
                  </h3>
                  <p className="text-xs text-slate-400">
                    {activeModalConnector.taglineBn}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveModalConnector(null)}
                className="p-2 bg-slate-800 hover:bg-slate-700 rounded-xl text-slate-400 hover:text-white transition cursor-pointer"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            {/* Fields */}
            <div className="space-y-4 text-xs">
              {activeModalConnector.fields.map((field) => (
                <div key={field.key} className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="font-bold text-slate-200">{field.labelBn}:</label>
                    <span className="text-[10px] text-slate-500 font-mono">{field.key}</span>
                  </div>
                  <input
                    type={field.type}
                    placeholder={field.placeholder}
                    value={formData[field.key] || ''}
                    onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 font-mono text-xs focus:outline-none focus:border-emerald-400 placeholder:text-slate-600"
                  />
                  <p className="text-[11px] text-slate-400">{field.description}</p>
                </div>
              ))}

              {/* Event Subscriptions */}
              <div className="pt-2 border-t border-slate-800 space-y-2">
                <label className="font-bold text-slate-200 block">স্বয়ংক্রিয় ইভেন্ট নোটিফিকেশন ট্রিগার:</label>
                <div className="grid grid-cols-2 gap-2">
                  {activeModalConnector.supportedEvents.map((ev) => {
                    const isChecked = selectedEvents.includes(ev);
                    return (
                      <label
                        key={ev}
                        onClick={() => {
                          if (isChecked) {
                            setSelectedEvents(selectedEvents.filter(e => e !== ev));
                          } else {
                            setSelectedEvents([...selectedEvents, ev]);
                          }
                        }}
                        className={`p-2 rounded-xl border flex items-center gap-2 cursor-pointer transition ${
                          isChecked
                            ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-200'
                            : 'bg-slate-950/60 border-slate-800 text-slate-400'
                        }`}
                      >
                        <div className={`w-4 h-4 rounded flex items-center justify-center ${isChecked ? 'bg-emerald-500 text-slate-950' : 'border border-slate-700'}`}>
                          {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                        <span className="font-mono text-[11px]">{ev}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Sample Code Preview */}
              <div className="pt-2 border-t border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <Code2 className="w-3.5 h-3.5 text-amber-400" />
                    <span>ইন্টিগ্রেশন কোড স্নাইপেট (Code Reference)</span>
                  </span>
                  <button
                    onClick={() => copyToClipboard(activeModalConnector.sampleCodeSnippet, 'modal_code')}
                    className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                  >
                    {copiedKey === 'modal_code' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedKey === 'modal_code' ? 'কপি হয়েছে' : 'কপি'}</span>
                  </button>
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[10.5px] font-mono text-emerald-300 overflow-x-auto max-h-32">
                  <pre>{activeModalConnector.sampleCodeSnippet}</pre>
                </div>
              </div>
            </div>

            {/* Test Result Message */}
            {testResult && (
              <div className={`p-3 rounded-xl text-xs font-bold flex items-center gap-2 ${
                testResult.success ? 'bg-emerald-950/80 border border-emerald-500/50 text-emerald-300' : 'bg-red-950/80 border border-red-500/50 text-red-300'
              }`}>
                {testResult.success ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />}
                <span>{testResult.message}</span>
              </div>
            )}

            {/* Modal Actions */}
            <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => handleTestPing(activeModalConnector)}
                disabled={isTesting}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Play className={`w-3.5 h-3.5 text-amber-400 ${isTesting ? 'animate-spin' : ''}`} />
                <span>{isTesting ? 'টেস্টিং চলছে...' : 'টেস্ট পিং পাঠান'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModalConnector(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="button"
                  onClick={handleSaveConnector}
                  disabled={isTesting}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold rounded-xl transition shadow-lg flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Check className="w-4 h-4" />
                  <span>সংরক্ষণ ও সক্রিয় করুন</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
