import React, { useState } from 'react';
import { 
  Calculator, 
  X, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Sparkles, 
  BookOpen, 
  LandPlot, 
  Coins, 
  Users, 
  ArrowRight,
  ShieldCheck,
  Percent,
  FileSpreadsheet
} from 'lucide-react';
import { 
  HeirInput, 
  HeirRelationship, 
  calculateIslamicFaraez, 
  calculateHinduSuccession, 
  FaraezCalculationResult 
} from '../utils/faraezCalculator';
import { toBengaliNumeral } from '../lib/utils';

interface FaraezCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyToTable: (generatedRows: string[][]) => void;
  defaultDeceasedName?: string;
}

const RELATION_PRESETS: { key: HeirRelationship; labelBn: string; gender: 'পুরুষ' | 'মহিলা' }[] = [
  { key: 'wife', labelBn: 'স্ত্রী', gender: 'মহিলা' },
  { key: 'husband', labelBn: 'স্বামী', gender: 'পুরুষ' },
  { key: 'son', labelBn: 'পুত্র', gender: 'পুরুষ' },
  { key: 'daughter', labelBn: 'কন্যা', gender: 'মহিলা' },
  { key: 'father', labelBn: 'পিতা', gender: 'পুরুষ' },
  { key: 'mother', labelBn: 'মাতা', gender: 'মহিলা' },
  { key: 'brother', labelBn: 'সহোদর ভাই', gender: 'পুরুষ' },
  { key: 'sister', labelBn: 'সহোদর বোন', gender: 'মহিলা' }
];

export const FaraezCalculatorModal: React.FC<FaraezCalculatorModalProps> = ({
  isOpen,
  onClose,
  onApplyToTable,
  defaultDeceasedName = ''
}) => {
  const [deceasedName, setDeceasedName] = useState<string>(defaultDeceasedName || 'মরহুম আব্দুল খালেক');
  const [deceasedGender, setDeceasedGender] = useState<'পুরুষ' | 'মহিলা'>('পুরুষ');
  const [religion, setReligion] = useState<'muslim' | 'hindu'>('muslim');
  const [totalLandDecimals, setTotalLandDecimals] = useState<number>(100);
  const [totalCashAmount, setTotalCashAmount] = useState<number>(0);

  const [heirs, setHeirs] = useState<HeirInput[]>([
    { id: '1', name: 'মোছাঃ রাহিমা বেগম', relation: 'wife', relationLabelBn: 'স্ত্রী', gender: 'মহিলা', nidOrBirthNo: '1980261821000001' },
    { id: '2', name: 'মোঃ রফিকুল ইসলাম', relation: 'son', relationLabelBn: 'পুত্র', gender: 'পুরুষ', nidOrBirthNo: '1995261821000002' },
    { id: '3', name: 'মোছাঃ ফাতেমা খাতুন', relation: 'daughter', relationLabelBn: 'কন্যা', gender: 'মহিলা', nidOrBirthNo: '2001261821000003' },
    { id: '4', name: 'মোছাঃ আমেনা বেগম', relation: 'mother', relationLabelBn: 'মাতা', gender: 'মহিলা', nidOrBirthNo: '1955261821000004' }
  ]);

  if (!isOpen) return null;

  // Add heir
  const handleAddHeir = (presetKey: HeirRelationship = 'son') => {
    const preset = RELATION_PRESETS.find(p => p.key === presetKey) || RELATION_PRESETS[2];
    const newHeir: HeirInput = {
      id: `${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: '',
      relation: preset.key,
      relationLabelBn: preset.labelBn,
      gender: preset.gender,
      nidOrBirthNo: ''
    };
    setHeirs([...heirs, newHeir]);
  };

  const handleUpdateHeir = (id: string, updates: Partial<HeirInput>) => {
    setHeirs(heirs.map(h => h.id === id ? { ...h, ...updates } : h));
  };

  const handleRemoveHeir = (id: string) => {
    setHeirs(heirs.filter(h => h.id !== id));
  };

  // Perform Calculation
  const result: FaraezCalculationResult = religion === 'muslim'
    ? calculateIslamicFaraez(deceasedName, deceasedGender, heirs, totalLandDecimals, totalCashAmount)
    : calculateHinduSuccession(deceasedName, deceasedGender, heirs, totalLandDecimals, totalCashAmount);

  // Apply to Warishan Certificate Table
  const handleExportToTable = () => {
    const generatedRows: string[][] = result.heirs.map((heir, idx) => [
      toBengaliNumeral(idx + 1), // ক্রমিক নং
      heir.name || 'নাম উল্লেখ নেই', // ওয়ারিশের নাম
      heir.relationLabelBn, // সম্পর্ক
      heir.nidOrBirthNo || 'প্রযোজ্য নয়', // এনআইডি/জন্ম নিবন্ধন
      heir.percentageBn, // প্রাপ্ত অংশ (%)
      heir.allocatedLandBn // মোট জমির অংশ
    ]);
    onApplyToTable(generatedRows);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-700/80 border border-emerald-500/40 flex items-center justify-center text-amber-300 shadow-md">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold flex items-center gap-2">
                <span>ওয়ারিশান ফারায়েজ ও সম্পত্তি বণ্টন ক্যালকুলেটর</span>
                <span className="text-[11px] bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full font-bold">
                  শরীয়াহ ও আইন সম্মত
                </span>
              </h2>
              <p className="text-xs text-emerald-200">
                মৃত ব্যক্তির ওয়ারিশগণের আইনানুযায়ী হিস্যা, আনা-গণ্ডা ও জমির অংশ স্বয়ংক্রিয় গণনা
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-emerald-950/40 hover:bg-emerald-950 text-emerald-200 hover:text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-slate-800 text-xs">
          {/* Section 1: Basic Deceased & Estate Information */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">মৃত ব্যক্তির নাম:</label>
              <input
                type="text"
                value={deceasedName}
                onChange={(e) => setDeceasedName(e.target.value)}
                placeholder="মরহুমের নাম"
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-900 focus:border-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">মৃত ব্যক্তির লিঙ্গ:</label>
              <select
                value={deceasedGender}
                onChange={(e) => setDeceasedGender(e.target.value as any)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-900 focus:border-emerald-600 focus:outline-none"
              >
                <option value="পুরুষ">পুরুষ (স্বামী/পিতা)</option>
                <option value="মহিলা">মহিলা (স্ত্রী/মাতা)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">আইন / ধর্মীয় বিধি:</label>
              <select
                value={religion}
                onChange={(e) => setReligion(e.target.value as any)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-900 focus:border-emerald-600 focus:outline-none"
              >
                <option value="muslim">☪️ মুসলিম ফারায়েজ আইন</option>
                <option value="hindu">🕉️ হিন্দু উত্তরাধিকার আইন</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">মোট সম্পত্তি (শতাংশ):</label>
              <div className="relative">
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={totalLandDecimals}
                  onChange={(e) => setTotalLandDecimals(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-900 focus:border-emerald-600 focus:outline-none pr-12"
                />
                <span className="absolute right-2.5 top-2 text-[11px] font-bold text-slate-500">শতক</span>
              </div>
            </div>
          </div>

          {/* Quick Preset Buttons to Add Heirs */}
          <div className="flex flex-wrap items-center gap-1.5 bg-emerald-50/70 p-2.5 rounded-xl border border-emerald-200">
            <span className="text-[11px] font-bold text-emerald-900 mr-1 flex items-center gap-1">
              <Plus className="w-3.5 h-3.5" />
              <span>দ্রুত ওয়ারিশ যোগ করুন:</span>
            </span>
            {RELATION_PRESETS.map((preset) => (
              <button
                key={preset.key}
                type="button"
                onClick={() => handleAddHeir(preset.key)}
                className="px-2.5 py-1 bg-white hover:bg-emerald-100 text-emerald-900 font-semibold border border-emerald-300 rounded-md shadow-2xs transition cursor-pointer flex items-center gap-1 text-[11px]"
              >
                <span>+ {preset.labelBn}</span>
              </button>
            ))}
          </div>

          {/* Heirs Table Form */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-700" />
                <span>ওয়ারিশগণের তালিকা ({toBengaliNumeral(heirs.length)} জন)</span>
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-300">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300">
                  <tr>
                    <th className="p-2 w-10 text-center">নং</th>
                    <th className="p-2 min-w-[160px]">ওয়ারিশের নাম</th>
                    <th className="p-2 min-w-[120px]">সম্পর্ক</th>
                    <th className="p-2 min-w-[140px]">জাতীয় পরিচয়পত্র / জন্ম নিবন্ধন</th>
                    <th className="p-2 w-12 text-center">মুছুন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 bg-white">
                  {heirs.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center py-4 text-slate-400">
                        কোনো ওয়ারিশ তালিকাভুক্ত নাই। উপরের বাটন হতে যোগ করুন।
                      </td>
                    </tr>
                  ) : (
                    heirs.map((heir, idx) => (
                      <tr key={heir.id} className="hover:bg-slate-50">
                        <td className="p-2 text-center font-bold text-slate-500">
                          {toBengaliNumeral(idx + 1)}
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={heir.name}
                            onChange={(e) => handleUpdateHeir(heir.id, { name: e.target.value })}
                            placeholder="ওয়ারিশের পূর্ণ নাম"
                            className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded focus:bg-white focus:border-emerald-600 focus:outline-none"
                          />
                        </td>
                        <td className="p-2">
                          <select
                            value={heir.relation}
                            onChange={(e) => {
                              const rel = e.target.value as HeirRelationship;
                              const preset = RELATION_PRESETS.find(p => p.key === rel);
                              handleUpdateHeir(heir.id, {
                                relation: rel,
                                relationLabelBn: preset ? preset.labelBn : 'অন্যান্য',
                                gender: preset ? preset.gender : 'পুরুষ'
                              });
                            }}
                            className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded focus:bg-white focus:border-emerald-600 focus:outline-none font-semibold text-slate-800"
                          >
                            {RELATION_PRESETS.map((p) => (
                              <option key={p.key} value={p.key}>{p.labelBn}</option>
                            ))}
                          </select>
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={heir.nidOrBirthNo}
                            onChange={(e) => handleUpdateHeir(heir.id, { nidOrBirthNo: e.target.value })}
                            placeholder="এনআইডি বা জন্ম নিবন্ধন নং"
                            className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded focus:bg-white focus:border-emerald-600 focus:outline-none font-mono text-[11px]"
                          />
                        </td>
                        <td className="p-2 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveHeir(heir.id)}
                            className="p-1 text-red-600 hover:bg-red-50 rounded transition cursor-pointer"
                            title="মুছুন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Calculation Results Card */}
          <div className="bg-emerald-950 text-white p-4 rounded-xl space-y-3 shadow-lg">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-800/80 pb-2">
              <span className="font-bold text-sm text-amber-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>হিসাব ফলাফল ও আইনি বণ্টন বিশ্লেষণ</span>
              </span>
              <span className="text-[11px] font-mono bg-emerald-900 px-2.5 py-0.5 rounded-full text-emerald-200 border border-emerald-700">
                মোট বণ্টন: {toBengaliNumeral(result.totalPercentage)}% {result.isBalanced ? '✓ (সঠিক)' : '⚠️ (সংশোধন প্রয়োজন)'}
              </span>
            </div>

            <div className="overflow-x-auto rounded-lg border border-emerald-800">
              <table className="w-full text-xs text-left text-emerald-100">
                <thead className="bg-emerald-900/90 text-amber-300 font-bold border-b border-emerald-800">
                  <tr>
                    <th className="p-2">ওয়ারিশ</th>
                    <th className="p-2">সম্পর্ক</th>
                    <th className="p-2">হিস্যা (ভগ্নাংশ)</th>
                    <th className="p-2">শতাংশ (%)</th>
                    <th className="p-2">আনা-গণ্ডা-কড়া</th>
                    <th className="p-2">প্রাপ্ত জমি (শতক)</th>
                    <th className="p-2">আইনি ব্যাখ্যা</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-emerald-900 bg-emerald-950/80">
                  {result.heirs.map((h, i) => (
                    <tr key={h.id} className="hover:bg-emerald-900/40">
                      <td className="p-2 font-bold text-white">{h.name}</td>
                      <td className="p-2 text-emerald-200">{h.relationLabelBn}</td>
                      <td className="p-2 font-mono font-bold text-amber-300">{h.fractionText}</td>
                      <td className="p-2 font-bold text-emerald-300">{h.percentageBn}</td>
                      <td className="p-2 text-[11px] text-emerald-300 font-serif">{h.anaGandaKaraKranti}</td>
                      <td className="p-2 font-bold text-amber-200">{h.allocatedLandBn}</td>
                      <td className="p-2 text-[10px] text-slate-300">{h.legalNote}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <p className="text-[11px] text-emerald-300 italic pt-1">
              📌 {result.legalSummaryBn}
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-100 p-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-200 text-slate-700 font-bold rounded-lg border border-slate-300 transition cursor-pointer text-xs"
          >
            বন্ধ করুন
          </button>

          <button
            type="button"
            onClick={handleExportToTable}
            className="px-5 py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-md hover:shadow-lg transition cursor-pointer flex items-center gap-2 text-xs"
          >
            <FileSpreadsheet className="w-4 h-4 text-amber-300" />
            <span>সনদের ওয়ারিশান টেবিলে অটো-ইনসার্ট করুন</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
