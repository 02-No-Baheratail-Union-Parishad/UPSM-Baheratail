import React, { useState, useEffect, useMemo } from 'react';
import { 
  Building2, 
  Home, 
  Store, 
  Factory, 
  Landmark, 
  CreditCard, 
  DollarSign, 
  Search, 
  Filter, 
  Plus, 
  Printer, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  TrendingUp, 
  Download, 
  Send, 
  ExternalLink, 
  Phone, 
  User, 
  FileText, 
  ChevronRight, 
  RefreshCw, 
  X, 
  Layers, 
  Check, 
  QrCode,
  ShieldCheck,
  MapPin,
  PieChart,
  BarChart3,
  Calendar,
  Eye
} from 'lucide-react';
import { 
  HoldingTaxRecord, 
  HoldingTaxWardSummary, 
  HoldingType, 
  TaxPaymentStatus, 
  UnionParishadConfig,
  HoldingTaxReceipt
} from '../types';
import { INITIAL_HOLDING_TAX_RECORDS, computeHoldingTaxWardSummaries } from '../data/holdingTaxData';
import { WARD_VILLAGE_MAPPINGS } from '../data/villages';

interface HoldingTaxDashboardProps {
  config: UnionParishadConfig;
}

export const HoldingTaxDashboard: React.FC<HoldingTaxDashboardProps> = ({ config }) => {
  // State
  const [records, setRecords] = useState<HoldingTaxRecord[]>(INITIAL_HOLDING_TAX_RECORDS);
  const [loading, setLoading] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedWard, setSelectedWard] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedFiscalYear, setSelectedFiscalYear] = useState<string>('২০২৫-২০২৬');
  
  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [isCollectModalOpen, setIsCollectModalOpen] = useState<boolean>(false);
  const [selectedRecordForPayment, setSelectedRecordForPayment] = useState<HoldingTaxRecord | null>(null);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState<boolean>(false);
  const [activeReceipt, setActiveReceipt] = useState<HoldingTaxReceipt | null>(null);
  const [isBatchNoticeModalOpen, setIsBatchNoticeModalOpen] = useState<boolean>(false);
  const [viewDetailsRecord, setViewDetailsRecord] = useState<HoldingTaxRecord | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // New Holding Form State
  const [newHoldingForm, setNewHoldingForm] = useState({
    holdingNo: '',
    holdingType: 'residential' as HoldingType,
    structureType: 'semi_pucca',
    ownerName: '',
    guardianName: '',
    motherName: '',
    mobile: '',
    nid: '',
    wardNo: '০১',
    village: 'ডাবাইল',
    postOffice: 'নাগবাড়ী',
    annualValuation: '20000',
    currentTaxDemand: '1000',
    arrearsDue: '0',
    fiscalYear: '২০২৫-২০২৬',
    notes: ''
  });

  // Payment Collection Form State
  const [paymentForm, setPaymentForm] = useState({
    paymentAmount: '',
    paymentMethod: 'bKash' as 'bKash' | 'Nagad' | 'Cash' | 'Bank' | 'Rocket',
    trxId: '',
    collectedBy: 'ইউপি ট্যাক্স কালেক্টর',
    notes: ''
  });

  // Fetch holding tax records from backend API
  const fetchHoldingTaxData = async () => {
    setLoading(true);
    try {
      const queryParams = new URLSearchParams();
      if (selectedWard !== 'all') queryParams.append('ward', selectedWard);
      if (selectedType !== 'all') queryParams.append('holdingType', selectedType);
      if (selectedStatus !== 'all') queryParams.append('paymentStatus', selectedStatus);
      if (selectedFiscalYear !== 'all') queryParams.append('fiscalYear', selectedFiscalYear);
      if (searchQuery.trim()) queryParams.append('search', searchQuery.trim());

      const res = await fetch(`/api/holding-tax?${queryParams.toString()}`);
      const data = await res.json();
      if (data.success && Array.isArray(data.records)) {
        setRecords(data.records);
      }
    } catch (err) {
      console.warn('API error, using local fallback:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHoldingTaxData();
  }, [selectedWard, selectedType, selectedStatus, selectedFiscalYear]);

  // Handle Search Trigger
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchHoldingTaxData();
  };

  // Compute Overall KPI Metrics
  const metrics = useMemo(() => {
    const totalHoldings = records.length;
    const totalDemand = records.reduce((sum, r) => sum + (r.totalDemand || 0), 0);
    const totalCollected = records.reduce((sum, r) => sum + (r.paidAmount || 0), 0);
    const totalDue = records.reduce((sum, r) => sum + (r.currentDue || 0), 0);
    const collectionRate = totalDemand > 0 ? Math.round((totalCollected / totalDemand) * 100) : 0;

    const residentialRecords = records.filter(r => r.holdingType === 'residential');
    const commercialRecords = records.filter(r => r.holdingType === 'commercial');
    const industrialRecords = records.filter(r => r.holdingType === 'industrial');

    const residentialDemand = residentialRecords.reduce((sum, r) => sum + (r.totalDemand || 0), 0);
    const residentialCollected = residentialRecords.reduce((sum, r) => sum + (r.paidAmount || 0), 0);
    const residentialDue = residentialRecords.reduce((sum, r) => sum + (r.currentDue || 0), 0);

    const commercialDemand = commercialRecords.reduce((sum, r) => sum + (r.totalDemand || 0), 0);
    const commercialCollected = commercialRecords.reduce((sum, r) => sum + (r.paidAmount || 0), 0);
    const commercialDue = commercialRecords.reduce((sum, r) => sum + (r.currentDue || 0), 0);

    const paidCount = records.filter(r => r.paymentStatus === 'paid').length;
    const partialCount = records.filter(r => r.paymentStatus === 'partial').length;
    const unpaidCount = records.filter(r => r.paymentStatus === 'unpaid').length;

    return {
      totalHoldings,
      totalDemand,
      totalCollected,
      totalDue,
      collectionRate,
      paidCount,
      partialCount,
      unpaidCount,
      residential: {
        count: residentialRecords.length,
        demand: residentialDemand,
        collected: residentialCollected,
        due: residentialDue,
        rate: residentialDemand > 0 ? Math.round((residentialCollected / residentialDemand) * 100) : 0
      },
      commercial: {
        count: commercialRecords.length,
        demand: commercialDemand,
        collected: commercialCollected,
        due: commercialDue,
        rate: commercialDemand > 0 ? Math.round((commercialCollected / commercialDemand) * 100) : 0
      },
      industrial: {
        count: industrialRecords.length,
        demand: industrialRecords.reduce((sum, r) => sum + (r.totalDemand || 0), 0),
        collected: industrialRecords.reduce((sum, r) => sum + (r.paidAmount || 0), 0),
        due: industrialRecords.reduce((sum, r) => sum + (r.currentDue || 0), 0)
      }
    };
  }, [records]);

  // Compute Ward-Wise Summaries
  const wardSummaries = useMemo(() => {
    return computeHoldingTaxWardSummaries(records);
  }, [records]);

  // Open Payment Modal for a record
  const handleOpenPaymentModal = (record: HoldingTaxRecord) => {
    setSelectedRecordForPayment(record);
    setPaymentForm({
      paymentAmount: String(record.currentDue > 0 ? record.currentDue : record.totalDemand),
      paymentMethod: 'bKash',
      trxId: '',
      collectedBy: 'ইউপি আদায়কারী',
      notes: ''
    });
    setIsCollectModalOpen(true);
  };

  // Submit Payment Collection
  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRecordForPayment) return;

    const amount = Number(paymentForm.paymentAmount);
    if (!amount || amount <= 0) {
      alert('সঠিক টাকার পরিমাণ প্রদান করুন!');
      return;
    }

    try {
      const res = await fetch('/api/holding-tax/collect-tax', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          holdingId: selectedRecordForPayment.id,
          paymentAmount: amount,
          paymentMethod: paymentForm.paymentMethod,
          trxId: paymentForm.trxId,
          collectedBy: paymentForm.collectedBy,
          fiscalYear: selectedRecordForPayment.fiscalYear,
          notes: paymentForm.notes
        })
      });

      const data = await res.json();
      if (data.success && data.receipt) {
        setActiveReceipt(data.receipt);
        setIsCollectModalOpen(false);
        setIsReceiptModalOpen(true);
        setToastMessage(`🎉 ৳${amount}/- ট্যাক্স সফলভাবে গৃহীত হইয়াছে!`);
        setTimeout(() => setToastMessage(null), 5000);
        fetchHoldingTaxData();
      } else {
        alert(data.message || 'পেমেন্ট প্রক্রিয়াকরণে সমস্যা হইয়াছে');
      }
    } catch (err: any) {
      alert('সার্ভার কানেকশনে ত্রুটি: ' + err.message);
    }
  };

  // Submit New Holding Registration
  const handleCreateHoldingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHoldingForm.ownerName || !newHoldingForm.wardNo || !newHoldingForm.village) {
      alert('অনুগ্রহ করে করদাতার নাম, ওয়ার্ড এবং গ্রামের নাম পূরণ করুন!');
      return;
    }

    try {
      const res = await fetch('/api/holding-tax', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newHoldingForm)
      });

      const data = await res.json();
      if (data.success) {
        setIsAddModalOpen(false);
        setToastMessage(`✅ নতুন হোল্ডিং নং ${data.record.holdingNo} সফলভাবে সিস্টেমে যুক্ত হইয়াছে!`);
        setTimeout(() => setToastMessage(null), 5000);
        fetchHoldingTaxData();
        // Reset form
        setNewHoldingForm({
          holdingNo: '',
          holdingType: 'residential',
          structureType: 'semi_pucca',
          ownerName: '',
          guardianName: '',
          motherName: '',
          mobile: '',
          nid: '',
          wardNo: '০১',
          village: 'ডাবাইল',
          postOffice: 'নাগবাড়ী',
          annualValuation: '20000',
          currentTaxDemand: '1000',
          arrearsDue: '0',
          fiscalYear: '২০২৫-২০২৬',
          notes: ''
        });
      } else {
        alert(data.message || 'হোল্ডিং যুক্ত করতে সমস্যা হইয়াছে');
      }
    } catch (err: any) {
      alert('সার্ভার কানেকশনে ত্রুটি: ' + err.message);
    }
  };

  // Villages for Selected Ward in New Holding Form
  const availableVillagesForNewHolding = useMemo(() => {
    const mapping = WARD_VILLAGE_MAPPINGS.find(m => m.wardNo === newHoldingForm.wardNo);
    return mapping ? mapping.villages : ['বহেড়াতৈল', 'ডাবাইল', 'আমতৈল', 'বেতুয়া', 'কালিয়ান'];
  }, [newHoldingForm.wardNo]);

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['হোল্ডিং নং,মালিকের নাম,অভিভাবক,মোবাইল,ওয়ার্ড,গ্রাম,ধরনের নাম,বাৎসরিক মূল্যায়ন,চলতি দাবি,পূর্বের বকেয়া,মোট দাবি,আদায়কৃত,অবশিষ্ট বকেয়া,অবস্থা,অর্থবছর'];
    const rows = records.map(r => [
      `"${r.holdingNo}"`,
      `"${r.ownerName}"`,
      `"${r.guardianName}"`,
      `"${r.mobile}"`,
      `"ওয়ার্ড ${r.wardNo}"`,
      `"${r.village}"`,
      `"${r.holdingType === 'residential' ? 'বসতবাড়ি' : r.holdingType === 'commercial' ? 'ব্যবসা প্রতিষ্ঠান' : 'শিল্প ইউনিট'}"`,
      r.annualValuation,
      r.currentTaxDemand,
      r.arrearsDue,
      r.totalDemand,
      r.paidAmount,
      r.currentDue,
      `"${r.paymentStatus === 'paid' ? 'পরিশোধিত' : r.paymentStatus === 'partial' ? 'আংশিক পরিশোধিত' : 'বকেয়া'}"`,
      `"${r.fiscalYear}"`
    ].join(','));

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `bup_holding_tax_register_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="holding-tax-dashboard-root" className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-20 font-sans text-slate-800 dark:text-slate-100">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-emerald-600 text-white px-5 py-3 rounded-xl shadow-2xl flex items-center gap-3 animate-bounce">
          <CheckCircle2 className="w-6 h-6 shrink-0" />
          <span className="font-semibold text-sm">{toastMessage}</span>
        </div>
      )}

      {/* Hero Header */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white pt-8 pb-14 px-4 sm:px-6 lg:px-8 border-b border-emerald-800/40">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold uppercase tracking-wider border border-emerald-400/30">
                  <Landmark className="w-3.5 h-3.5" />
                  রাজস্ব ও কর আদায় সেল
                </span>
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-medium border border-amber-400/30">
                  <Calendar className="w-3.5 h-3.5" />
                  অর্থবছর: ২০২৫-২০২৬
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white flex items-center gap-3">
                <Building2 className="w-8 h-8 text-emerald-400" />
                {config.upName} — হোল্ডিং ট্যাক্স ও বকেয়া ব্যবস্থাপনা
              </h1>
              <p className="mt-1 text-slate-300 text-sm max-w-2xl">
                ওয়ার্ডভিত্তিক বসতবাড়ি ও ব্যবসা প্রতিষ্ঠানের কর নির্ধারণ, স্বয়ংক্রিয় বকেয়া ট্র্যাকিং, ডিজিটাল মানি রসিদ জেনারেশন ও হোয়াটসঅ্যাপ তাগাদা পোর্টাল।
              </p>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex flex-wrap items-center gap-3">
              <button
                id="btn-add-new-holding"
                onClick={() => setIsAddModalOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-medium text-sm shadow-lg shadow-emerald-900/30 transition active:scale-95"
              >
                <Plus className="w-4 h-4" />
                নতুন হোল্ডিং সংযুক্তি
              </button>

              <button
                id="btn-batch-whatsapp-notices"
                onClick={() => setIsBatchNoticeModalOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-700/80 hover:bg-teal-700 text-white font-medium text-sm border border-teal-500/30 transition active:scale-95"
              >
                <Send className="w-4 h-4 text-emerald-300" />
                বকেয়া তাগাদা নোটিশ
              </button>

              <button
                id="btn-export-holding-csv"
                onClick={handleExportCSV}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-sm border border-slate-700 transition active:scale-95"
              >
                <Download className="w-4 h-4 text-slate-300" />
                CSV এক্সপোর্ট
              </button>

              <button
                id="btn-refresh-holding-data"
                onClick={fetchHoldingTaxData}
                disabled={loading}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
                title="রিফ্রেশ"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 space-y-8">
        {/* ============================================================ */}
        {/* KPI CARDS (4 CARDS) */}
        {/* ============================================================ */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Total Holdings */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">মোট হোল্ডিং সংখ্যা</span>
              <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
                <Building2 className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-4">
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white">
                {metrics.totalHoldings} <span className="text-sm font-medium text-slate-500">টি</span>
              </div>
              <div className="mt-2 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 flex-wrap">
                <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                  <Home className="w-3.5 h-3.5" /> বসতবাড়ি: {metrics.residential.count}
                </span>
                <span>•</span>
                <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400">
                  <Store className="w-3.5 h-3.5" /> ব্যবসা: {metrics.commercial.count}
                </span>
              </div>
            </div>
          </div>

          {/* Card 2: Total Demand */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">সর্বমোট করের দাবি</span>
              <div className="p-2.5 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400">
                <DollarSign className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-4">
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white">
                ৳{metrics.totalDemand.toLocaleString('bn-BD')}
              </div>
              <div className="mt-2 text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
                <span>চলতি + পূর্বের বকেয়া ধার্য</span>
                <span className="font-semibold text-purple-600 dark:text-purple-400">১০০% বেস</span>
              </div>
            </div>
          </div>

          {/* Card 3: Collected Tax */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">আদায়কৃত কর</span>
              <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
                <TrendingUp className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-4">
              <div className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">
                ৳{metrics.totalCollected.toLocaleString('bn-BD')}
              </div>
              <div className="mt-2 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span>আদায়ের শতকরা হার:</span>
                <span className="font-bold px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                  {metrics.collectionRate}%
                </span>
              </div>
            </div>
          </div>

          {/* Card 4: Total Due / Arrears */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">অবশিষ্ট মোট বকেয়া</span>
              <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400">
                <AlertCircle className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-4">
              <div className="text-3xl font-extrabold text-rose-600 dark:text-rose-400">
                ৳{metrics.totalDue.toLocaleString('bn-BD')}
              </div>
              <div className="mt-2 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span>বকেয়া করদাতা:</span>
                <span className="font-semibold text-rose-600 dark:text-rose-400">
                  {metrics.unpaidCount + metrics.partialCount} জন
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* ============================================================ */}
        {/* CATEGORY COMPARISON BARS */}
        {/* ============================================================ */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Residential vs Commercial Breakdown */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-4">
              <Home className="w-5 h-5 text-emerald-600" />
              বসতবাড়ি হোল্ডিং ট্যাক্স চিত্র (Residential)
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
                <span>মোট বসতবাড়ি:</span>
                <span className="font-semibold text-slate-900 dark:text-white">{metrics.residential.count} টি</span>
              </div>
              <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
                <span>মোট দাবি:</span>
                <span className="font-semibold text-slate-900 dark:text-white">৳{metrics.residential.demand.toLocaleString('bn-BD')}</span>
              </div>
              <div className="flex justify-between items-center text-emerald-600 dark:text-emerald-400">
                <span>আদায়কৃত কর:</span>
                <span className="font-bold">৳{metrics.residential.collected.toLocaleString('bn-BD')}</span>
              </div>
              <div className="flex justify-between items-center text-rose-600 dark:text-rose-400">
                <span>বকেয়া কর:</span>
                <span className="font-bold">৳{metrics.residential.due.toLocaleString('bn-BD')}</span>
              </div>
              <div className="pt-2">
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span>আদায় অগ্রগতি</span>
                  <span>{metrics.residential.rate}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-emerald-500 rounded-full transition-all duration-500" 
                    style={{ width: `${Math.min(100, metrics.residential.rate)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Commercial & Business Units */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-4">
              <Store className="w-5 h-5 text-amber-600" />
              ব্যবসা প্রতিষ্ঠান ও বাজার ইউনিট (Commercial)
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
                <span>মোট প্রতিষ্ঠান/দোকান:</span>
                <span className="font-semibold text-slate-900 dark:text-white">{metrics.commercial.count} টি</span>
              </div>
              <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
                <span>মোট দাবি:</span>
                <span className="font-semibold text-slate-900 dark:text-white">৳{metrics.commercial.demand.toLocaleString('bn-BD')}</span>
              </div>
              <div className="flex justify-between items-center text-emerald-600 dark:text-emerald-400">
                <span>আদায়কৃত কর:</span>
                <span className="font-bold">৳{metrics.commercial.collected.toLocaleString('bn-BD')}</span>
              </div>
              <div className="flex justify-between items-center text-rose-600 dark:text-rose-400">
                <span>বকেয়া কর:</span>
                <span className="font-bold">৳{metrics.commercial.due.toLocaleString('bn-BD')}</span>
              </div>
              <div className="pt-2">
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span>আদায় অগ্রগতি</span>
                  <span>{metrics.commercial.rate}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-amber-500 rounded-full transition-all duration-500" 
                    style={{ width: `${Math.min(100, metrics.commercial.rate)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ============================================================ */}
        {/* WARD-WISE BREAKDOWN & HEATMAP (WARDS 01 TO 09) */}
        {/* ============================================================ */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <MapPin className="w-5 h-5 text-emerald-600" />
                ওয়ার্ডভিত্তিক বকেয়া ও আদায় অগ্রগতি চিত্র (ওয়ার্ড ০১ হতে ০৯)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                বহেড়াতৈল ইউনিয়নের প্রতিটি ওয়ার্ডের বাড়ি ও ব্যবসা প্রতিষ্ঠানের আলাদা পরিসংখ্যান
              </p>
            </div>
            <div className="text-xs font-medium text-slate-500">
              *যেকোনো ওয়ার্ডে ক্লিক করে নিচের তালিকা স্বয়ংক্রিয়ভাবে ফিল্টার করুন
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-4 pt-2">
            {wardSummaries.map(ward => {
              const isSelected = selectedWard === ward.wardNo;
              return (
                <div
                  key={ward.wardNo}
                  onClick={() => setSelectedWard(isSelected ? 'all' : ward.wardNo)}
                  className={`cursor-pointer rounded-xl p-4 border transition-all ${
                    isSelected 
                      ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/40 ring-2 ring-emerald-500/30' 
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/60 dark:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
                      {ward.wardLabel}
                    </span>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300">
                      {ward.collectionRate}% আদায়
                    </span>
                  </div>

                  <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-slate-500 block">বসতবাড়ি:</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{ward.residentialCount} টি</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">ব্যবসা/দোকান:</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{ward.commercialCount} টি</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">মোট দাবি:</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">৳{ward.totalDemand.toLocaleString('bn-BD')}</span>
                    </div>
                    <div>
                      <span className="text-rose-600 dark:text-rose-400 font-medium block">বকেয়া:</span>
                      <span className="font-bold text-rose-600 dark:text-rose-400">৳{ward.totalDue.toLocaleString('bn-BD')}</span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mt-3 w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-300 ${
                        ward.collectionRate >= 75 ? 'bg-emerald-500' : ward.collectionRate >= 40 ? 'bg-amber-500' : 'bg-rose-500'
                      }`}
                      style={{ width: `${ward.collectionRate}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* ============================================================ */}
        {/* INTERACTIVE REGISTER & TAXPAYER TABLE */}
        {/* ============================================================ */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          {/* Table Header Controls */}
          <div className="p-5 border-b border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-600" />
                  হোল্ডিং ট্যাক্স রেজিস্টার ও অ্যাসেসমেন্ট তালিকা
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  মোট {records.length} জন করদাতার তথ্য প্রদর্শিত হচ্ছে
                </p>
              </div>

              {/* Search Bar */}
              <form onSubmit={handleSearchSubmit} className="flex items-center gap-2 w-full lg:w-96">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    id="input-holding-search"
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="হোল্ডিং নং, নাম, মোবাইল বা গ্রাম খুঁজুন..."
                    className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-100"
                  />
                </div>
                <button
                  type="submit"
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-medium transition"
                >
                  খুঁজুন
                </button>
              </form>
            </div>

            {/* Filter Pills */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              {/* Ward Filter */}
              <div className="flex items-center gap-1.5 text-xs">
                <span className="font-semibold text-slate-500">ওয়ার্ড:</span>
                <select
                  id="select-holding-ward-filter"
                  value={selectedWard}
                  onChange={(e) => setSelectedWard(e.target.value)}
                  className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="all">সকল ওয়ার্ড (১-৯)</option>
                  {['০১', '০২', '০৩', '০৪', '০৫', '০৬', '০৭', '০৮', '০৯'].map(w => (
                    <option key={w} value={w}>ওয়ার্ড নং {w}</option>
                  ))}
                </select>
              </div>

              {/* Holding Type Filter */}
              <div className="flex items-center gap-1.5 text-xs">
                <span className="font-semibold text-slate-500">ধরন:</span>
                <select
                  id="select-holding-type-filter"
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="all">সকল ধরন</option>
                  <option value="residential">বসতবাড়ি (Residential)</option>
                  <option value="commercial">ব্যবসা প্রতিষ্ঠান (Commercial)</option>
                  <option value="industrial">শিল্প / রাইস মিল (Industrial)</option>
                  <option value="institutional">প্রতিষ্ঠান (Institutional)</option>
                </select>
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-1.5 text-xs">
                <span className="font-semibold text-slate-500">অবস্থা:</span>
                <select
                  id="select-holding-status-filter"
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="all">সকল অবস্থা</option>
                  <option value="paid">পরিশোধিত (Paid)</option>
                  <option value="partial">আংশিক বকেয়া (Partial)</option>
                  <option value="unpaid">সম্পূর্ণ বকেয়া (Unpaid)</option>
                </select>
              </div>

              {/* Fiscal Year Filter */}
              <div className="flex items-center gap-1.5 text-xs">
                <span className="font-semibold text-slate-500">অর্থবছর:</span>
                <select
                  id="select-holding-fiscal-filter"
                  value={selectedFiscalYear}
                  onChange={(e) => setSelectedFiscalYear(e.target.value)}
                  className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="all">সকল অর্থবছর</option>
                  <option value="২০২৫-২০২৬">২০২৫-২০২৬ (চলতি)</option>
                  <option value="২০২৪-২০২৫">২০২৪-২০২৫</option>
                  <option value="২০২৩-২০২৪">২০২৩-২০২৪</option>
                </select>
              </div>

              {(selectedWard !== 'all' || selectedType !== 'all' || selectedStatus !== 'all' || searchQuery) && (
                <button
                  onClick={() => {
                    setSelectedWard('all');
                    setSelectedType('all');
                    setSelectedStatus('all');
                    setSearchQuery('');
                  }}
                  className="text-xs text-rose-600 hover:text-rose-700 underline font-medium ml-auto"
                >
                  ফিল্টার রিসেট
                </button>
              )}
            </div>
          </div>

          {/* Table Body */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 text-xs uppercase font-semibold border-b border-slate-200 dark:border-slate-700">
                  <th className="py-3.5 px-4">হোল্ডিং নং</th>
                  <th className="py-3.5 px-4">করদাতার নাম ও বিবরণ</th>
                  <th className="py-3.5 px-4">ওয়ার্ড ও গ্রাম</th>
                  <th className="py-3.5 px-4">ধরন ও কাঠামো</th>
                  <th className="py-3.5 px-4 text-right">মোট দাবি</th>
                  <th className="py-3.5 px-4 text-right">আদায়কৃত</th>
                  <th className="py-3.5 px-4 text-right">বকেয়া</th>
                  <th className="py-3.5 px-4 text-center">স্ট্যাটাস</th>
                  <th className="py-3.5 px-4 text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {records.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-slate-500">
                      কোনো হোল্ডিং তথ্য পাওয়া যায় নাই।
                    </td>
                  </tr>
                ) : (
                  records.map((r) => {
                    const cleanPhone = r.mobile ? r.mobile.replace(/\D/g, '') : '';
                    const phoneWithCountry = cleanPhone.startsWith('880') ? cleanPhone : `88${cleanPhone.replace(/^0/, '')}`;
                    const waNoticeText = `সম্মানিত করদাতা ${r.ownerName},\n০২নং বহেড়াতৈল ইউনিয়ন পরিষদের হোল্ডিং নং: ${r.holdingNo} (গ্রাম: ${r.village}, ওয়ার্ড: ${r.wardNo})-এর ${r.fiscalYear} অর্থবছরের মোট বকেয়া কর ৳${r.currentDue}/-। অতিসত্বর ইউপি ভবনে কর পরিশোধ করে ডিজিটাল রসিদ গ্রহণ করুন।\n- চেয়ারম্যান, ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ।`;
                    const waUrl = `https://wa.me/${phoneWithCountry}?text=${encodeURIComponent(waNoticeText)}`;

                    return (
                      <tr 
                        key={r.id}
                        className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                      >
                        <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white whitespace-nowrap">
                          {r.holdingNo}
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-slate-900 dark:text-white">{r.ownerName}</div>
                          <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                            <span>পিতা/স্বামী: {r.guardianName}</span>
                            {r.mobile && (
                              <span className="inline-flex items-center gap-0.5 text-slate-600 dark:text-slate-400">
                                <Phone className="w-3 h-3 text-emerald-600" /> {r.mobile}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span className="font-medium text-slate-800 dark:text-slate-200">ওয়ার্ড {r.wardNo}</span>
                          <div className="text-xs text-slate-500">{r.village}</div>
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
                            r.holdingType === 'residential' 
                              ? 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300' 
                              : r.holdingType === 'commercial'
                              ? 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                              : 'bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300'
                          }`}>
                            {r.holdingType === 'residential' ? <Home className="w-3 h-3" /> : <Store className="w-3 h-3" />}
                            {r.holdingType === 'residential' ? 'বসতবাড়ি' : r.holdingType === 'commercial' ? 'ব্যবসা প্রতিষ্ঠান' : 'শিল্প প্রতিষ্ঠান'}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right font-medium text-slate-900 dark:text-white whitespace-nowrap">
                          ৳{r.totalDemand.toLocaleString('bn-BD')}
                        </td>
                        <td className="py-3.5 px-4 text-right font-semibold text-emerald-600 dark:text-emerald-400 whitespace-nowrap">
                          ৳{r.paidAmount.toLocaleString('bn-BD')}
                        </td>
                        <td className="py-3.5 px-4 text-right font-bold text-rose-600 dark:text-rose-400 whitespace-nowrap">
                          ৳{r.currentDue.toLocaleString('bn-BD')}
                        </td>
                        <td className="py-3.5 px-4 text-center whitespace-nowrap">
                          {r.paymentStatus === 'paid' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                              <Check className="w-3 h-3" /> পরিশোধিত
                            </span>
                          ) : r.paymentStatus === 'partial' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                              <Clock className="w-3 h-3" /> আংশিক বকেয়া
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300">
                              <AlertCircle className="w-3 h-3" /> সম্পূর্ণ বকেয়া
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Pay Tax Button */}
                            <button
                              onClick={() => handleOpenPaymentModal(r)}
                              className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition flex items-center gap-1 shadow-sm"
                              title="কর গ্রহণ ও রসিদ তৈরি"
                            >
                              <CreditCard className="w-3.5 h-3.5" /> কর আদায়
                            </button>

                            {/* WhatsApp Due Notice Button */}
                            {r.currentDue > 0 && r.mobile && (
                              <a
                                href={waUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-1.5 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-800 dark:bg-emerald-950 dark:hover:bg-emerald-900 dark:text-emerald-300 transition"
                                title="হোয়াটসঅ্যাপে বকেয়া তাগাদা নোটিশ পাঠান"
                              >
                                <Send className="w-3.5 h-3.5" />
                              </a>
                            )}

                            {/* View Details */}
                            <button
                              onClick={() => setViewDetailsRecord(r)}
                              className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 transition"
                              title="বিস্তারিত বিবরণ"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* MODAL 1: COLLECT TAX PAYMENT & ISSUE RECEIPT */}
      {/* ============================================================ */}
      {isCollectModalOpen && selectedRecordForPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-600" />
                হোল্ডিং ট্যাক্স গ্রহণ ও রসিদ এন্ট্রি
              </h3>
              <button 
                onClick={() => setIsCollectModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Target Holding Summary */}
            <div className="p-3.5 bg-emerald-50/70 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-800/50 text-xs space-y-1">
              <div className="flex justify-between font-bold text-slate-900 dark:text-white">
                <span>হোল্ডিং নং: {selectedRecordForPayment.holdingNo}</span>
                <span>ওয়ার্ড: {selectedRecordForPayment.wardNo} ({selectedRecordForPayment.village})</span>
              </div>
              <div className="text-slate-600 dark:text-slate-300">
                করদাতা: {selectedRecordForPayment.ownerName} (পিতা/স্বামী: {selectedRecordForPayment.guardianName})
              </div>
              <div className="flex justify-between font-semibold pt-1 border-t border-emerald-200/60 dark:border-emerald-800/40">
                <span>মোট দাবি: ৳{selectedRecordForPayment.totalDemand}</span>
                <span className="text-rose-600 dark:text-rose-400">বর্তমান বকেয়া: ৳{selectedRecordForPayment.currentDue}</span>
              </div>
            </div>

            <form onSubmit={handlePaymentSubmit} className="space-y-4 text-sm">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  পরিশোধিত টাকার পরিমাণ (টাকা) *
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  max={selectedRecordForPayment.totalDemand}
                  value={paymentForm.paymentAmount}
                  onChange={(e) => setPaymentForm({ ...paymentForm, paymentAmount: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-emerald-600 dark:text-emerald-400 focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    পরিশোধের মাধ্যম *
                  </label>
                  <select
                    value={paymentForm.paymentMethod}
                    onChange={(e: any) => setPaymentForm({ ...paymentForm, paymentMethod: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  >
                    <option value="bKash">বিকাশ (bKash)</option>
                    <option value="Nagad">নগদ (Nagad)</option>
                    <option value="Rocket">রকেট (Rocket)</option>
                    <option value="Cash">ক্যাশ / নগদ টাকা</option>
                    <option value="Bank">ব্যাংক জমা</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    ট্রানজেকশন / ব্যাংক রশিদ নং
                  </label>
                  <input
                    type="text"
                    value={paymentForm.trxId}
                    onChange={(e) => setPaymentForm({ ...paymentForm, trxId: e.target.value })}
                    placeholder="উদা: TRX-92817"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  ট্যাক্স আদায়কারী কর্মকর্তা / উদ্যোক্তা
                </label>
                <input
                  type="text"
                  value={paymentForm.collectedBy}
                  onChange={(e) => setPaymentForm({ ...paymentForm, collectedBy: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCollectModalOpen(false)}
                  className="px-4 py-2 text-slate-600 dark:text-slate-400 text-xs font-semibold hover:bg-slate-100 rounded-xl"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-900/20 flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" /> কর গ্রহণ ও ডিজিটাল রসিদ ইস্যু
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL 2: PRINTABLE OFFICIAL TAX COLLECTION MONEY RECEIPT */}
      {/* ============================================================ */}
      {isReceiptModalOpen && activeReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fadeIn overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-2xl max-w-2xl w-full p-8 shadow-2xl space-y-6 my-8 border-4 border-double border-emerald-700">
            {/* Header / Seal */}
            <div className="text-center space-y-1 border-b-2 border-emerald-700 pb-4">
              <div className="text-xs font-bold uppercase tracking-widest text-emerald-800">গণপ্রজাতন্ত্রী বাংলাদেশ সরকার</div>
              <h2 className="text-2xl font-black text-emerald-900">{config.upName}</h2>
              <div className="text-xs text-slate-600">উপজেলা: {config.upazila}, জেলা: {config.district}</div>
              <div className="inline-block mt-2 px-4 py-1 rounded-full bg-emerald-800 text-white font-bold text-sm tracking-wide">
                হোল্ডিং ট্যাক্স ও কর আদায় রসিদ (মানি রসিদ)
              </div>
            </div>

            {/* Receipt Memo Details */}
            <div className="grid grid-cols-2 text-xs gap-2 bg-slate-50 p-3 rounded-lg border border-slate-200">
              <div>
                <span className="font-bold text-slate-700">রসিদ নং:</span> <span className="font-mono font-bold text-emerald-800">{activeReceipt.receiptNo}</span>
              </div>
              <div className="text-right">
                <span className="font-bold text-slate-700">তারিখ:</span> {activeReceipt.date}
              </div>
              <div>
                <span className="font-bold text-slate-700">অর্থবছর:</span> {activeReceipt.fiscalYear}
              </div>
              <div className="text-right">
                <span className="font-bold text-slate-700">পেমেন্ট মাধ্যম:</span> {activeReceipt.paymentMethod} {activeReceipt.trxId ? `(${activeReceipt.trxId})` : ''}
              </div>
            </div>

            {/* Taxpayer Information Grid */}
            <div className="border border-slate-300 rounded-lg overflow-hidden text-xs">
              <table className="w-full text-left">
                <tbody>
                  <tr className="border-b border-slate-200 bg-slate-50/50">
                    <td className="p-2.5 font-bold text-slate-700 w-1/3">হোল্ডিং নম্বর:</td>
                    <td className="p-2.5 font-mono font-bold text-emerald-900">{activeReceipt.holdingNo}</td>
                  </tr>
                  <tr className="border-b border-slate-200">
                    <td className="p-2.5 font-bold text-slate-700">করদাতার নাম:</td>
                    <td className="p-2.5 font-semibold text-slate-900">{activeReceipt.ownerName}</td>
                  </tr>
                  <tr className="border-b border-slate-200 bg-slate-50/50">
                    <td className="p-2.5 font-bold text-slate-700">পিতা/স্বামীর নাম:</td>
                    <td className="p-2.5 text-slate-800">{activeReceipt.guardianName}</td>
                  </tr>
                  <tr className="border-b border-slate-200">
                    <td className="p-2.5 font-bold text-slate-700">ঠিকানা ও ওয়ার্ড:</td>
                    <td className="p-2.5 text-slate-800">গ্রাম: {activeReceipt.village}, ওয়ার্ড নং: {activeReceipt.wardNo}</td>
                  </tr>
                  <tr className="border-b border-slate-200 bg-slate-50/50">
                    <td className="p-2.5 font-bold text-slate-700">হোল্ডিংয়ের ধরন:</td>
                    <td className="p-2.5 text-slate-800">{activeReceipt.holdingType === 'residential' ? 'বসতবাড়ি' : 'ব্যবসা প্রতিষ্ঠান/মার্কেট'}</td>
                  </tr>
                  <tr className="border-b border-slate-200">
                    <td className="p-2.5 font-bold text-slate-700">মোট করের দাবি:</td>
                    <td className="p-2.5 font-semibold text-slate-800">৳{activeReceipt.totalDemand}/-</td>
                  </tr>
                  <tr className="border-b border-slate-200 bg-emerald-50 text-emerald-900 font-bold">
                    <td className="p-2.5">গৃহীত করের পরিমাণ:</td>
                    <td className="p-2.5 text-base">৳{activeReceipt.paidAmount}/- (পরিশোধিত)</td>
                  </tr>
                  <tr className="bg-rose-50 text-rose-900">
                    <td className="p-2.5 font-bold">অবশিষ্ট বকেয়া:</td>
                    <td className="p-2.5 font-bold">৳{activeReceipt.remainingDue}/-</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Bottom QR & Signatures */}
            <div className="flex items-end justify-between pt-6 border-t border-slate-200 text-xs">
              <div className="flex items-center gap-3">
                {activeReceipt.qrCodeUrl && (
                  <img 
                    src={activeReceipt.qrCodeUrl} 
                    alt="QR Verify" 
                    className="w-20 h-20 border border-slate-300 p-1 rounded bg-white shadow-sm"
                  />
                )}
                <div>
                  <div className="font-bold text-emerald-900">ডিজিটাল ভেরিফিকেশন QR</div>
                  <div className="text-[10px] text-slate-500">অনলাইন যাচাই ও সত্যতা নিশ্চিতকরণ</div>
                </div>
              </div>

              <div className="text-center space-y-1">
                <div className="w-36 border-b border-slate-400 mx-auto" />
                <div className="font-bold text-slate-800">{activeReceipt.collectedBy}</div>
                <div className="text-[10px] text-slate-500">ট্যাক্স আদায়কারী / ইউপি সচিব</div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 print:hidden">
              <button
                onClick={() => setIsReceiptModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
              >
                বন্ধ করুন
              </button>
              <button
                onClick={() => window.print()}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" /> রসিদ প্রিন্ট করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL 3: ADD NEW HOLDING REGISTRATION */}
      {/* ============================================================ */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-5 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-600" />
                নতুন হোল্ডিং নিবন্ধন ও কর নির্ধারণ
              </h3>
              <button 
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateHoldingSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    ওয়ার্ড নম্বর *
                  </label>
                  <select
                    value={newHoldingForm.wardNo}
                    onChange={(e) => {
                      const ward = e.target.value;
                      const mapping = WARD_VILLAGE_MAPPINGS.find(m => m.wardNo === ward);
                      const defaultVillage = mapping ? mapping.villages[0] : 'বহেড়াতৈল';
                      setNewHoldingForm({ ...newHoldingForm, wardNo: ward, village: defaultVillage });
                    }}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  >
                    {['০১', '০২', '০৩', '০৪', '০৫', '০৬', '০৭', '০৮', '০৯'].map(w => (
                      <option key={w} value={w}>ওয়ার্ড নং {w}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    গ্রামের নাম *
                  </label>
                  <select
                    value={newHoldingForm.village}
                    onChange={(e) => setNewHoldingForm({ ...newHoldingForm, village: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  >
                    {availableVillagesForNewHolding.map(v => (
                      <option key={v} value={v}>{v}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    হোল্ডিং নং (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    value={newHoldingForm.holdingNo}
                    onChange={(e) => setNewHoldingForm({ ...newHoldingForm, holdingNo: e.target.value })}
                    placeholder="ফাঁকা রাখলে অটো জেনারেট"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    হোল্ডিংয়ের ধরন *
                  </label>
                  <select
                    value={newHoldingForm.holdingType}
                    onChange={(e: any) => setNewHoldingForm({ ...newHoldingForm, holdingType: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  >
                    <option value="residential">বসতবাড়ি (Residential)</option>
                    <option value="commercial">ব্যবসা প্রতিষ্ঠান / মার্কেট (Commercial)</option>
                    <option value="industrial">শিল্প কারখানা / রাইস মিল (Industrial)</option>
                    <option value="institutional">প্রতিষ্ঠান (Institutional)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    কাঠামো / ভবনের ধরন
                  </label>
                  <select
                    value={newHoldingForm.structureType}
                    onChange={(e: any) => setNewHoldingForm({ ...newHoldingForm, structureType: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  >
                    <option value="pucca">পাকা দালান (Pucca)</option>
                    <option value="semi_pucca">আধাপাকা টিনশেড (Semi-pucca)</option>
                    <option value="kacha">কাঁচা ঘর (Kacha)</option>
                    <option value="multi_storied">বহুতল বাণিজ্যিক ভবন (Multi-storied)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    করদাতার নাম / প্রতিষ্ঠানের নাম *
                  </label>
                  <input
                    type="text"
                    required
                    value={newHoldingForm.ownerName}
                    onChange={(e) => setNewHoldingForm({ ...newHoldingForm, ownerName: e.target.value })}
                    placeholder="উদা: মোঃ শাহ আলম"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    পিতা / স্বামীর নাম
                  </label>
                  <input
                    type="text"
                    value={newHoldingForm.guardianName}
                    onChange={(e) => setNewHoldingForm({ ...newHoldingForm, guardianName: e.target.value })}
                    placeholder="উদা: মৃত মজিবুর রহমান"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    মোবাইল নম্বর
                  </label>
                  <input
                    type="tel"
                    value={newHoldingForm.mobile}
                    onChange={(e) => setNewHoldingForm({ ...newHoldingForm, mobile: e.target.value })}
                    placeholder="017XXXXXXXX"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    জাতীয় পরিচয়পত্র (NID) নম্বর
                  </label>
                  <input
                    type="text"
                    value={newHoldingForm.nid}
                    onChange={(e) => setNewHoldingForm({ ...newHoldingForm, nid: e.target.value })}
                    placeholder="১০ বা ১৭ ডিজিট"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              {/* Assessment Values */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="font-bold text-slate-800 dark:text-slate-200">কর মূল্যায়ন ও ধার্যকৃত অর্থ</div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      বাৎসরিক মূল্যায়ন (টাকা)
                    </label>
                    <input
                      type="number"
                      value={newHoldingForm.annualValuation}
                      onChange={(e) => {
                        const val = Number(e.target.value) || 0;
                        const defaultDemand = Math.round(val * 0.05);
                        setNewHoldingForm({ 
                          ...newHoldingForm, 
                          annualValuation: e.target.value,
                          currentTaxDemand: String(defaultDemand)
                        });
                      }}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      চলতি বাৎসরিক কর (টাকা)
                    </label>
                    <input
                      type="number"
                      value={newHoldingForm.currentTaxDemand}
                      onChange={(e) => setNewHoldingForm({ ...newHoldingForm, currentTaxDemand: e.target.value })}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      পূর্বের বকেয়া কর (যদি থাকে)
                    </label>
                    <input
                      type="number"
                      value={newHoldingForm.arrearsDue}
                      onChange={(e) => setNewHoldingForm({ ...newHoldingForm, arrearsDue: e.target.value })}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-rose-600"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  মন্তব্য / বিবরণ
                </label>
                <input
                  type="text"
                  value={newHoldingForm.notes}
                  onChange={(e) => setNewHoldingForm({ ...newHoldingForm, notes: e.target.value })}
                  placeholder="উদা: পাকা একতলা বাড়ি, ৩ রুম"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-slate-600 dark:text-slate-400 font-semibold hover:bg-slate-100 rounded-xl"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-md flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" /> সিস্টেমে সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL 4: BATCH WHATSAPP NOTICE DISPATCHER */}
      {/* ============================================================ */}
      {isBatchNoticeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Send className="w-5 h-5 text-emerald-600" />
                বকেয়া কর তাগাদা হোয়াটসঅ্যাপ নোটিশ
              </h3>
              <button 
                onClick={() => setIsBatchNoticeModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300">
              বকেয়া থাকা করদাতাদের মোবাইলে ইউনিয়ন পরিষদের পক্ষ থেকে স্বয়ংক্রিয় হোয়াটসঅ্যাপ নোটিশ প্রেরণের তালিকা।
            </p>

            <div className="max-h-72 overflow-y-auto space-y-2 pr-1">
              {records.filter(r => r.currentDue > 0 && r.mobile).map(r => {
                const cleanPhone = r.mobile ? r.mobile.replace(/\D/g, '') : '';
                const phoneWithCountry = cleanPhone.startsWith('880') ? cleanPhone : `88${cleanPhone.replace(/^0/, '')}`;
                const text = `সম্মানিত করদাতা ${r.ownerName},\n০২নং বহেড়াতৈল ইউনিয়ন পরিষদের হোল্ডিং নং: ${r.holdingNo} (গ্রাম: ${r.village}, ওয়ার্ড: ${r.wardNo})-এর ${r.fiscalYear} অর্থবছরের মোট বকেয়া কর ৳${r.currentDue}/-। ইউপি ভবনে কর পরিশোধের অনুরোধ রইল।\n- চেয়ারম্যান, ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ।`;
                const link = `https://wa.me/${phoneWithCountry}?text=${encodeURIComponent(text)}`;

                return (
                  <div key={r.id} className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="font-bold text-slate-900 dark:text-white">{r.ownerName} ({r.holdingNo})</div>
                      <div className="text-slate-500">ওয়ার্ড: {r.wardNo}, {r.village} • বকেয়া: <span className="text-rose-600 font-bold">৳{r.currentDue}</span></div>
                    </div>
                    <a
                      href={link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold flex items-center gap-1 shrink-0"
                    >
                      <Send className="w-3 h-3" /> WhatsApp পাঠান
                    </a>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setIsBatchNoticeModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold"
              >
                সম্পন্ন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL 5: RECORD DETAILS MODAL */}
      {/* ============================================================ */}
      {viewDetailsRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-600" />
                হোল্ডিং বিস্তারিত — {viewDetailsRecord.holdingNo}
              </h3>
              <button 
                onClick={() => setViewDetailsRecord(null)}
                className="p-1 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">মালিকের নাম:</span>
                <span className="font-bold text-slate-900 dark:text-white">{viewDetailsRecord.ownerName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">পিতা/স্বামীর নাম:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{viewDetailsRecord.guardianName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">ঠিকানা:</span>
                <span className="text-slate-800 dark:text-slate-200">গ্রাম: {viewDetailsRecord.village}, ওয়ার্ড: {viewDetailsRecord.wardNo}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">মোবাইল:</span>
                <span className="font-mono text-slate-800 dark:text-slate-200">{viewDetailsRecord.mobile || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">এনআইডি:</span>
                <span className="font-mono text-slate-800 dark:text-slate-200">{viewDetailsRecord.nid || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">বাৎসরিক মূল্যায়ন:</span>
                <span className="font-bold text-slate-900 dark:text-white">৳{viewDetailsRecord.annualValuation}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">চলতি ধার্য কর:</span>
                <span className="font-semibold text-emerald-600">৳{viewDetailsRecord.currentTaxDemand}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">পূর্বের বকেয়া:</span>
                <span className="font-semibold text-rose-600">৳{viewDetailsRecord.arrearsDue}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 font-bold">মোট দাবি:</span>
                <span className="font-bold text-slate-900 dark:text-white">৳{viewDetailsRecord.totalDemand}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 font-bold">আদায়কৃত:</span>
                <span className="font-bold text-emerald-600">৳{viewDetailsRecord.paidAmount}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 font-bold">বর্তমান বকেয়া:</span>
                <span className="font-bold text-rose-600">৳{viewDetailsRecord.currentDue}</span>
              </div>
              {viewDetailsRecord.notes && (
                <div className="py-1">
                  <span className="text-slate-500 block mb-0.5">মন্তব্য:</span>
                  <p className="text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800 p-2 rounded-lg">{viewDetailsRecord.notes}</p>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setViewDetailsRecord(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
