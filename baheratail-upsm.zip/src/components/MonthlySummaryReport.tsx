import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  FileText, 
  Download, 
  Printer, 
  Calendar, 
  Filter, 
  RefreshCw, 
  Building2, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  DollarSign, 
  Layers, 
  Search, 
  Check, 
  SlidersHorizontal, 
  Eye, 
  Share2, 
  FileSpreadsheet, 
  ShieldCheck, 
  Sparkles,
  ArrowUpDown,
  TrendingUp,
  MapPin,
  UserCheck,
  ChevronDown
} from 'lucide-react';
import { CertificateRecord, UnionParishadConfig } from '../types';
import { fetchCertificatesFromFirebase } from '../firebase';
import { StyledQrCode } from './StyledQrCode';

interface MonthlySummaryReportProps {
  config: UnionParishadConfig;
  initialCertificates?: CertificateRecord[];
  onClose?: () => void;
}

const BANGLA_MONTHS = [
  { value: '01', nameBn: 'জানুয়ারি', nameEn: 'January' },
  { value: '02', nameBn: 'ফেব্রুয়ারি', nameEn: 'February' },
  { value: '03', nameBn: 'মার্চ', nameEn: 'March' },
  { value: '04', nameBn: 'এপ্রিল', nameEn: 'April' },
  { value: '05', nameBn: 'মে', nameEn: 'May' },
  { value: '06', nameBn: 'জুন', nameEn: 'June' },
  { value: '07', nameBn: 'জুলাই', nameEn: 'July' },
  { value: '08', nameBn: 'আগস্ট', nameEn: 'August' },
  { value: '09', nameBn: 'সেপ্টেম্বর', nameEn: 'September' },
  { value: '10', nameBn: 'অক্টোবর', nameEn: 'October' },
  { value: '11', nameBn: 'নভেম্বর', nameEn: 'November' },
  { value: '12', nameBn: 'ডিসেম্বর', nameEn: 'December' },
];

const BANGLA_DIGITS: Record<string, string> = {
  '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
  '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'
};

export function toBnDigits(num: number | string | undefined | null): string {
  if (num === undefined || num === null) return '০';
  return String(num).replace(/[0-9]/g, d => BANGLA_DIGITS[d] || d);
}

// Convert English / Bangla formatted date string to Year & Month numbers
export function extractYearAndMonth(cert: CertificateRecord): { year: string; month: string } {
  const tryStrings = [cert.issueDateEn, cert.createdAt, cert.issueDate].filter(Boolean) as string[];
  
  for (const str of tryStrings) {
    // Check ISO: 2026-08-14 or 2026/08/14
    const matchIso = str.match(/(\d{4})[-/](\d{1,2})/);
    if (matchIso) {
      return {
        year: matchIso[1],
        month: matchIso[2].padStart(2, '0')
      };
    }
    // Check DD/MM/YYYY
    const matchDmy = str.match(/(\d{1,2})[-/](\d{1,2})[-/](\d{4})/);
    if (matchDmy) {
      return {
        year: matchDmy[3],
        month: matchDmy[2].padStart(2, '0')
      };
    }
    // Check Bangla digits: ১৪/০৮/২০২৬ or ২০২৬-০৮-১৪
    const enDigitsStr = str.replace(/[০-৯]/g, d => {
      const bnKeys = Object.keys(BANGLA_DIGITS);
      const idx = bnKeys.findIndex(k => BANGLA_DIGITS[k] === d);
      return idx !== -1 ? String(idx) : d;
    });
    const matchBnIso = enDigitsStr.match(/(\d{4})[-/](\d{1,2})/);
    if (matchBnIso) {
      return {
        year: matchBnIso[1],
        month: matchBnIso[2].padStart(2, '0')
      };
    }
    const matchBnDmy = enDigitsStr.match(/(\d{1,2})[-/](\d{1,2})[-/](\d{4})/);
    if (matchBnDmy) {
      return {
        year: matchBnDmy[3],
        month: matchBnDmy[2].padStart(2, '0')
      };
    }
  }

  // Fallback to current year & month
  const now = new Date();
  return {
    year: String(now.getFullYear()),
    month: String(now.getMonth() + 1).padStart(2, '0')
  };
}

export const MonthlySummaryReport: React.FC<MonthlySummaryReportProps> = ({
  config,
  initialCertificates,
  onClose
}) => {
  const currentDate = new Date();
  const [selectedYear, setSelectedYear] = useState<string>(String(currentDate.getFullYear()));
  const [selectedMonth, setSelectedMonth] = useState<string>(String(currentDate.getMonth() + 1).padStart(2, '0'));
  const [selectedWard, setSelectedWard] = useState<string>('ALL');
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Certificates dataset
  const [certificates, setCertificates] = useState<CertificateRecord[]>(initialCertificates || []);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'detailed_register' | 'pdf_preview'>('dashboard');

  // Load all certificates from Firebase & local cache
  const loadData = async () => {
    setIsLoading(true);
    try {
      const fbRecords = await fetchCertificatesFromFirebase();
      if (fbRecords && fbRecords.length > 0) {
        setCertificates(fbRecords);
      } else {
        const res = await fetch('/api/admin/logs');
        const data = await res.json();
        if (data.logs) {
          setCertificates(data.logs);
        }
      }
    } catch (err) {
      console.warn('Error loading certificates for monthly report:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!initialCertificates || initialCertificates.length === 0) {
      loadData();
    }
  }, []);

  // Filter available years dynamically
  const availableYears = useMemo(() => {
    const yearsSet = new Set<string>();
    yearsSet.add(String(new Date().getFullYear()));
    yearsSet.add(String(new Date().getFullYear() - 1));
    certificates.forEach(c => {
      const { year } = extractYearAndMonth(c);
      if (year && year.length === 4) yearsSet.add(year);
    });
    return Array.from(yearsSet).sort((a, b) => Number(b) - Number(a));
  }, [certificates]);

  // Distinct certificate types
  const availableTypes = useMemo(() => {
    const typesMap = new Map<string, string>();
    certificates.forEach(c => {
      const key = c.typeKey || 'general';
      const label = c.typeLabel || key;
      typesMap.set(key, label);
    });
    return Array.from(typesMap.entries()).map(([key, label]) => ({ key, label }));
  }, [certificates]);

  // Filter certificates for the selected Month and Year
  const monthFilteredCertificates = useMemo(() => {
    return certificates.filter(cert => {
      const { year, month } = extractYearAndMonth(cert);
      const matchMonth = month === selectedMonth && year === selectedYear;
      if (!matchMonth) return false;

      if (selectedWard !== 'ALL') {
        const certWard = cert.citizen?.wardNo || '';
        const normSelectedWard = selectedWard.replace(/^0+/, '');
        const normCertWard = certWard.replace(/^0+/, '');
        if (normCertWard !== normSelectedWard && certWard !== selectedWard) {
          return false;
        }
      }

      if (selectedType !== 'ALL') {
        if (cert.typeKey !== selectedType) return false;
      }

      if (selectedStatus !== 'ALL') {
        if (selectedStatus === 'approved' && cert.status !== 'approved') return false;
        if (selectedStatus === 'pending' && cert.status !== 'pending_approval' && cert.status !== 'issued') return false;
        if (selectedStatus === 'rejected' && cert.status !== 'cancelled' && cert.status !== 'revoked') return false;
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesQuery = 
          (cert.memoNo && cert.memoNo.toLowerCase().includes(q)) ||
          (cert.citizen?.name && cert.citizen.name.toLowerCase().includes(q)) ||
          (cert.citizen?.father && cert.citizen.father.toLowerCase().includes(q)) ||
          (cert.citizen?.nid && cert.citizen.nid.includes(q)) ||
          (cert.citizen?.village && cert.citizen.village.toLowerCase().includes(q)) ||
          (cert.typeLabel && cert.typeLabel.toLowerCase().includes(q));
        if (!matchesQuery) return false;
      }

      return true;
    });
  }, [certificates, selectedYear, selectedMonth, selectedWard, selectedType, selectedStatus, searchQuery]);

  // Calculate comprehensive metrics
  const monthlyMetrics = useMemo(() => {
    let totalProcessed = monthFilteredCertificates.length;
    let approvedCount = 0;
    let pendingCount = 0;
    let rejectedCount = 0;
    let totalRevenue = 0;
    let digitalPayments = 0;
    let cashPayments = 0;

    const typeBreakdown: Record<string, { label: string; count: number; fee: number; category: string }> = {};
    const wardBreakdown: Record<string, { count: number; fee: number }> = {};

    // Initialize wards 1 to 9
    for (let i = 1; i <= 9; i++) {
      const wardKey = String(i).padStart(2, '0');
      wardBreakdown[wardKey] = { count: 0, fee: 0 };
    }

    monthFilteredCertificates.forEach(cert => {
      const fee = Number(cert.feeAmount) || 0;
      totalRevenue += fee;

      if (cert.status === 'approved') {
        approvedCount++;
      } else if (cert.status === 'cancelled' || cert.status === 'revoked') {
        rejectedCount++;
      } else {
        pendingCount++;
      }

      if (cert.paymentMethod && cert.paymentMethod !== 'Cash') {
        digitalPayments += fee;
      } else {
        cashPayments += fee;
      }

      // Type breakdown
      const typeKey = cert.typeKey || 'general';
      const label = cert.typeLabel || typeKey;
      if (!typeBreakdown[typeKey]) {
        typeBreakdown[typeKey] = {
          label,
          count: 0,
          fee: 0,
          category: cert.category || 'নাগরিক সেবা'
        };
      }
      typeBreakdown[typeKey].count += 1;
      typeBreakdown[typeKey].fee += fee;

      // Ward breakdown
      const rawWard = (cert.citizen?.wardNo || '০১').replace(/[^0-9]/g, '');
      const wardKey = rawWard ? rawWard.padStart(2, '0') : '০১';
      if (!wardBreakdown[wardKey]) {
        wardBreakdown[wardKey] = { count: 0, fee: 0 };
      }
      wardBreakdown[wardKey].count += 1;
      wardBreakdown[wardKey].fee += fee;
    });

    const sortedTypes = Object.entries(typeBreakdown)
      .map(([key, data]) => ({ key, ...data }))
      .sort((a, b) => b.count - a.count);

    const sortedWards = Object.entries(wardBreakdown)
      .map(([ward, data]) => ({ ward, ...data }))
      .sort((a, b) => a.ward.localeCompare(b.ward));

    const approvalRate = totalProcessed > 0 ? Math.round((approvedCount / totalProcessed) * 100) : 0;

    return {
      totalProcessed,
      approvedCount,
      pendingCount,
      rejectedCount,
      totalRevenue,
      digitalPayments,
      cashPayments,
      approvalRate,
      sortedTypes,
      sortedWards
    };
  }, [monthFilteredCertificates]);

  const selectedMonthObj = BANGLA_MONTHS.find(m => m.value === selectedMonth) || BANGLA_MONTHS[0];

  // Print Action Handler
  const handlePrintPdf = () => {
    window.print();
  };

  // Export to CSV / Excel
  const handleExportCsv = () => {
    if (monthFilteredCertificates.length === 0) {
      alert('এক্সপোর্ট করার জন্য নির্বাচিত মাসে কোনো রেকর্ড পাওয়া যায়নি।');
      return;
    }

    const headers = [
      'ক্র.নং',
      'স্মারক নম্বর',
      'ইস্যুর তারিখ',
      'সনদের ধরন',
      'নাগরিকের নাম',
      'পিতা/স্বামীর নাম',
      'মাতার নাম',
      'গ্রাম',
      'ওয়ার্ড নং',
      'এনআইডি / জন্ম নিবন্ধন',
      'মোবাইল নম্বর',
      'আদায়কৃত ফি (টাকা)',
      'পেমেন্ট মেথড',
      'ট্রানজেকশন আইডি',
      'স্ট্যাটাস',
      'ইস্যুকারী কর্মকর্তা'
    ];

    const rows = monthFilteredCertificates.map((c, index) => [
      index + 1,
      `"${c.memoNo || ''}"`,
      `"${c.issueDate || c.issueDateEn || ''}"`,
      `"${c.typeLabel || ''}"`,
      `"${c.citizen?.name || ''}"`,
      `"${c.citizen?.father || ''}"`,
      `"${c.citizen?.mother || ''}"`,
      `"${c.citizen?.village || ''}"`,
      `"${c.citizen?.wardNo || ''}"`,
      `"${c.citizen?.nid || c.citizen?.birthNo || ''}"`,
      `"${c.citizen?.mobile || ''}"`,
      c.feeAmount || 0,
      `"${c.paymentMethod || 'Cash'}"`,
      `"${c.trxId || ''}"`,
      `"${c.status || 'approved'}"`,
      `"${c.issuedBy || 'ইউপি সচিব / চেয়ারম্যান'}"`
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `BUP_Monthly_Report_${selectedYear}_${selectedMonth}_${selectedMonthObj.nameEn}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const reportRefNo = `BUP/REP/${selectedYear}/${selectedMonth}/${monthFilteredCertificates.length.toString().padStart(4, '0')}`;
  const printDateBn = new Date().toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' });

  return (
    <div className="space-y-6 animate-fade-in text-slate-800">
      
      {/* 1. Header Toolbar & Month Selector (Hidden in Print Mode) */}
      <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-slate-950 text-white p-6 rounded-3xl shadow-xl border border-emerald-800/80 relative overflow-hidden print:hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-3">
              <div className="p-3 bg-amber-400 text-emerald-950 rounded-2xl font-black shadow-lg">
                <FileText className="w-7 h-7" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl md:text-2xl font-black tracking-tight text-white">
                    মাসিক সনদপত্র ও রাজস্ব নিরীক্ষা প্রতিবেদন
                  </h1>
                  <span className="px-3 py-1 bg-amber-400 text-emerald-950 text-[11px] font-black rounded-full uppercase tracking-wider">
                    Official PDF Generator
                  </span>
                </div>
                <p className="text-xs md:text-sm text-emerald-200 mt-1">
                  ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ — মাসভিত্তিক প্রক্রিয়াকৃত সনদসমূহের পূর্ণাঙ্গ পরিসংখ্যান ও অফিশিয়াল প্রিন্ট রিপোর্ট
                </p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={loadData}
              disabled={isLoading}
              className="px-4 py-2.5 bg-emerald-800/80 hover:bg-emerald-700 text-white text-xs font-black rounded-xl border border-emerald-600/60 shadow-md transition flex items-center gap-2 cursor-pointer active:scale-95 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              <span>ডাটা রিফ্রেশ</span>
            </button>

            <button
              onClick={handleExportCsv}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-black rounded-xl border border-slate-700 shadow-md transition flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>CSV / Excel এক্সপোর্ট</span>
            </button>

            <button
              onClick={handlePrintPdf}
              className="px-5 py-2.5 bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-emerald-950 text-xs font-black rounded-xl shadow-lg transition flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <Printer className="w-4 h-4 text-emerald-950" />
              <span>📄 PDF ডাউনলোড / প্রিন্ট করুন</span>
            </button>

            {onClose && (
              <button
                onClick={onClose}
                className="p-2.5 bg-emerald-900/60 hover:bg-emerald-800 text-white rounded-xl transition cursor-pointer"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Filters and Month-Year Bar */}
        <div className="mt-6 pt-5 border-t border-emerald-800/60 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3">
          
          {/* Year Picker */}
          <div>
            <label className="block text-[11px] font-bold text-emerald-300 mb-1">
              📅 বছর নির্বাচন (Year)
            </label>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="w-full bg-emerald-900/90 text-white text-xs font-extrabold px-3 py-2.5 rounded-xl border border-emerald-700 focus:outline-none focus:ring-2 focus:ring-amber-400 cursor-pointer"
            >
              {availableYears.map(yr => (
                <option key={yr} value={yr} className="bg-slate-900 text-white">
                  {yr} (বঙ্গাব্দ/খ্রিস্টাব্দ {toBnDigits(yr)})
                </option>
              ))}
            </select>
          </div>

          {/* Month Picker */}
          <div>
            <label className="block text-[11px] font-bold text-emerald-300 mb-1">
              🗓️ মাস নির্বাচন (Month)
            </label>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="w-full bg-emerald-900/90 text-white text-xs font-extrabold px-3 py-2.5 rounded-xl border border-emerald-700 focus:outline-none focus:ring-2 focus:ring-amber-400 cursor-pointer"
            >
              {BANGLA_MONTHS.map(m => (
                <option key={m.value} value={m.value} className="bg-slate-900 text-white">
                  {m.nameBn} ({m.nameEn})
                </option>
              ))}
            </select>
          </div>

          {/* Ward Filter */}
          <div>
            <label className="block text-[11px] font-bold text-emerald-300 mb-1">
              📍 ওয়ার্ড ফিল্টার (Ward)
            </label>
            <select
              value={selectedWard}
              onChange={(e) => setSelectedWard(e.target.value)}
              className="w-full bg-emerald-900/90 text-white text-xs font-extrabold px-3 py-2.5 rounded-xl border border-emerald-700 focus:outline-none focus:ring-2 focus:ring-amber-400 cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900 text-white">সকল ওয়ার্ড (All Wards)</option>
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(w => (
                <option key={w} value={String(w).padStart(2, '0')} className="bg-slate-900 text-white">
                  ওয়ার্ড নং {toBnDigits(w)} ({String(w).padStart(2, '0')})
                </option>
              ))}
            </select>
          </div>

          {/* Certificate Type Filter */}
          <div>
            <label className="block text-[11px] font-bold text-emerald-300 mb-1">
              📜 সনদের ধরন (Type)
            </label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full bg-emerald-900/90 text-white text-xs font-extrabold px-3 py-2.5 rounded-xl border border-emerald-700 focus:outline-none focus:ring-2 focus:ring-amber-400 cursor-pointer truncate"
            >
              <option value="ALL" className="bg-slate-900 text-white">সকল ধরনের সনদপত্র</option>
              {availableTypes.map(t => (
                <option key={t.key} value={t.key} className="bg-slate-900 text-white">
                  {t.label}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <label className="block text-[11px] font-bold text-emerald-300 mb-1">
              ⚡ স্ট্যাটাস ফিল্টার (Status)
            </label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full bg-emerald-900/90 text-white text-xs font-extrabold px-3 py-2.5 rounded-xl border border-emerald-700 focus:outline-none focus:ring-2 focus:ring-amber-400 cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900 text-white">সকল স্থিতি (All Status)</option>
              <option value="approved" className="bg-slate-900 text-white">অনুমোদিত (Approved)</option>
              <option value="pending" className="bg-slate-900 text-white">অপেক্ষমাণ / ইস্যু (Pending)</option>
              <option value="rejected" className="bg-slate-900 text-white">বাতিল (Rejected)</option>
            </select>
          </div>

        </div>
      </div>

      {/* 2. Top Navigation Tabs (Dashboard vs Detailed Register vs PDF Print Preview) - Hidden in Print */}
      <div className="flex items-center gap-2 bg-slate-200/80 p-1.5 rounded-2xl print:hidden overflow-x-auto">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex-1 min-w-[180px] py-3 px-4 rounded-xl text-xs font-extrabold transition flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'dashboard'
              ? 'bg-emerald-900 text-amber-300 shadow-md ring-2 ring-amber-400/50'
              : 'text-slate-700 hover:bg-slate-300/80'
          }`}
        >
          <TrendingUp className="w-4 h-4 text-amber-300" />
          <span>১. মাসিক অ্যানালিটিক্স ও মেট্রিক্স</span>
        </button>

        <button
          onClick={() => setActiveTab('detailed_register')}
          className={`flex-1 min-w-[200px] py-3 px-4 rounded-xl text-xs font-extrabold transition flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'detailed_register'
              ? 'bg-emerald-900 text-amber-300 shadow-md ring-2 ring-amber-400/50'
              : 'text-slate-700 hover:bg-slate-300/80'
          }`}
        >
          <Layers className="w-4 h-4 text-amber-300" />
          <span>২. প্রক্রিয়াকৃত সনদ রেজিস্টার বহি ({monthFilteredCertificates.length} টি)</span>
        </button>

        <button
          onClick={() => setActiveTab('pdf_preview')}
          className={`flex-1 min-w-[190px] py-3 px-4 rounded-xl text-xs font-extrabold transition flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'pdf_preview'
              ? 'bg-emerald-900 text-amber-300 shadow-md ring-2 ring-amber-400/50'
              : 'text-slate-700 hover:bg-slate-300/80'
          }`}
        >
          <Eye className="w-4 h-4 text-amber-300" />
          <span>৩. অফিশিয়াল A4 PDF প্রিভিউ ও প্রিন্ট</span>
        </button>
      </div>

      {/* 3. TAB 1: Monthly Analytics Dashboard (Hidden in Print) */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6 print:hidden">
          
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Total Processed */}
            <div className="bg-white p-5 rounded-3xl border-2 border-emerald-100 shadow-sm flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  {selectedMonthObj.nameBn} {selectedYear}-এ মোট সনদ
                </p>
                <div className="flex items-baseline gap-2 mt-1">
                  <h3 className="text-3xl font-black text-slate-900">
                    {monthlyMetrics.totalProcessed}
                  </h3>
                  <span className="text-xs font-bold text-emerald-700">
                    ({toBnDigits(monthlyMetrics.totalProcessed)} টি)
                  </span>
                </div>
                <p className="text-[11px] text-emerald-800 font-semibold mt-1 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>অনুমোদন হার: {monthlyMetrics.approvalRate}%</span>
                </p>
              </div>
              <div className="p-3.5 bg-emerald-100 text-emerald-900 rounded-2xl shadow-xs">
                <FileText className="w-7 h-7 text-emerald-700" />
              </div>
            </div>

            {/* Approved Count */}
            <div className="bg-white p-5 rounded-3xl border-2 border-teal-100 shadow-sm flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  অনুমোদিত ও স্বাক্ষরিত
                </p>
                <div className="flex items-baseline gap-2 mt-1">
                  <h3 className="text-3xl font-black text-slate-900">
                    {monthlyMetrics.approvedCount}
                  </h3>
                  <span className="text-xs font-bold text-teal-700">
                    ({toBnDigits(monthlyMetrics.approvedCount)} টি)
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 font-semibold mt-1">
                  কিউআর কোডসহ ভেরিফায়েড
                </p>
              </div>
              <div className="p-3.5 bg-teal-100 text-teal-900 rounded-2xl shadow-xs">
                <Check className="w-7 h-7 text-teal-700 stroke-[3]" />
              </div>
            </div>

            {/* Total Revenue Collected */}
            <div className="bg-white p-5 rounded-3xl border-2 border-amber-100 shadow-sm flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  মোট সংগৃহীত ইউপি ফি
                </p>
                <div className="flex items-baseline gap-2 mt-1">
                  <h3 className="text-3xl font-black text-emerald-800">
                    ৳ {monthlyMetrics.totalRevenue.toLocaleString('en-US')}
                  </h3>
                </div>
                <p className="text-[11px] text-slate-600 font-bold mt-1">
                  ডিজিটাল: ৳{monthlyMetrics.digitalPayments} | ক্যাশ: ৳{monthlyMetrics.cashPayments}
                </p>
              </div>
              <div className="p-3.5 bg-amber-100 text-amber-900 rounded-2xl shadow-xs">
                <DollarSign className="w-7 h-7 text-amber-700" />
              </div>
            </div>

            {/* Pending & Rejected */}
            <div className="bg-white p-5 rounded-3xl border-2 border-rose-100 shadow-sm flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  পেন্ডিং ও বাতিল আবেদন
                </p>
                <div className="flex items-baseline gap-2 mt-1">
                  <h3 className="text-2xl font-black text-slate-900">
                    {monthlyMetrics.pendingCount} <span className="text-xs text-amber-700 font-bold">পেন্ডিং</span> / {monthlyMetrics.rejectedCount} <span className="text-xs text-rose-700 font-bold">বাতিল</span>
                  </h3>
                </div>
                <p className="text-[11px] text-slate-500 font-semibold mt-1">
                  প্রশাসনিক পর্যবেক্ষণাধীন
                </p>
              </div>
              <div className="p-3.5 bg-rose-100 text-rose-900 rounded-2xl shadow-xs">
                <Clock className="w-7 h-7 text-rose-700" />
              </div>
            </div>

          </div>

          {/* Category Breakdown and Ward Distribution Two-Column Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Card 1: Certificate Type-wise Breakdown */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                    <Layers className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-sm">
                      সনদের ক্যাটাগরি ও ধরনভিত্তিক বিশ্লেষণ ({selectedMonthObj.nameBn})
                    </h3>
                    <p className="text-xs text-slate-500">প্রক্রিয়াকৃত সনদপত্রের প্রকারভেদ ও রাজস্ব</p>
                  </div>
                </div>
                <span className="text-xs font-black px-2.5 py-1 bg-emerald-50 text-emerald-900 rounded-lg border border-emerald-200">
                  {monthlyMetrics.sortedTypes.length} টি ধরন
                </span>
              </div>

              {monthlyMetrics.sortedTypes.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs">
                  নির্বাচিত মাসে কোনো সনদ প্রক্রিয়াকরণ রেকর্ড পাওয়া যায়নি।
                </div>
              ) : (
                <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
                  {monthlyMetrics.sortedTypes.map((type, idx) => {
                    const percent = monthlyMetrics.totalProcessed > 0
                      ? Math.round((type.count / monthlyMetrics.totalProcessed) * 100)
                      : 0;

                    return (
                      <div key={type.key} className="p-3 bg-slate-50 rounded-2xl border border-slate-200/80 hover:border-emerald-300 transition">
                        <div className="flex items-center justify-between text-xs font-bold text-slate-900 mb-1.5">
                          <span className="flex items-center gap-1.5">
                            <span className="w-5 h-5 rounded-full bg-emerald-900 text-amber-300 text-[10px] flex items-center justify-center font-black">
                              {toBnDigits(idx + 1)}
                            </span>
                            <span>{type.label}</span>
                          </span>
                          <span className="font-black text-emerald-900">
                            {type.count} টি ({toBnDigits(type.count)}) • ৳{type.fee.toLocaleString('en-US')}
                          </span>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden flex">
                          <div
                            className="bg-emerald-600 rounded-full transition-all duration-500"
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1 font-semibold">
                          <span>ক্যাটাগরি: {type.category}</span>
                          <span>মোট সনদের {percent}%</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Card 2: Ward-wise Distribution */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-amber-100 text-amber-800 rounded-xl">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-sm">
                      ওয়ার্ডভিত্তিক সনদপত্র বণ্টন (Ward 01 - 09)
                    </h3>
                    <p className="text-xs text-slate-500">বহেড়াতৈল ইউনিয়নের ৯টি ওয়ার্ডের নাগরিক সেবা প্রবাহ</p>
                  </div>
                </div>
                <span className="text-xs font-black px-2.5 py-1 bg-amber-50 text-amber-900 rounded-lg border border-amber-200">
                  ৯টি ওয়ার্ড
                </span>
              </div>

              <div className="grid grid-cols-3 gap-3">
                {monthlyMetrics.sortedWards.map(item => {
                  const percent = monthlyMetrics.totalProcessed > 0
                    ? Math.round((item.count / monthlyMetrics.totalProcessed) * 100)
                    : 0;

                  return (
                    <div 
                      key={item.ward}
                      onClick={() => setSelectedWard(item.ward)}
                      className={`p-3 rounded-2xl border transition cursor-pointer text-center ${
                        selectedWard === item.ward
                          ? 'bg-emerald-900 text-white border-amber-400 ring-2 ring-amber-400/40 shadow-sm'
                          : 'bg-slate-50 hover:bg-emerald-50 text-slate-900 border-slate-200'
                      }`}
                    >
                      <p className="text-[11px] font-bold text-slate-500 uppercase">
                        ওয়ার্ড নং {toBnDigits(item.ward)}
                      </p>
                      <h4 className="text-xl font-black mt-1">
                        {item.count} <span className="text-[10px] font-normal">টি</span>
                      </h4>
                      <p className="text-[10px] font-semibold text-emerald-700 mt-1">
                        {percent}% • ৳{item.fee}
                      </p>
                    </div>
                  );
                })}
              </div>

              {/* Summary Note */}
              <div className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-start gap-2.5 text-xs text-emerald-950 font-medium">
                <Sparkles className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  <strong>প্রশাসনিক নিরীক্ষা নোট:</strong> {selectedMonthObj.nameBn} মাসে সর্বোচ্চ সনদপত্র ইস্যু হয়েছে {
                    monthlyMetrics.sortedWards.reduce((max, w) => w.count > max.count ? w : max, { ward: '০১', count: 0 }).ward
                  } নং ওয়ার্ড থেকে। সকল ফি সরকারি কোষাগার অ্যাকাউন্টে রাজস্ব ভাউচারভুক্ত করা হয়েছে।
                </p>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* 4. TAB 2: Detailed Certificates Register Ledger Table (Hidden in Print) */}
      {activeTab === 'detailed_register' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4 print:hidden">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h3 className="font-extrabold text-slate-900 text-base">
                {selectedMonthObj.nameBn} {selectedYear} মাসের পূর্ণাঙ্গ সনদ রেজিস্টার বহি
              </h3>
              <p className="text-xs text-slate-500">
                মোট ফিল্টারকৃত রেকর্ড: {monthFilteredCertificates.length} টি ({toBnDigits(monthFilteredCertificates.length)} টি)
              </p>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="স্মারক, নাম, এনআইডি, গ্রাম খুঁজুন..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 pr-4 py-2 bg-slate-50 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-600 w-64 font-medium"
                />
              </div>

              <button
                onClick={handlePrintPdf}
                className="px-3.5 py-2 bg-emerald-900 hover:bg-emerald-800 text-amber-300 text-xs font-black rounded-xl transition flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>প্রিন্ট ভিউ</span>
              </button>
            </div>
          </div>

          {monthFilteredCertificates.length === 0 ? (
            <div className="text-center py-16 text-slate-400 space-y-2">
              <FileText className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="font-bold text-sm text-slate-600">কোনো সনদপত্র রেকর্ড পাওয়া যায়নি</p>
              <p className="text-xs text-slate-400">ফিল্টার পরিবর্তন করে পুনরায় চেষ্টা করুন</p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-2xl border border-slate-200">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-800 font-extrabold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-3 w-12 text-center">ক্র.নং</th>
                    <th className="py-3 px-3">স্মারক নম্বর</th>
                    <th className="py-3 px-3">ইস্যুর তারিখ</th>
                    <th className="py-3 px-3">সনদের ধরন</th>
                    <th className="py-3 px-3">আবেদনকারীর নাম ও পরিচয়</th>
                    <th className="py-3 px-3">গ্রাম ও ওয়ার্ড</th>
                    <th className="py-3 px-3">ইউপি ফি</th>
                    <th className="py-3 px-3 text-center">স্ট্যাটাস</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {monthFilteredCertificates.map((cert, idx) => (
                    <tr key={cert.id || cert.memoNo || idx} className="hover:bg-slate-50 transition">
                      <td className="py-3 px-3 text-center font-bold text-slate-500">
                        {toBnDigits(idx + 1)}
                      </td>
                      <td className="py-3 px-3 font-mono font-bold text-emerald-950">
                        {cert.memoNo}
                      </td>
                      <td className="py-3 px-3 font-medium text-slate-700">
                        {cert.issueDate || cert.issueDateEn || '-'}
                      </td>
                      <td className="py-3 px-3 font-bold text-slate-900">
                        <span className="px-2 py-0.5 bg-emerald-50 text-emerald-900 rounded border border-emerald-200">
                          {cert.typeLabel}
                        </span>
                      </td>
                      <td className="py-3 px-3">
                        <p className="font-extrabold text-slate-900">{cert.citizen?.name || '-'}</p>
                        <p className="text-[10px] text-slate-500">
                          পিতা/স্বামী: {cert.citizen?.father || '-'} • NID: {cert.citizen?.nid || cert.citizen?.birthNo || '-'}
                        </p>
                      </td>
                      <td className="py-3 px-3">
                        <p className="font-semibold text-slate-800">{cert.citizen?.village || '-'}</p>
                        <p className="text-[10px] text-slate-500">ওয়ার্ড: {toBnDigits(cert.citizen?.wardNo || '০১')}</p>
                      </td>
                      <td className="py-3 px-3 font-extrabold text-emerald-800">
                        ৳{cert.feeAmount || 0}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <span className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-black ${
                          cert.status === 'approved'
                            ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                            : cert.status === 'cancelled'
                            ? 'bg-rose-100 text-rose-900 border border-rose-300'
                            : 'bg-amber-100 text-amber-900 border border-amber-300'
                        }`}>
                          {cert.status === 'approved' ? 'অনুমোদিত' : cert.status === 'cancelled' ? 'বাতিল' : 'ইস্যুকৃত/পেন্ডিং'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* 5. TAB 3 & OFFICIAL PRINT DOCUMENT (Visible on TAB 3 and ALWAYS on window.print()) */}
      <div 
        id="monthly-report-print-sheet"
        className={`${activeTab === 'pdf_preview' ? 'block' : 'hidden'} print:block bg-white p-8 md:p-12 rounded-3xl shadow-2xl border border-slate-300 max-w-5xl mx-auto text-slate-900 print:shadow-none print:p-0 print:border-none print:m-0 print:w-full print:max-w-none`}
      >
        {/* Print Header Controls Bar (Hidden in Print) */}
        <div className="bg-slate-100 p-4 rounded-2xl border border-slate-200 mb-6 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-emerald-800" />
            <span className="text-xs font-bold text-slate-800">
              অফিশিয়াল A4 সরকারি ডকুমেন্ট প্রিন্ট মোড
            </span>
          </div>
          <button
            onClick={handlePrintPdf}
            className="px-5 py-2 bg-emerald-900 text-amber-300 font-extrabold text-xs rounded-xl shadow-md flex items-center gap-2 cursor-pointer hover:bg-emerald-800"
          >
            <Download className="w-4 h-4" />
            <span>এখনই PDF হিসেবে সেভ করুন</span>
          </button>
        </div>

        {/* Printable Official Government Letterhead */}
        <div className="border-b-2 border-slate-800 pb-4 text-center relative">
          
          {/* Government / UP Seal */}
          <div className="flex items-center justify-center gap-4 mb-2">
            <img 
              src={config.logoUrl || '/baheratail_seal.svg'} 
              alt="UP Seal" 
              className="w-16 h-16 object-contain"
            />
            <div>
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-widest">
                গণপ্রজাতন্ত্রী বাংলাদেশ সরকার
              </h4>
              <h2 className="text-xl md:text-2xl font-black text-emerald-950 tracking-tight">
                ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ কার্যালয়
              </h2>
              <p className="text-xs font-bold text-slate-700">
                ডাকঘর: বহেড়াতৈল, উপজেলা: সখিপুর, জেলা: টাঙ্গাইল — ১৯৫০
              </p>
            </div>
          </div>

          <div className="mt-2 inline-block bg-slate-900 text-white font-black text-xs md:text-sm px-6 py-1.5 rounded-full border border-slate-700 uppercase tracking-wide">
            মাসিক প্রত্যয়নপত্র প্রক্রিয়াকরণ সারসংক্ষেপ ও রাজস্ব নিরীক্ষা প্রতিবেদন
          </div>

          {/* Reference and Date Bar */}
          <div className="mt-4 flex items-center justify-between text-xs font-bold text-slate-800 border-t border-slate-300 pt-2">
            <div>
              <span>স্মারক নম্বর: </span>
              <span className="font-mono">{reportRefNo}</span>
            </div>
            <div>
              <span>প্রতিবেদনের সময়কাল: </span>
              <span className="text-emerald-900 font-black">{selectedMonthObj.nameBn} {toBnDigits(selectedYear)} খ্রি.</span>
            </div>
            <div>
              <span>প্রতিবেদন তৈরির তারিখ: </span>
              <span>{printDateBn}</span>
            </div>
          </div>
        </div>

        {/* Section 1: Executive KPI Matrix Table */}
        <div className="my-6 space-y-2">
          <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider bg-slate-100 px-3 py-1.5 rounded border border-slate-200">
            ১. একনজরে {selectedMonthObj.nameBn} {toBnDigits(selectedYear)} মাসের পরিসংখ্যান
          </h3>

          <div className="grid grid-cols-4 gap-3 text-center">
            <div className="p-3 bg-slate-50 border border-slate-300 rounded-lg">
              <p className="text-[10px] font-bold text-slate-600 uppercase">মোট প্রক্রিয়াকৃত আবেদন</p>
              <p className="text-xl font-black text-slate-900 mt-0.5">{toBnDigits(monthlyMetrics.totalProcessed)} টি</p>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-300 rounded-lg">
              <p className="text-[10px] font-bold text-slate-600 uppercase">অনুমোদিত ও ইস্যুকৃত সনদ</p>
              <p className="text-xl font-black text-emerald-900 mt-0.5">{toBnDigits(monthlyMetrics.approvedCount)} টি</p>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-300 rounded-lg">
              <p className="text-[10px] font-bold text-slate-600 uppercase">পেন্ডিং / বাতিল আবেদন</p>
              <p className="text-xl font-black text-slate-900 mt-0.5">{toBnDigits(monthlyMetrics.pendingCount + monthlyMetrics.rejectedCount)} টি</p>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-300 rounded-lg">
              <p className="text-[10px] font-bold text-slate-600 uppercase">মোট সংগৃহীত সরকারি ফি</p>
              <p className="text-xl font-black text-emerald-900 mt-0.5">৳ {toBnDigits(monthlyMetrics.totalRevenue)}/-</p>
            </div>
          </div>
        </div>

        {/* Section 2: Type-wise Breakdown Summary Table */}
        <div className="my-6 space-y-2">
          <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider bg-slate-100 px-3 py-1.5 rounded border border-slate-200">
            ২. সনদের ধরন ও ক্যাটাগরিভিত্তিক সারসংক্ষেপ
          </h3>

          <table className="w-full text-xs text-left border-collapse border border-slate-300">
            <thead className="bg-slate-200 text-slate-900 font-black">
              <tr>
                <th className="border border-slate-300 p-2 text-center w-12">ক্র.নং</th>
                <th className="border border-slate-300 p-2">সনদের বিবরণ / ধরন</th>
                <th className="border border-slate-300 p-2">ক্যাটাগরি</th>
                <th className="border border-slate-300 p-2 text-center">আবেদন সংখ্যা</th>
                <th className="border border-slate-300 p-2 text-center">শতকরা হার (%)</th>
                <th className="border border-slate-300 p-2 text-right">আদায়কৃত রাজস্ব ফি (টাকা)</th>
              </tr>
            </thead>
            <tbody>
              {monthlyMetrics.sortedTypes.map((t, idx) => {
                const pct = monthlyMetrics.totalProcessed > 0 ? ((t.count / monthlyMetrics.totalProcessed) * 100).toFixed(1) : '0';
                return (
                  <tr key={t.key} className="even:bg-slate-50">
                    <td className="border border-slate-300 p-1.5 text-center font-bold">{toBnDigits(idx + 1)}</td>
                    <td className="border border-slate-300 p-1.5 font-bold">{t.label}</td>
                    <td className="border border-slate-300 p-1.5 text-slate-700">{t.category}</td>
                    <td className="border border-slate-300 p-1.5 text-center font-bold">{toBnDigits(t.count)}</td>
                    <td className="border border-slate-300 p-1.5 text-center font-medium">{toBnDigits(pct)}%</td>
                    <td className="border border-slate-300 p-1.5 text-right font-bold text-slate-900">৳ {toBnDigits(t.fee)}</td>
                  </tr>
                );
              })}
              <tr className="bg-slate-200 font-black text-slate-950">
                <td colSpan={3} className="border border-slate-300 p-2 text-right">সর্বমোট:</td>
                <td className="border border-slate-300 p-2 text-center">{toBnDigits(monthlyMetrics.totalProcessed)} টি</td>
                <td className="border border-slate-300 p-2 text-center">১০০%</td>
                <td className="border border-slate-300 p-2 text-right">৳ {toBnDigits(monthlyMetrics.totalRevenue)}/-</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Section 3: Ward-wise Summary Grid */}
        <div className="my-6 space-y-2">
          <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider bg-slate-100 px-3 py-1.5 rounded border border-slate-200">
            ৩. ওয়ার্ডভিত্তিক প্রত্যয়নপত্র ইস্যুর সারসংক্ষেপ
          </h3>

          <div className="grid grid-cols-9 gap-1 text-center border border-slate-300 p-2 rounded bg-slate-50">
            {monthlyMetrics.sortedWards.map(w => (
              <div key={w.ward} className="border border-slate-200 bg-white p-1 rounded">
                <p className="text-[9px] font-bold text-slate-600">ওয়ার্ড {toBnDigits(w.ward)}</p>
                <p className="text-xs font-black text-emerald-950 mt-0.5">{toBnDigits(w.count)} টি</p>
              </div>
            ))}
          </div>
        </div>

        {/* Section 4: Detailed Processing Register (First 50 items or all) */}
        <div className="my-6 space-y-2">
          <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider bg-slate-100 px-3 py-1.5 rounded border border-slate-200">
            ৪. প্রক্রিয়াকৃত সনদসমূহের সংক্ষিপ্ত রেজিস্টার তালিকা
          </h3>

          <table className="w-full text-[11px] text-left border-collapse border border-slate-300">
            <thead className="bg-slate-200 text-slate-900 font-black">
              <tr>
                <th className="border border-slate-300 p-1.5 text-center w-10">ক্র.</th>
                <th className="border border-slate-300 p-1.5">স্মারক নম্বর</th>
                <th className="border border-slate-300 p-1.5">ইস্যুর তারিখ</th>
                <th className="border border-slate-300 p-1.5">সনদের ধরন</th>
                <th className="border border-slate-300 p-1.5">নাগরিকের নাম</th>
                <th className="border border-slate-300 p-1.5">পিতা/স্বামী</th>
                <th className="border border-slate-300 p-1.5">গ্রাম ও ওয়ার্ড</th>
                <th className="border border-slate-300 p-1.5 text-right">ফি</th>
                <th className="border border-slate-300 p-1.5 text-center">স্ট্যাটাস</th>
              </tr>
            </thead>
            <tbody>
              {monthFilteredCertificates.slice(0, 100).map((c, idx) => (
                <tr key={c.id || idx} className="even:bg-slate-50">
                  <td className="border border-slate-300 p-1 text-center">{toBnDigits(idx + 1)}</td>
                  <td className="border border-slate-300 p-1 font-mono font-bold text-[10px]">{c.memoNo}</td>
                  <td className="border border-slate-300 p-1">{c.issueDate || c.issueDateEn || '-'}</td>
                  <td className="border border-slate-300 p-1 font-bold">{c.typeLabel}</td>
                  <td className="border border-slate-300 p-1 font-bold">{c.citizen?.name}</td>
                  <td className="border border-slate-300 p-1">{c.citizen?.father || '-'}</td>
                  <td className="border border-slate-300 p-1">{c.citizen?.village || '-'}, ওয়ার্ড-{toBnDigits(c.citizen?.wardNo || '০১')}</td>
                  <td className="border border-slate-300 p-1 text-right font-bold">৳{toBnDigits(c.feeAmount || 0)}</td>
                  <td className="border border-slate-300 p-1 text-center font-bold text-[10px]">
                    {c.status === 'approved' ? 'অনুমোদিত' : c.status === 'cancelled' ? 'বাতিল' : 'ইস্যুকৃত'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {monthFilteredCertificates.length > 100 && (
            <p className="text-[10px] text-slate-500 italic text-right">
              * প্রথম ১০০টি রেকর্ড প্রিন্ট তালিকায় দেখানো হয়েছে। সম্পূর্ণ তালিকার জন্য CSV এক্সপোর্ট করুন।
            </p>
          )}
        </div>

        {/* Section 5: Official Signatures & Verification Block */}
        <div className="mt-12 pt-6 border-t-2 border-slate-800 grid grid-cols-3 gap-6 text-center text-xs">
          
          {/* Operator */}
          <div className="space-y-8">
            <div className="h-10" />
            <div className="border-t border-slate-400 pt-1">
              <p className="font-black text-slate-900">প্রস্তুতকারীর স্বাক্ষর</p>
              <p className="text-[10px] text-slate-600">কম্পিউটার সহকারী / ইউডিসি উদ্যোক্তা</p>
              <p className="text-[10px] text-slate-500">০২নং বহেড়াতৈল ইউনিয়ন পরিষদ</p>
            </div>
          </div>

          {/* Secretary */}
          <div className="space-y-8 flex flex-col items-center">
            <div className="w-14 h-14 border border-dashed border-slate-300 rounded-full flex items-center justify-center text-[9px] text-slate-400">
              অফিস সিল
            </div>
            <div className="border-t border-slate-400 pt-1 w-full">
              <p className="font-black text-slate-900">যাচাইকারীর স্বাক্ষর</p>
              <p className="text-[10px] text-slate-600">প্রশাসনিক কর্মকর্তা / সচিব</p>
              <p className="text-[10px] text-slate-500">০২নং বহেড়াতৈল ইউনিয়ন পরিষদ</p>
            </div>
          </div>

          {/* Chairman */}
          <div className="space-y-8">
            <div className="h-10" />
            <div className="border-t border-slate-400 pt-1">
              <p className="font-black text-slate-900">অনুমোদনকারীর স্বাক্ষর</p>
              <p className="text-[10px] text-slate-600">চেয়ারম্যান</p>
              <p className="text-[10px] text-slate-500">০২নং বহেড়াতৈল ইউনিয়ন পরিষদ</p>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
