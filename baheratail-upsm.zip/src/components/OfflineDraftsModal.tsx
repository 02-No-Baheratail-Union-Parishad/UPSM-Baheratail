import React, { useState, useEffect } from 'react';
import { 
  FolderArchive, 
  CloudUpload, 
  Trash2, 
  Edit3, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Loader2, 
  X, 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  FileText,
  User,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { DraftCertificate, DraftSyncStats } from '../types';
import { 
  getAllDraftsFromIndexedDB, 
  deleteDraftFromIndexedDB, 
  clearSyncedDraftsFromIndexedDB,
  getDraftStats 
} from '../services/draftStorage';
import { draftSyncService, SyncProgressEvent } from '../services/draftSyncService';

interface OfflineDraftsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDraftToEdit?: (draft: DraftCertificate) => void;
}

export const OfflineDraftsModal: React.FC<OfflineDraftsModalProps> = ({
  isOpen,
  onClose,
  onSelectDraftToEdit
}) => {
  const [drafts, setDrafts] = useState<DraftCertificate[]>([]);
  const [stats, setStats] = useState<DraftSyncStats>({ total: 0, pending: 0, synced: 0, failed: 0 });
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncProgress, setSyncProgress] = useState<SyncProgressEvent | null>(null);
  const [filter, setFilter] = useState<'all' | 'pending' | 'synced'>('all');
  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);

  const loadDrafts = async () => {
    setIsLoading(true);
    try {
      const allDrafts = await getAllDraftsFromIndexedDB();
      const currentStats = await getDraftStats();
      setDrafts(allDrafts);
      setStats(currentStats);
    } catch (err) {
      console.error('Error loading drafts from IndexedDB:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadDrafts();
    }
  }, [isOpen]);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    const handleDraftsChanged = () => loadDrafts();

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('bup:drafts-changed', handleDraftsChanged);

    const unsubscribe = draftSyncService.subscribe((progress) => {
      setSyncProgress(progress);
      if (progress.status === 'syncing') {
        setIsSyncing(true);
      } else if (progress.status === 'completed' || progress.status === 'error') {
        setIsSyncing(false);
        loadDrafts();
      }
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('bup:drafts-changed', handleDraftsChanged);
      unsubscribe();
    };
  }, []);

  const handleManualSync = async () => {
    if (!navigator.onLine) {
      alert('⚠️ আপনি বর্তমানে অফলাইনে আছেন। ইন্টারনেট সংযোগ পুনঃস্থাপন হইলে স্বয়ংক্রিয়ভাবে বা ম্যানুয়ালি সিঙ্ক করিতে পারিবেন।');
      return;
    }
    setIsSyncing(true);
    await draftSyncService.triggerAutoSync();
    await loadDrafts();
    setIsSyncing(false);
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('আপনি কি নিশ্চিত যে এই অফলাইন ড্রাফটটি মুছে ফেলিতে চান?')) {
      await deleteDraftFromIndexedDB(id);
      await loadDrafts();
    }
  };

  const handleClearSynced = async () => {
    if (confirm('সকল সফলভাবে সিঙ্ক হওয়া ড্রাফট তালিকা হইতে সাফ করিতে চান?')) {
      await clearSyncedDraftsFromIndexedDB();
      await loadDrafts();
    }
  };

  if (!isOpen) return null;

  const filteredDrafts = drafts.filter((d) => {
    if (filter === 'pending') return d.syncStatus === 'pending' || d.syncStatus === 'failed' || !d.syncStatus;
    if (filter === 'synced') return d.syncStatus === 'synced';
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-400/20 text-amber-300 rounded-2xl border border-amber-300/30">
              <FolderArchive className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight text-amber-200 flex items-center gap-2">
                <span>অফলাইন ড্রাফট ও ব্যাকগ্রাউন্ড সিঙ্ক ভল্ট</span>
                <span className="text-[10px] px-2 py-0.5 bg-emerald-800 text-emerald-200 rounded-full border border-emerald-600 font-mono">
                  IndexedDB v2 + Service Worker
                </span>
              </h2>
              <p className="text-xs text-emerald-100/80">
                ইন্টারনেট বিহীন অবস্থায় তৈরিকৃত খসড়া সনদপত্রসমূহ লোকাল স্টোরেজে সংরক্ষিত এবং সংযোগ ফিরলে স্বয়ংক্রিয়ভাবে ফায়ারবেসে আপলোড হইবে।
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Network & Stats Ribbon */}
        <div className="bg-slate-50 dark:bg-slate-800/60 p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs text-xs font-bold">
              {isOnline ? (
                <>
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <Wifi className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700 dark:text-emerald-400">অনলাইন (Live Connected)</span>
                </>
              ) : (
                <>
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping"></span>
                  <WifiOff className="w-4 h-4 text-amber-600" />
                  <span className="text-amber-700 dark:text-amber-400">অফলাইন (Local Storage Active)</span>
                </>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="px-2.5 py-1 bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-200 rounded-lg font-bold border border-amber-300 dark:border-amber-700">
                পেন্ডিং সিঙ্ক: {stats.pending} টি
              </span>
              <span className="px-2.5 py-1 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200 rounded-lg font-bold border border-emerald-300 dark:border-emerald-700">
                সিঙ্ক সম্পন্ন: {stats.synced} টি
              </span>
              <span className="px-2.5 py-1 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg font-bold">
                সর্বমোট: {stats.total} টি
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {stats.synced > 0 && (
              <button
                type="button"
                onClick={handleClearSynced}
                className="px-3 py-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white dark:bg-slate-800 hover:bg-slate-100 border border-slate-300 dark:border-slate-700 rounded-xl transition cursor-pointer"
              >
                সাফ সম্পন্ন ড্রাফট
              </button>
            )}

            <button
              type="button"
              onClick={handleManualSync}
              disabled={isSyncing || stats.pending === 0 || !isOnline}
              className={`px-4 py-1.5 text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 transition cursor-pointer ${
                isSyncing || stats.pending === 0 || !isOnline
                  ? 'bg-slate-200 dark:bg-slate-700 text-slate-400 dark:text-slate-500 cursor-not-allowed'
                  : 'bg-emerald-700 hover:bg-emerald-600 text-white shadow-emerald-700/20'
              }`}
            >
              {isSyncing ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>সিঙ্ক হইতেছে...</span>
                </>
              ) : (
                <>
                  <CloudUpload className="w-3.5 h-3.5" />
                  <span>ফায়ারবেসে এখনই সিঙ্ক করুন ({stats.pending})</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Sync Progress Notice Banner */}
        {syncProgress && syncProgress.status === 'syncing' && (
          <div className="bg-emerald-50 dark:bg-emerald-950/50 p-3 border-b border-emerald-200 dark:border-emerald-800 flex items-center justify-between text-xs text-emerald-900 dark:text-emerald-200 animate-fade-in">
            <div className="flex items-center gap-2">
              <Loader2 className="w-4 h-4 text-emerald-600 animate-spin" />
              <span className="font-bold">{syncProgress.message}</span>
            </div>
            <span className="font-mono text-xs bg-emerald-200 dark:bg-emerald-900 px-2 py-0.5 rounded-md font-bold">
              {syncProgress.completed} / {syncProgress.total}
            </span>
          </div>
        )}

        {/* Filter Tabs */}
        <div className="px-5 pt-3 pb-2 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setFilter('all')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition ${
                filter === 'all'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              সকল ড্রাফট ({drafts.length})
            </button>
            <button
              type="button"
              onClick={() => setFilter('pending')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition ${
                filter === 'pending'
                  ? 'bg-amber-600 text-white'
                  : 'text-amber-800 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40'
              }`}
            >
              পেন্ডিং সিঙ্ক ({stats.pending})
            </button>
            <button
              type="button"
              onClick={() => setFilter('synced')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition ${
                filter === 'synced'
                  ? 'bg-emerald-700 text-white'
                  : 'text-emerald-800 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
              }`}
            >
              সিঙ্ক সম্পন্ন ({stats.synced})
            </button>
          </div>

          <button
            onClick={loadDrafts}
            className="p-1.5 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            title="রিফ্রেশ করুন"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {/* Draft List Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3">
          {isLoading ? (
            <div className="py-16 text-center text-slate-400 flex flex-col items-center justify-center gap-2">
              <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
              <p className="text-xs font-bold">IndexedDB লোকাল ভল্ট হইতে ড্রাফট লোড হইতেছে...</p>
            </div>
          ) : filteredDrafts.length === 0 ? (
            <div className="py-16 text-center text-slate-400 dark:text-slate-500 flex flex-col items-center justify-center gap-3">
              <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-full">
                <FileText className="w-8 h-8 text-slate-400" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-700 dark:text-slate-300">কোনো ড্রাফট পাওয়া যায়নি</p>
                <p className="text-xs text-slate-500 mt-1 max-w-sm">
                  অফলাইনে বা অনলাইনে প্রত্যয়নপত্র ফরম পূরণকালীন "অফলাইন খসড়া সংরক্ষণ করুন" বাটনে চাপ দিলে এখানে ড্রাফট জমা হইবে।
                </p>
              </div>
            </div>
          ) : (
            filteredDrafts.map((draft) => {
              const isSynced = draft.syncStatus === 'synced';
              const isPending = draft.syncStatus === 'pending' || !draft.syncStatus;
              const isSyncingItem = draft.syncStatus === 'syncing';
              const isFailed = draft.syncStatus === 'failed';

              return (
                <div
                  key={draft.id}
                  className={`p-4 rounded-2xl border transition-all duration-150 flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                    isSynced
                      ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/60'
                      : isFailed
                      ? 'bg-rose-50/40 dark:bg-rose-950/20 border-rose-200 dark:border-rose-800/60'
                      : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 shadow-2xs hover:border-emerald-400'
                  }`}
                >
                  <div className="flex items-start gap-3.5">
                    <div className={`p-2.5 rounded-xl shrink-0 mt-0.5 ${
                      isSynced 
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200' 
                        : isFailed 
                        ? 'bg-rose-100 text-rose-800' 
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200'
                    }`}>
                      {isSynced ? (
                        <CheckCircle2 className="w-5 h-5" />
                      ) : isSyncingItem ? (
                        <Loader2 className="w-5 h-5 animate-spin text-teal-600" />
                      ) : isFailed ? (
                        <AlertCircle className="w-5 h-5" />
                      ) : (
                        <Clock className="w-5 h-5" />
                      )}
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-black text-sm text-slate-900 dark:text-slate-100">
                          {draft.typeNameBn}
                        </span>
                        <span className="font-mono text-xs text-slate-500 bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded-md">
                          {draft.memoNo}
                        </span>

                        {isSynced ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-900 dark:bg-emerald-900 dark:text-emerald-200">
                            <CheckCircle2 className="w-3 h-3" />
                            ফায়ারবেসে সিঙ্কড
                          </span>
                        ) : isSyncingItem ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-teal-100 text-teal-900 dark:bg-teal-900 dark:text-teal-200 animate-pulse">
                            সিঙ্ক চলিতেছে...
                          </span>
                        ) : isFailed ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-100 text-rose-900 dark:bg-rose-900 dark:text-rose-200">
                            আপলোড ত্রুটি
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-900 dark:bg-amber-900 dark:text-amber-200">
                            পেন্ডিং সিঙ্ক (অফলাইন)
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-3 text-xs text-slate-600 dark:text-slate-300 flex-wrap">
                        <span className="font-bold flex items-center gap-1">
                          <User className="w-3.5 h-3.5 text-slate-400" />
                          আবেদনকারী: {draft.citizen.name || 'নাম বিহীন'}
                        </span>
                        {draft.citizen.nid && (
                          <span className="font-mono">NID: {draft.citizen.nid}</span>
                        )}
                        <span>গ্রাম: {draft.citizen.village} (ওয়ার্ড {draft.citizen.wardNo})</span>
                      </div>

                      <div className="text-[11px] text-slate-400 flex items-center gap-3">
                        <span>তৈরির সময়: {new Date(draft.createdAt).toLocaleString('bn-BD')}</span>
                        {draft.syncedAt && (
                          <span className="text-emerald-600 dark:text-emerald-400">
                            সিঙ্ক সময়: {new Date(draft.syncedAt).toLocaleTimeString('bn-BD')}
                          </span>
                        )}
                        {draft.syncError && (
                          <span className="text-rose-600 dark:text-rose-400 font-semibold">
                            কারণ: {draft.syncError}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                    {onSelectDraftToEdit && (
                      <button
                        type="button"
                        onClick={() => {
                          onSelectDraftToEdit(draft);
                          onClose();
                        }}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl transition flex items-center gap-1 cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>ফর্মে লোড করুন</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={(e) => handleDelete(draft.id, e)}
                      className="p-2 text-rose-500 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition cursor-pointer"
                      title="মুছে ফেলুন"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 dark:bg-slate-800/60 p-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Service Worker Background Sync ব্যাকগ্রাউন্ডে স্বয়ংক্রিয়ভাবে কার্যকর রহিয়াছে।</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 text-white font-bold rounded-xl transition cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
