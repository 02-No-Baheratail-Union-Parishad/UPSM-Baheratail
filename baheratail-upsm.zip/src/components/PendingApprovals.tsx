import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  XCircle,
  Clock,
  User,
  FileText,
  Search,
  Filter,
  CheckCheck,
  RefreshCw,
  Eye,
  ShieldCheck,
  Sparkles,
  AlertCircle,
  Building2,
  Phone,
  Calendar,
  X,
  CreditCard,
  Database,
  Stamp,
  FileCheck2,
  Send,
  MessageSquareShare,
  FileBadge,
  Check,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { CertificateRecord, UnionParishadConfig, ApprovalStage } from '../types';
import { CERTIFICATE_TYPES, CERTIFICATE_CATEGORIES } from '../data/certificateTypes';
import { saveCertificateToFirebase } from '../firebase';
import { BiometricAuthModal } from './BiometricAuthModal';

interface PendingApprovalsProps {
  config: UnionParishadConfig;
  onCertificateStatusUpdated?: () => void;
}

export const PendingApprovals: React.FC<PendingApprovalsProps> = ({ config, onCertificateStatusUpdated }) => {
  const [allCertificates, setAllCertificates] = useState<CertificateRecord[]>([]);
  const [pendingList, setPendingList] = useState<CertificateRecord[]>([]);
  const [approvedTodayCount, setApprovedTodayCount] = useState<number>(0);
  const [rejectedCount, setRejectedCount] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedWard, setSelectedWard] = useState<string>('সব ওয়ার্ড');
  const [selectedCategory, setSelectedCategory] = useState<string>('সব ক্যাটাগরি');
  const [selectedCertType, setSelectedCertType] = useState<string>('সব সনদের ধরন');
  const [activeStageTab, setActiveStageTab] = useState<'all' | 'stage1_operator' | 'stage2_secretary' | 'stage3_approved' | 'rejected'>('all');
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [previewCert, setPreviewCert] = useState<CertificateRecord | null>(null);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  
  // Secretary verification modal state
  const [secretaryVerifyCert, setSecretaryVerifyCert] = useState<CertificateRecord | null>(null);
  const [secretaryNotesInput, setSecretaryNotesInput] = useState<string>('এনআইডি ও তথ্যাদি সঠিকভাবে যাচাইপূর্বক অনুমোদনের জন্য সুপারিশ করা হইলো।');
  const [checkNid, setCheckNid] = useState<boolean>(true);
  const [checkWard, setCheckWard] = useState<boolean>(true);
  const [checkDoc, setCheckDoc] = useState<boolean>(true);

  // Chairman approval notes state
  const [chairmanNotesInput, setChairmanNotesInput] = useState<string>('যাচাইপূর্বক চূড়ান্ত অনুমোদন ও ডিজিটাল স্বাক্ষর প্রদান করা হইলো।');

  // Rejection reason modal state
  const [rejectingCert, setRejectingCert] = useState<CertificateRecord | null>(null);
  const [rejectReasonInput, setRejectReasonInput] = useState<string>('তথ্য অসম্পূর্ণ বা এনআইডি যাচাই ব্যর্থ');

  // Biometric Auth Modal State
  const [isBiometricModalOpen, setIsBiometricModalOpen] = useState<boolean>(false);
  const [pendingBiometricTarget, setPendingBiometricTarget] = useState<CertificateRecord | 'ALL' | null>(null);

  // Fetch Pending List & Stats from Server
  const fetchPendingList = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/pending');
      const data = await res.json();
      if (data.success) {
        setPendingList(data.pending || []);
        setAllCertificates(data.pending || []);
        setApprovedTodayCount(data.stats?.approvedToday || 0);
        setRejectedCount(data.stats?.totalRejected || 0);
      }
    } catch (err) {
      console.error('Failed to fetch pending list:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPendingList();
  }, []);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Helper to determine stage
  const getRecordStage = (cert: CertificateRecord): ApprovalStage => {
    if (cert.approvalStage) return cert.approvalStage;
    if (cert.status === 'issued' || cert.status === 'approved') return 'chairman_approved';
    if (cert.secretaryVerifiedBy || cert.secretaryVerifiedAt) return 'secretary_verified';
    return 'operator_submitted';
  };

  // Stage 2: Secretary Verification
  const handleSecretaryVerify = async (cert: CertificateRecord) => {
    setProcessingId(cert.id);
    try {
      const res = await fetch('/api/admin/secretary-verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: cert.id,
          verifiedBy: config.secretaryName || 'ইউপি সচিব',
          notes: secretaryNotesInput
        })
      });
      const data = await res.json();

      if (data.success) {
        if (data.certificate) {
          saveCertificateToFirebase(data.certificate).catch(err =>
            console.warn('Firebase sync warning:', err)
          );
        }

        setPendingList(prev =>
          prev.map(c => (c.id === cert.id ? { ...c, ...data.certificate, approvalStage: 'secretary_verified' } : c))
        );
        showToast(data.message || 'সচিব কর্তৃক যাচাই সম্পন্ন ও চেয়ারম্যানের সুপারিশে প্রেরণ করা হয়েছে!', 'success');
        setSecretaryVerifyCert(null);
        if (onCertificateStatusUpdated) onCertificateStatusUpdated();
      } else {
        showToast(data.message || 'যাচাইকরণে ত্রুটি ঘটিয়াছে।', 'error');
      }
    } catch (e) {
      console.error('Secretary verify request failed:', e);
      showToast('সার্ভার সংযোগ ত্রুটি ঘটিয়াছে।', 'error');
    } finally {
      setProcessingId(null);
    }
  };

  // Stage 3: Chairman Final Approval & E-Sign
  const handleApprove = async (
    cert: CertificateRecord,
    biometricVerification?: { authType: string; timestamp: string; verifiedBy: string }
  ) => {
    if (!biometricVerification) {
      setPendingBiometricTarget(cert);
      setIsBiometricModalOpen(true);
      return;
    }

    setProcessingId(cert.id);
    try {
      const res = await fetch('/api/admin/approve-cert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: cert.id,
          approvedBy: config.chairmanName || 'ইউপি চেয়ারম্যান',
          chairmanNotes: chairmanNotesInput,
          biometricVerified: true,
          biometricAuthType: biometricVerification.authType,
          biometricTimestamp: biometricVerification.timestamp,
          verifiedByBiometrics: biometricVerification.verifiedBy
        })
      });
      const data = await res.json();

      if (data.success) {
        if (data.certificate) {
          saveCertificateToFirebase(data.certificate).catch(err =>
            console.warn('Firebase sync warning:', err)
          );
        }

        setPendingList(prev => prev.filter(c => c.id !== cert.id));
        setApprovedTodayCount(prev => prev + 1);
        showToast(data.message || 'সনদ সফলভাবে চেয়ারম্যান কর্তৃক চূড়ান্ত অনুমোদিত ও ই-স্বাক্ষরিত হইয়াছে!', 'success');
        if (onCertificateStatusUpdated) onCertificateStatusUpdated();
      } else {
        showToast(data.message || 'অনুমোদনে ত্রুটি ঘটিয়াছে।', 'error');
      }
    } catch (e) {
      console.error('Approval request failed:', e);
      showToast('অনুমোদনে সার্ভার সংযোগ ত্রুটি ঘটিয়াছে।', 'error');
    } finally {
      setProcessingId(null);
    }
  };

  // One-Click Cancel / Reject
  const handleConfirmCancel = async () => {
    if (!rejectingCert) return;
    const cert = rejectingCert;
    setProcessingId(cert.id);

    try {
      const res = await fetch('/api/admin/cancel-cert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: cert.id,
          cancelledBy: config.chairmanName || 'ইউপি চেয়ারম্যান',
          reason: rejectReasonInput
        })
      });
      const data = await res.json();

      if (data.success) {
        if (data.certificate) {
          saveCertificateToFirebase(data.certificate).catch(err =>
            console.warn('Firebase sync warning:', err)
          );
        }

        setPendingList(prev => prev.filter(c => c.id !== cert.id));
        setRejectedCount(prev => prev + 1);
        showToast(data.message || 'আবেদন বাতিল করা হইয়াছে।', 'error');
        setRejectingCert(null);
        if (onCertificateStatusUpdated) onCertificateStatusUpdated();
      } else {
        showToast(data.message || 'বাতিলকরণে ত্রুটি ঘটিয়াছে।', 'error');
      }
    } catch (e) {
      console.error('Cancel request failed:', e);
      showToast('সার্ভার সংযোগ ত্রুটি ঘটিয়াছে।', 'error');
    } finally {
      setProcessingId(null);
    }
  };

  // One-Click Batch Approve All
  const handleBatchApprove = async (
    biometricVerification?: { authType: string; timestamp: string; verifiedBy: string }
  ) => {
    if (pendingList.length === 0) return;

    if (!biometricVerification) {
      if (!window.confirm(`আপনি কি নিশ্চিত যে সকল (${pendingList.length} টি) পেন্ডিং আবেদন একসাথে চূড়ান্ত অনুমোদন ও ডিজিটাল স্বাক্ষর করতে চান?`)) {
        return;
      }
      setPendingBiometricTarget('ALL');
      setIsBiometricModalOpen(true);
      return;
    }

    const approveCount = pendingList.length;
    setLoading(true);
    try {
      const res = await fetch('/api/admin/batch-approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          approvedBy: config.chairmanName || 'ইউপি চেয়ারম্যান',
          biometricVerified: true,
          biometricAuthType: biometricVerification.authType,
          biometricTimestamp: biometricVerification.timestamp,
          verifiedByBiometrics: biometricVerification.verifiedBy
        })
      });
      const data = await res.json();

      if (data.success) {
        setPendingList([]);
        setApprovedTodayCount(prev => prev + approveCount);
        showToast(data.message || 'সকল পেন্ডিং আবেদন সফলভাবে অনুমোদন হইয়াছে!', 'success');
        if (onCertificateStatusUpdated) onCertificateStatusUpdated();
      }
    } catch (e) {
      showToast('ব্যাচ অনুমোদনে সংযোগ ত্রুটি।', 'error');
    } finally {
      setLoading(false);
    }
  };

  // WhatsApp Notification Link Generator
  const sendWhatsAppNotification = (cert: CertificateRecord) => {
    const rawMobile = cert.citizen.mobile ? cert.citizen.mobile.replace(/[^0-9]/g, '') : '';
    const cleanMobile = rawMobile.startsWith('880') ? rawMobile : (rawMobile.startsWith('0') ? `88${rawMobile}` : `880${rawMobile}`);
    
    const message = `শ্রদ্ধেয় ${cert.citizen.name},\nআপনার ${cert.typeLabel} আবেদনটি ${config.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ'} কর্তৃক অনুমোদিত হয়েছে।\n\n📄 ট্র্যাকিং/স্মারক নং: ${cert.memoNo}\n🔍 অনলাইন ভেরিফিকেশন: https://baheratailup.gov.bd/verify/${encodeURIComponent(cert.memoNo)}\n\nধন্যবাদান্তে,\n${config.chairmanName || 'ইউপি চেয়ারম্যান'}\n${config.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ'}`;
    
    const url = `https://wa.me/${cleanMobile}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  // Filter calculations
  const stage1Count = pendingList.filter(item => getRecordStage(item) === 'operator_submitted').length;
  const stage2Count = pendingList.filter(item => getRecordStage(item) === 'secretary_verified').length;

  const categoriesList = Array.from(
    new Set([
      'সব ক্যাটাগরি',
      ...CERTIFICATE_CATEGORIES.filter(c => c !== 'সব ধরন'),
      ...pendingList.map(item => item.category).filter(Boolean)
    ])
  );

  const certTypesList = Array.from(
    new Set([
      'সব সনদের ধরন',
      ...CERTIFICATE_TYPES.map(t => t.label),
      ...pendingList.map(item => item.typeLabel).filter(Boolean)
    ])
  );

  const filteredList = pendingList.filter(item => {
    const stage = getRecordStage(item);

    if (activeStageTab === 'stage1_operator' && stage !== 'operator_submitted') return false;
    if (activeStageTab === 'stage2_secretary' && stage !== 'secretary_verified') return false;

    const q = searchQuery.trim().toLowerCase();
    const matchesSearch =
      !q ||
      item.citizen.name.toLowerCase().includes(q) ||
      item.memoNo.toLowerCase().includes(q) ||
      (item.citizen.nid && item.citizen.nid.includes(q)) ||
      (item.citizen.mobile && item.citizen.mobile.includes(q)) ||
      item.citizen.village.toLowerCase().includes(q) ||
      item.typeLabel.toLowerCase().includes(q);

    const matchesWard = selectedWard === 'সব ওয়ার্ড' || item.citizen.wardNo === selectedWard;
    const matchesCategory = selectedCategory === 'সব ক্যাটাগরি' || item.category === selectedCategory;
    const matchesCertType = selectedCertType === 'সব সনদের ধরন' || item.typeLabel === selectedCertType;

    return matchesSearch && matchesWard && matchesCategory && matchesCertType;
  });

  const isFilterActive =
    searchQuery.trim() !== '' ||
    selectedWard !== 'সব ওয়ার্ড' ||
    selectedCategory !== 'সব ক্যাটাগরি' ||
    selectedCertType !== 'সব সনদের ধরন' ||
    activeStageTab !== 'all';

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedWard('সব ওয়ার্ড');
    setSelectedCategory('সব ক্যাটাগরি');
    setSelectedCertType('সব সনদের ধরন');
    setActiveStageTab('all');
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`fixed top-5 right-5 z-50 px-5 py-3 rounded-xl shadow-2xl border flex items-center gap-3 text-xs font-bold transition animate-bounce ${
            toastMessage.type === 'success'
              ? 'bg-emerald-950 text-amber-300 border-amber-400/40'
              : 'bg-rose-950 text-rose-200 border-rose-500/40'
          }`}
        >
          {toastMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-amber-300" />
          ) : (
            <XCircle className="w-4 h-4 text-rose-400" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* 3-Stage Approval Portal Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-emerald-800 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 bg-emerald-800/80 backdrop-blur border border-emerald-600/50 text-amber-300 px-3 py-1 rounded-full text-xs font-bold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>৩-স্তর বিশিষ্ট প্রশাসনিক অনুমোদন ডেক্স (3-Stage UP Approval Desk)</span>
            </div>

            <h2 className="text-xl md:text-2xl font-extrabold tracking-tight text-white flex items-center gap-2">
              <span>{config.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ'}</span>
            </h2>

            {/* Visual Workflow Chain */}
            <div className="pt-2 flex flex-wrap items-center gap-2 text-xs">
              <div className="flex items-center gap-1.5 bg-slate-900/60 border border-slate-700 px-3 py-1 rounded-lg">
                <span className="w-2 h-2 rounded-full bg-blue-400" />
                <span className="font-semibold text-slate-200">১. উদ্যোক্তা খসড়া দাখিল</span>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-emerald-400 hidden sm:inline" />
              <div className="flex items-center gap-1.5 bg-slate-900/60 border border-slate-700 px-3 py-1 rounded-lg">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                <span className="font-semibold text-amber-200">২. সচিব যাচাই ও সুপারিশ ({config.secretaryName})</span>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-emerald-400 hidden sm:inline" />
              <div className="flex items-center gap-1.5 bg-slate-900/60 border border-slate-700 px-3 py-1 rounded-lg">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="font-semibold text-emerald-200">৩. চেয়ারম্যান চূড়ান্ত অনুমোদন ও ই-স্বাক্ষর ({config.chairmanName})</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-emerald-900/80 border border-emerald-700/80 p-3.5 rounded-xl text-center min-w-[120px]">
              <span className="text-[10px] text-emerald-300 block font-semibold">মোট অপেক্ষমাণ</span>
              <span className="text-2xl font-black text-amber-300">{pendingList.length} টি</span>
            </div>

            <div className="bg-emerald-900/80 border border-emerald-700/80 p-3.5 rounded-xl text-center min-w-[140px]">
              <span className="text-[10px] text-emerald-300 block font-semibold flex items-center justify-center gap-1">
                <Database className="w-3 h-3 text-emerald-400" />
                <span>ক্লাউড ও শিট সিঙ্ক</span>
              </span>
              <span className="text-xs font-bold text-emerald-200 flex items-center justify-center gap-1 mt-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse inline-block" />
                <span>রিয়েলটাইম সক্রিয়</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 3-Stage Tab Selector Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <button
          onClick={() => setActiveStageTab('all')}
          className={`p-4 rounded-xl border text-left transition flex items-center justify-between cursor-pointer ${
            activeStageTab === 'all'
              ? 'bg-emerald-900 text-white border-emerald-700 shadow-md ring-2 ring-emerald-500'
              : 'bg-white text-slate-800 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <div>
            <span className={`text-[11px] font-bold block ${activeStageTab === 'all' ? 'text-emerald-300' : 'text-slate-500'}`}>
              সকল অপেক্ষমাণ আবেদন
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black">{pendingList.length}</span>
              <span className="text-xs font-semibold">টি</span>
            </div>
          </div>
          <FileText className={`w-7 h-7 ${activeStageTab === 'all' ? 'text-amber-300' : 'text-slate-400'}`} />
        </button>

        <button
          onClick={() => setActiveStageTab('stage1_operator')}
          className={`p-4 rounded-xl border text-left transition flex items-center justify-between cursor-pointer ${
            activeStageTab === 'stage1_operator'
              ? 'bg-blue-900 text-white border-blue-700 shadow-md ring-2 ring-blue-500'
              : 'bg-white text-slate-800 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <div>
            <span className={`text-[11px] font-bold block ${activeStageTab === 'stage1_operator' ? 'text-blue-300' : 'text-blue-700'}`}>
              ১. সচিবের যাচাই প্রয়োজন
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-blue-900 dark:text-white">{stage1Count}</span>
              <span className="text-xs font-semibold text-blue-600">খসড়া জমা</span>
            </div>
          </div>
          <User className={`w-7 h-7 ${activeStageTab === 'stage1_operator' ? 'text-blue-300' : 'text-blue-500'}`} />
        </button>

        <button
          onClick={() => setActiveStageTab('stage2_secretary')}
          className={`p-4 rounded-xl border text-left transition flex items-center justify-between cursor-pointer ${
            activeStageTab === 'stage2_secretary'
              ? 'bg-amber-900 text-white border-amber-700 shadow-md ring-2 ring-amber-500'
              : 'bg-white text-slate-800 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <div>
            <span className={`text-[11px] font-bold block ${activeStageTab === 'stage2_secretary' ? 'text-amber-300' : 'text-amber-700'}`}>
              ২. সচিব কর্তৃক সুপারিশকৃত
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-amber-900 dark:text-white">{stage2Count}</span>
              <span className="text-xs font-semibold text-amber-600">অনুমোদন প্রস্তুত</span>
            </div>
          </div>
          <FileCheck2 className={`w-7 h-7 ${activeStageTab === 'stage2_secretary' ? 'text-amber-300' : 'text-amber-500'}`} />
        </button>

        <button
          onClick={() => setActiveStageTab('stage3_approved')}
          className={`p-4 rounded-xl border text-left transition flex items-center justify-between cursor-pointer ${
            activeStageTab === 'stage3_approved'
              ? 'bg-emerald-900 text-white border-emerald-700 shadow-md ring-2 ring-emerald-500'
              : 'bg-white text-slate-800 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <div>
            <span className={`text-[11px] font-bold block ${activeStageTab === 'stage3_approved' ? 'text-emerald-300' : 'text-emerald-700'}`}>
              ৩. আজকের অনুমোদিত
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-emerald-900 dark:text-white">{approvedTodayCount}</span>
              <span className="text-xs font-semibold text-emerald-600">টি ইস্যুকৃত</span>
            </div>
          </div>
          <ShieldCheck className={`w-7 h-7 ${activeStageTab === 'stage3_approved' ? 'text-emerald-300' : 'text-emerald-500'}`} />
        </button>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="নাম, স্মারক, NID, মোবাইল বা গ্রাম খুঁজুন..."
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-600 focus:outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Filters & Actions */}
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-end">
            <select
              value={selectedWard}
              onChange={e => setSelectedWard(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:bg-white focus:border-emerald-600 focus:outline-none"
            >
              <option value="সব ওয়ার্ড">সব ওয়ার্ড (১-৯)</option>
              {Array.from({ length: 9 }, (_, i) => (
                <option key={i + 1} value={`০${i + 1}`}>
                  ওয়ার্ড ০{i + 1}
                </option>
              ))}
            </select>

            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:bg-white focus:border-emerald-600 focus:outline-none max-w-[150px]"
            >
              {categoriesList.map(cat => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>

            <button
              onClick={fetchPendingList}
              disabled={loading}
              className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl border border-slate-300 transition cursor-pointer"
              title="রিফ্রেশ করুন"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-emerald-700' : ''}`} />
            </button>

            {pendingList.length > 0 && (
              <button
                onClick={() => handleBatchApprove()}
                disabled={loading}
                className="px-4 py-2 bg-emerald-900 hover:bg-emerald-950 text-amber-300 font-bold text-xs rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCheck className="w-4 h-4 text-amber-300" />
                <span>চেয়ারম্যান ব্যাচ অনুমোদন ({pendingList.length})</span>
              </button>
            )}
          </div>
        </div>

        {/* Quick Category Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] font-bold text-slate-500 mr-1">ফিল্টার:</span>
            {['সব ক্যাটাগরি', 'নাগরিকত্ব ও পরিচয়', 'উত্তরাধিকার ও পরিবার', 'অর্থনৈতিক ও পেশা'].map(pill => (
              <button
                key={pill}
                onClick={() => setSelectedCategory(pill)}
                className={`px-3 py-1 rounded-full text-[11px] font-bold transition cursor-pointer border ${
                  selectedCategory === pill
                    ? 'bg-emerald-900 text-amber-300 border-emerald-800 shadow-sm'
                    : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                }`}
              >
                {pill}
              </button>
            ))}
          </div>

          {isFilterActive && (
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-lg border border-emerald-200">
                ফলাফল: {filteredList.length} টি
              </span>
              <button
                onClick={resetFilters}
                className="text-[11px] text-rose-700 hover:text-rose-900 font-bold underline flex items-center gap-1 cursor-pointer"
              >
                <X className="w-3 h-3" />
                <span>রিসেট</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Certificate Cards Grid */}
      {loading ? (
        <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center space-y-3">
          <RefreshCw className="w-8 h-8 text-emerald-700 animate-spin mx-auto" />
          <p className="text-xs text-slate-600 font-bold">পেন্ডিং আবেদনসমূহ লোড হচ্ছে...</p>
        </div>
      ) : filteredList.length === 0 ? (
        <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center space-y-3">
          <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
          <h3 className="font-bold text-slate-900 text-sm">কোনো আবেদন অপেক্ষমাণ নেই!</h3>
          <p className="text-xs text-slate-500">
            নির্বাচিত ফিল্টারে কোনো অপেক্ষমাণ প্রত্যয়নপত্র পাওয়া যায় নাই।
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredList.map(item => {
            const isProcessing = processingId === item.id;
            const stage = getRecordStage(item);

            return (
              <div
                key={item.id}
                className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:shadow-md transition flex flex-col justify-between space-y-4 relative overflow-hidden"
              >
                {/* Stage Header Badge */}
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  {stage === 'secretary_verified' ? (
                    <span className="bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-black px-2.5 py-0.5 rounded-full flex items-center gap-1">
                      <FileCheck2 className="w-3 h-3 text-amber-700" />
                      <span>সচিব কর্তৃক সুপারিশকৃত</span>
                    </span>
                  ) : (
                    <span className="bg-blue-100 text-blue-900 border border-blue-300 text-[10px] font-black px-2.5 py-0.5 rounded-full flex items-center gap-1">
                      <Clock className="w-3 h-3 text-blue-700" />
                      <span>উদ্যোক্তা খসড়া (সচিব যাচাই অপেক্ষমাণ)</span>
                    </span>
                  )}

                  <span className="text-[11px] font-extrabold text-slate-500 font-mono">
                    {item.memoNo}
                  </span>
                </div>

                {/* Citizen Summary */}
                <div className="space-y-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                        <User className="w-4 h-4 text-emerald-700" />
                        <span>{item.citizen.name}</span>
                      </h4>
                      <p className="text-xs text-slate-500 mt-0.5">
                        পিতা/স্বামী: {item.citizen.father || item.citizen.spouseName || 'N/A'}
                      </p>
                    </div>

                    <span className="bg-emerald-900 text-white font-black text-[10px] px-2 py-0.5 rounded">
                      ওয়ার্ড {item.citizen.wardNo}
                    </span>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs space-y-1">
                    <p className="font-bold text-emerald-950 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-emerald-700" />
                      <span>{item.typeLabel}</span>
                    </p>
                    <p className="text-[11px] text-slate-600">
                      গ্রাম: {item.citizen.village}, ডাকঘর: {item.citizen.postOffice}
                    </p>
                    {item.citizen.nid && (
                      <p className="text-[10px] text-slate-500 font-mono">
                        NID: {item.citizen.nid}
                      </p>
                    )}
                  </div>

                  {/* Secretary verification notes if verified */}
                  {item.secretaryVerifiedBy && (
                    <div className="bg-amber-50/80 p-2 rounded-lg border border-amber-200 text-[11px] text-amber-900">
                      <span className="font-bold flex items-center gap-1">
                        <Check className="w-3 h-3 text-amber-700" />
                        সচিব সুপারিশ: {item.secretaryVerifiedBy}
                      </span>
                      <p className="text-[10px] text-amber-800 italic mt-0.5">
                        "{item.secretaryNotes || 'যাচাইপূর্বক সুপারিশকৃত'}"
                      </p>
                    </div>
                  )}
                </div>

                {/* Body Snippet */}
                <p className="text-[11px] text-slate-600 line-clamp-2 italic bg-slate-50 p-2 rounded border border-slate-200">
                  "{item.bodyText}"
                </p>

                {/* 3-Stage Specific Action Buttons */}
                <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-2">
                  {stage === 'operator_submitted' ? (
                    /* Stage 2 Action: Secretary Verify */
                    <button
                      onClick={() => {
                        setSecretaryVerifyCert(item);
                        setSecretaryNotesInput('এনআইডি ও তথ্যাদি সঠিকভাবে যাচাইপূর্বক অনুমোদনের জন্য সুপারিশ করা হইলো।');
                      }}
                      disabled={isProcessing}
                      className="flex-1 py-2 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl shadow transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <FileCheck2 className="w-3.5 h-3.5" />
                      <span>সচিব হিসেবে যাচাই</span>
                    </button>
                  ) : (
                    /* Stage 3 Action: Chairman Final Approve */
                    <button
                      onClick={() => handleApprove(item)}
                      disabled={isProcessing}
                      className="flex-1 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      {isProcessing ? (
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5 text-amber-300" />
                      )}
                      <span>চেয়ারম্যান অনুমোদন</span>
                    </button>
                  )}

                  {/* Citizen WhatsApp Link Button */}
                  {item.citizen.mobile && (
                    <button
                      onClick={() => sendWhatsAppNotification(item)}
                      className="p-2 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-xl border border-emerald-300 transition cursor-pointer"
                      title="নাগরিককে হোয়াটসঅ্যাপে বার্তা পাঠান"
                    >
                      <MessageSquareShare className="w-3.5 h-3.5" />
                    </button>
                  )}

                  <button
                    onClick={() => setRejectingCert(item)}
                    disabled={isProcessing}
                    className="p-2 bg-rose-100 hover:bg-rose-200 text-rose-800 border border-rose-300 rounded-xl transition cursor-pointer"
                    title="আবেদনটি বাতিল বা সংশোধনে ফেরত পাঠান"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => setPreviewCert(item)}
                    className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl border border-slate-300 transition cursor-pointer"
                    title="বিস্তারিত দেখুন"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* SECRETARY VERIFICATION MODAL */}
      {secretaryVerifyCert && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in duration-200 my-8">
            <div className="flex items-center justify-between border-b pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-100 text-blue-800 rounded-lg">
                  <FileCheck2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">সচিব যাচাই ও সুপারিশ ডেক্স</h3>
                  <span className="text-[11px] text-slate-500">ধাপ ২: নথি ও এনআইডি পরীক্ষা</span>
                </div>
              </div>
              <button
                onClick={() => setSecretaryVerifyCert(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 bg-slate-100 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-blue-50/60 p-3 rounded-xl border border-blue-200 text-xs space-y-1.5">
              <p className="font-bold text-slate-900">আবেদনকারী: {secretaryVerifyCert.citizen.name}</p>
              <p className="text-slate-600">সনদের ধরন: {secretaryVerifyCert.typeLabel}</p>
              <p className="text-slate-600">গ্রাম ও ওয়ার্ড: {secretaryVerifyCert.citizen.village}, ওয়ার্ড- {secretaryVerifyCert.citizen.wardNo}</p>
              <p className="text-slate-600 font-mono">NID: {secretaryVerifyCert.citizen.nid || 'N/A'}</p>
            </div>

            {/* Verification Checklist */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 block">যাচাইকরণ চেকলিস্ট:</label>
              <div className="space-y-1.5 text-xs bg-slate-50 p-3 rounded-xl border border-slate-200">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={checkNid}
                    onChange={e => setCheckNid(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>জাতীয় পরিচয়পত্র (NID) / জন্ম সনদ ডাটাবেসে সঠিক পাওয়া গেছে</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={checkWard}
                    onChange={e => setCheckWard(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>ওয়ার্ড মেম্বার / হোল্ডিং রেজিস্টারের সাথে তথ্যের মিল আছে</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={checkDoc}
                    onChange={e => setCheckDoc(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>সরকারি প্রত্যয়ন ফি পরিশোধিত এবং প্রয়োজনীয় সংযুক্তি সঠিক</span>
                </label>
              </div>
            </div>

            {/* Secretary Recommendation Notes */}
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                সচিবের মন্তব্য ও সুপারিশ (চেয়ারম্যানের জন্য):
              </label>
              <textarea
                value={secretaryNotesInput}
                onChange={e => setSecretaryNotesInput(e.target.value)}
                rows={2}
                className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-600 focus:outline-none"
              />
            </div>

            <div className="flex gap-3 pt-2 border-t">
              <button
                onClick={() => handleSecretaryVerify(secretaryVerifyCert)}
                disabled={processingId === secretaryVerifyCert.id || !checkNid || !checkWard}
                className="flex-1 py-2.5 bg-blue-800 hover:bg-blue-900 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <CheckCircle2 className="w-4 h-4 text-amber-300" />
                <span>যাচাই সম্পন্ন করে চেয়ারম্যানের কাছে প্রেরণ করুন</span>
              </button>
              <button
                onClick={() => setSecretaryVerifyCert(null)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FULL CERTIFICATE PREVIEW MODAL */}
      {previewCert && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-in fade-in zoom-in duration-200 my-8">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-3">
                <span className="bg-amber-100 text-amber-900 border border-amber-300 font-black text-xs px-2.5 py-1 rounded-lg">
                  স্মারক: {previewCert.memoNo}
                </span>
                <h3 className="font-bold text-base text-slate-900">{previewCert.typeLabel}</h3>
              </div>

              <button
                onClick={() => setPreviewCert(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 bg-slate-100 rounded-lg transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Citizen Info Grid */}
            <div className="grid grid-cols-2 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
              <div>
                <span className="text-slate-500 text-[10px] block">আবেদনকারীর নাম:</span>
                <span className="font-bold text-slate-900">{previewCert.citizen.name}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">পিতা/স্বামী:</span>
                <span className="font-bold text-slate-900">{previewCert.citizen.father || previewCert.citizen.spouseName || 'N/A'}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">মাতার নাম:</span>
                <span className="font-bold text-slate-900">{previewCert.citizen.mother}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">গ্রাম ও ওয়ার্ড:</span>
                <span className="font-bold text-slate-900">{previewCert.citizen.village}, ওয়ার্ড- {previewCert.citizen.wardNo}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">জাতীয় পরিচয়পত্র/জন্ম সনদ:</span>
                <span className="font-bold text-slate-900 font-mono">{previewCert.citizen.nid || previewCert.citizen.birthNo || 'N/A'}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">মোবাইল নম্বর:</span>
                <span className="font-bold text-slate-900 font-mono">{previewCert.citizen.mobile || 'N/A'}</span>
              </div>
            </div>

            {/* Official Generated Text Preview */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
                <span>দাপ্তরিক বক্তব্য (Body Text Preview):</span>
              </label>
              <div className="p-4 bg-emerald-50/50 rounded-xl border border-emerald-200 text-xs text-slate-800 leading-relaxed font-serif">
                {previewCert.bodyText}
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-3 border-t border-slate-200">
              <button
                onClick={() => {
                  handleApprove(previewCert);
                  setPreviewCert(null);
                }}
                className="flex-1 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-amber-300 font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4 text-amber-300" />
                <span>চেয়ারম্যান অনুমোদন প্রদান করুন</span>
              </button>

              <button
                onClick={() => {
                  setRejectingCert(previewCert);
                  setPreviewCert(null);
                }}
                className="px-4 py-2.5 bg-rose-100 hover:bg-rose-200 text-rose-800 border border-rose-300 font-bold text-xs rounded-xl transition cursor-pointer"
              >
                আবেদন বাতিল করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REJECTION REASON MODAL */}
      {rejectingCert && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-2 text-rose-900 border-b pb-3">
              <XCircle className="w-5 h-5 text-rose-600" />
              <h3 className="font-bold text-sm">আবেদন বাতিলের কারণ উল্লেখ করুন</h3>
            </div>

            <p className="text-xs text-slate-600">
              আবেদনকারী: <strong>{rejectingCert.citizen.name}</strong> ({rejectingCert.typeLabel})
            </p>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                বাতিলের কারণ:
              </label>
              <textarea
                value={rejectReasonInput}
                onChange={e => setRejectReasonInput(e.target.value)}
                rows={3}
                className="w-full p-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-rose-600 focus:outline-none"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={handleConfirmCancel}
                disabled={processingId === rejectingCert.id}
                className="flex-1 py-2.5 bg-rose-800 hover:bg-rose-900 text-white font-bold text-xs rounded-xl shadow transition"
              >
                বাতিল নিশ্চিত করুন
              </button>
              <button
                onClick={() => setRejectingCert(null)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
              >
                ফিরে যান
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BIOMETRIC AUTH MODAL FOR ONE-CLICK / BATCH APPROVAL */}
      <BiometricAuthModal
        isOpen={isBiometricModalOpen}
        onClose={() => {
          setIsBiometricModalOpen(false);
          setPendingBiometricTarget(null);
        }}
        onSuccess={biometricData => {
          setIsBiometricModalOpen(false);
          if (pendingBiometricTarget === 'ALL') {
            handleBatchApprove(biometricData);
          } else if (pendingBiometricTarget) {
            handleApprove(pendingBiometricTarget, biometricData);
          }
          setPendingBiometricTarget(null);
        }}
        actionName={
          pendingBiometricTarget === 'ALL'
            ? `সকল (${pendingList.length} টি) অপেক্ষমাণ আবেদন চূড়ান্ত অনুমোদন`
            : pendingBiometricTarget
            ? `সনদ নং ${pendingBiometricTarget.memoNo} অনুমোদন`
            : 'সনদ অনুমোদন'
        }
        officialRole="ইউপি চেয়ারম্যান"
      />
    </div>
  );
};
