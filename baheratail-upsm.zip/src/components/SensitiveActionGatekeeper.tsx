import React, { useState, useEffect, useCallback } from 'react';
import {
  Fingerprint,
  ShieldCheck,
  Key,
  ShieldAlert,
  Lock,
  Unlock,
  AlertCircle,
  CheckCircle2,
  X,
  UserCheck,
  Check,
  Cpu,
  Laptop,
  Smartphone,
  Sparkles
} from 'lucide-react';
import {
  isWebAuthnSupported,
  isPlatformBiometricAvailable,
  getWebAuthnDiagnostics,
  getStoredPasskeys,
  verifyWebAuthnPasskey,
  verifySecurityPin,
  getBiometricSessionElevation,
  setBiometricSessionElevation,
  clearBiometricSessionElevation,
  BiometricSessionState,
  WebAuthnDiagnostics
} from '../utils/webauthn';
import { AdminUserRecord } from '../types';
import { addAuditLogToFirebase } from '../firebase';

export interface SensitiveActionOptions {
  actionTitle: string;
  actionDetails?: string;
  actionType?: 'COUNCIL_MEMBERS_MODIFIED' | 'ADMIN_SETTINGS_MODIFIED' | 'BACKUP_RESTORE' | 'PERMISSIONS_MODIFIED' | 'CRITICAL_DELETE';
  impactDescription?: string;
}

interface SensitiveActionGatekeeperModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  options: SensitiveActionOptions;
  adminUser?: {
    name: string;
    email: string;
    role: string;
  } | null;
}

export const SensitiveActionGatekeeperModal: React.FC<SensitiveActionGatekeeperModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  options,
  adminUser
}) => {
  const [activeTab, setActiveTab] = useState<'biometric' | 'pin'>('biometric');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [diagnostics, setDiagnostics] = useState<WebAuthnDiagnostics | null>(null);
  const [pinInput, setPinInput] = useState<string>('');
  const [isVerifiedSuccess, setIsVerifiedSuccess] = useState<boolean>(false);

  const effectiveEmail = adminUser?.email || 'admin@boheratoil.gov.bd';
  const effectiveName = adminUser?.name || 'ইউপি কর্মকর্তা';
  const effectiveRole = adminUser?.role || 'super_admin';

  useEffect(() => {
    if (isOpen) {
      setIsVerifiedSuccess(false);
      setErrorMessage(null);
      setStatusMessage(null);
      setPinInput('');
      setActiveTab('biometric');

      getWebAuthnDiagnostics().then(diag => {
        setDiagnostics(diag);
        if (!diag.isPlatformAvailable) {
          const passkeys = getStoredPasskeys(effectiveEmail);
          if (passkeys.length === 0) {
            // Keep on biometric tab or offer pin as ready option
          }
        }
      });
    }
  }, [isOpen, effectiveEmail]);

  if (!isOpen) return null;

  // Handle WebAuthn Biometric Verification
  const handleBiometricVerify = async () => {
    setIsVerifying(true);
    setErrorMessage(null);
    setStatusMessage('আপনার ডিভাইসের বায়োমেট্রিক সেন্সর (Touch ID / Face ID / Windows Hello) স্পর্শ করুন...');

    try {
      const res = await verifyWebAuthnPasskey(effectiveEmail);
      if (res.success) {
        setIsVerifiedSuccess(true);
        setStatusMessage(res.message);

        // Elevate session
        setBiometricSessionElevation(effectiveEmail, res.authType, res.credentialId);

        // Write to Firebase Audit Log
        await addAuditLogToFirebase({
          action: 'CONFIG_UPDATED',
          actionTitle: `[WebAuthn Gatekeeper] ${options.actionTitle}`,
          details: `কর্মকর্তা ${effectiveName} (${effectiveEmail}) [${effectiveRole}] বায়োমেট্রিক প্যাসকি যাচাই সাপেক্ষে উচ্চ-নিরাপত্তা কার্যক্রম সফলভাবে অনুমোদন করিয়াছেন। বিবরণ: ${options.actionDetails || options.actionTitle}`,
          performedByEmail: effectiveEmail,
          performedByName: effectiveName,
          performedByRole: effectiveRole as any
        }).catch(() => {});

        setTimeout(() => {
          onSuccess();
          onClose();
        }, 800);
      } else {
        setErrorMessage(res.message);
      }
    } catch (err: any) {
      setErrorMessage(`বায়োমেট্রিক স্ক্যানকালে ত্রুটি: ${err.message || 'অজানা সমস্যা'}`);
    } finally {
      setIsVerifying(false);
    }
  };

  // Handle PIN verification fallback
  const handlePinVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (verifySecurityPin(pinInput)) {
      setIsVerifiedSuccess(true);
      setStatusMessage('✓ অফিশিয়াল মাস্টার সিকিউরিটি পিন যাচাই সফল হইয়াছে!');

      // Elevate session
      setBiometricSessionElevation(effectiveEmail, 'Master Security PIN');

      // Write to Firebase Audit Log
      await addAuditLogToFirebase({
        action: 'CONFIG_UPDATED',
        actionTitle: `[PIN Gatekeeper] ${options.actionTitle}`,
        details: `কর্মকর্তা ${effectiveName} (${effectiveEmail}) [${effectiveRole}] অফিশিয়াল মাস্টার পিন যাচাই সাপেক্ষে উচ্চ-নিরাপত্তা কার্যক্রম অনুমোদন করিয়াছেন। বিবরণ: ${options.actionDetails || options.actionTitle}`,
        performedByEmail: effectiveEmail,
        performedByName: effectiveName,
        performedByRole: effectiveRole as any
      }).catch(() => {});

      setTimeout(() => {
        onSuccess();
        onClose();
      }, 700);
    } else {
      setErrorMessage('⚠️ ভুল সিকিউরিটি পিন নম্বর প্রদান করা হয়েছে। সঠিক ৬-ডিজিটের মাস্টার পিন দিন।');
    }
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden space-y-0 relative">
        
        {/* Top Security Banner */}
        <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 text-white p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-48 h-48 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />

          <div className="flex items-start justify-between gap-4 relative z-10">
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-3 py-0.5 bg-amber-400/20 text-amber-300 border border-amber-400/40 rounded-full text-[11px] font-black uppercase tracking-wider">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-300" />
                <span>সংবেদনশীল প্রশাসনিক কার্যক্রম সুরক্ষক (Gatekeeper)</span>
              </div>
              <h3 className="text-lg font-black text-white tracking-tight">
                {options.actionTitle}
              </h3>
              <p className="text-xs text-emerald-200/90 leading-relaxed">
                উচ্চ-নিরাপত্তা নিশ্চিতকরণে আপনার ডিভাইসের বায়োমেট্রিক বা মাস্টার সিকিউরিটি পিন যাচাই করুন।
              </p>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-white/70 hover:text-white hover:bg-white/10 rounded-xl transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5">
          
          {/* Action Impact Warning Box */}
          <div className="p-4 bg-amber-50/80 border border-amber-200/90 rounded-2xl flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1 text-amber-900">
              <p className="font-extrabold text-amber-950">
                কার্যক্রম বিবরণ ও নিরাপত্তা প্রভাব:
              </p>
              <p className="text-amber-900/90 leading-relaxed font-medium">
                {options.actionDetails || 'এই সংবেদনশীল পরিবর্তনটি ইউনিয়ন পরিষদের অফিশিয়াল সিস্টেম কনফিগারেশন, ডাটাবেজ বা পরিষদ সদস্যদের তালিকায় সরাসরি প্রভাব ফেলবে।'}
              </p>
            </div>
          </div>

          {/* Official Officer Identity Card */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="p-2 bg-emerald-100 text-emerald-900 rounded-xl font-bold">
                <UserCheck className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <p className="font-extrabold text-slate-900 truncate">{effectiveName}</p>
                <p className="text-[11px] text-slate-500 truncate">{effectiveEmail}</p>
              </div>
            </div>
            <span className="px-2.5 py-1 bg-emerald-100 text-emerald-900 font-bold rounded-lg text-[10px] uppercase border border-emerald-300">
              {effectiveRole}
            </span>
          </div>

          {/* Verification Method Tabs */}
          <div className="flex rounded-xl bg-slate-100 p-1 border border-slate-200">
            <button
              type="button"
              onClick={() => { setActiveTab('biometric'); setErrorMessage(null); }}
              className={`flex-1 py-2 rounded-lg text-xs font-black transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'biometric'
                  ? 'bg-emerald-900 text-amber-300 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Fingerprint className="w-4 h-4" />
              <span>১. বায়োমেট্রিক প্যাসকি (WebAuthn)</span>
            </button>

            <button
              type="button"
              onClick={() => { setActiveTab('pin'); setErrorMessage(null); }}
              className={`flex-1 py-2 rounded-lg text-xs font-black transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'pin'
                  ? 'bg-slate-900 text-amber-300 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Key className="w-4 h-4" />
              <span>২. অফিশিয়াল মাস্টার পিন</span>
            </button>
          </div>

          {/* Feedback Status / Alerts */}
          {statusMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-2 animate-fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{statusMessage}</span>
            </div>
          )}

          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-900 rounded-xl text-xs font-bold flex items-center gap-2 animate-fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* TAB 1: BIOMETRIC SCAN */}
          {activeTab === 'biometric' && (
            <div className="space-y-4 text-center">
              <div className="p-5 bg-gradient-to-b from-slate-50 to-emerald-50/40 rounded-2xl border border-slate-200/80 space-y-3">
                <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto transition-all ${
                  isVerifiedSuccess
                    ? 'bg-emerald-100 border-4 border-emerald-500 text-emerald-700 shadow-lg'
                    : isVerifying
                    ? 'bg-amber-100 border-4 border-amber-500 text-amber-600 animate-pulse'
                    : 'bg-white border-2 border-slate-300 text-slate-700 hover:border-emerald-500 hover:text-emerald-700 shadow-sm'
                }`}>
                  {isVerifiedSuccess ? (
                    <Check className="w-10 h-10 stroke-[3]" />
                  ) : (
                    <Fingerprint className={`w-10 h-10 ${isVerifying ? 'animate-bounce' : ''}`} />
                  )}
                </div>

                <div className="space-y-1">
                  <p className="font-extrabold text-slate-900 text-xs">
                    {diagnostics?.recommendedMethod ? `${diagnostics.recommendedMethod} সেন্সরে স্পর্শ করুন` : 'ডিভাইস সেন্সরে স্পর্শ করুন'}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    {diagnostics?.hardwareDeviceName || 'Touch ID, Windows Hello, বা Android স্ক্রিনলক'}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleBiometricVerify}
                  disabled={isVerifying || isVerifiedSuccess}
                  className="w-full py-3 bg-emerald-900 hover:bg-emerald-800 text-amber-300 font-black text-xs rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 active:scale-95"
                >
                  <Fingerprint className="w-4 h-4 text-amber-300" />
                  <span>{isVerifying ? 'বায়োমেট্রিক স্ক্যান হচ্ছে...' : 'বায়োমেট্রিক স্ক্যান শুরু করুন'}</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: MASTER PIN */}
          {activeTab === 'pin' && (
            <form onSubmit={handlePinVerify} className="space-y-4">
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700">
                  অফিশিয়াল ৬-ডিজিটের মাস্টার সিকিউরিটি পিন নম্বর:
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="password"
                    maxLength={6}
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value)}
                    placeholder="যেমন: 786021"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono tracking-widest text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none"
                    autoFocus
                  />
                </div>
                <p className="text-[10px] text-slate-500">
                  ইউনিয়ন পরিষদ চেয়ারম্যান ও সচিবের জন্য নির্ধারিত অফিশিয়াল সিকিউরিটি পিন।
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  বাতিল
                </button>

                <button
                  type="submit"
                  disabled={!pinInput.trim() || isVerifiedSuccess}
                  className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 text-amber-300 font-black text-xs rounded-xl shadow transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Key className="w-4 h-4 text-amber-300" />
                  <span>পিন যাচাই ও অনুমোদন</span>
                </button>
              </div>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};

/**
 * Custom React Hook for easily guarding sensitive actions across components
 */
export function useSensitiveActionGatekeeper(adminUser?: { name: string; email: string; role: string } | null) {
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [currentOptions, setCurrentOptions] = useState<SensitiveActionOptions>({
    actionTitle: 'সংবেদনশীল কার্যক্রম অনুমোদন'
  });
  const [pendingAction, setPendingAction] = useState<(() => Promise<void> | void) | null>(null);

  const executeWithGatekeeper = useCallback((
    actionFn: () => Promise<void> | void,
    options: SensitiveActionOptions
  ) => {
    // 1. Check if user already has an active biometric session elevation
    const elevation = getBiometricSessionElevation();
    if (elevation?.isElevated) {
      // Already elevated, run immediately!
      actionFn();
      return;
    }

    // 2. Not elevated, trigger the WebAuthn Gatekeeper Modal
    setCurrentOptions(options);
    setPendingAction(() => actionFn);
    setIsModalOpen(true);
  }, []);

  const handleSuccess = useCallback(() => {
    if (pendingAction) {
      pendingAction();
      setPendingAction(null);
    }
  }, [pendingAction]);

  const handleClose = useCallback(() => {
    setIsModalOpen(false);
    setPendingAction(null);
  }, []);

  const GatekeeperModal = (
    <SensitiveActionGatekeeperModal
      isOpen={isModalOpen}
      onClose={handleClose}
      onSuccess={handleSuccess}
      options={currentOptions}
      adminUser={adminUser}
    />
  );

  return {
    executeWithGatekeeper,
    GatekeeperModal,
    isElevated: !!getBiometricSessionElevation()?.isElevated,
    clearElevation: clearBiometricSessionElevation
  };
}
