import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Smartphone,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Clock,
  RefreshCw,
  MessageSquare,
  Lock,
  ArrowRight,
  ExternalLink,
  Check,
  User,
  PhoneCall,
  Sparkles,
  ArrowLeft
} from 'lucide-react';
import { whatsappAuthService } from '../services/whatsappAuthService';
import { WhatsAppVerifyResponse } from '../types';

export interface VerifyOTPProps {
  /**
   * Pre-filled phone number (optional). If provided, can auto-send or jump directly to OTP code entry.
   */
  initialPhoneNumber?: string;
  /**
   * Pre-generated OTP token if OTP was already sent by a parent component.
   */
  initialOtpToken?: string;
  /**
   * Role hint for validation ('citizen' | 'staff' | 'auto')
   */
  roleHint?: 'citizen' | 'staff' | 'auto';
  /**
   * Callback fired when OTP is successfully verified and session is validated.
   */
  onSuccess?: (user: WhatsAppVerifyResponse['user'], token?: string) => void;
  /**
   * Callback fired if user clicks Cancel or Close.
   */
  onCancel?: () => void;
  /**
   * Callback fired if user wants to change their phone number or go back.
   */
  onBack?: () => void;
  /**
   * Custom title heading for the component.
   */
  title?: string;
  /**
   * Custom subtitle description for the component.
   */
  subtitle?: string;
  /**
   * Compact layout mode for embedding inside compact sidebars or modals.
   */
  compact?: boolean;
  /**
   * Automatically send OTP on mount if valid phone number is provided.
   */
  autoSendOtp?: boolean;
  /**
   * Show or hide the Twilio WhatsApp Gateway connection badge.
   */
  showGatewayBadge?: boolean;
}

export const VerifyOTP: React.FC<VerifyOTPProps> = ({
  initialPhoneNumber = '',
  initialOtpToken = '',
  roleHint = 'auto' as 'citizen' | 'staff' | 'auto',
  onSuccess,
  onCancel,
  onBack,
  title,
  subtitle,
  compact = false,
  autoSendOtp = false,
  showGatewayBadge = true
}) => {
  // Navigation & Step State
  const [step, setStep] = useState<'phone' | 'otp' | 'success'>(
    initialOtpToken && initialPhoneNumber ? 'otp' : (initialPhoneNumber && autoSendOtp ? 'phone' : (initialPhoneNumber ? 'otp' : 'phone'))
  );

  // Phone and OTP state
  const [phoneNumber, setPhoneNumber] = useState(initialPhoneNumber);
  const [otpToken, setOtpToken] = useState(initialOtpToken);
  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [countdown, setCountdown] = useState(60);
  const [canResend, setCanResend] = useState(false);
  const [devOtp, setDevOtp] = useState<string | undefined>();
  const [directWaUrl, setDirectWaUrl] = useState<string | undefined>();
  const [verifiedUser, setVerifiedUser] = useState<WhatsAppVerifyResponse['user'] | null>(null);

  // Twilio Gateway status state
  const [twilioStatus, setTwilioStatus] = useState<{
    isConfigured: boolean;
    provider: string;
    senderNumber: string;
    accountSidMasked?: string;
  } | null>(null);

  // Input refs for 6 OTP boxes
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // 1. Fetch Twilio WhatsApp Business Gateway Status
  useEffect(() => {
    let isMounted = true;
    fetch('/api/messaging/whatsapp/status')
      .then(res => res.json())
      .then(data => {
        if (isMounted) {
          setTwilioStatus({
            isConfigured: data.isConfigured,
            provider: data.provider,
            senderNumber: data.senderNumber,
            accountSidMasked: data.accountSidMasked
          });
        }
      })
      .catch(() => {
        if (isMounted) {
          setTwilioStatus({
            isConfigured: false,
            provider: 'simulation',
            senderNumber: 'whatsapp:+14155238886'
          });
        }
      });

    return () => {
      isMounted = false;
    };
  }, []);

  // 2. Countdown timer for Resend OTP
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (step === 'otp' && countdown > 0) {
      timer = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            setCanResend(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [step, countdown]);

  // 3. Handle Auto Send OTP if requested
  useEffect(() => {
    if (autoSendOtp && initialPhoneNumber && !initialOtpToken && step === 'phone') {
      handleSendOtp();
    }
  }, []);

  // Helper to focus on first OTP box
  const focusFirstOtpBox = () => {
    setTimeout(() => {
      inputRefs.current[0]?.focus();
    }, 150);
  };

  // 4. Request / Send OTP via Twilio WhatsApp Gateway
  const handleSendOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    const { isValid, formatted } = whatsappAuthService.formatBangladeshiPhone(phoneNumber);
    if (!isValid) {
      setErrorMessage('সঠিক ১১ ডিজিটের বাংলাদেশী মোবাইল নম্বর লিখুন (যেমন: 017XXXXXXXX)');
      return;
    }

    setIsLoading(true);
    try {
      const res = await whatsappAuthService.sendOtp(phoneNumber, roleHint);
      if (res.success && res.token) {
        setOtpToken(res.token);
        setDirectWaUrl(res.directWaUrl);
        setDevOtp(res.devOtp);
        setStep('otp');
        setCountdown(res.expiresInSeconds || 60);
        setCanResend(false);
        setOtpDigits(['', '', '', '', '', '']);
        setSuccessMessage(res.message || 'আপনার হোয়াটসঅ্যাপে ৬ ডিজিটের ওটিপি পাঠানো হয়েছে।');
        focusFirstOtpBox();
      } else {
        setErrorMessage(res.message || 'ওটিপি প্রেরণে ত্রুটি হয়েছে। পুনরায় চেষ্টা করুন।');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'নেটওয়ার্ক সংযোগে সমস্যা হয়েছে।');
    } finally {
      setIsLoading(false);
    }
  };

  // 5. Verify OTP against backend API & Validate Session
  const handleVerifyOtp = useCallback(async (codeToVerify?: string) => {
    const finalCode = codeToVerify || otpDigits.join('');
    if (finalCode.length !== 6) {
      setErrorMessage('অনুগ্রহ করে সম্পূর্ণ ৬ ডিজিটের ওটিপি কোড লিখুন।');
      return;
    }

    setErrorMessage('');
    setIsLoading(true);

    try {
      const res = await whatsappAuthService.verifyOtp(phoneNumber, finalCode, otpToken);
      if (res.success && res.user) {
        setVerifiedUser(res.user);
        setStep('success');
        setSuccessMessage(res.message || 'সফলভাবে যাচাইকরণ সম্পন্ন হয়েছে!');
        
        // Notify parent callback
        if (onSuccess) {
          onSuccess(res.user, res.token);
        }
      } else {
        setErrorMessage(res.message || 'ভুল ওটিপি কোড অথবা মেয়াদ শেষ। পুনরায় চেষ্টা করুন।');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'যাচাইকরণ প্রক্রিয়া সম্পন্ন করা যায়নি।');
    } finally {
      setIsLoading(false);
    }
  }, [otpDigits, phoneNumber, otpToken, onSuccess]);

  // 6. Handle single digit change
  const handleDigitChange = (index: number, value: string) => {
    const cleanVal = whatsappAuthService.convertBanglaToEnglishDigits(value).replace(/\D/g, '').slice(-1);
    const newDigits = [...otpDigits];
    newDigits[index] = cleanVal;
    setOtpDigits(newDigits);

    // Auto advance to next box
    if (cleanVal && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    // Auto submit if all 6 digits are provided
    if (cleanVal && newDigits.every(d => d !== '')) {
      handleVerifyOtp(newDigits.join(''));
    }
  };

  // 7. Handle backspace navigation
  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    } else if (e.key === 'ArrowLeft' && index > 0) {
      inputRefs.current[index - 1]?.focus();
    } else if (e.key === 'ArrowRight' && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  // 8. Handle paste event (6 digits)
  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pastedText = e.clipboardData.getData('text');
    const cleanDigits = whatsappAuthService.convertBanglaToEnglishDigits(pastedText).replace(/\D/g, '').slice(0, 6);
    
    if (cleanDigits) {
      const newDigits = [...otpDigits];
      cleanDigits.split('').forEach((digit, i) => {
        if (i < 6) newDigits[i] = digit;
      });
      setOtpDigits(newDigits);

      if (cleanDigits.length === 6) {
        handleVerifyOtp(cleanDigits);
      } else {
        inputRefs.current[Math.min(cleanDigits.length, 5)]?.focus();
      }
    }
  };

  // Format phone display
  const phoneDisplayInfo = whatsappAuthService.formatBangladeshiPhone(phoneNumber);

  return (
    <div id="verify-otp-component" className={`w-full bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden ${compact ? 'p-4' : 'p-6 sm:p-7'}`}>
      {/* Header Section */}
      <div className="flex items-start justify-between gap-3 mb-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100/80 border border-emerald-200 flex items-center justify-center text-emerald-700 shadow-sm shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-base sm:text-lg leading-tight">
              {title || (step === 'phone' ? 'হোয়াটসঅ্যাপ ওটিপি যাচাইকরণ' : step === 'otp' ? '৬-ডিজিটের ওটিপি প্রবেশ করান' : 'যাচাইকরণ সম্পন্ন')}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {subtitle || (step === 'phone' ? 'আপনার নিবন্ধিত নম্বরে নিরাপত্তা ওটিপি কোড পাঠানো হবে' : `কোডটি ${phoneDisplayInfo.display || phoneNumber} নম্বরে পাঠানো হয়েছে`)}
            </p>
          </div>
        </div>

        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="text-xs font-semibold text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
            title="বাতিল করুন"
          >
            ✕
          </button>
        )}
      </div>

      {/* Twilio WhatsApp Gateway Status Badge */}
      {showGatewayBadge && (
        <div className="flex items-center justify-between px-3 py-2 bg-emerald-50/70 border border-emerald-200/80 rounded-xl text-[11px] mb-5">
          <div className="flex items-center gap-2 font-medium text-emerald-950">
            <span className={`w-2 h-2 rounded-full ${twilioStatus?.isConfigured ? 'bg-emerald-600 animate-ping' : 'bg-emerald-500'}`} />
            <span>Twilio WhatsApp Business Gateway:</span>
          </div>
          <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${twilioStatus?.isConfigured ? 'bg-emerald-200 text-emerald-900' : 'bg-emerald-100 text-emerald-800'}`}>
            {twilioStatus?.isConfigured ? 'সক্রিয় (Live Twilio Gateway)' : 'ক্লাউড ইন্টিগ্রেটেড'}
          </span>
        </div>
      )}

      {/* Messages */}
      {errorMessage && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-start gap-2 mb-4 animate-in fade-in">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
          <span className="leading-relaxed font-medium">{errorMessage}</span>
        </div>
      )}

      {successMessage && step !== 'success' && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-start gap-2 mb-4 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
          <span className="leading-relaxed font-medium">{successMessage}</span>
        </div>
      )}

      {/* ================= STEP 1: Phone Number Input ================= */}
      {step === 'phone' && (
        <form onSubmit={handleSendOtp} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              আপনার হোয়াটসঅ্যাপ বা মোবাইল নম্বর:
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs">
                🇧🇩 +88
              </span>
              <input
                id="otp-phone-input"
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="01XXXXXXXXX"
                required
                disabled={isLoading}
                className="w-full pl-16 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-mono text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all"
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              উদাহরণ: 01712345678 (বাংলা বা ইংরেজি উভয় সংখ্যা সমর্থন করে)
            </p>
          </div>

          <button
            id="btn-send-otp"
            type="submit"
            disabled={isLoading || !phoneNumber.trim()}
            className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>ওটিপি কোড পাঠানো হচ্ছে...</span>
              </>
            ) : (
              <>
                <MessageSquare className="w-4 h-4" />
                <span>হোয়াটসঅ্যাপে ওটিপি কোড পাঠান</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </>
            )}
          </button>
        </form>
      )}

      {/* ================= STEP 2: 6-Digit OTP Verification ================= */}
      {step === 'otp' && (
        <div className="space-y-5">
          {/* Target Phone info bar */}
          <div className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs">
            <div className="flex items-center gap-2 text-slate-700">
              <Smartphone className="w-4 h-4 text-emerald-600" />
              <span className="font-mono font-bold text-slate-900">
                {phoneDisplayInfo.display || phoneNumber}
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                if (onBack) {
                  onBack();
                } else {
                  setStep('phone');
                  setOtpDigits(['', '', '', '', '', '']);
                }
              }}
              className="text-[11px] text-emerald-700 hover:text-emerald-800 font-bold hover:underline flex items-center gap-1"
            >
              <ArrowLeft className="w-3 h-3" />
              <span>নম্বর পরিবর্তন</span>
            </button>
          </div>

          {/* 6 Digit Input Cells */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-700">
                হোয়াটসঅ্যাপ থেকে ৬ ডিজিটের কোডটি লিখুন:
              </label>
              <span className="text-[11px] text-slate-400 font-medium">
                অটো-সাবমিট সক্রিয়
              </span>
            </div>

            <div className="grid grid-cols-6 gap-2 sm:gap-3" onPaste={handlePaste}>
              {otpDigits.map((digit, idx) => (
                <input
                  key={idx}
                  ref={(el) => (inputRefs.current[idx] = el)}
                  id={`otp-box-${idx}`}
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleDigitChange(idx, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(idx, e)}
                  disabled={isLoading}
                  autoComplete="one-time-code"
                  className={`w-full h-12 sm:h-14 text-center font-bold text-lg sm:text-xl rounded-xl border transition-all focus:outline-none focus:ring-2 ${
                    digit
                      ? 'bg-emerald-50/70 border-emerald-500 text-emerald-950 ring-emerald-500/20'
                      : 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-emerald-500 focus:ring-emerald-500/30'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Direct WhatsApp open link button if available */}
          {directWaUrl && (
            <div className="p-3 bg-emerald-50/90 border border-emerald-200 rounded-xl flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="text-[11px] text-emerald-950 font-medium">
                  ওটিপি মেসেজ পাননি? সরাসরি হোয়াটসঅ্যাপে দেখতে:
                </span>
              </div>
              <a
                href={directWaUrl}
                target="_blank"
                rel="noreferrer"
                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-bold shrink-0 flex items-center gap-1 shadow-sm transition-all"
              >
                <span>WhatsApp খুলুন</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          )}

          {/* Verify Button */}
          <button
            id="btn-verify-otp"
            type="button"
            onClick={() => handleVerifyOtp()}
            disabled={isLoading || otpDigits.some((d) => d === '')}
            className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>যাচাইকরণ চলছে...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>ওটিপি কোড যাচাই ও লগইন করুন</span>
              </>
            )}
          </button>

          {/* Resend OTP Timer & Trigger */}
          <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100 text-slate-500">
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              {countdown > 0 ? (
                <span>পুনরায় পাঠানো যাবে: <strong>{countdown} সেকেন্ড</strong> পর</span>
              ) : (
                <span className="text-emerald-700 font-bold">এখন কোড পুনরায় পাঠানো যাবে</span>
              )}
            </div>

            <button
              type="button"
              onClick={() => handleSendOtp()}
              disabled={!canResend || isLoading}
              className="font-bold text-emerald-700 hover:text-emerald-900 disabled:text-slate-300 disabled:cursor-not-allowed transition-colors"
            >
              পুনরায় পাঠান
            </button>
          </div>
        </div>
      )}

      {/* ================= STEP 3: Verification Success ================= */}
      {step === 'success' && (
        <div className="text-center py-4 space-y-4 animate-in fade-in zoom-in-95">
          <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div>
            <h4 className="font-bold text-slate-900 text-base">
              যাচাইকরণ সফল হয়েছে!
            </h4>
            <p className="text-xs text-slate-500 mt-1">
              আপনার সেশনটি সুরক্ষিতভাবে সংযুক্ত ও অনুমোদিত হয়েছে।
            </p>
          </div>

          {verifiedUser && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-left text-xs space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">নাম:</span>
                <span className="font-bold text-slate-900">{verifiedUser.name}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">পদবি/ভূমিকা:</span>
                <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100">
                  {verifiedUser.designation || verifiedUser.role}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">মোবাইল:</span>
                <span className="font-mono text-slate-700">{verifiedUser.phone}</span>
              </div>
            </div>
          )}

          <div className="flex items-center justify-center gap-2 pt-2">
            <div className="flex items-center gap-1 text-[11px] text-emerald-700 font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>ডিজিটাল ইউনিয়ন পরিষদে স্বাগতম</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
