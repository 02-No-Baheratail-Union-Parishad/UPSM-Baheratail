import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  MessageSquare, 
  Smartphone, 
  Send, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  RefreshCw, 
  QrCode, 
  ShieldCheck, 
  User, 
  ExternalLink, 
  Lock, 
  Check, 
  ArrowRight,
  LogOut,
  Sparkles,
  PhoneCall
} from 'lucide-react';
import { whatsappAuthService } from '../services/whatsappAuthService';
import { WhatsAppVerifyResponse, WhatsAppInstantSession } from '../types';

interface WhatsAppAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (user: WhatsAppVerifyResponse['user']) => void;
  initialRoleHint?: 'citizen' | 'staff' | 'auto';
}

export const WhatsAppAuthModal: React.FC<WhatsAppAuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialRoleHint = 'auto'
}) => {
  const [authMode, setAuthMode] = useState<'otp' | 'qr'>('otp');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [roleHint, setRoleHint] = useState<'citizen' | 'staff' | 'auto'>(initialRoleHint);
  
  // OTP State
  const [step, setStep] = useState<'phone' | 'otp' | 'success'>('phone');
  const [isLoading, setIsLoading] = useState(false);
  const [otpToken, setOtpToken] = useState('');
  const [otpCode, setOtpCode] = useState(['', '', '', '', '', '']);
  const [countdown, setCountdown] = useState(60);
  const [canResend, setCanResend] = useState(false);
  const [devOtp, setDevOtp] = useState<string | undefined>();
  const [directWaUrl, setDirectWaUrl] = useState<string | undefined>();
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [currentUser, setCurrentUser] = useState<WhatsAppVerifyResponse['user'] | null>(null);
  const [twilioStatus, setTwilioStatus] = useState<{ isConfigured: boolean; provider: string; senderNumber: string } | null>(null);

  // QR / Instant Session State
  const [instantSession, setInstantSession] = useState<WhatsAppInstantSession | null>(null);
  const [isQrLoading, setIsQrLoading] = useState(false);
  const pollingRef = useRef<NodeJS.Timeout | null>(null);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (isOpen) {
      const active = whatsappAuthService.getActiveUser();
      if (active) {
        setCurrentUser(active);
        setStep('success');
      } else {
        setStep('phone');
        setErrorMessage('');
        setSuccessMessage('');
      }
    } else {
      if (pollingRef.current) {
        clearInterval(pollingRef.current);
      }
    }
  }, [isOpen]);

  // Fetch Twilio WhatsApp Business Gateway status
  useEffect(() => {
    if (isOpen) {
      fetch('/api/messaging/whatsapp/status')
        .then(res => res.json())
        .then(data => {
          setTwilioStatus({
            isConfigured: data.isConfigured,
            provider: data.provider,
            senderNumber: data.senderNumber
          });
        })
        .catch(() => {});
    }
  }, [isOpen]);

  // Resend Countdown Timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (step === 'otp' && countdown > 0) {
      timer = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            setCanResend(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [step, countdown]);

  // QR Session Polling
  useEffect(() => {
    if (authMode === 'qr' && instantSession && instantSession.status === 'pending') {
      pollingRef.current = setInterval(async () => {
        const res = await whatsappAuthService.checkInstantSession(instantSession.sessionId);
        if (res.success && res.status === 'verified' && res.user) {
          if (pollingRef.current) clearInterval(pollingRef.current);
          setCurrentUser(res.user);
          setStep('success');
          if (onSuccess) onSuccess(res.user);
        }
      }, 2500);
    }

    return () => {
      if (pollingRef.current) clearInterval(pollingRef.current);
    };
  }, [authMode, instantSession]);

  if (!isOpen) return null;

  // Handle Send OTP
  const handleSendOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    const { isValid, formatted } = whatsappAuthService.formatBangladeshiPhone(phoneNumber);
    if (!isValid) {
      setErrorMessage('সঠিক ১১ ডিজিটের বাংলাদেশী মোবাইল নম্বর লিখুন (যেমন: 017XXXXXXXX)');
      return;
    }

    setIsLoading(true);
    try {
      const res = await whatsappAuthService.sendOtp(phoneNumber, roleHint);
      if (res.success && res.token) {
        setOtpToken(res.token);
        setDirectWaUrl(res.directWaUrl);
        setDevOtp(res.devOtp);
        setStep('otp');
        setCountdown(60);
        setCanResend(false);
        setOtpCode(['', '', '', '', '', '']);
        setSuccessMessage(res.message);
        setTimeout(() => {
          inputRefs.current[0]?.focus();
        }, 100);
      } else {
        setErrorMessage(res.message || 'ওটিপি প্রেরণ ব্যর্থ হয়েছে।');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'নেটওয়ার্ক সংযোগে সমস্যা।');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle OTP Input Change
  const handleOtpDigitChange = (index: number, value: string) => {
    const cleanVal = whatsappAuthService.convertBanglaToEnglishDigits(value).replace(/\D/g, '').slice(-1);
    const newCode = [...otpCode];
    newCode[index] = cleanVal;
    setOtpCode(newCode);

    // Auto move to next input
    if (cleanVal && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    // Auto submit if all 6 digits entered
    if (newCode.every(d => d !== '') && cleanVal) {
      verifyOtpCode(newCode.join(''));
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpCode[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleOtpPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pasted = whatsappAuthService.convertBanglaToEnglishDigits(e.clipboardData.getData('text')).replace(/\D/g, '').slice(0, 6);
    if (pasted) {
      const digits = pasted.split('');
      const newCode = [...otpCode];
      digits.forEach((d, idx) => {
        if (idx < 6) newCode[idx] = d;
      });
      setOtpCode(newCode);
      if (pasted.length === 6) {
        verifyOtpCode(pasted);
      } else {
        inputRefs.current[Math.min(pasted.length, 5)]?.focus();
      }
    }
  };

  // Verify OTP
  const verifyOtpCode = async (codeToVerify?: string) => {
    const finalCode = codeToVerify || otpCode.join('');
    if (finalCode.length !== 6) {
      setErrorMessage('সম্পূর্ণ ৬ ডিজিটের ওটিপি কোড প্রবেশ করান।');
      return;
    }

    setErrorMessage('');
    setIsLoading(true);
    try {
      const res = await whatsappAuthService.verifyOtp(phoneNumber, finalCode, otpToken);
      if (res.success && res.user) {
        setCurrentUser(res.user);
        setStep('success');
        if (onSuccess) onSuccess(res.user);
      } else {
        setErrorMessage(res.message || 'ভুল ওটিপি কোড। পুনরায় চেষ্টা করুন।');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'যাচাইকরণ ব্যর্থ হয়েছে।');
    } finally {
      setIsLoading(false);
    }
  };

  // Create Instant QR
  const handleLoadInstantQr = async () => {
    setIsQrLoading(true);
    setErrorMessage('');
    try {
      const res = await whatsappAuthService.createInstantSession();
      if (res.success && res.session) {
        setInstantSession(res.session);
      } else {
        setErrorMessage(res.message || 'কিউআর কোড তৈরি করা যায়নি।');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'নেটওয়ার্ক সমস্যা।');
    } finally {
      setIsQrLoading(false);
    }
  };

  // Handle Logout
  const handleLogout = () => {
    whatsappAuthService.logout();
    setCurrentUser(null);
    setStep('phone');
    setOtpToken('');
    setOtpCode(['', '', '', '', '', '']);
    setPhoneNumber('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden relative flex flex-col max-h-[90vh]">
        
        {/* Header with WhatsApp Green Accent */}
        <div className="bg-gradient-to-r from-emerald-600 via-emerald-700 to-teal-800 text-white p-5 relative shrink-0">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 border border-white/30 flex items-center justify-center shadow-inner shrink-0">
              <MessageSquare className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black tracking-tight">হোয়াটসঅ্যাপ লগইন ও ওটিপি</h2>
                <span className="bg-emerald-400/30 text-emerald-100 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-300/40">
                  Live
                </span>
              </div>
              <p className="text-xs text-emerald-100/90 font-medium">
                ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল সেবা
              </p>
            </div>
          </div>

          {/* Mode Switcher Tabs */}
          {step !== 'success' && (
            <div className="flex items-center gap-1 bg-black/20 p-1 rounded-xl mt-4 text-xs font-bold">
              <button
                type="button"
                onClick={() => setAuthMode('otp')}
                className={`flex-1 py-1.5 px-3 rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  authMode === 'otp' ? 'bg-white text-emerald-900 shadow' : 'text-emerald-100 hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>ওটিপি এসএমএস কোড</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthMode('qr');
                  if (!instantSession) handleLoadInstantQr();
                }}
                className={`flex-1 py-1.5 px-3 rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  authMode === 'qr' ? 'bg-white text-emerald-900 shadow' : 'text-emerald-100 hover:text-white'
                }`}
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>১-ক্লিক QR কোড</span>
              </button>
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4">
          
          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-2.5 text-rose-800 text-xs animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              <div className="flex-1 font-medium">{errorMessage}</div>
            </div>
          )}

          {/* Success Banner */}
          {successMessage && step === 'otp' && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-start gap-2.5 text-emerald-800 text-xs">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
              <div className="flex-1 font-medium">{successMessage}</div>
            </div>
          )}

          {/* ================= STEP 1: Phone Input (OTP Mode) ================= */}
          {authMode === 'otp' && step === 'phone' && (
            <form onSubmit={handleSendOtp} className="space-y-4">
              {/* Twilio WhatsApp Business API Gateway Badge */}
              <div className="flex items-center justify-between p-2.5 bg-emerald-50/80 border border-emerald-200/80 rounded-xl text-[11px]">
                <div className="flex items-center gap-1.5 font-bold text-emerald-950">
                  <span className={`w-2 h-2 rounded-full ${twilioStatus?.isConfigured ? 'bg-emerald-600 animate-ping' : 'bg-emerald-500'}`} />
                  <span>Twilio WhatsApp Business Gateway:</span>
                </div>
                <span className={`px-2 py-0.5 rounded-full font-extrabold text-[10px] ${twilioStatus?.isConfigured ? 'bg-emerald-200 text-emerald-900' : 'bg-emerald-100 text-emerald-800'}`}>
                  {twilioStatus?.isConfigured ? 'সক্রিয় (Live Twilio OTP)' : 'ক্লাউড ইন্টিগ্রেটেড'}
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  আপনার হোয়াটসঅ্যাপ বা মোবাইল নম্বর দিন:
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 text-xs font-bold">
                    🇧🇩 +880
                  </div>
                  <input
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="01XXXXXXXXX"
                    className="w-full pl-20 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold text-slate-800 focus:bg-white focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 transition outline-none"
                    autoFocus
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  এই নম্বরে সরাসরি হোয়াটসঅ্যাপে ৬ ডিজিটের একটি নিরাপত্তা ওটিপি কোড পাঠানো হবে।
                </p>

                {/* Quick Number Selector Chips */}
                <div className="space-y-1.5 pt-2">
                  <span className="text-[11px] font-bold text-slate-500 block">
                    দ্রুত টেস্ট ও কর্মকর্তা/ডেভেলপার নম্বর নির্বাচন:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setPhoneNumber('01834333300');
                        setRoleHint('staff');
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition flex items-center gap-1 border cursor-pointer ${
                        phoneNumber === '01834333300'
                          ? 'bg-amber-100 text-amber-900 border-amber-400 shadow-xs'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                      }`}
                    >
                      <span>👨‍💻 ডেভেলপার (01834333300)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPhoneNumber('01712345678');
                        setRoleHint('staff');
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition flex items-center gap-1 border cursor-pointer ${
                        phoneNumber === '01712345678'
                          ? 'bg-emerald-100 text-emerald-900 border-emerald-400 shadow-xs'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                      }`}
                    >
                      <span>🏛️ চেয়ারম্যান (01712345678)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPhoneNumber('01711122233');
                        setRoleHint('staff');
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition flex items-center gap-1 border cursor-pointer ${
                        phoneNumber === '01711122233'
                          ? 'bg-emerald-100 text-emerald-900 border-emerald-400 shadow-xs'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                      }`}
                    >
                      <span>📋 সচিব (01711122233)</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Role Selection Hint */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <span className="text-[11px] font-bold text-slate-600 block">
                  অ্যাক্সেস ক্যাটাগরি:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRoleHint('citizen')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer border ${
                      roleHint === 'citizen'
                        ? 'bg-emerald-100 text-emerald-900 border-emerald-400 shadow-sm'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <User className="w-3.5 h-3.5 text-emerald-700" />
                    <span>নাগরিক সেবা</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRoleHint('staff')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer border ${
                      roleHint === 'staff'
                        ? 'bg-emerald-100 text-emerald-900 border-emerald-400 shadow-sm'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                    <span>ইউপি স্টাফ / এডমিন</span>
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading || !phoneNumber.trim()}
                className="w-full py-3.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm rounded-2xl shadow-lg hover:shadow-emerald-900/20 transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 active:scale-98"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>ওটিপি পাঠানো হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>হোয়াটসঅ্যাপ ওটিপি কোড পাঠান</span>
                  </>
                )}
              </button>

              <div className="pt-2 text-[11px] text-slate-400 flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>এন্ড-টু-এন্ড এনক্রিপ্টেড নিরাপদ প্রমাণীকরণ</span>
              </div>
            </form>
          )}

          {/* ================= STEP 2: OTP Entry (OTP Mode) ================= */}
          {authMode === 'otp' && step === 'otp' && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <p className="text-xs text-slate-600">
                  <strong className="text-slate-900">{phoneNumber}</strong> নম্বরে প্রেরিত ৬ ডিজিটের কোডটি লিখুন:
                </p>
                <button
                  type="button"
                  onClick={() => setStep('phone')}
                  className="text-xs text-emerald-700 hover:underline font-bold"
                >
                  নম্বর পরিবর্তন করুন
                </button>
              </div>

              {/* 6 Digit Input Boxes */}
              <div className="flex items-center justify-center gap-2 py-2" onPaste={handleOtpPaste}>
                {otpCode.map((digit, idx) => (
                  <input
                    key={idx}
                    ref={(el) => (inputRefs.current[idx] = el)}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpDigitChange(idx, e.target.value)}
                    onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                    className="w-11 h-12 text-center text-xl font-black bg-slate-50 border-2 border-slate-200 rounded-xl focus:border-emerald-600 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 outline-none transition"
                  />
                ))}
              </div>

              {/* Dev / Preview OTP Helper */}
              {devOtp && (
                <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between text-xs">
                  <span className="text-amber-900 font-medium">
                    টেস্ট ওটিপি কোড: <strong className="font-mono text-sm text-amber-950 font-black">{devOtp}</strong>
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const digits = devOtp.split('');
                      setOtpCode(digits);
                      verifyOtpCode(devOtp);
                    }}
                    className="px-2.5 py-1 bg-amber-200 hover:bg-amber-300 text-amber-950 rounded-lg font-bold text-[11px] transition cursor-pointer"
                  >
                    স্বয়ংক্রিয় পূরণ
                  </button>
                </div>
              )}

              {/* Direct WhatsApp URL helper */}
              {directWaUrl && (
                <a
                  href={directWaUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 transition flex items-center justify-center gap-1.5"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>WhatsApp-এ সরাসরি মেসেজ চেক করুন</span>
                </a>
              )}

              <button
                type="button"
                onClick={() => verifyOtpCode()}
                disabled={isLoading || otpCode.some(d => !d)}
                className="w-full py-3.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm rounded-2xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>যাচাই করা হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>যাচাই করে লগইন সম্পন্ন করুন</span>
                  </>
                )}
              </button>

              {/* Resend OTP */}
              <div className="text-center pt-2">
                {canResend ? (
                  <button
                    type="button"
                    onClick={() => handleSendOtp()}
                    className="text-xs text-emerald-700 hover:text-emerald-900 font-bold flex items-center justify-center gap-1 mx-auto"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>পুনরায় ওটিপি কোড পাঠান</span>
                  </button>
                ) : (
                  <p className="text-xs text-slate-400 flex items-center justify-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{countdown} সেকেন্ড পর পুনরায় পাঠানো যাবে</span>
                  </p>
                )}
              </div>
            </div>
          )}

          {/* ================= STEP 1-B: 1-Click QR Code Mode ================= */}
          {authMode === 'qr' && step !== 'success' && (
            <div className="text-center space-y-4 py-2">
              <div className="space-y-1">
                <h3 className="font-extrabold text-sm text-slate-900">
                  মোবাইল WhatsApp দিয়ে QR কোড স্ক্যান করুন
                </h3>
                <p className="text-xs text-slate-500 max-w-xs mx-auto">
                  ক্যামেরা বা WhatsApp দিয়ে স্ক্যান করে ভেরিফিকেশন মেসেজ পাঠালে স্বয়ংক্রিয় লগইন সম্পন্ন হবে।
                </p>
              </div>

              {/* QR Container */}
              <div className="relative inline-block p-4 bg-white rounded-2xl border-2 border-emerald-200 shadow-md">
                {isQrLoading ? (
                  <div className="w-56 h-56 flex flex-col items-center justify-center gap-2 text-slate-400">
                    <RefreshCw className="w-8 h-8 animate-spin text-emerald-600" />
                    <span className="text-xs font-bold">QR তৈরি হচ্ছে...</span>
                  </div>
                ) : instantSession?.qrCodeUrl ? (
                  <img
                    src={instantSession.qrCodeUrl}
                    alt="WhatsApp QR Code"
                    className="w-56 h-56 object-contain rounded-xl"
                  />
                ) : (
                  <div className="w-56 h-56 flex items-center justify-center text-slate-400 text-xs">
                    কিউআর লোড করা যায়নি
                  </div>
                )}
              </div>

              {/* Deep Link Button */}
              {instantSession?.deepLink && (
                <div className="space-y-2">
                  <a
                    href={instantSession.deepLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-2"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>WhatsApp-এ ১-ক্লিকে বার্তা পাঠান</span>
                  </a>

                  {/* Dev Simulation button */}
                  <button
                    type="button"
                    onClick={async () => {
                      setIsLoading(true);
                      await fetch('/api/auth/whatsapp/instant-verify-simulate', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ sessionId: instantSession.sessionId, roleHint })
                      });
                      setIsLoading(false);
                    }}
                    className="text-[11px] text-slate-400 hover:text-emerald-700 font-medium underline block mx-auto"
                  >
                    (টেস্টিং মোড: ১-ক্লিক ভেরিফাই সিমুলেট করুন)
                  </button>
                </div>
              )}

              <div className="flex items-center justify-center gap-2 text-xs text-slate-400">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-600" />
                <span>ভেরিফিকেশনের জন্য অপেক্ষা করা হচ্ছে...</span>
              </div>
            </div>
          )}

          {/* ================= STEP 3: Authenticated User Profile ================= */}
          {step === 'success' && currentUser && (
            <div className="space-y-4 text-center py-2">
              <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto shadow-inner border border-emerald-200">
                <CheckCircle2 className="w-10 h-10 text-emerald-700" />
              </div>

              <div>
                <h3 className="text-lg font-black text-slate-900">
                  হোয়াটসঅ্যাপ লগইন সফল!
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  নিরাপদ ওটিপি যাচাইকরণের মাধ্যমে পরিচয় নিশ্চিত করা হয়েছে।
                </p>
              </div>

              {/* User Profile Card */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left space-y-2">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="text-xs text-slate-500">নাম:</span>
                  <span className="text-xs font-black text-slate-800">{currentUser.name}</span>
                </div>
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="text-xs text-slate-500">মোবাইল:</span>
                  <span className="text-xs font-mono font-bold text-emerald-800">{currentUser.phone}</span>
                </div>
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="text-xs text-slate-500">পদবী / রোল:</span>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                    {currentUser.designation || currentUser.role}
                  </span>
                </div>
                {currentUser.village && (
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500">গ্রাম / ঠিকানা:</span>
                    <span className="text-xs font-medium text-slate-700">{currentUser.village}{currentUser.wardNo ? ` (ওয়ার্ড ${currentUser.wardNo})` : ''}</span>
                  </div>
                )}
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-3 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow transition cursor-pointer"
                >
                  প্রবেশ করুন
                </button>
                <button
                  type="button"
                  onClick={handleLogout}
                  className="py-3 px-4 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs rounded-xl border border-rose-200 transition flex items-center justify-center gap-1 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>লগআউট</span>
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
