import React, { useState, useEffect } from 'react';
import { 
  X, 
  Send, 
  Share2, 
  Copy, 
  Check, 
  MessageSquare, 
  Phone, 
  QrCode, 
  ExternalLink, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  Clock, 
  ShieldCheck, 
  FileText, 
  RefreshCw,
  Smartphone
} from 'lucide-react';
import { CertificateRecord, UnionParishadConfig, WhatsAppSendResult } from '../types';
import { whatsappService } from '../services/whatsappMessagingService';

interface WhatsAppDispatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  certificate: CertificateRecord | null;
  config: UnionParishadConfig;
  onSuccess?: (result: WhatsAppSendResult) => void;
}

export const WhatsAppDispatchModal: React.FC<WhatsAppDispatchModalProps> = ({
  isOpen,
  onClose,
  certificate,
  config,
  onSuccess
}) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [customNote, setCustomNote] = useState('আপনার কাঙ্ক্ষিত প্রত্যয়নপত্রটি ইউনিয়ন পরিষদ থেকে সফলভাবে অনুমোদন ও ডিজিটাল ডাটাবেজে যুক্ত করা হয়েছে।');
  const [templateType, setTemplateType] = useState<'approval' | 'verification' | 'fee_receipt' | 'custom'>('approval');
  const [isSending, setIsSending] = useState(false);
  const [sendResult, setSendResult] = useState<WhatsAppSendResult | null>(null);
  const [copied, setCopied] = useState(false);
  const [serviceStatus, setServiceStatus] = useState<{ isConfigured: boolean; provider: string; senderNumber: string } | null>(null);

  useEffect(() => {
    if (certificate) {
      setPhoneNumber(certificate.citizen?.mobile || '');
      setSendResult(null);
      // Fetch server messaging status
      whatsappService.getServiceStatus().then(status => {
        setServiceStatus(status);
      });
    }
  }, [certificate, isOpen]);

  if (!isOpen || !certificate) return null;

  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://baheratailup.gov.bd';
  const realVerifyUrl = certificate.verificationUrl || `${origin}/verify/${certificate.memoNo}`;
  const qrImageUrl = certificate.qrCodeUrl || `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(realVerifyUrl)}`;

  const phoneInfo = whatsappService.formatBangladeshiPhone(phoneNumber);
  const messageBody = whatsappService.buildCertificateMessageText(certificate, config, customNote, templateType);

  const handleSendViaTwilio = async () => {
    if (!phoneInfo.isValid) {
      alert('অনুগ্রহ করে একটি সঠিক বাংলাদেশী মোবাইল নম্বর (১১ ডিজিট, যেমন 017XXXXXXXX) প্রদান করুন।');
      return;
    }

    setIsSending(true);
    setSendResult(null);

    try {
      const result = await whatsappService.sendViaTwilio({
        to: phoneInfo.formatted,
        certificate,
        customNote,
        templateType,
        mediaUrl: qrImageUrl,
        sendMethod: 'twilio'
      });

      setSendResult(result);
      if (result.success && onSuccess) {
        onSuccess(result);
      }
    } catch (err: any) {
      setSendResult({
        success: false,
        provider: 'twilio',
        status: 'failed',
        to: phoneInfo.formatted,
        timestamp: new Date().toISOString(),
        error: err.message || 'মেসেজ প্রেরণে ব্যর্থতা।'
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleOpenDirectWhatsApp = () => {
    whatsappService.openDirectWhatsAppWeb(phoneNumber, messageBody);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(messageBody);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-800 to-teal-900 text-white flex items-center justify-between border-b border-emerald-700/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#25D366] text-slate-950 flex items-center justify-center shadow-lg font-black">
              <Share2 className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black flex items-center gap-2">
                <span>হোয়াটসঅ্যাপ নোটিফিকেশন ও ভেরিফিকেশন লিংক</span>
                <span className="text-[10px] bg-emerald-700/80 px-2 py-0.5 rounded-full uppercase tracking-wider font-semibold border border-emerald-500/30">
                  Twilio & Direct
                </span>
              </h2>
              <p className="text-xs text-emerald-200">
                স্মারক নং: <span className="font-mono font-bold text-amber-300">{certificate.memoNo}</span> • {certificate.typeLabel}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-emerald-950/40 hover:bg-emerald-950/80 text-emerald-200 hover:text-white transition cursor-pointer"
            aria-label="বন্ধ করুন"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-slate-800 dark:text-slate-100 flex-1 text-sm">
          
          {/* Result Alert if just sent */}
          {sendResult && (
            <div className={`p-4 rounded-xl border flex items-start gap-3 ${
              sendResult.success 
                ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200' 
                : 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200'
            }`}>
              {sendResult.success ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
              )}
              <div className="flex-1 text-xs">
                <div className="font-bold text-sm mb-0.5">
                  {sendResult.success ? 'হোয়াটসঅ্যাপ মেসেজ সফলভাবে প্রেরণ করা হয়েছে!' : 'মেসেজ প্রেরণে ত্রুটি:'}
                </div>
                <div>{sendResult.message || sendResult.error}</div>
                {sendResult.messageId && (
                  <div className="mt-1 font-mono text-[11px] opacity-80">
                    Message ID: {sendResult.messageId} • Provider: {sendResult.provider}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Recipient & Template Config */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Phone Number Input */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                নাগরিকের মোবাইল নম্বর (হোয়াটসঅ্যাপ):
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Phone className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="017XXXXXXXX"
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className={phoneInfo.isValid ? 'text-emerald-600 dark:text-emerald-400 font-semibold' : 'text-amber-600 dark:text-amber-400'}>
                  {phoneInfo.isValid ? `ভেরিফাইড: ${phoneInfo.display}` : '১১ ডিজিটের বাংলাদেশী মোবাইল নম্বর দিন'}
                </span>
                <span className="text-slate-400 font-mono">BD (+880)</span>
              </div>
            </div>

            {/* Template Selector */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                মেসেজ টেমপ্লেট ধরন:
              </label>
              <select
                value={templateType}
                onChange={(e: any) => setTemplateType(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                <option value="approval">সনদ অনুমোদন ও ভেরিফিকেশন QR কোড লিংক</option>
                <option value="fee_receipt">ইউপি ফি প্রাপ্তি রসিদ (Payment Receipt)</option>
                <option value="custom">কাস্টম বার্তা সহ সংক্ষিপ্ত নোটিশ</option>
              </select>
            </div>
          </div>

          {/* Custom Note */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              বিশেষ দাপ্তরিক বার্তা / নির্দেশনা (ঐচ্ছিক):
            </label>
            <input
              type="text"
              value={customNote}
              onChange={(e) => setCustomNote(e.target.value)}
              placeholder="যেমন: মূল সনদের হার্ডকপি সংগ্রহের জন্য ইউপি কার্যালয়ে যোগাযোগ করুন।"
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          {/* Preview of Direct Verification & QR Information */}
          <div className="bg-emerald-50/70 dark:bg-emerald-950/20 p-3.5 rounded-xl border border-emerald-200 dark:border-emerald-800/60 flex flex-col sm:flex-row items-center gap-4">
            <div className="w-20 h-20 bg-white p-1 rounded-lg shadow-sm border border-emerald-300 shrink-0 flex items-center justify-center">
              <img 
                src={qrImageUrl} 
                alt="QR Code Preview" 
                className="w-full h-full object-contain" 
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="space-y-1 text-center sm:text-left flex-1 min-w-0">
              <div className="flex items-center justify-center sm:justify-start gap-1.5 text-xs font-bold text-emerald-900 dark:text-emerald-300">
                <QrCode className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
                <span>সরাসরি অনলাইন ভেরিফিকেশন ও ডাউনলোড লিংক:</span>
              </div>
              <div className="text-[11px] font-mono text-slate-600 dark:text-slate-400 truncate bg-white/80 dark:bg-slate-900/80 px-2.5 py-1 rounded-lg border border-emerald-200/60 dark:border-emerald-800/40">
                {realVerifyUrl}
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                নাগরিক লিংকে ক্লিক করলে সাথে সাথে মূল সরকারি সিল ও চেয়ারম্যানের স্বাক্ষরযুক্ত অনলাইন সনদ দেখতে পাবেন।
              </p>
            </div>
          </div>

          {/* Message Preview Box */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                <span>হোয়াটসঅ্যাপ মেসেজ প্রিভিউ:</span>
              </label>
              <button
                onClick={handleCopy}
                className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'কপি হয়েছে' : 'মেসেজ টেক্সট কপি'}</span>
              </button>
            </div>
            <div className="p-3 bg-slate-900 text-emerald-300 rounded-xl font-mono text-xs whitespace-pre-wrap max-h-48 overflow-y-auto border border-slate-800 selection:bg-emerald-800">
              {messageBody}
            </div>
          </div>

        </div>

        {/* Action Footer */}
        <div className="p-4 sm:p-5 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          
          {/* Provider status indicator */}
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <span>Twilio WhatsApp Gateway: <strong className="text-slate-700 dark:text-slate-200">{serviceStatus?.isConfigured ? 'Active API' : 'Automated Simulation / Web'}</strong></span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            {/* Direct WhatsApp Web Button */}
            <button
              type="button"
              onClick={handleOpenDirectWhatsApp}
              className="px-4 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl transition flex items-center gap-2 cursor-pointer"
              title="ব্রাউজার বা মোবাইল অ্যাপে সরাসরি চ্যাট খুলুন"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>WhatsApp Web চ্যাট</span>
            </button>

            {/* Twilio Automated Send Button */}
            <button
              type="button"
              onClick={handleSendViaTwilio}
              disabled={isSending || !phoneInfo.isValid}
              className={`px-5 py-2 text-xs font-black rounded-xl transition flex items-center gap-2 cursor-pointer shadow-md ${
                isSending || !phoneInfo.isValid
                  ? 'bg-slate-300 dark:bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-[#25D366] hover:bg-[#20bd5a] text-slate-950 shadow-emerald-500/20'
              }`}
            >
              {isSending ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>পাঠানো হচ্ছে...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 stroke-[2.5]" />
                  <span>Twilio স্বয়ংক্রিয় প্রেরণ</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
