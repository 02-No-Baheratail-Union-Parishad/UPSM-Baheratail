import { UnionParishadConfig } from '../types';

export const KNOWN_VILLAGES = [
  'ডাবাইল',
  'কামারঙ্গ',
  'গোহাইলবাড়ী',
  'যোগীর কোফা',
  'ঘাটেশ্বরী',
  'বহেড়াতৈল',
  'নয়াপড়া',
  'ভুগলীচালা',
  'নেরগীছ চালা',
  'ধোপার চালা',
  'আমতৈল',
  'শালগ্রামপুর',
  'বগাপ্রতিমা',
  'ছাতিয়াচালা',
  'আন্দি',
  'বেতুয়া',
  'কালিয়ান'
];

export const KNOWN_POST_OFFICES = [
  { name: 'বহেড়াতৈল', code: '১৯৫০' },
  { name: 'নাগবাড়ী', code: '১৯৭২' },
  { name: 'বেতুয়া', code: '১৯৫০' },
  { name: 'ছিলিমপুর', code: '১৯৫০' }
];

export interface WardVillageInfo {
  wardNo: string;
  wardDigit: number;
  villages: string[];
  postOffices: Array<{ name: string; code: string; villages: string[] }>;
}

export const WARD_VILLAGE_MAPPINGS: WardVillageInfo[] = [
  {
    wardNo: '০১',
    wardDigit: 1,
    villages: ['ডাবাইল', 'কামারঙ্গ', 'গোহাইলবাড়ী'],
    postOffices: [
      { name: 'নাগবাড়ী', code: '১৯৭২', villages: ['ডাবাইল', 'কামারঙ্গ', 'গোহাইলবাড়ী'] }
    ]
  },
  {
    wardNo: '০২',
    wardDigit: 2,
    villages: ['গোহাইলবাড়ী', 'যোগীর কোফা'],
    postOffices: [
      { name: 'নাগবাড়ী', code: '১৯৭২', villages: ['গোহাইলবাড়ী'] },
      { name: 'বহেড়াতৈল', code: '১৯৫০', villages: ['যোগীর কোফা'] }
    ]
  },
  {
    wardNo: '০৩',
    wardDigit: 3,
    villages: ['ঘাটেশ্বরী'],
    postOffices: [
      { name: 'বহেড়াতৈল', code: '১৯৫০', villages: ['ঘাটেশ্বরী'] }
    ]
  },
  {
    wardNo: '০৪',
    wardDigit: 4,
    villages: ['বহেড়াতৈল', 'নয়াপড়া', 'ভুগলীচালা', 'নেরগীছ চালা', 'ধোপার চালা'],
    postOffices: [
      { name: 'বহেড়াতৈল', code: '১৯৫০', villages: ['বহেড়াতৈল', 'নয়াপড়া', 'ভুগলীচালা', 'নেরগীছ চালা', 'ধোপার চালা'] }
    ]
  },
  {
    wardNo: '০৫',
    wardDigit: 5,
    villages: ['আমতৈল', 'শালগ্রামপুর'],
    postOffices: [
      { name: 'বেতুয়া', code: '১৯৫০', villages: ['আমতৈল'] },
      { name: 'ছিলিমপুর', code: '১৯৫০', villages: ['শালগ্রামপুর'] }
    ]
  },
  {
    wardNo: '০৬',
    wardDigit: 6,
    villages: ['বগাপ্রতিমা', 'ছাতিয়াচালা', 'আন্দি'],
    postOffices: [
      { name: 'বহেড়াতৈল', code: '১৯৫০', villages: ['বগাপ্রতিমা', 'ছাতিয়াচালা', 'আন্দি'] }
    ]
  },
  {
    wardNo: '০৭',
    wardDigit: 7,
    villages: ['বেতুয়া'],
    postOffices: [
      { name: 'বেতুয়া', code: '১৯৫০', villages: ['বেতুয়া'] }
    ]
  },
  {
    wardNo: '০৮',
    wardDigit: 8,
    villages: ['কালিয়ান', 'বেতুয়া'],
    postOffices: [
      { name: 'বেতুয়া', code: '১৯৫০', villages: ['কালিয়ান', 'বেতুয়া'] }
    ]
  },
  {
    wardNo: '০৯',
    wardDigit: 9,
    villages: ['কালিয়ান'],
    postOffices: [
      { name: 'বেতুয়া', code: '১৯৫০', villages: ['কালিয়ান'] }
    ]
  }
];

export const WARDS = ['০১', '০২', '০৩', '০৪', '০৫', '০৬', '০৭', '০৮', '০৯'];

export const COMMON_OCCUPATIONS = [
  'কৃষি / কৃষক',
  'ব্যবসা / ব্যবসায়ী',
  'চাকরিজীবী (সরকারি/বেসরকারি)',
  'প্রবাসী / রেমিট্যান্স যোদ্ধা',
  'শিক্ষার্থী',
  'গৃহিণী',
  'দিনমজুর / শ্রমিক',
  'শিক্ষক / শিক্ষিকা',
  'চালক / পরিবহন শ্রমিক',
  'ডাক্তার / স্বাস্থ্যকর্মী',
  'অবসরপ্রাপ্ত',
  'অন্যান্য'
];

export const AGE_GROUP_RANGES = [
  { key: 'all', label: 'সব বয়স', min: 0, max: 200, badgeColor: 'bg-slate-100 text-slate-700' },
  { key: 'child', label: 'শিশু ও কিশোর (০-১৭ বছর)', min: 0, max: 17, badgeColor: 'bg-sky-100 text-sky-900 border-sky-300' },
  { key: 'youth', label: 'তরুণ ও যুবক (১৮-৩৫ বছর)', min: 18, max: 35, badgeColor: 'bg-emerald-100 text-emerald-900 border-emerald-300' },
  { key: 'middle', label: 'মধ্যবয়সী (৩৬-৫০ বছর)', min: 36, max: 50, badgeColor: 'bg-amber-100 text-amber-900 border-amber-300' },
  { key: 'senior', label: 'প্রবীণ ও জ্যেষ্ঠ নাগরিক (৫১+ বছর)', min: 51, max: 200, badgeColor: 'bg-purple-100 text-purple-900 border-purple-300' }
];

export const DEFAULT_UP_CONFIG: UnionParishadConfig = {
  upName: '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ',
  upNameEn: '02 No. Baheratail Union Parishad',
  upazila: 'সখিপুর',
  district: 'টাঙ্গাইল',
  address: 'ডাকঘর: বহেড়াতৈল - ১৯৫০, উপজেলা: সখিপুর, জেলা: টাঙ্গাইল।',
  phone: '০১৮৩৪-৩৩৩৩৩০০',
  email: 'baheratailunion@gmail.com',
  chairmanName: 'মোশাররফ হোসেন (হিরো মিয়া)',
  chairmanTitle: 'প্যানেল চেয়ারম্যান /চেয়ারম্যান/প্রশাসক',
  chairmanPhone: '০১৭৯৯-১১২২৩৩',
  chairmanSignatureUrl: '',
  secretaryName: 'মোঃ সাইদুজ্জামান',
  secretaryTitle: 'ইউনিয়ন পরিষদ প্রশাসনিক কর্মকর্তা',
  secretaryPhone: '০১৮১২-৪৪৫৫৬৬',
  secretarySignatureUrl: '',
  enableDigitalSignature: true,
  showSecretarySignature: true,
  logoUrl: '/baheratail_seal.svg',
  sealText: '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ * সখিপুর, টাঙ্গাইল',
  defaultPromptPrefix: 'তুমি ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল-এর একজন দক্ষ ও পেশাদার প্রশাসনিক লেখক। সরকারি গাম্ভীর্য বজায় রেখে প্রত্যয়নপত্রের বিবরণী তৈরি করো।',
  enableHeaderInPrint: true,
  watermarkOpacity: 0.08,
  certificateFeeDefault: 50,
  categoryFees: {
    'নাগরিকত্ব ও পরিচয়': 50,
    'উত্তরাধিকার ও ওয়ারিশান': 100,
    'চারিত্রিক ও প্রত্যয়ন': 50,
    'সম্পত্তি ও ভূমি সংক্রান্ত': 100,
    'বিবিধ ও অন্যান্য': 50
  },
  typeFeeOverrides: {
    'warish': 100,
    'family': 100,
    'landless': 50,
    'unmarried': 50,
    'monthly_income': 50
  },
  paymentBkashNumber: '01799-112233',
  paymentNagadNumber: '01812-445566',
  paymentRocketNumber: '01911-223344',
  paymentInstructions: 'বিকাশ, নগদ বা রকেটের মার্চেন্ট/পার্সোনাল নম্বরে সনদের ফি প্রদান করে ট্রানজেকশন আইডি (TrxID) ইনপুট দিন।',
  templateHeaderStyle: 'tri-column',
  bodyFontSize: 16,
  borderStyle: 'double-green-red',
  blankSealSize: 96,
  qrCodePosition: 'left-bottom',
  qrColorScheme: 'govt-emerald',
  qrEmbedLogo: true,
  qrLogoShape: 'circle',
  qrFrameStyle: 'clean',
  qrSize: 72,
  templateDocId: '1iJ4jvnV7om8rPp9Tjth4e7l_ipjxc6QpQ1ejLxlJd5k',
  targetFolderId: '16vXelYwApSFuFFru0Qkj1gaHCUwKZ-vz',
  sheetId: '15ePvh-T4nvs6Xn2ghwrwowogFbMV7yex2uV6lZ7jBUY',
  appsScriptUrl: 'https://script.google.com/macros/s/AKfycbwa7PHYGGucLgz4V9aKcIw3pO8zkoYafvHLgAG7MI1OW-ca0txcRGj8q8YsOl9o9r67Jw/exec',
  r2AccountId: '8145fd7882d729f182b85e7c18c1a5f0',
  r2AccessKeyId: '26d4ea0bfd548258646061ba6d80d57d',
  r2SecretAccessKey: 'b4c85f0e7c2937703376d89fb7d2a880cb2aa00631fcb8c32c8aa3d6612db94f',
  r2Endpoint: 'https://8145fd7882d729f182b85e7c18c1a5f0.r2.cloudflarestorage.com',
  r2BucketName: 'certificates-storage',
  developerName: 'MD JUBAER HOSSEN',
  developerTitle: 'লীড সিস্টেম আর্কিটেক্ট ও ফুল-স্ট্যাক অটোমেশন ইঞ্জিনিয়ার',
  developerPhotoUrl: '',
  developerBio: '০২নং বহেড়াতৈল ইউনিয়ন পরিষদের ডিজিটাল অটোমেশন সিস্টেম, ক্লাউড আর্কিটেকচার এবং Gemini AI চালিত স্মার্ট প্রত্যয়নপত্র ইঞ্জিন প্রস্তুতকারক।',
  developerEmail: 'baheratailunion@gmail.com',
  developerPhone: '01834-333300',
  developerWhatsappNumber: '01834-333300',
  developerWhatsappUsername: 'Xobaer6090',
  developerWhatsappUrl: 'https://wa.me/message/7PMRKZ6ZMPT2G1',
  developerFacebookUrl: 'https://facebook.com/xobaer6090',
  developerLinkedinUrl: 'https://linkedin.com/in/xobaer6090',
  developerTiktokUrl: 'https://www.tiktok.com/@xobaer6090?_r=1&_t=ZS-98qqxpnGbVA',
  developerInstagramUrl: 'https://www.instagram.com/xobaer6090?igsh=MWlua2h6YjQ2c2JmOA==',
  developerGithubProfileUrl: 'https://github.com/inbox6090',
  developerTwitterUrl: 'https://x.com/Xobaer6090',
  developerWordpressUrl: 'https://xobaer.wordpress.com',
  githubRepoUrl: 'https://github.com/inbox6090/UPSM-Baheratail',
  githubBranch: 'main',
  googleDriveBackupUrl: 'https://drive.google.com/drive/folders/16vXelYwApSFuFFru0Qkj1gaHCUwKZ-vz',
  mcpEndpointUrl: 'https://api.baheratailup.gov.bd/v1/mcp',
  webhookUrl: 'https://api.baheratailup.gov.bd/v1/webhook',
  webhookSecret: 'whsec_up_baheratail_2026_secret_key',
  lastBackupDate: '2026-08-04 11:15 AM',
  pluginsConfig: {
    smsNotification: true,
    gdriveAutoSync: true,
    geminiOcrVision: true,
    auditTrailLog: true,
    webhookIntegration: false,
    mcpProtocolAgent: true
  }
};
