import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signInWithRedirect,
  getRedirectResult,
  signOut, 
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  getFirestore,
  initializeFirestore,
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  addDoc, 
  query, 
  where, 
  orderBy, 
  deleteDoc,
  onSnapshot,
  serverTimestamp,
  writeBatch,
  getDocFromServer
} from 'firebase/firestore';
import { getStorage, ref, uploadString, getDownloadURL } from 'firebase/storage';
import firebaseConfig from '../firebase-applet-config.json';
import { CertificateRecord, UnionParishadConfig, AdminPermissions } from './types';
export type { AdminPermissions };

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Firebase Auth
export const auth = getAuth(app);

// Base Google Auth Provider for Admin and Staff authentication
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

// Dedicated Google Workspace Provider (with spreadsheets, drive, and Google Chat scopes)
export const workspaceGoogleProvider = new GoogleAuthProvider();
workspaceGoogleProvider.addScope('https://www.googleapis.com/auth/spreadsheets');
workspaceGoogleProvider.addScope('https://www.googleapis.com/auth/drive.file');
workspaceGoogleProvider.addScope('https://www.googleapis.com/auth/chat.spaces');
workspaceGoogleProvider.addScope('https://www.googleapis.com/auth/chat.spaces.readonly');
workspaceGoogleProvider.addScope('https://www.googleapis.com/auth/chat.spaces.create');
workspaceGoogleProvider.addScope('https://www.googleapis.com/auth/chat.messages');
workspaceGoogleProvider.addScope('https://www.googleapis.com/auth/chat.messages.readonly');
workspaceGoogleProvider.addScope('https://www.googleapis.com/auth/chat.messages.create');
workspaceGoogleProvider.addScope('https://www.googleapis.com/auth/chat.memberships');
workspaceGoogleProvider.addScope('https://www.googleapis.com/auth/chat.memberships.readonly');
workspaceGoogleProvider.setCustomParameters({
  prompt: 'select_account'
});

// In-memory OAuth access token cache
let cachedGoogleAccessToken: string | null = null;

export function getGoogleAccessToken(): string | null {
  return cachedGoogleAccessToken;
}

export function setGoogleAccessToken(token: string | null): void {
  cachedGoogleAccessToken = token;
}

// Initialize Firestore with specific database ID if present
const rawDbId = (firebaseConfig as any).firestoreDatabaseId;
export const db = rawDbId && rawDbId !== '(default)' 
  ? getFirestore(app, rawDbId) 
  : getFirestore(app);

// Initialize Firebase Storage
export const storage = getStorage(app);

const CERTIFICATES_COLLECTION = 'certificates';
const CONFIGS_COLLECTION = 'configs';
const MASTER_CONFIG_DOC = 'master_config';

// Initialize Firestore Collections and Service functions
export async function saveCertificateToFirebase(record: CertificateRecord): Promise<string> {
  try {
    const docId = record.memoNo.replace(/[^a-zA-Z0-9.-]/g, '_') || `cert_${Date.now()}`;
    const docRef = doc(db, CERTIFICATES_COLLECTION, docId);
    
    const cleanData = JSON.parse(JSON.stringify(record));
    await setDoc(docRef, {
      ...cleanData,
      updatedAt: new Date().toISOString(),
      timestamp: serverTimestamp()
    }, { merge: true });
    
    return docId;
  } catch (error) {
    console.error('Error saving certificate to Firebase:', error);
    throw error;
  }
}

/**
 * Batch write operation to restore historical records into Firestore in chunks of up to 400 records.
 */
export async function batchRestoreCertificatesToFirebase(records: CertificateRecord[]): Promise<{ count: number; batches: number }> {
  try {
    if (!Array.isArray(records) || records.length === 0) {
      return { count: 0, batches: 0 };
    }

    const BATCH_SIZE = 400; // Safe threshold under Firestore 500 writes limit per batch
    let totalRestored = 0;
    let batchCount = 0;

    for (let i = 0; i < records.length; i += BATCH_SIZE) {
      const chunk = records.slice(i, i + BATCH_SIZE);
      const batch = writeBatch(db);

      for (const record of chunk) {
        if (!record || !record.memoNo) continue;
        const docId = record.memoNo.replace(/[^a-zA-Z0-9.-]/g, '_') || `cert_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const docRef = doc(db, CERTIFICATES_COLLECTION, docId);
        const cleanData = JSON.parse(JSON.stringify(record));
        batch.set(docRef, {
          ...cleanData,
          updatedAt: new Date().toISOString(),
          timestamp: serverTimestamp()
        }, { merge: true });
        totalRestored++;
      }

      await batch.commit();
      batchCount++;
    }

    return { count: totalRestored, batches: batchCount };
  } catch (error) {
    console.error('Error batch restoring certificates to Firestore:', error);
    throw error;
  }
}

export async function fetchCertificatesFromFirebase(): Promise<CertificateRecord[]> {
  try {
    const colRef = collection(db, CERTIFICATES_COLLECTION);
    const snapshot = await getDocs(colRef);
    const records: CertificateRecord[] = [];
    
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      if (data.memoNo) {
        records.push(data as CertificateRecord);
      }
    });
    
    return records;
  } catch (error) {
    console.error('Error fetching certificates from Firebase:', error);
    return [];
  }
}

export async function searchCertificateInFirebase(queryStr: string): Promise<CertificateRecord | null> {
  try {
    const trimmed = queryStr.trim();
    if (!trimmed) return null;

    // Search by exact memoNo first
    const colRef = collection(db, CERTIFICATES_COLLECTION);
    const qMemo = query(colRef, where('memoNo', '==', trimmed));
    const memoSnap = await getDocs(qMemo);
    
    if (!memoSnap.empty) {
      const data = memoSnap.docs[0].data();
      return data as CertificateRecord;
    }

    // Search by NID
    const qNid = query(colRef, where('citizen.nid', '==', trimmed));
    const nidSnap = await getDocs(qNid);
    
    if (!nidSnap.empty) {
      const data = nidSnap.docs[0].data();
      return data as CertificateRecord;
    }

    // Client-side fallback check in all docs
    const allRecords = await fetchCertificatesFromFirebase();
    return allRecords.find(r => 
      r.memoNo.toLowerCase() === trimmed.toLowerCase() || 
      (r.citizen && (r.citizen.nid === trimmed || r.citizen.birthNo === trimmed))
    ) || null;
  } catch (error) {
    console.error('Error searching certificate in Firebase:', error);
    return null;
  }
}

export async function saveConfigToFirebase(config: UnionParishadConfig): Promise<void> {
  try {
    const cleanConfig = JSON.parse(JSON.stringify(config));
    
    // 1. Separate public branding configuration from sensitive credentials
    const {
      geminiApiKey,
      webhookSecret,
      r2SecretAccessKey,
      googleServiceAccountKey,
      ...publicBranding
    } = cleanConfig as any;

    // Save public branding document
    const publicDocRef = doc(db, CONFIGS_COLLECTION, 'public_branding');
    await setDoc(publicDocRef, { ...publicBranding, updatedAt: new Date().toISOString() }, { merge: true });

    // Save master config for backward compatibility
    const masterDocRef = doc(db, CONFIGS_COLLECTION, MASTER_CONFIG_DOC);
    await setDoc(masterDocRef, cleanConfig, { merge: true });

    // Save private secrets in secured doc if any secret exists
    if (geminiApiKey || webhookSecret || r2SecretAccessKey || googleServiceAccountKey) {
      const secretsDocRef = doc(db, CONFIGS_COLLECTION, 'private_secrets');
      await setDoc(secretsDocRef, {
        geminiApiKey: geminiApiKey || '',
        webhookSecret: webhookSecret || '',
        r2SecretAccessKey: r2SecretAccessKey || '',
        googleServiceAccountKey: googleServiceAccountKey || '',
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }
  } catch (error) {
    console.error('Error saving config to Firebase:', error);
  }
}

export async function fetchConfigFromFirebase(): Promise<UnionParishadConfig | null> {
  try {
    // 1. Fetch public branding first (accessible to all)
    const publicRef = doc(db, CONFIGS_COLLECTION, 'public_branding');
    const masterRef = doc(db, CONFIGS_COLLECTION, MASTER_CONFIG_DOC);
    
    const timeout = new Promise<null>((resolve) => setTimeout(() => resolve(null), 3000));
    
    const fetchPublic = getDoc(publicRef).then(async (pubSnap) => {
      if (pubSnap.exists()) {
        const pubData = pubSnap.data();
        // Try fetching private secrets if authenticated
        try {
          const secretsRef = doc(db, CONFIGS_COLLECTION, 'private_secrets');
          const secSnap = await getDoc(secretsRef);
          if (secSnap.exists()) {
            return { ...pubData, ...secSnap.data() } as UnionParishadConfig;
          }
        } catch (_) {
          // Unauthenticated/citizen will safely get public branding
        }
        return pubData as UnionParishadConfig;
      }

      // Fallback to master_config
      const masterSnap = await getDoc(masterRef);
      return masterSnap.exists() ? (masterSnap.data() as UnionParishadConfig) : null;
    });

    return await Promise.race([fetchPublic, timeout]);
  } catch (error) {
    console.warn('Notice: Firestore config fetch unavailable (using default configuration):', error);
    return null;
  }
}

export async function fetchPendingCertificatesCountFromFirebase(): Promise<number> {
  try {
    const colRef = collection(db, CERTIFICATES_COLLECTION);
    const snapshot = await getDocs(colRef);
    let count = 0;
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      if (data.status === 'pending_approval' || data.status === 'draft') {
        count++;
      }
    });
    return count;
  } catch (error: any) {
    console.warn('Notice: Firestore pending count fetch notice:', error?.message || error);
    return 0;
  }
}

export function subscribePendingCertificatesCount(callback: (count: number) => void): () => void {
  try {
    const colRef = collection(db, CERTIFICATES_COLLECTION);
    return onSnapshot(colRef, (snapshot) => {
      let count = 0;
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        if (data.status === 'pending_approval' || data.status === 'draft') {
          count++;
        }
      });
      callback(count);
    }, (error) => {
      console.warn('Firestore subscription warning:', error);
    });
  } catch (error) {
    console.warn('Firestore subscription failed:', error);
    return () => {};
  }
}

export interface FirestoreCollectionExportResult {
  filename: string;
  timestamp: string;
  downloadUrl?: string;
  storagePath?: string;
  collections: { [colName: string]: number };
  totalDocuments: number;
  sizeKb: number;
  jsonData: any;
}

/**
 * Export selected Firestore collections as JSON and save to Firebase Storage
 */
export async function exportFirestoreCollectionsToStorage(
  selectedCollections: string[],
  notes: string = 'Developer Firestore Export',
  onProgress?: (progress: { stage: string; percent: number; currentCol?: string }) => void
): Promise<FirestoreCollectionExportResult> {
  const exportData: Record<string, any[]> = {};
  const collectionCounts: Record<string, number> = {};
  let totalDocs = 0;

  const totalCols = selectedCollections.length;

  for (let i = 0; i < totalCols; i++) {
    const colName = selectedCollections[i];
    const fetchPercent = Math.round(((i + 0.5) / totalCols) * 70);
    
    if (onProgress) {
      onProgress({
        stage: `ফায়ারস্টোর কালেকশন '${colName}' ডাউনলোড করা হচ্ছে... (${i + 1}/${totalCols})`,
        percent: fetchPercent,
        currentCol: colName
      });
    }

    try {
      const colRef = collection(db, colName);
      const snap = await getDocs(colRef);
      const docs: any[] = [];
      snap.forEach((d) => {
        docs.push({ _docId: d.id, ...d.data() });
      });
      exportData[colName] = docs;
      collectionCounts[colName] = docs.length;
      totalDocs += docs.length;
    } catch (err) {
      console.warn(`Collection ${colName} export warning:`, err);
      exportData[colName] = [];
      collectionCounts[colName] = 0;
    }

    if (onProgress) {
      onProgress({
        stage: `লেকশন '${colName}' এর ${collectionCounts[colName]} টি রেকর্ড প্রাপ্ত হয়েছে (${i + 1}/${totalCols})`,
        percent: Math.round(((i + 1) / totalCols) * 70),
        currentCol: colName
      });
    }
  }

  if (onProgress) {
    onProgress({
      stage: `JSON অবজেক্ট কম্প্রেশন ও স্ট্রাকচার তৈরি হচ্ছে...`,
      percent: 80
    });
  }

  const timestamp = new Date().toISOString();
  const dateStr = timestamp.replace(/[:.]/g, '-').slice(0, 19);
  const filename = `Firestore_Export_${dateStr}.json`;

  const payload = {
    meta: {
      exporterRole: 'developer',
      exportType: 'FIRESTORE_CUSTOM_COLLECTIONS_BACKUP',
      timestamp,
      selectedCollections,
      collectionCounts,
      totalDocuments: totalDocs,
      notes
    },
    collectionsData: exportData
  };

  const jsonStr = JSON.stringify(payload, null, 2);
  const sizeKb = Math.round(new Blob([jsonStr]).size / 1024);

  let downloadUrl: string | undefined = undefined;
  let storagePath: string | undefined = undefined;

  if (onProgress) {
    onProgress({
      stage: `Firebase Cloud Storage-এ ব্যাকআপ ফাইল (${sizeKb} KB) আপলোড করা হচ্ছে...`,
      percent: 90
    });
  }

  // Attempt Firebase Storage Upload
  try {
    const storageRef = ref(storage, `backups/firestore_exports/${filename}`);
    await uploadString(storageRef, jsonStr, 'raw', {
      contentType: 'application/json'
    });
    downloadUrl = await getDownloadURL(storageRef);
    storagePath = storageRef.fullPath;
  } catch (storageErr) {
    console.warn('Firebase Storage upload notice (fallback to local JSON download and Firestore log):', storageErr);
  }

  if (onProgress) {
    onProgress({
      stage: `Firestore ব্যাকআপ লগ ডকুমেন্ট সংরক্ষণ করা হচ্ছে...`,
      percent: 96
    });
  }

  // Record export snapshot in Firestore 'backups' collection
  try {
    const backupDocRef = doc(db, 'backups', `fs_exp_${Date.now()}`);
    await setDoc(backupDocRef, {
      filename,
      timestamp,
      recordsCount: totalDocs,
      sizeKb,
      status: 'completed',
      notes: notes || 'Developer Firestore Collections Export',
      downloadUrl: downloadUrl || null,
      storagePath: storagePath || null,
      collections: collectionCounts
    }, { merge: true });
  } catch (err) {
    console.warn('Notice saving backup log to Firestore:', err);
  }

  if (onProgress) {
    onProgress({
      stage: `ফায়ারস্টোর ডাটাবেস এক্সপোর্ট প্রক্রিয়া সফলভাবে সম্পন্ন হয়েছে!`,
      percent: 100
    });
  }

  return {
    filename,
    timestamp,
    downloadUrl,
    storagePath,
    collections: collectionCounts,
    totalDocuments: totalDocs,
    sizeKb,
    jsonData: payload
  };
}

export interface FirestoreBackupRecord {
  id: string;
  filename: string;
  timestamp: string;
  sizeKb: number;
  recordsCount: number;
  downloadUrl?: string | null;
  storagePath?: string | null;
  notes?: string;
  collections?: Record<string, number>;
  status?: string;
  backupData?: any;
  source?: 'firebase_storage' | 'server_snapshot';
}

/**
 * Fetch all backup records logged in Firestore 'backups' collection, resolving Storage URLs if needed
 */
export async function fetchFirestoreBackupsFromFirebase(): Promise<FirestoreBackupRecord[]> {
  const list: FirestoreBackupRecord[] = [];
  try {
    const colRef = collection(db, 'backups');
    const snap = await getDocs(colRef);
    
    for (const docSnap of snap.docs) {
      const data = docSnap.data();
      let downloadUrl = data.downloadUrl || null;
      
      // If downloadUrl is missing but storagePath exists, try resolving download URL from Firebase Storage
      if (!downloadUrl && data.storagePath) {
        try {
          const storageRef = ref(storage, data.storagePath);
          downloadUrl = await getDownloadURL(storageRef);
        } catch (e) {
          console.warn('Could not resolve download URL for storage path:', data.storagePath);
        }
      }

      list.push({
        id: docSnap.id,
        filename: data.filename || `Backup_${docSnap.id}.json`,
        timestamp: data.timestamp || new Date().toISOString(),
        sizeKb: data.sizeKb || 0,
        recordsCount: data.recordsCount || 0,
        downloadUrl,
        storagePath: data.storagePath || null,
        notes: data.notes || '',
        collections: data.collections || undefined,
        status: data.status || 'completed',
        backupData: data.backupData || undefined,
        source: 'firebase_storage'
      });
    }

    // Sort by timestamp descending
    list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  } catch (err) {
    console.warn('Notice fetching Firestore backup records:', err);
  }
  return list;
}

/**
 * Restore a full database backup JSON object into Firestore collections using batch writes
 */
export async function restoreFullBackupToFirestore(backupData: any): Promise<{ totalRestored: number; collectionsRestored: string[] }> {
  let totalRestored = 0;
  const collectionsRestored: string[] = [];

  if (!backupData || typeof backupData !== 'object') {
    throw new Error('অবৈধ বা খালি ব্যাকআপ ডাটা।');
  }

  // Scenario 1: Multi-collection export format (collectionsData)
  if (backupData.collectionsData && typeof backupData.collectionsData === 'object') {
    for (const [colName, docs] of Object.entries(backupData.collectionsData)) {
      if (!Array.isArray(docs) || docs.length === 0) continue;
      
      collectionsRestored.push(colName);
      const BATCH_SIZE = 400;
      for (let i = 0; i < docs.length; i += BATCH_SIZE) {
        const batch = writeBatch(db);
        const chunk = docs.slice(i, i + BATCH_SIZE);

        for (const item of chunk) {
          const docId = item._docId || item.id || item.memoNo?.replace(/[^a-zA-Z0-9.-]/g, '_') || `doc_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
          const cleanItem = { ...item };
          delete cleanItem._docId;

          const docRef = doc(db, colName, String(docId));
          batch.set(docRef, JSON.parse(JSON.stringify(cleanItem)), { merge: true });
        }

        await batch.commit();
        totalRestored += chunk.length;
      }
    }
  } 
  // Scenario 2: Legacy or Certificates array format
  else {
    const certsToRestore = backupData.certificates || backupData.masterDatabase?.certificates || backupData.sheetData?.certificates || (Array.isArray(backupData) ? backupData : []);
    
    if (Array.isArray(certsToRestore) && certsToRestore.length > 0) {
      collectionsRestored.push('certificates');
      const res = await batchRestoreCertificatesToFirebase(certsToRestore);
      totalRestored = res.count;
    }
  }

  return { totalRestored, collectionsRestored };
}

export interface AdminUserRecord {
  uid?: string;
  email: string;
  name: string;
  role: 'super_admin' | 'chairman' | 'secretary' | 'member' | 'developer';
  designation: string;
  photoUrl?: string;
  addedAt: string;
  lastLoginAt?: string;
  status: 'active' | 'suspended';
  wardNo?: string;
  permissions?: AdminPermissions;
}

const ADMINS_COLLECTION = 'admins';

export const DEFAULT_ADMINS_LIST: AdminUserRecord[] = [
  {
    email: 'inbox600900@gmail.com',
    name: 'MD JUBAER HOSSEN',
    role: 'developer',
    designation: 'প্রধান আইটি ডেভেলপার ও সিস্টেম এডমিন',
    addedAt: '2026-01-01T00:00:00.000Z',
    status: 'active'
  },
  {
    email: 'baheratailunion@gmail.com',
    name: '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ এডমিন',
    role: 'super_admin',
    designation: 'অফিসিয়াল ইউপি এডমিন অ্যাকাউন্ট',
    addedAt: '2026-01-01T00:00:00.000Z',
    status: 'active'
  },
  {
    email: 'chairman@gmail.com',
    name: 'চেয়ারম্যান কার্যালয়',
    role: 'chairman',
    designation: 'ইউপি চেয়ারম্যান',
    addedAt: '2026-01-01T00:00:00.000Z',
    status: 'active'
  },
  {
    email: 'secretary@gmail.com',
    name: 'সচিব কার্যালয়',
    role: 'secretary',
    designation: 'প্রশাসনিক কর্মকর্তা / সচিব',
    addedAt: '2026-01-01T00:00:00.000Z',
    status: 'active'
  }
];

export async function fetchAdminUsersFromFirebase(): Promise<AdminUserRecord[]> {
  try {
    const colRef = collection(db, ADMINS_COLLECTION);
    const snap = await getDocs(colRef);
    if (snap.empty) {
      for (const adm of DEFAULT_ADMINS_LIST) {
        const cleanEmail = adm.email.toLowerCase().trim();
        await setDoc(doc(db, ADMINS_COLLECTION, cleanEmail), adm, { merge: true });
      }
      return DEFAULT_ADMINS_LIST;
    }
    const list: AdminUserRecord[] = [];
    snap.forEach(docSnap => {
      list.push(docSnap.data() as AdminUserRecord);
    });
    return list;
  } catch (err) {
    console.warn('Notice fetching admin users from Firebase:', err);
    return DEFAULT_ADMINS_LIST;
  }
}

export async function saveAdminUserToFirebase(admin: AdminUserRecord): Promise<void> {
  const cleanEmail = admin.email.toLowerCase().trim();
  const docRef = doc(db, ADMINS_COLLECTION, cleanEmail);
  await setDoc(docRef, admin, { merge: true });
}

export function subscribeToAdminUsersFromFirebase(callback: (admins: AdminUserRecord[]) => void): () => void {
  const colRef = collection(db, ADMINS_COLLECTION);
  return onSnapshot(colRef, (snap) => {
    if (snap.empty) {
      callback(DEFAULT_ADMINS_LIST);
      return;
    }
    const list: AdminUserRecord[] = [];
    snap.forEach(docSnap => {
      list.push(docSnap.data() as AdminUserRecord);
    });
    callback(list);
  }, (err) => {
    console.warn('Real-time admin users snapshot warning:', err);
  });
}

export async function saveRolePermissionsMatrixToFirebase(matrix: Record<string, AdminPermissions>): Promise<void> {
  const docRef = doc(db, CONFIGS_COLLECTION, 'role_permissions_matrix');
  await setDoc(docRef, { matrix, updatedAt: new Date().toISOString() }, { merge: true });
}

export function subscribeToRolePermissionsMatrix(callback: (matrix: Record<string, AdminPermissions> | null) => void): () => void {
  const docRef = doc(db, CONFIGS_COLLECTION, 'role_permissions_matrix');
  return onSnapshot(docRef, (docSnap) => {
    if (docSnap.exists() && docSnap.data()?.matrix) {
      callback(docSnap.data().matrix as Record<string, AdminPermissions>);
    } else {
      callback(null);
    }
  }, (err) => {
    console.warn('Role permissions matrix listener warning:', err);
  });
}

export async function deleteAdminUserFromFirebase(email: string): Promise<void> {
  const cleanEmail = email.toLowerCase().trim();
  const docRef = doc(db, ADMINS_COLLECTION, cleanEmail);
  await deleteDoc(docRef);
}

export function formatFirebaseAuthError(err: any): string {
  if (!err) return 'অজানা ত্রুটি দেখা দিয়েছে।';
  if (err.code === 'auth/popup-closed-by-user' || err.message?.includes('popup-closed-by-user')) {
    return 'সাইন-ইন পপআপ উইন্ডোটি বন্ধ করা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।';
  }
  if (err.code === 'auth/popup-blocked' || err.message?.includes('popup-blocked')) {
    return 'ব্রাউজার পপআপ ডায়ালগ ব্লক করেছে। অনুগ্রহ করে ব্রাউজার অ্যাড্রেসবারে পপআপ অনুমোদন করুন অথবা "নতুন ট্যাবে খুলুন" বাটন ব্যবহার করুন।';
  }
  if (err.code === 'auth/cancelled-popup-request' || err.message?.includes('cancelled-popup-request')) {
    return 'পূর্বে স্থগিত পপআপ অনুরোধটি বাতিল করা হয়েছে।';
  }
  if (err.code === 'auth/unauthorized-domain' || err.message?.includes('unauthorized-domain')) {
    const hostname = typeof window !== 'undefined' ? window.location.hostname : '';
    return `বর্তমান ডোমেইনটি (${hostname}) ফায়ারবেস কনসোলের Authorized Domains তালিকায় অনুমোদিত নয়। অনুগ্রহ করে Firebase Console > Authentication > Settings > Authorized domains-এ এই ডোমেইনটি যোগ করুন অথবা মূল লাইভ URL থেকে লগইন করুন।`;
  }
  return err.message || 'গুগল সাইন-ইন প্রক্রিয়া সম্পন্ন করা সম্ভব হয়নি।';
}

export async function signInWithGooglePopup(): Promise<FirebaseUser> {
  const result = await signInWithPopup(auth, googleProvider);
  const credential = GoogleAuthProvider.credentialFromResult(result);
  if (credential?.accessToken) {
    cachedGoogleAccessToken = credential.accessToken;
  }
  return result.user;
}

export async function signInWithGoogleRedirect(): Promise<void> {
  await signInWithRedirect(auth, googleProvider);
}

export async function checkRedirectAuthResult(): Promise<FirebaseUser | null> {
  try {
    const result = await getRedirectResult(auth);
    if (result?.user) {
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        cachedGoogleAccessToken = credential.accessToken;
      }
      return result.user;
    }
    return null;
  } catch (err: any) {
    console.warn('Redirect auth result notice:', err?.message || err);
    return null;
  }
}

export async function signInWithGooglePopupForWorkspace(): Promise<{ user: FirebaseUser; accessToken: string }> {
  const result = await signInWithPopup(auth, workspaceGoogleProvider);
  const credential = GoogleAuthProvider.credentialFromResult(result);
  if (!credential?.accessToken) {
    throw new Error('Google Workspace Access Token পাওয়া যায় নাই। আবার চেষ্টা করুন।');
  }
  cachedGoogleAccessToken = credential.accessToken;
  return { user: result.user, accessToken: credential.accessToken };
}

export async function logoutUserFromFirebase(): Promise<void> {
  cachedGoogleAccessToken = null;
  await signOut(auth);
}

// ============================================================
// AUDIT LOGS FOR SYSTEM MODIFICATIONS
// ============================================================
import { AuditLogRecord } from './types';

const AUDIT_LOGS_COLLECTION = 'audit_logs';

export const INITIAL_AUDIT_LOGS: AuditLogRecord[] = [
  {
    id: 'log_init_001',
    action: 'ADMIN_LOGIN',
    actionTitle: 'গুগল ফায়ারবেস অথেন্টিকেশন সেশন চালু',
    details: 'সিস্টেম এডমিন MD JUBAER HOSSEN (inbox600900@gmail.com) গুগল OAuth 2.0 এর মাধ্যমে সিকিউর এডমিন সেশনে প্রবেশ করিয়াছেন।',
    performedByEmail: 'inbox600900@gmail.com',
    performedByName: 'MD JUBAER HOSSEN',
    performedByRole: 'developer',
    timestamp: new Date(Date.now() - 3600000 * 1).toISOString(),
    ipAddress: '103.114.98.12',
    checksum: 'sha256-a81d42e2b9c7'
  },
  {
    id: 'log_cert_002',
    action: 'CERTIFICATE_APPROVED',
    actionTitle: 'চেয়ারম্যান কর্তৃক নাগরিক সনদপত্র অনুমোদন (Approved)',
    details: 'নাগরিক সনদপত্র (স্মারক নং: UP/BAHER/2026/0482, আবেদনকারী: মোঃ মোস্তফা কামাল) ইউপি চেয়ারম্যান জনাব মোঃ সোহেল রানা কর্তৃক চূড়ান্তভাবে অনুমোদিত ও কিউআর স্বাক্ষরিত হইয়াছে।',
    performedByEmail: 'chairman@gmail.com',
    performedByName: 'চেয়ারম্যান কার্যালয়',
    performedByRole: 'chairman',
    timestamp: new Date(Date.now() - 3600000 * 3).toISOString(),
    ipAddress: '103.114.98.15',
    checksum: 'sha256-f902e1c8d7b3'
  },
  {
    id: 'log_cert_003',
    action: 'CERTIFICATE_ISSUED',
    actionTitle: 'ওয়ারিশান সনদপত্র নতুন আবেদন জমা (Pending)',
    details: 'ওয়ারিশান সনদপত্র (স্মারক নং: UP/BAHER/2026/0485, আবেদনকারী: মোছাঃ সালমা খাতুন, ওয়ার্ড নং: ০৪) খসড়া তৈরি হইয়াছে এবং প্রশাসনিক যাচাই ও অনুমোদনের জন্য অপেক্ষমাণ রহিয়াছে।',
    performedByEmail: 'secretary@gmail.com',
    performedByName: 'সচিব কার্যালয়',
    performedByRole: 'secretary',
    timestamp: new Date(Date.now() - 3600000 * 6).toISOString(),
    ipAddress: '103.114.98.18',
    checksum: 'sha256-c3098e21a4f1'
  },
  {
    id: 'log_cert_004',
    action: 'CERTIFICATE_APPROVED',
    actionTitle: 'সচিব কর্তৃক চারিত্রিক সনদপত্র অনুমোদন (Approved)',
    details: 'চারিত্রিক সনদপত্র (স্মারক নং: UP/BAHER/2026/0481, আবেদনকারী: তানভীর আহমেদ, ওয়ার্ড নং: ০২) তথ্য যাচাই সাপেক্ষে সচিব কর্তৃক অনুমোদিত হইয়াছে।',
    performedByEmail: 'secretary@gmail.com',
    performedByName: 'সচিব কার্যালয়',
    performedByRole: 'secretary',
    timestamp: new Date(Date.now() - 3600000 * 9).toISOString(),
    ipAddress: '103.114.98.18',
    checksum: 'sha256-78e209a15bc4'
  },
  {
    id: 'log_cert_005',
    action: 'CERTIFICATE_REJECTED',
    actionTitle: 'অসম্পূর্ণ তথ্যের কারণে প্রত্যয়নপত্র বাতিল (Rejected)',
    details: 'পারিবারিক সনদপত্র (স্মারক নং: UP/BAHER/2026/0479) জাতীয় পরিচয়পত্রের সাথে জন্মতারিখ গরমিল থাকায় চেয়ারম্যান কর্তৃক বাতিল/প্রত্যাখ্যাত করা হইয়াছে।',
    performedByEmail: 'chairman@gmail.com',
    performedByName: 'চেয়ারম্যান কার্যালয়',
    performedByRole: 'chairman',
    timestamp: new Date(Date.now() - 3600000 * 14).toISOString(),
    ipAddress: '103.114.98.15',
    checksum: 'sha256-d4198ec27b88'
  },
  {
    id: 'log_admin_006',
    action: 'ADMIN_ADDED',
    actionTitle: 'নতুন ইউপি সদস্য এডমিন অ্যাকাউন্ট যুক্তকরণ',
    details: 'ওয়ার্ড নং ৩ এর ইউপি সদস্যের গুগল ইমেইল (member.ward3@gmail.com) ফায়ারবেস অথেন্টিকেশন অ্যাকসেস তালিকায় যুক্ত করা হইয়াছে।',
    performedByEmail: 'baheratailunion@gmail.com',
    performedByName: '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ এডমিন',
    performedByRole: 'super_admin',
    timestamp: new Date(Date.now() - 3600000 * 20).toISOString(),
    ipAddress: '103.114.98.20',
    checksum: 'sha256-e41b80c9a1d2'
  },
  {
    id: 'log_config_007',
    action: 'CONFIG_UPDATED',
    actionTitle: 'ইউনিয়ন পরিষদ মাস্টার কনফিগারেশন আপডেট',
    details: 'ইউনিয়ন পরিষদের অফিসিয়াল লোগো, হেল্পলাইন নম্বর এবং গুগল ডক টেমপ্লেট আইডি আপডেট করা হইয়াছে।',
    performedByEmail: 'secretary@gmail.com',
    performedByName: 'সচিব কার্যালয়',
    performedByRole: 'secretary',
    timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
    ipAddress: '103.114.98.22',
    checksum: 'sha256-b33c10a4f5d8'
  }
];

export async function fetchAuditLogsFromFirebase(): Promise<AuditLogRecord[]> {
  try {
    const colRef = collection(db, AUDIT_LOGS_COLLECTION);
    const snap = await getDocs(colRef);
    if (snap.empty) {
      for (const logItem of INITIAL_AUDIT_LOGS) {
        await setDoc(doc(db, AUDIT_LOGS_COLLECTION, logItem.id), logItem, { merge: true });
      }
      return INITIAL_AUDIT_LOGS;
    }
    const list: AuditLogRecord[] = [];
    snap.forEach(docSnap => {
      list.push(docSnap.data() as AuditLogRecord);
    });
    // Sort by timestamp descending
    list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return list;
  } catch (err) {
    console.warn('Notice fetching audit logs from Firebase:', err);
    return INITIAL_AUDIT_LOGS;
  }
}

export async function addAuditLogToFirebase(
  logData: Omit<AuditLogRecord, 'id' | 'timestamp'>
): Promise<string> {
  try {
    const id = `audit_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
    const timestamp = new Date().toISOString();
    const checksumStr = `sha256-${Math.random().toString(36).substring(2, 10)}${Math.random().toString(36).substring(2, 6)}`;

    const fullRecord: AuditLogRecord = {
      ...logData,
      id,
      timestamp,
      checksum: checksumStr
    };

    const docRef = doc(db, AUDIT_LOGS_COLLECTION, id);
    await setDoc(docRef, fullRecord);
    return id;
  } catch (err) {
    console.error('Error adding audit log to Firebase:', err);
    throw err;
  }
}

export function subscribeToAuditLogsFromFirebase(callback: (logs: AuditLogRecord[]) => void): () => void {
  const colRef = collection(db, AUDIT_LOGS_COLLECTION);
  return onSnapshot(colRef, (snap) => {
    if (snap.empty) {
      callback(INITIAL_AUDIT_LOGS);
      return;
    }
    const list: AuditLogRecord[] = [];
    snap.forEach(docSnap => {
      list.push(docSnap.data() as AuditLogRecord);
    });
    list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    callback(list);
  }, (err) => {
    console.warn('Real-time audit logs snapshot warning:', err);
  });
}

export async function deleteAuditLogFromFirebase(logId: string): Promise<void> {
  const docRef = doc(db, AUDIT_LOGS_COLLECTION, logId);
  await deleteDoc(docRef);
}



