import React, { useState, useEffect, useRef } from 'react';
import { Camera, RefreshCw, CheckCircle2, XCircle, Search, ShieldCheck, AlertCircle } from 'lucide-react';
import { QrScannerController, ScanResult } from '../utils/qrScanner';
import { verifyCertificateFromGas } from '../services/gas';

interface QRScannerPageProps {
  onVerifyMemo?: (memoNo: string) => void;
  onClose?: () => void;
}

export const QRScannerPage: React.FC<QRScannerPageProps> = ({ onVerifyMemo, onClose }) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const scannerRef = useRef<QrScannerController | null>(null);
  
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [lastScannedResult, setLastScannedResult] = useState<ScanResult | null>(null);
  const [manualMemo, setManualMemo] = useState<string>('');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [verificationData, setVerificationData] = useState<any | null>(null);

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    setCameraError(null);
    if (!videoRef.current) return;

    try {
      const scanner = new QrScannerController();
      scannerRef.current = scanner;

      await scanner.start(
        videoRef.current,
        (result: ScanResult) => {
          handleScanSuccess(result);
        },
        (err: Error) => {
          console.warn('Camera scan error:', err);
          setCameraError('ক্যামেরা চালু করতে সমস্যা হয়েছে। অনুগ্রহ করে ব্রাউজার/অ্যাপে ক্যামেরার অনুমতি দিন।');
          setIsScanning(false);
        }
      );
      setIsScanning(true);
    } catch (err: any) {
      setCameraError(err.message || 'ক্যামেরা চালু করা সম্ভব হয়নি।');
      setIsScanning(false);
    }
  };

  const stopCamera = () => {
    if (scannerRef.current) {
      scannerRef.current.stop();
      scannerRef.current = null;
    }
    setIsScanning(false);
  };

  const handleScanSuccess = async (result: ScanResult) => {
    if (!result.isValidUpQr && !result.memoNo) return;
    
    // Stop scanning once detected
    stopCamera();
    setLastScannedResult(result);

    const memoToVerify = result.memoNo || result.rawText;
    await performVerification(memoToVerify);
  };

  const performVerification = async (memo: string) => {
    setIsVerifying(true);
    setVerificationData(null);

    if (onVerifyMemo) {
      onVerifyMemo(memo);
    }

    try {
      // First try local backend / Firebase, fallback to GAS
      const res = await fetch(`/api/verify-certificate?memo=${encodeURIComponent(memo)}`);
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.certificate) {
          setVerificationData(json.certificate);
          setIsVerifying(false);
          return;
        }
      }

      // GAS Fallback
      const gasRes = await verifyCertificateFromGas(memo);
      if (gasRes.success && gasRes.data) {
        setVerificationData(gasRes.data);
      } else {
        setVerificationData({ notFound: true, memoNo: memo });
      }
    } catch (e) {
      setVerificationData({ notFound: true, memoNo: memo });
    } finally {
      setIsVerifying(false);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualMemo.trim()) return;
    performVerification(manualMemo.trim());
  };

  const resetScanner = () => {
    setLastScannedResult(null);
    setVerificationData(null);
    setManualMemo('');
    startCamera();
  };

  return (
    <div id="qr-scanner-page" className="max-w-3xl mx-auto p-4 sm:p-6 bg-white rounded-2xl shadow-up-card border border-emerald-100">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-emerald-100 pb-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-800">
            <Camera className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-emerald-950">কিউআর কোড স্ক্যানার ও যাচাইকরণ</h2>
            <p className="text-xs text-slate-500">০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল ভেরিফিকেশন</p>
          </div>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg hover:bg-slate-200"
          >
            বন্ধ করুন
          </button>
        )}
      </div>

      {/* Main Scanner Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        {/* Camera Viewport */}
        <div className="relative rounded-2xl overflow-hidden bg-slate-950 aspect-square flex items-center justify-center border-2 border-emerald-600 shadow-inner">
          <video
            ref={videoRef}
            className="w-full h-full object-cover"
            playsInline
            muted
          />

          {/* Scanner Overlay Frame */}
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center p-8">
            <div className="w-48 h-48 sm:w-56 sm:h-56 relative border-2 border-emerald-400/60 rounded-xl bg-emerald-500/5">
              {/* Gold Corner Accents */}
              <div className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-amber-400 rounded-tl" />
              <div className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-amber-400 rounded-tr" />
              <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-amber-400 rounded-bl" />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-amber-400 rounded-br" />

              {/* Animated Scan Line */}
              {isScanning && (
                <div className="w-full h-0.5 bg-emerald-400 shadow-up-gold-glow animate-pulse absolute top-1/2 -translate-y-1/2" />
              )}
            </div>
          </div>

          {/* Camera Error Message */}
          {cameraError && (
            <div className="absolute inset-0 bg-slate-900/90 flex flex-col items-center justify-center p-6 text-center text-white">
              <AlertCircle className="w-10 h-10 text-amber-400 mb-3" />
              <p className="text-sm text-slate-200 mb-4">{cameraError}</p>
              <button
                onClick={startCamera}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-xs font-semibold flex items-center gap-2"
              >
                <RefreshCw className="w-3.5 h-3.5" /> পুনরায় চেষ্টা করুন
              </button>
            </div>
          )}
        </div>

        {/* Manual Input & Verification Result Card */}
        <div className="space-y-4">
          {/* Manual Input Form */}
          <form onSubmit={handleManualSubmit} className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-100">
            <label className="block text-xs font-semibold text-emerald-950 mb-2">
              ম্যানুয়ালি স্মারক / সনদ নম্বর লিখুন:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={manualMemo}
                onChange={(e) => setManualMemo(e.target.value)}
                placeholder="যেমন: BAU-2026-0042 বা BUP-..."
                className="flex-1 px-3 py-2 text-sm bg-white border border-emerald-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
              <button
                type="submit"
                disabled={isVerifying || !manualMemo.trim()}
                className="px-4 py-2 bg-emerald-800 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Search className="w-3.5 h-3.5" /> যাচাই
              </button>
            </div>
          </form>

          {/* Verification Status Feedback */}
          {isVerifying && (
            <div className="p-6 text-center bg-slate-50 rounded-xl border border-slate-200">
              <RefreshCw className="w-6 h-6 text-emerald-700 animate-spin mx-auto mb-2" />
              <p className="text-xs font-medium text-slate-600">সার্ভার থেকে সনদ ভেরিফাই করা হচ্ছে...</p>
            </div>
          )}

          {/* Result Card */}
          {verificationData && !isVerifying && (
            <div className="p-5 rounded-xl border transition-all animate-fadeIn">
              {verificationData.notFound ? (
                <div className="text-center py-4 bg-red-50/70 border border-red-200 rounded-xl p-4">
                  <XCircle className="w-10 h-10 text-red-600 mx-auto mb-2" />
                  <h3 className="text-base font-bold text-red-900">সনদ পাওয়া যায়নি বা সঠিক নয়</h3>
                  <p className="text-xs text-red-700 mt-1">স্মারক নং: {verificationData.memoNo}</p>
                  <p className="text-xs text-slate-500 mt-2">অনুগ্রহ করে সঠিক কিউআর কোড বা সনদ নম্বর দিন।</p>
                </div>
              ) : (
                <div className="bg-emerald-50/70 border border-emerald-300 rounded-xl p-4">
                  <div className="flex items-center gap-2 text-emerald-900 mb-3">
                    <ShieldCheck className="w-6 h-6 text-emerald-700" />
                    <div>
                      <h3 className="text-sm font-bold">ভেরিফাইড ও আসল সনদ</h3>
                      <span className="text-[11px] text-emerald-700 font-mono font-medium">
                        স্মারক: {verificationData.memoNo || verificationData.id}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-700 border-t border-emerald-200/60 pt-3">
                    <div className="flex justify-between">
                      <span className="text-slate-500">নাগরিকের নাম:</span>
                      <span className="font-semibold text-slate-900">{verificationData.citizen?.name || verificationData.name || 'তথ্য উপলব্ধ'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">সনদের ধরন:</span>
                      <span className="font-medium text-emerald-900">{verificationData.serviceType || verificationData.certType || 'প্রত্যয়নপত্র'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">গ্রাম ও ওয়ার্ড:</span>
                      <span>{verificationData.citizen?.village || 'বহেড়াতৈল'}, ওয়ার্ড নং {verificationData.citizen?.ward || '০২'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">ইস্যুর তারিখ:</span>
                      <span>{verificationData.issueDate || verificationData.createdAt || 'অফিসিয়াল রেকর্ড'}</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-emerald-200/60 flex items-center justify-between">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-200/70 text-emerald-900">
                      <CheckCircle2 className="w-3 h-3 text-emerald-700" /> সক্রিয় অনুমোদিত
                    </span>
                    <button
                      onClick={resetScanner}
                      className="text-xs text-emerald-800 font-semibold hover:underline flex items-center gap-1"
                    >
                      <RefreshCw className="w-3 h-3" /> পরবর্তী স্ক্যান
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
