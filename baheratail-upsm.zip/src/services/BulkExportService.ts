import { CertificateRecord, CitizenAccountRecord, UnionParishadConfig } from '../types';

export type ExportFormat = 'csv' | 'tsv' | 'json' | 'google-sheets-clipboard';

export interface ExportColumnDefinition<T> {
  key: string;
  label: string;
  accessor: (item: T, index: number, config?: UnionParishadConfig) => string | number;
  defaultSelected?: boolean;
  category?: 'identity' | 'address' | 'certificate' | 'administrative' | 'contact';
}

export interface ExportFilterOptions {
  ward?: string;
  village?: string;
  category?: string;
  certType?: string;
  dateFrom?: string;
  dateTo?: string;
  gender?: string;
  occupation?: string;
  status?: string;
  searchQuery?: string;
}

export interface BulkExportOptions<T = any> {
  format?: ExportFormat;
  filename?: string;
  includeHeaders?: boolean;
  selectedColumns?: string[]; // Column keys
  filters?: ExportFilterOptions;
  config?: UnionParishadConfig;
  customTitle?: string;
}

// ---------------------------------------------------------------------------
// 1. Citizen Records Column Definitions
// ---------------------------------------------------------------------------
export const CITIZEN_EXPORT_COLUMNS: ExportColumnDefinition<CitizenAccountRecord>[] = [
  {
    key: 'sl',
    label: 'ক্রমিক নং',
    accessor: (_, index) => index + 1,
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'id',
    label: 'সিটিজেন আইডি',
    accessor: (c) => c.id || '',
    defaultSelected: false,
    category: 'administrative'
  },
  {
    key: 'name',
    label: 'নাগরিকের নাম',
    accessor: (c) => c.name || '',
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'father',
    label: 'পিতা / অভিভাবক',
    accessor: (c) => c.father || '',
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'mother',
    label: 'মাতার নাম',
    accessor: (c) => c.mother || '',
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'spouse',
    label: 'স্বামী / স্ত্রী',
    accessor: (c) => c.spouseName || '',
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'gender',
    label: 'লিঙ্গ',
    accessor: (c) => c.gender || 'পুরুষ',
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'age',
    label: 'বয়স',
    accessor: (c) => (c.age !== undefined && c.age !== null && c.age > 0 ? `${c.age} বছর` : ''),
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'dob',
    label: 'জন্ম তারিখ',
    accessor: (c) => c.dateOfBirth || '',
    defaultSelected: false,
    category: 'identity'
  },
  {
    key: 'occupation',
    label: 'পেশা',
    accessor: (c) => c.occupation || '',
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'village',
    label: 'গ্রাম',
    accessor: (c) => c.village || '',
    defaultSelected: true,
    category: 'address'
  },
  {
    key: 'ward',
    label: 'ওয়ার্ড নং',
    accessor: (c) => (c.wardNo ? `ওয়ার্ড ${c.wardNo}` : ''),
    defaultSelected: true,
    category: 'address'
  },
  {
    key: 'holding',
    label: 'হোল্ডিং নম্বর',
    accessor: (c) => c.holdingNo || '',
    defaultSelected: true,
    category: 'address'
  },
  {
    key: 'postOffice',
    label: 'ডাকঘর',
    accessor: (c) => c.postOffice || 'বহেড়াতৈল',
    defaultSelected: false,
    category: 'address'
  },
  {
    key: 'postCode',
    label: 'পোস্ট কোড',
    accessor: (c) => c.postCode || '১৯৫০',
    defaultSelected: false,
    category: 'address'
  },
  {
    key: 'nid',
    label: 'জাতীয় পরিচয়পত্র (NID)',
    accessor: (c) => (c.nid ? `'${c.nid}` : ''), // prepending quote for Excel numeric protection
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'birthNo',
    label: 'জন্ম নিবন্ধন নম্বর',
    accessor: (c) => (c.birthNo ? `'${c.birthNo}` : ''),
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'mobile',
    label: 'মোবাইল নম্বর',
    accessor: (c) => (c.mobile ? `'${c.mobile}` : ''),
    defaultSelected: true,
    category: 'contact'
  },
  {
    key: 'totalCertificates',
    label: 'মোট ইস্যুকৃত সনদ',
    accessor: (c) => c.totalCertificates || 0,
    defaultSelected: true,
    category: 'certificate'
  },
  {
    key: 'lastCertificateType',
    label: 'সর্বশেষ সনদ ধরন',
    accessor: (c) => c.lastCertificateType || 'কোনো সনদ নেই',
    defaultSelected: true,
    category: 'certificate'
  },
  {
    key: 'lastCertificateDate',
    label: 'সর্বশেষ সনদের তারিখ',
    accessor: (c) => c.lastCertificateDate || '',
    defaultSelected: true,
    category: 'certificate'
  },
  {
    key: 'registeredAt',
    label: 'নিবন্ধন তারিখ',
    accessor: (c) => (c.registeredAt ? c.registeredAt.split('T')[0] : ''),
    defaultSelected: false,
    category: 'administrative'
  }
];

// ---------------------------------------------------------------------------
// 2. Certificate Records Column Definitions
// ---------------------------------------------------------------------------
export const CERTIFICATE_EXPORT_COLUMNS: ExportColumnDefinition<CertificateRecord>[] = [
  {
    key: 'sl',
    label: 'ক্রমিক নং',
    accessor: (_, index) => index + 1,
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'memoNo',
    label: 'স্মারক / ট্র্যাকিং নম্বর',
    accessor: (c) => c.memoNo || '',
    defaultSelected: true,
    category: 'administrative'
  },
  {
    key: 'issueDate',
    label: 'ইস্যুর তারিখ (বাংলা)',
    accessor: (c) => c.issueDate || '',
    defaultSelected: true,
    category: 'administrative'
  },
  {
    key: 'issueDateEn',
    label: 'ইস্যুর তারিখ (ইংরেজি)',
    accessor: (c) => c.issueDateEn || (c.createdAt ? c.createdAt.split('T')[0] : ''),
    defaultSelected: false,
    category: 'administrative'
  },
  {
    key: 'category',
    label: 'সনদের শ্রেণি / ক্যাটাগরি',
    accessor: (c) => c.category || 'নাগরিক সেবা',
    defaultSelected: true,
    category: 'certificate'
  },
  {
    key: 'typeLabel',
    label: 'সনদের পূর্ণ বিবরণ / ধরন',
    accessor: (c) => c.typeLabel || '',
    defaultSelected: true,
    category: 'certificate'
  },
  {
    key: 'citizenName',
    label: 'নাগরিকের নাম',
    accessor: (c) => c.citizen?.name || '',
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'fatherOrSpouse',
    label: 'পিতা / স্বামী',
    accessor: (c) => c.citizen?.father || c.citizen?.spouseName || '',
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'mother',
    label: 'মাতার নাম',
    accessor: (c) => c.citizen?.mother || '',
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'gender',
    label: 'লিঙ্গ',
    accessor: (c) => c.citizen?.gender || 'পুরুষ',
    defaultSelected: false,
    category: 'identity'
  },
  {
    key: 'village',
    label: 'গ্রাম',
    accessor: (c) => c.citizen?.village || '',
    defaultSelected: true,
    category: 'address'
  },
  {
    key: 'wardNo',
    label: 'ওয়ার্ড নং',
    accessor: (c) => (c.citizen?.wardNo ? `ওয়ার্ড ${c.citizen.wardNo}` : ''),
    defaultSelected: true,
    category: 'address'
  },
  {
    key: 'holdingNo',
    label: 'হোল্ডিং নম্বর',
    accessor: (c) => c.citizen?.holdingNo || (c.extra?.simpleFields ? c.extra.simpleFields['holdingNo'] : '') || '',
    defaultSelected: false,
    category: 'address'
  },
  {
    key: 'nid',
    label: 'জাতীয় পরিচয়পত্র (NID)',
    accessor: (c) => (c.citizen?.nid ? `'${c.citizen.nid}` : ''),
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'birthNo',
    label: 'জন্ম নিবন্ধন নম্বর',
    accessor: (c) => (c.citizen?.birthNo ? `'${c.citizen.birthNo}` : ''),
    defaultSelected: true,
    category: 'identity'
  },
  {
    key: 'mobile',
    label: 'মোবাইল নম্বর',
    accessor: (c) => (c.citizen?.mobile ? `'${c.citizen.mobile}` : ''),
    defaultSelected: true,
    category: 'contact'
  },
  {
    key: 'feeAmount',
    label: 'ফি / শুল্ক (টাকা)',
    accessor: (c) => (c.feeAmount !== undefined ? `${c.feeAmount} ৳` : '৫০ ৳'),
    defaultSelected: true,
    category: 'administrative'
  },
  {
    key: 'status',
    label: 'অনুমোদনের স্ট্যাটাস',
    accessor: (c) => {
      switch (c.status) {
        case 'issued':
          return 'ইস্যুকৃত (সক্রিয়)';
        case 'approved':
          return 'অনুমোদিত';
        case 'pending_approval':
          return 'অনুমোদন অপেক্ষায়';
        case 'cancelled':
        case 'revoked':
          return 'বাতিলকৃত';
        case 'draft':
          return 'খসড়া (ড্রাফট)';
        default:
          return 'ইস্যুকৃত';
      }
    },
    defaultSelected: true,
    category: 'administrative'
  },
  {
    key: 'issuedBy',
    label: 'ইস্যুকারী কর্মকর্তা',
    accessor: (c) => c.issuedBy || 'ইউপি সচিব',
    defaultSelected: true,
    category: 'administrative'
  },
  {
    key: 'approvedBy',
    label: 'অনুমোদনকারী চেয়ারম্যান',
    accessor: (c) => c.approvedBy || '',
    defaultSelected: false,
    category: 'administrative'
  },
  {
    key: 'verificationUrl',
    label: 'অনলাইন যাচাই লিংক (QR Link)',
    accessor: (c, _, config) => {
      if (c.verificationUrl && c.verificationUrl.startsWith('http')) {
        return c.verificationUrl;
      }
      const domain = typeof window !== 'undefined' ? window.location.origin : 'https://upsm-baheratail.vercel.app';
      return `${domain}/verify/${encodeURIComponent(c.memoNo || c.id)}`;
    },
    defaultSelected: true,
    category: 'administrative'
  },
  {
    key: 'biometricVerified',
    label: 'বায়োমেট্রিক অথেন্টিকেশন',
    accessor: (c) => (c.biometricVerified ? 'সত্যায়িত (WebAuthn / Passkey)' : 'স্বাভাবিক'),
    defaultSelected: false,
    category: 'administrative'
  }
];

// ---------------------------------------------------------------------------
// 3. Helper Formatter Functions
// ---------------------------------------------------------------------------

/**
 * Escape string value for CSV (handles quotes, commas, line breaks)
 */
function escapeCsvValue(val: string | number): string {
  if (val === null || val === undefined) return '""';
  const str = String(val);
  return `"${str.replace(/"/g, '""')}"`;
}

/**
 * Escape string value for TSV / Google Sheets clipboard (handles tabs, newlines)
 */
function escapeTsvValue(val: string | number): string {
  if (val === null || val === undefined) return '';
  const str = String(val);
  // Replace line breaks and tabs with spaces for clean tabular paste
  return str.replace(/\t/g, ' ').replace(/\r?\n/g, ' ');
}

// ---------------------------------------------------------------------------
// 4. BulkExportService Class Implementation
// ---------------------------------------------------------------------------

class BulkExportService {
  /**
   * Filter Citizens by options
   */
  filterCitizens(citizens: CitizenAccountRecord[], filters?: ExportFilterOptions): CitizenAccountRecord[] {
    if (!filters) return citizens;

    return citizens.filter((c) => {
      if (filters.ward && c.wardNo !== filters.ward) return false;
      if (filters.village && c.village !== filters.village) return false;
      if (filters.gender && filters.gender !== 'সব' && c.gender !== filters.gender) return false;
      if (filters.occupation && c.occupation !== filters.occupation) return false;
      
      if (filters.searchQuery) {
        const q = filters.searchQuery.toLowerCase();
        const matchName = c.name?.toLowerCase().includes(q);
        const matchNid = c.nid?.includes(q) || c.birthNo?.includes(q);
        const matchMobile = c.mobile?.includes(q);
        const matchVillage = c.village?.toLowerCase().includes(q);
        const matchHolding = c.holdingNo?.toLowerCase().includes(q);
        if (!matchName && !matchNid && !matchMobile && !matchVillage && !matchHolding) return false;
      }

      return true;
    });
  }

  /**
   * Filter Certificates by options
   */
  filterCertificates(certificates: CertificateRecord[], filters?: ExportFilterOptions): CertificateRecord[] {
    if (!filters) return certificates;

    return certificates.filter((c) => {
      if (filters.ward && c.citizen?.wardNo !== filters.ward) return false;
      if (filters.village && c.citizen?.village !== filters.village) return false;
      if (filters.category && filters.category !== 'সব ধরন' && c.category !== filters.category) return false;
      if (filters.certType && filters.certType !== 'সকল সনদের ধরন' && c.typeLabel !== filters.certType) return false;
      if (filters.status && filters.status !== 'all' && c.status !== filters.status) return false;

      if (filters.dateFrom) {
        const itemDate = c.issueDateEn || (c.createdAt ? c.createdAt.split('T')[0] : '');
        if (itemDate && itemDate < filters.dateFrom) return false;
      }

      if (filters.dateTo) {
        const itemDate = c.issueDateEn || (c.createdAt ? c.createdAt.split('T')[0] : '');
        if (itemDate && itemDate > filters.dateTo) return false;
      }

      if (filters.searchQuery) {
        const q = filters.searchQuery.toLowerCase();
        const matchMemo = c.memoNo?.toLowerCase().includes(q);
        const matchName = c.citizen?.name?.toLowerCase().includes(q);
        const matchNid = c.citizen?.nid?.includes(q) || c.citizen?.birthNo?.includes(q);
        const matchType = c.typeLabel?.toLowerCase().includes(q);
        const matchVillage = c.citizen?.village?.toLowerCase().includes(q);
        if (!matchMemo && !matchName && !matchNid && !matchType && !matchVillage) return false;
      }

      return true;
    });
  }

  // =========================================================================
  // Citizen Records Generators
  // =========================================================================

  /**
   * Generate CSV content for Citizen Master Register
   */
  generateCitizensCsv(
    citizens: CitizenAccountRecord[],
    options: BulkExportOptions<CitizenAccountRecord> = {}
  ): string {
    const activeCitizens = this.filterCitizens(citizens, options.filters);
    const columns = this.getColumnsForCitizens(options.selectedColumns);

    const headerRow = columns.map((col) => escapeCsvValue(col.label)).join(',');
    const dataRows = activeCitizens.map((citizen, idx) =>
      columns.map((col) => escapeCsvValue(col.accessor(citizen, idx, options.config))).join(',')
    );

    // UTF-8 BOM \uFEFF for perfect Excel Bengali rendering
    return '\uFEFF' + [headerRow, ...dataRows].join('\r\n');
  }

  /**
   * Generate Google Sheets Compatible TSV content for Citizen Master Register
   */
  generateCitizensTsv(
    citizens: CitizenAccountRecord[],
    options: BulkExportOptions<CitizenAccountRecord> = {}
  ): string {
    const activeCitizens = this.filterCitizens(citizens, options.filters);
    const columns = this.getColumnsForCitizens(options.selectedColumns);

    const headerRow = columns.map((col) => escapeTsvValue(col.label)).join('\t');
    const dataRows = activeCitizens.map((citizen, idx) =>
      columns.map((col) => escapeTsvValue(col.accessor(citizen, idx, options.config))).join('\t')
    );

    return [headerRow, ...dataRows].join('\n');
  }

  /**
   * Generate JSON Backup for Citizen Master Register
   */
  generateCitizensJson(
    citizens: CitizenAccountRecord[],
    options: BulkExportOptions<CitizenAccountRecord> = {}
  ): string {
    const activeCitizens = this.filterCitizens(citizens, options.filters);
    const payload = {
      metadata: {
        exportType: 'CITIZEN_MASTER_REGISTER',
        unionName: options.config?.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ',
        upazila: options.config?.upazila || 'সখিপুর',
        district: options.config?.district || 'টাঙ্গাইল',
        exportedAt: new Date().toISOString(),
        exportedAtBn: new Date().toLocaleString('bn-BD', { timeZone: 'Asia/Dhaka' }),
        totalRecords: activeCitizens.length,
        version: '4.2.0'
      },
      records: activeCitizens
    };
    return JSON.stringify(payload, null, 2);
  }

  // =========================================================================
  // Certificate Records Generators
  // =========================================================================

  /**
   * Generate CSV content for Certificate Logs
   */
  generateCertificatesCsv(
    certificates: CertificateRecord[],
    options: BulkExportOptions<CertificateRecord> = {}
  ): string {
    const activeCertificates = this.filterCertificates(certificates, options.filters);
    const columns = this.getColumnsForCertificates(options.selectedColumns);

    const headerRow = columns.map((col) => escapeCsvValue(col.label)).join(',');
    const dataRows = activeCertificates.map((cert, idx) =>
      columns.map((col) => escapeCsvValue(col.accessor(cert, idx, options.config))).join(',')
    );

    return '\uFEFF' + [headerRow, ...dataRows].join('\r\n');
  }

  /**
   * Generate Google Sheets Compatible TSV content for Certificate Logs
   */
  generateCertificatesTsv(
    certificates: CertificateRecord[],
    options: BulkExportOptions<CertificateRecord> = {}
  ): string {
    const activeCertificates = this.filterCertificates(certificates, options.filters);
    const columns = this.getColumnsForCertificates(options.selectedColumns);

    const headerRow = columns.map((col) => escapeTsvValue(col.label)).join('\t');
    const dataRows = activeCertificates.map((cert, idx) =>
      columns.map((col) => escapeTsvValue(col.accessor(cert, idx, options.config))).join('\t')
    );

    return [headerRow, ...dataRows].join('\n');
  }

  /**
   * Generate JSON Backup for Certificate Logs
   */
  generateCertificatesJson(
    certificates: CertificateRecord[],
    options: BulkExportOptions<CertificateRecord> = {}
  ): string {
    const activeCertificates = this.filterCertificates(certificates, options.filters);
    const payload = {
      metadata: {
        exportType: 'CERTIFICATE_REGISTRY_LOGS',
        unionName: options.config?.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ',
        upazila: options.config?.upazila || 'সখিপুর',
        district: options.config?.district || 'টাঙ্গাইল',
        exportedAt: new Date().toISOString(),
        exportedAtBn: new Date().toLocaleString('bn-BD', { timeZone: 'Asia/Dhaka' }),
        totalRecords: activeCertificates.length,
        version: '4.2.0'
      },
      records: activeCertificates
    };
    return JSON.stringify(payload, null, 2);
  }

  // =========================================================================
  // Download & Clipboard Actions
  // =========================================================================

  /**
   * Trigger browser file download
   */
  downloadFile(content: string, filename: string, mimeType: string = 'text/csv;charset=utf-8;'): void {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  /**
   * Copy formatted text into clipboard for instant paste into Google Sheets / Excel
   */
  async copyToClipboard(content: string): Promise<boolean> {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(content);
        return true;
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = content;
        textarea.style.position = 'fixed';
        textarea.style.left = '-999999px';
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        const success = document.execCommand('copy');
        document.body.removeChild(textarea);
        return success;
      }
    } catch (err) {
      console.error('[BulkExportService] Clipboard write error:', err);
      return false;
    }
  }

  // =========================================================================
  // Convenient High-Level Citizen Export Methods
  // =========================================================================

  /**
   * Export & Download Citizen CSV file
   */
  exportCitizensToCsvFile(
    citizens: CitizenAccountRecord[],
    config?: UnionParishadConfig,
    options: BulkExportOptions<CitizenAccountRecord> = {}
  ): void {
    const opts = { ...options, config };
    const content = this.generateCitizensCsv(citizens, opts);
    const dateStr = new Date().toISOString().substring(0, 10);
    const upNameSlug = (config?.upName || 'Baheratail_UP').replace(/\s+/g, '_');
    const filename = opts.filename || `Citizen_Master_Register_${upNameSlug}_${dateStr}.csv`;
    this.downloadFile(content, filename, 'text/csv;charset=utf-8;');
  }

  /**
   * Export & Download Citizen TSV file
   */
  exportCitizensToTsvFile(
    citizens: CitizenAccountRecord[],
    config?: UnionParishadConfig,
    options: BulkExportOptions<CitizenAccountRecord> = {}
  ): void {
    const opts = { ...options, config };
    const content = this.generateCitizensTsv(citizens, opts);
    const dateStr = new Date().toISOString().substring(0, 10);
    const upNameSlug = (config?.upName || 'Baheratail_UP').replace(/\s+/g, '_');
    const filename = opts.filename || `Citizen_Master_Register_${upNameSlug}_${dateStr}.tsv`;
    this.downloadFile(content, filename, 'text/tab-separated-values;charset=utf-8;');
  }

  /**
   * Export & Download Citizen JSON file
   */
  exportCitizensToJsonFile(
    citizens: CitizenAccountRecord[],
    config?: UnionParishadConfig,
    options: BulkExportOptions<CitizenAccountRecord> = {}
  ): void {
    const opts = { ...options, config };
    const content = this.generateCitizensJson(citizens, opts);
    const dateStr = new Date().toISOString().substring(0, 10);
    const upNameSlug = (config?.upName || 'Baheratail_UP').replace(/\s+/g, '_');
    const filename = opts.filename || `Citizen_Master_Backup_${upNameSlug}_${dateStr}.json`;
    this.downloadFile(content, filename, 'application/json;charset=utf-8;');
  }

  /**
   * Copy Citizen data formatted for Google Sheets
   */
  async copyCitizensForGoogleSheets(
    citizens: CitizenAccountRecord[],
    config?: UnionParishadConfig,
    options: BulkExportOptions<CitizenAccountRecord> = {}
  ): Promise<boolean> {
    const opts = { ...options, config };
    const content = this.generateCitizensTsv(citizens, opts);
    return await this.copyToClipboard(content);
  }

  // =========================================================================
  // Convenient High-Level Certificate Export Methods
  // =========================================================================

  /**
   * Export & Download Certificate Logs CSV file
   */
  exportCertificatesToCsvFile(
    certificates: CertificateRecord[],
    config?: UnionParishadConfig,
    options: BulkExportOptions<CertificateRecord> = {}
  ): void {
    const opts = { ...options, config };
    const content = this.generateCertificatesCsv(certificates, opts);
    const dateStr = new Date().toISOString().substring(0, 10);
    const upNameSlug = (config?.upName || 'Baheratail_UP').replace(/\s+/g, '_');
    const filename = opts.filename || `Certificate_Registry_Logs_${upNameSlug}_${dateStr}.csv`;
    this.downloadFile(content, filename, 'text/csv;charset=utf-8;');
  }

  /**
   * Export & Download Certificate Logs TSV file
   */
  exportCertificatesToTsvFile(
    certificates: CertificateRecord[],
    config?: UnionParishadConfig,
    options: BulkExportOptions<CertificateRecord> = {}
  ): void {
    const opts = { ...options, config };
    const content = this.generateCertificatesTsv(certificates, opts);
    const dateStr = new Date().toISOString().substring(0, 10);
    const upNameSlug = (config?.upName || 'Baheratail_UP').replace(/\s+/g, '_');
    const filename = opts.filename || `Certificate_Registry_Logs_${upNameSlug}_${dateStr}.tsv`;
    this.downloadFile(content, filename, 'text/tab-separated-values;charset=utf-8;');
  }

  /**
   * Export & Download Certificate Logs JSON file
   */
  exportCertificatesToJsonFile(
    certificates: CertificateRecord[],
    config?: UnionParishadConfig,
    options: BulkExportOptions<CertificateRecord> = {}
  ): void {
    const opts = { ...options, config };
    const content = this.generateCertificatesJson(certificates, opts);
    const dateStr = new Date().toISOString().substring(0, 10);
    const upNameSlug = (config?.upName || 'Baheratail_UP').replace(/\s+/g, '_');
    const filename = opts.filename || `Certificate_Registry_Backup_${upNameSlug}_${dateStr}.json`;
    this.downloadFile(content, filename, 'application/json;charset=utf-8;');
  }

  /**
   * Copy Certificate Logs formatted for Google Sheets
   */
  async copyCertificatesForGoogleSheets(
    certificates: CertificateRecord[],
    config?: UnionParishadConfig,
    options: BulkExportOptions<CertificateRecord> = {}
  ): Promise<boolean> {
    const opts = { ...options, config };
    const content = this.generateCertificatesTsv(certificates, opts);
    return await this.copyToClipboard(content);
  }

  // =========================================================================
  // Internal Column Resolvers
  // =========================================================================

  private getColumnsForCitizens(selectedKeys?: string[]): ExportColumnDefinition<CitizenAccountRecord>[] {
    if (!selectedKeys || selectedKeys.length === 0) {
      return CITIZEN_EXPORT_COLUMNS.filter((c) => c.defaultSelected);
    }
    return CITIZEN_EXPORT_COLUMNS.filter((c) => selectedKeys.includes(c.key));
  }

  private getColumnsForCertificates(selectedKeys?: string[]): ExportColumnDefinition<CertificateRecord>[] {
    if (!selectedKeys || selectedKeys.length === 0) {
      return CERTIFICATE_EXPORT_COLUMNS.filter((c) => c.defaultSelected);
    }
    return CERTIFICATE_EXPORT_COLUMNS.filter((c) => selectedKeys.includes(c.key));
  }
}

export const bulkExportService = new BulkExportService();
