import { BiometricLoginEventRecord, BiometricLoginDeviceInfo } from '../types';

const STORAGE_KEY = 'bup_biometric_login_history';

/**
 * Automatically inspects the current client environment to detect OS, Browser, Hardware, and Biometric capabilities
 */
export function detectCurrentDeviceInfo(overrideDeviceName?: string, credentialId?: string): BiometricLoginDeviceInfo {
  if (typeof window === 'undefined') {
    return {
      platform: 'Server / Node',
      browser: 'Unknown',
      deviceType: 'desktop',
      deviceName: overrideDeviceName || 'Server Environment',
      authenticatorType: 'WebAuthn Virtual Sensor'
    };
  }

  const ua = navigator.userAgent;
  let platform = 'Unknown OS';
  let deviceType: 'desktop' | 'mobile' | 'tablet' = 'desktop';

  // Detect Platform / OS
  if (/Macintosh|Mac OS X/i.test(ua)) {
    platform = 'macOS';
    deviceType = 'desktop';
  } else if (/Windows NT 10.0|Windows NT 11.0|Windows/i.test(ua)) {
    platform = 'Windows 10/11';
    deviceType = 'desktop';
  } else if (/iPhone/i.test(ua)) {
    platform = 'iOS (iPhone)';
    deviceType = 'mobile';
  } else if (/iPad/i.test(ua)) {
    platform = 'iPadOS';
    deviceType = 'tablet';
  } else if (/Android/i.test(ua)) {
    platform = 'Android OS';
    deviceType = /Mobile/i.test(ua) ? 'mobile' : 'tablet';
  } else if (/Linux/i.test(ua)) {
    platform = 'Linux Desktop';
    deviceType = 'desktop';
  }

  // Detect Browser
  let browser = 'Chrome';
  if (/Edg\//i.test(ua)) {
    browser = 'Microsoft Edge';
  } else if (/Chrome\//i.test(ua) && !/Edg\//i.test(ua)) {
    browser = 'Google Chrome';
  } else if (/Safari\//i.test(ua) && !/Chrome\//i.test(ua)) {
    browser = 'Apple Safari';
  } else if (/Firefox\//i.test(ua)) {
    browser = 'Mozilla Firefox';
  } else if (/OPR\//i.test(ua)) {
    browser = 'Opera';
  }

  // Authenticator Type
  let authenticatorType = 'FIDO2 / WebAuthn Platform Biometrics';
  if (platform === 'macOS') {
    authenticatorType = 'Apple Touch ID / Secure Enclave';
  } else if (platform.includes('Windows')) {
    authenticatorType = 'Windows Hello (Fingerprint / Facial Recognition)';
  } else if (platform.includes('iOS')) {
    authenticatorType = 'Apple Face ID / Touch ID';
  } else if (platform.includes('Android')) {
    authenticatorType = 'Android BiometricPrompt (Fingerprint / Face)';
  }

  const screenResolution = `${window.screen.width}x${window.screen.height}`;
  const touchSupport = navigator.maxTouchPoints > 0;

  // Name representation
  const defaultDeviceName = `${platform} • ${browser} (${touchSupport ? 'Touch Enabled' : 'Workstation'})`;

  return {
    platform,
    browser,
    deviceType,
    deviceName: overrideDeviceName || defaultDeviceName,
    authenticatorType,
    credentialId,
    userAgent: ua,
    screenResolution,
    ipOrOrigin: window.location.origin,
    touchSupport
  };
}

/**
 * Format timestamp in Bengali and English
 */
export function formatBiometricEventTimestamp(date: Date = new Date()): string {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  const toBn = (n: number | string) => String(n).split('').map(d => bnDigits[parseInt(d, 10)] || d).join('');

  const day = toBn(date.getDate());
  const months = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
  const month = months[date.getMonth()];
  const year = toBn(date.getFullYear());

  const hours = date.getHours();
  const minutes = date.getMinutes();
  const seconds = date.getSeconds();
  const period = hours >= 12 ? 'বিকাল/রাত' : 'সকাল';
  const displayHours = hours % 12 || 12;

  const bnTime = `${toBn(displayHours)}:${toBn(minutes.toString().padStart(2, '0'))}:${toBn(seconds.toString().padStart(2, '0'))}`;
  const enFormatted = date.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  });

  return `${day} ${month} ${year}, ${period} ${bnTime} (${enFormatted})`;
}

/**
 * Record a successful biometric login event to persistent storage
 */
export function recordBiometricLoginEvent(params: {
  adminEmail: string;
  adminName: string;
  adminRole: string;
  adminDesignation?: string;
  authMethod?: string;
  credentialId?: string;
  deviceName?: string;
  context?: string;
  status?: 'SUCCESS' | 'FAILED' | 'CHALLENGE_ELEVATED';
  timestamp?: Date;
}): BiometricLoginEventRecord {
  const now = params.timestamp || new Date();
  const deviceInfo = detectCurrentDeviceInfo(params.deviceName, params.credentialId);

  const event: BiometricLoginEventRecord = {
    id: `bio-evt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    timestamp: now.toISOString(),
    formattedTimestamp: formatBiometricEventTimestamp(now),
    adminEmail: params.adminEmail.toLowerCase().trim(),
    adminName: params.adminName,
    adminRole: params.adminRole,
    adminDesignation: params.adminDesignation || 'ইউপি কর্মকর্তা',
    authMethod: params.authMethod || deviceInfo.authenticatorType,
    status: params.status || 'SUCCESS',
    deviceInfo,
    context: params.context || 'Admin Portal Login',
    checksum: `SHA256-${Math.random().toString(36).substring(2, 10).toUpperCase()}`
  };

  try {
    const existing = getBiometricLoginEvents();
    const updated = [event, ...existing].slice(0, 100); // Keep last 100 events
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));

    // Dispatch global window event for live real-time listeners
    window.dispatchEvent(new CustomEvent('biometric-login-recorded', { detail: event }));
  } catch (e) {
    console.warn('Failed to save biometric login event:', e);
  }

  return event;
}

/**
 * Get all stored biometric login events chronologically (Newest first by default)
 */
export function getBiometricLoginEvents(): BiometricLoginEventRecord[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      // Seed default initial logs so admin can immediately visualize history
      return seedInitialBiometricEventsIfEmpty();
    }
    const parsed: BiometricLoginEventRecord[] = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      return seedInitialBiometricEventsIfEmpty();
    }
    return parsed.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  } catch (e) {
    console.warn('Error reading biometric login events:', e);
    return seedInitialBiometricEventsIfEmpty();
  }
}

/**
 * Delete a specific biometric login event by ID
 */
export function deleteBiometricLoginEvent(id: string): boolean {
  try {
    const events = getBiometricLoginEvents();
    const filtered = events.filter(e => e.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
    window.dispatchEvent(new CustomEvent('biometric-login-recorded', { detail: null }));
    return true;
  } catch (e) {
    console.warn('Failed to delete biometric login event:', e);
    return false;
  }
}

/**
 * Clear all biometric login events
 */
export function clearAllBiometricLoginEvents(): boolean {
  try {
    localStorage.removeItem(STORAGE_KEY);
    window.dispatchEvent(new CustomEvent('biometric-login-recorded', { detail: null }));
    return true;
  } catch (e) {
    console.warn('Failed to clear biometric login events:', e);
    return false;
  }
}

/**
 * Seeds realistic initial biometric login history if storage is completely fresh
 */
export function seedInitialBiometricEventsIfEmpty(): BiometricLoginEventRecord[] {
  const now = new Date();
  
  const sampleEvents: BiometricLoginEventRecord[] = [
    {
      id: `bio-evt-seed-1`,
      timestamp: new Date(now.getTime() - 1000 * 60 * 12).toISOString(), // 12 mins ago
      formattedTimestamp: formatBiometricEventTimestamp(new Date(now.getTime() - 1000 * 60 * 12)),
      adminEmail: 'chairman@boheratoil.gov.bd',
      adminName: 'মো: সোহেল রানা',
      adminRole: 'chairman',
      adminDesignation: 'ইউপি চেয়ারম্যান',
      authMethod: 'Apple Touch ID / Secure Enclave',
      status: 'SUCCESS',
      context: 'Admin Portal Login',
      deviceInfo: {
        platform: 'macOS',
        browser: 'Apple Safari',
        deviceType: 'desktop',
        deviceName: 'MacBook Air M2 (Official Chairman Terminal)',
        authenticatorType: 'Apple Touch ID Platform Sensor',
        credentialId: 'cred-touchid-apple-9843',
        screenResolution: '2560x1664',
        touchSupport: true,
        ipOrOrigin: 'https://boheratoil.up.gov.bd'
      },
      checksum: 'SHA256-BIO-90812FA'
    },
    {
      id: `bio-evt-seed-2`,
      timestamp: new Date(now.getTime() - 1000 * 60 * 85).toISOString(), // 1 hr 25 mins ago
      formattedTimestamp: formatBiometricEventTimestamp(new Date(now.getTime() - 1000 * 60 * 85)),
      adminEmail: 'secretary@boheratoil.gov.bd',
      adminName: 'রফিকুল ইসলাম',
      adminRole: 'secretary',
      adminDesignation: 'ইউপি সচিব',
      authMethod: 'Windows Hello (Fingerprint Sensor)',
      status: 'SUCCESS',
      context: 'Sensitive Action Approval',
      deviceInfo: {
        platform: 'Windows 10/11',
        browser: 'Google Chrome',
        deviceType: 'desktop',
        deviceName: 'Dell Latitude 5420 (Secretary Office PC)',
        authenticatorType: 'Windows Hello Biometric Fingerprint',
        credentialId: 'cred-winhello-sec-1102',
        screenResolution: '1920x1080',
        touchSupport: false,
        ipOrOrigin: 'https://boheratoil.up.gov.bd'
      },
      checksum: 'SHA256-BIO-7721AC3'
    },
    {
      id: `bio-evt-seed-3`,
      timestamp: new Date(now.getTime() - 1000 * 60 * 60 * 5).toISOString(), // 5 hrs ago
      formattedTimestamp: formatBiometricEventTimestamp(new Date(now.getTime() - 1000 * 60 * 60 * 5)),
      adminEmail: 'inbox600900@gmail.com',
      adminName: 'সিস্টেম ডেভেলপার',
      adminRole: 'developer',
      adminDesignation: 'আইটি ইনফ্রাস্ট্রাকচার ও সিস্টেম ডেভেলপার',
      authMethod: 'WebAuthn FIDO2 Platform Biometrics',
      status: 'SUCCESS',
      context: 'Security Matrix & Key Management',
      deviceInfo: {
        platform: 'Windows 10/11',
        browser: 'Microsoft Edge',
        deviceType: 'desktop',
        deviceName: 'Primary IT Workstation (Biometric Security Key)',
        authenticatorType: 'FIDO2 Level 3 Passkey Hardware',
        credentialId: 'cred-fido2-dev-5509',
        screenResolution: '2560x1440',
        touchSupport: true,
        ipOrOrigin: 'https://boheratoil.up.gov.bd'
      },
      checksum: 'SHA256-BIO-44199EB'
    },
    {
      id: `bio-evt-seed-4`,
      timestamp: new Date(now.getTime() - 1000 * 60 * 60 * 22).toISOString(), // Yesterday
      formattedTimestamp: formatBiometricEventTimestamp(new Date(now.getTime() - 1000 * 60 * 60 * 22)),
      adminEmail: 'member1@boheratoil.gov.bd',
      adminName: 'মো: আক্তারুজ্জামান',
      adminRole: 'member',
      adminDesignation: '১নং ওয়ার্ড সদস্য',
      authMethod: 'Android BiometricPrompt (Fingerprint)',
      status: 'SUCCESS',
      context: 'Citizen Registration Fast-Verify',
      deviceInfo: {
        platform: 'Android OS',
        browser: 'Google Chrome Mobile',
        deviceType: 'mobile',
        deviceName: 'Samsung Galaxy Tab A8 (Field Device)',
        authenticatorType: 'Android In-Display Fingerprint',
        credentialId: 'cred-android-m1-4412',
        screenResolution: '1200x2000',
        touchSupport: true,
        ipOrOrigin: 'https://boheratoil.up.gov.bd'
      },
      checksum: 'SHA256-BIO-11988FA'
    }
  ];

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sampleEvents));
  } catch (e) {
    // ignore
  }

  return sampleEvents;
}

/**
 * Export Biometric Login Events to CSV format
 */
export function exportBiometricEventsToCSV(events: BiometricLoginEventRecord[]): void {
  if (!events || events.length === 0) return;

  const headers = [
    'Event ID',
    'ISO Timestamp',
    'Formatted Timestamp',
    'Admin Name',
    'Admin Email',
    'Role',
    'Designation',
    'Status',
    'Auth Method',
    'Device Name',
    'Platform / OS',
    'Browser',
    'Device Type',
    'Authenticator Type',
    'Credential ID',
    'Screen Resolution',
    'Checksum'
  ];

  const rows = events.map(evt => [
    evt.id,
    evt.timestamp,
    `"${evt.formattedTimestamp.replace(/"/g, '""')}"`,
    `"${evt.adminName.replace(/"/g, '""')}"`,
    evt.adminEmail,
    evt.adminRole,
    `"${(evt.adminDesignation || '').replace(/"/g, '""')}"`,
    evt.status,
    `"${evt.authMethod.replace(/"/g, '""')}"`,
    `"${(evt.deviceInfo?.deviceName || '').replace(/"/g, '""')}"`,
    `"${(evt.deviceInfo?.platform || '').replace(/"/g, '""')}"`,
    `"${(evt.deviceInfo?.browser || '').replace(/"/g, '""')}"`,
    evt.deviceInfo?.deviceType || 'desktop',
    `"${(evt.deviceInfo?.authenticatorType || '').replace(/"/g, '""')}"`,
    evt.deviceInfo?.credentialId || '',
    evt.deviceInfo?.screenResolution || '',
    evt.checksum || ''
  ]);

  const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `Biometric_Login_Events_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Export Biometric Login Events to formatted JSON file
 */
export function exportBiometricEventsToJSON(events: BiometricLoginEventRecord[]): void {
  if (!events || events.length === 0) return;
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(events, null, 2));
  const link = document.createElement('a');
  link.setAttribute('href', dataStr);
  link.setAttribute('download', `Biometric_Login_Events_${new Date().toISOString().split('T')[0]}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
