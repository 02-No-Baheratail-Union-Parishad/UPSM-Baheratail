import { DraftCertificate, DraftSyncStats, DraftSyncStatus, CertificateRecord } from '../types';

export const DB_NAME = 'bup_offline_db';
export const DB_VERSION = 2;
export const DRAFTS_STORE = 'draft_certificates';

/**
 * Open or upgrade the IndexedDB instance for offline draft storage
 */
export function openDraftsDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      return reject(new Error('IndexedDB is not supported in this environment'));
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(DRAFTS_STORE)) {
        const store = db.createObjectStore(DRAFTS_STORE, { keyPath: 'id' });
        store.createIndex('syncStatus', 'syncStatus', { unique: false });
        store.createIndex('createdAt', 'createdAt', { unique: false });
        store.createIndex('memoNo', 'memoNo', { unique: false });
        store.createIndex('certificateType', 'certificateType', { unique: false });
        store.createIndex('nid', 'citizen.nid', { unique: false });
      }
    };

    request.onsuccess = (event) => {
      resolve((event.target as IDBOpenDBRequest).result);
    };

    request.onerror = (event) => {
      console.error('Failed to open IndexedDB:', (event.target as IDBOpenDBRequest).error);
      reject((event.target as IDBOpenDBRequest).error);
    };
  });
}

/**
 * Save a new draft or update an existing draft in IndexedDB
 */
export async function saveDraftToIndexedDB(
  draftInput: Partial<DraftCertificate> & { certificateType: string; typeNameBn: string }
): Promise<DraftCertificate> {
  const db = await openDraftsDB();

  const now = new Date().toISOString();
  const id = draftInput.id || `draft_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  const memoNo = draftInput.memoNo || `UP/BAHER/${new Date().getFullYear()}/${Math.floor(1000 + Math.random() * 9000)}`;

  const draft: DraftCertificate = {
    id,
    memoNo,
    certificateType: draftInput.certificateType,
    typeNameBn: draftInput.typeNameBn,
    typeNameEn: draftInput.typeNameEn,
    citizen: {
      name: draftInput.citizen?.name || '',
      father: draftInput.citizen?.father || '',
      mother: draftInput.citizen?.mother || '',
      spouseName: draftInput.citizen?.spouseName || '',
      gender: draftInput.citizen?.gender || 'পুরুষ',
      nid: draftInput.citizen?.nid || '',
      birthNo: draftInput.citizen?.birthNo || '',
      mobile: draftInput.citizen?.mobile || '',
      holdingNo: draftInput.citizen?.holdingNo || '',
      wardNo: draftInput.citizen?.wardNo || '০৫',
      village: draftInput.citizen?.village || 'বহেড়াতৈল',
      postOffice: draftInput.citizen?.postOffice || 'বহেড়াতৈল',
      postCode: draftInput.citizen?.postCode || '১৯৫০'
    },
    formData: draftInput.formData || {},
    generatedText: draftInput.generatedText || '',
    fullRecord: draftInput.fullRecord,
    syncStatus: draftInput.syncStatus || 'pending',
    syncError: draftInput.syncError || undefined,
    retryCount: draftInput.retryCount || 0,
    createdAt: draftInput.createdAt || now,
    updatedAt: now,
    syncedAt: draftInput.syncedAt
  };

  return new Promise((resolve, reject) => {
    const transaction = db.transaction([DRAFTS_STORE], 'readwrite');
    const store = transaction.objectStore(DRAFTS_STORE);
    const request = store.put(draft);

    request.onsuccess = () => {
      notifyDraftsChanged();
      resolve(draft);
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

/**
 * Get all drafts from IndexedDB sorted from newest to oldest
 */
export async function getAllDraftsFromIndexedDB(): Promise<DraftCertificate[]> {
  try {
    const db = await openDraftsDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([DRAFTS_STORE], 'readonly');
      const store = transaction.objectStore(DRAFTS_STORE);
      const request = store.getAll();

      request.onsuccess = () => {
        const results: DraftCertificate[] = request.result || [];
        results.sort((a, b) => new Date(b.updatedAt || b.createdAt).getTime() - new Date(a.updatedAt || a.createdAt).getTime());
        resolve(results);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  } catch (error) {
    console.error('Error getting drafts from IndexedDB:', error);
    return [];
  }
}

/**
 * Get only pending/un-synced drafts
 */
export async function getPendingDraftsFromIndexedDB(): Promise<DraftCertificate[]> {
  const all = await getAllDraftsFromIndexedDB();
  return all.filter((d) => d.syncStatus === 'pending' || d.syncStatus === 'failed' || !d.syncStatus);
}

/**
 * Get a single draft by ID
 */
export async function getDraftById(id: string): Promise<DraftCertificate | null> {
  try {
    const db = await openDraftsDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([DRAFTS_STORE], 'readonly');
      const store = transaction.objectStore(DRAFTS_STORE);
      const request = store.get(id);

      request.onsuccess = () => {
        resolve(request.result || null);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  } catch (error) {
    console.error(`Error getting draft ${id} from IndexedDB:`, error);
    return null;
  }
}

/**
 * Update the sync status of a draft
 */
export async function updateDraftSyncStatus(
  id: string,
  syncStatus: DraftSyncStatus,
  syncError?: string,
  fullRecord?: CertificateRecord
): Promise<void> {
  try {
    const db = await openDraftsDB();
    const existing = await getDraftById(id);
    if (!existing) return;

    existing.syncStatus = syncStatus;
    existing.updatedAt = new Date().toISOString();
    if (syncStatus === 'synced') {
      existing.syncedAt = new Date().toISOString();
      existing.syncError = undefined;
    } else if (syncStatus === 'failed') {
      existing.syncError = syncError || 'আপলোড ব্যর্থ হইয়াছে';
      existing.retryCount = (existing.retryCount || 0) + 1;
    }

    if (fullRecord) {
      existing.fullRecord = fullRecord;
    }

    return new Promise((resolve, reject) => {
      const transaction = db.transaction([DRAFTS_STORE], 'readwrite');
      const store = transaction.objectStore(DRAFTS_STORE);
      const request = store.put(existing);

      request.onsuccess = () => {
        notifyDraftsChanged();
        resolve();
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  } catch (error) {
    console.error(`Error updating draft sync status for ${id}:`, error);
  }
}

/**
 * Delete a draft from IndexedDB
 */
export async function deleteDraftFromIndexedDB(id: string): Promise<void> {
  const db = await openDraftsDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([DRAFTS_STORE], 'readwrite');
    const store = transaction.objectStore(DRAFTS_STORE);
    const request = store.delete(id);

    request.onsuccess = () => {
      notifyDraftsChanged();
      resolve();
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

/**
 * Clear all already-synced drafts to free storage
 */
export async function clearSyncedDraftsFromIndexedDB(): Promise<number> {
  const all = await getAllDraftsFromIndexedDB();
  const synced = all.filter((d) => d.syncStatus === 'synced');
  for (const draft of synced) {
    await deleteDraftFromIndexedDB(draft.id);
  }
  notifyDraftsChanged();
  return synced.length;
}

/**
 * Get count statistics of drafts
 */
export async function getDraftStats(): Promise<DraftSyncStats> {
  const all = await getAllDraftsFromIndexedDB();
  const pending = all.filter((d) => d.syncStatus === 'pending' || !d.syncStatus).length;
  const synced = all.filter((d) => d.syncStatus === 'synced').length;
  const failed = all.filter((d) => d.syncStatus === 'failed').length;

  return {
    total: all.length,
    pending,
    synced,
    failed
  };
}

/**
 * Broadcast event to all listening React components that IndexedDB draft storage has changed
 */
export function notifyDraftsChanged(): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('bup:drafts-changed'));
  }
}
