import { 
  getPendingDraftsFromIndexedDB, 
  getAllDraftsFromIndexedDB,
  updateDraftSyncStatus, 
  getDraftStats,
  notifyDraftsChanged,
  saveDraftToIndexedDB
} from './draftStorage';
import { DraftCertificate, DraftSyncStats, CertificateRecord, UnionParishadConfig } from '../types';
import { saveCertificateToFirebase } from '../firebase';

export interface SyncProgressEvent {
  total: number;
  completed: number;
  currentDraft?: DraftCertificate;
  status: 'idle' | 'syncing' | 'completed' | 'error';
  message: string;
  syncedIds?: string[];
  syncedCount?: number;
}

type SyncProgressCallback = (event: SyncProgressEvent) => void;

class DraftSyncService {
  private isSyncing: boolean = false;
  private listeners: Set<SyncProgressCallback> = new Set();
  private isInitialized: boolean = false;

  /**
   * Initialize Service Worker, Background Sync listeners and network status observers
   */
  public async init(): Promise<void> {
    if (typeof window === 'undefined' || this.isInitialized) return;
    this.isInitialized = true;

    // 1. Register Service Worker
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
        console.log('[DraftSyncService] Service Worker registered with scope:', registration.scope);

        // Listen for messages from the Service Worker
        navigator.serviceWorker.addEventListener('message', (event) => {
          if (event.data && event.data.type === 'BACKGROUND_SYNC_COMPLETED') {
            console.log('[DraftSyncService] Received background sync completion from Service Worker:', event.data);
            notifyDraftsChanged();
            this.broadcastProgress({
              total: event.data.syncedCount || 0,
              completed: event.data.syncedCount || 0,
              status: 'completed',
              message: `সার্ভিস ওয়ার্কার কর্তৃক ${event.data.syncedCount || 0}টি অফলাইন ড্রাফট স্বয়ংক্রিয়ভাবে ফায়ারবেসে সিঙ্ক হইয়াছে!`
            });

            // Dispatch global window event for toasts
            window.dispatchEvent(new CustomEvent('bup:sw-sync-success', {
              detail: {
                count: event.data.syncedCount,
                syncedDrafts: event.data.syncedDrafts,
                timestamp: event.data.timestamp
              }
            }));
          }
        });
      } catch (err) {
        console.warn('[DraftSyncService] Service Worker registration warning:', err);
      }
    }

    // 2. Network connectivity restoration listener
    window.addEventListener('online', () => {
      console.log('[DraftSyncService] Network connectivity restored! Triggering automatic draft upload...');
      this.triggerAutoSync();
    });

    // 3. Check if online right now and has pending drafts
    if (navigator.onLine) {
      setTimeout(() => {
        this.triggerAutoSync();
      }, 2000);
    }
  }

  /**
   * Request background sync via Service Worker Background Sync API or immediate fallback
   */
  public async triggerAutoSync(): Promise<void> {
    if (!navigator.onLine) {
      console.log('[DraftSyncService] Device is offline. Drafts remain securely in IndexedDB.');
      return;
    }

    const pending = await getPendingDraftsFromIndexedDB();
    if (pending.length === 0) return;

    // Try Background Sync API first if supported
    if ('serviceWorker' in navigator && 'SyncManager' in window) {
      try {
        const registration = await navigator.serviceWorker.ready;
        if ((registration as any).sync) {
          await (registration as any).sync.register('sync-draft-certificates');
          console.log('[DraftSyncService] Background sync registered with tag: sync-draft-certificates');
        }
      } catch (e) {
        console.warn('[DraftSyncService] Background Sync register notice:', e);
      }
    }

    // Also notify active Service Worker controller via postMessage
    if (navigator.serviceWorker && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'TRIGGER_DRAFT_SYNC',
        timestamp: Date.now()
      });
    }

    // Run client synchronization with direct Firestore fallback
    await this.syncAllPendingDrafts();
  }

  /**
   * Synchronize all pending offline drafts to Firestore and Express Server
   */
  public async syncAllPendingDrafts(): Promise<{ synced: number; failed: number }> {
    if (this.isSyncing) {
      console.log('[DraftSyncService] Sync already in progress, skipping duplicate call');
      return { synced: 0, failed: 0 };
    }

    if (!navigator.onLine) {
      this.broadcastProgress({
        total: 0,
        completed: 0,
        status: 'error',
        message: 'ইন্টারনেট সংযোগ পাওয়া যায়নি। ড্রাফট সুরক্ষিতভাবে লোকাল স্টোরেজে রহিয়াছে।'
      });
      return { synced: 0, failed: 0 };
    }

    const pendingDrafts = await getPendingDraftsFromIndexedDB();
    if (pendingDrafts.length === 0) {
      return { synced: 0, failed: 0 };
    }

    this.isSyncing = true;
    let syncedCount = 0;
    let failedCount = 0;

    this.broadcastProgress({
      total: pendingDrafts.length,
      completed: 0,
      status: 'syncing',
      message: `${pendingDrafts.length}টি অফলাইন ড্রাফট ফায়ারবেসে আপলোড শুরু হইয়াছে...`
    });

    try {
      // 1. Batch sync to Server API
      try {
        const res = await fetch('/api/certificates/sync-drafts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ drafts: pendingDrafts })
        });

        if (res.ok) {
          const resData = await res.json();
          console.log('[DraftSyncService] Server sync-drafts response:', resData);
        }
      } catch (sErr) {
        console.warn('[DraftSyncService] Server endpoint sync notice (will fallback to direct Firestore):', sErr);
      }

      // 2. Individual certificate synchronization to Firestore and local IndexedDB state update
      for (let i = 0; i < pendingDrafts.length; i++) {
        const draft = pendingDrafts[i];
        
        await updateDraftSyncStatus(draft.id, 'syncing');

        this.broadcastProgress({
          total: pendingDrafts.length,
          completed: i,
          currentDraft: draft,
          status: 'syncing',
          message: `আপলোড হইতেছে (${i + 1}/${pendingDrafts.length}): ${draft.typeNameBn} - ${draft.citizen.name || draft.memoNo}`
        });

        try {
          // Prepare full CertificateRecord for Firestore
          const certRecord: CertificateRecord = draft.fullRecord || {
            id: draft.id,
            memoNo: draft.memoNo,
            issueDate: new Date().toLocaleDateString('bn-BD'),
            issueDateEn: new Date().toISOString().split('T')[0],
            typeKey: draft.certificateType || 'citizenship',
            typeLabel: draft.typeNameBn || 'নাগরিক সনদপত্র',
            category: 'নাগরিক সেবা',
            citizen: {
              name: draft.citizen.name,
              father: draft.citizen.father,
              mother: draft.citizen.mother,
              spouseName: draft.citizen.spouseName,
              gender: draft.citizen.gender,
              nid: draft.citizen.nid,
              birthNo: draft.citizen.birthNo,
              mobile: draft.citizen.mobile,
              wardNo: draft.citizen.wardNo,
              village: draft.citizen.village,
              postOffice: draft.citizen.postOffice,
              postCode: draft.citizen.postCode || '১৯৫০',
              holdingNo: draft.citizen.holdingNo
            },
            extra: {
              simpleFields: draft.formData?.simpleFields || {},
              tables: (draft.formData?.tablesData as any) || {}
            },
            bodyText: draft.generatedText || `এই মর্মে প্রত্যয়ন করা যাইতেছে যে, ${draft.citizen.name}, পিতা/স্বামী: ${draft.citizen.father || ''}, মাতা: ${draft.citizen.mother || ''}, গ্রাম: ${draft.citizen.village}, ওয়ার্ড নং: ${draft.citizen.wardNo}, ডাকঘর: ${draft.citizen.postOffice}, উপজেলা: সখিপুর, জেলা: টাঙ্গাইল-এর একজন স্থায়ী বাসিন্দা।`,
            verificationUrl: `${window.location.origin}/verify/${encodeURIComponent(draft.memoNo)}`,
            status: draft.formData?.targetStatus || 'draft',
            issuedBy: 'অফলাইন ব্যাকগ্রাউন্ড সিঙ্ক',
            createdAt: draft.createdAt,
            feeAmount: draft.formData?.feeAmount || 0,
            paymentMethod: (draft.formData?.paymentMethod as any) || 'Cash',
            trxId: draft.formData?.trxId || '',
            paymentStatus: 'paid'
          };

          // Save directly to Firestore Cloud Database
          await saveCertificateToFirebase(certRecord);

          // Update local IndexedDB draft status to synced
          await updateDraftSyncStatus(draft.id, 'synced', undefined, certRecord);
          syncedCount++;
        } catch (err: any) {
          console.error(`[DraftSyncService] Failed to sync draft ${draft.id}:`, err);
          await updateDraftSyncStatus(draft.id, 'failed', err?.message || 'আপলোড ব্যর্থ হইয়াছে');
          failedCount++;
        }
      }

      this.broadcastProgress({
        total: pendingDrafts.length,
        completed: syncedCount,
        status: 'completed',
        message: `${syncedCount}টি অফলাইন ড্রাফট সফলভাবে ফায়ারবেসে আপলোড হইয়াছে!`
      });

      notifyDraftsChanged();

      // Dispatch global window event for notifications
      window.dispatchEvent(new CustomEvent('bup:drafts-synced', {
        detail: {
          syncedCount,
          failedCount,
          total: pendingDrafts.length
        }
      }));

    } catch (error: any) {
      console.error('[DraftSyncService] Error during batch sync:', error);
      this.broadcastProgress({
        total: pendingDrafts.length,
        completed: syncedCount,
        status: 'error',
        message: 'ড্রাফট সিঙ্ক প্রক্রিয়ায় ত্রুটি দেখা দিয়াছে: ' + (error?.message || 'পুনরায় চেষ্টা করুন')
      });
    } finally {
      this.isSyncing = false;
    }

    return { synced: syncedCount, failed: failedCount };
  }

  /**
   * Subscribe to sync progress updates
   */
  public subscribe(callback: SyncProgressCallback): () => void {
    this.listeners.add(callback);
    return () => {
      this.listeners.delete(callback);
    };
  }

  private broadcastProgress(event: SyncProgressEvent): void {
    this.listeners.forEach((callback) => {
      try {
        callback(event);
      } catch (err) {
        console.error('[DraftSyncService] Error in progress listener:', err);
      }
    });
  }
}

export const draftSyncService = new DraftSyncService();
