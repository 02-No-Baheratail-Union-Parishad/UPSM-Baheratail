import { useState, useEffect } from 'react';
import { CertificateRecord, CitizenData } from '../types';

// Default Apps Script Web App URL (Can be customized via environment variable or UPMS admin settings)
export const GAS_APP_URL = 
  (import.meta as any).env?.VITE_GAS_APP_URL || 
  'https://script.google.com/macros/s/AKfycbz_default_baheratail_gas/exec';

export interface GasApiResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
  error?: string;
}

export interface GasNoticeItem {
  id: string;
  title: string;
  date: string;
  category: string;
  content: string;
}

/**
 * Submit certificate application to Google Apps Script / Google Sheets
 */
export async function submitApplicationToGas(payload: {
  serviceType: string;
  citizen: CitizenData;
  extraFields?: Record<string, any>;
  targetDocId?: string;
}): Promise<GasApiResponse<{ memoNo: string; pdfUrl?: string }>> {
  try {
    const response = await fetch(GAS_APP_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      mode: 'cors',
      body: JSON.stringify({
        action: 'submitApplication',
        ...payload,
        timestamp: new Date().toISOString()
      }),
    });

    if (!response.ok) {
      throw new Error(`GAS HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error: any) {
    console.warn('GAS submission notice (fallback to local server/Firebase):', error);
    return {
      success: false,
      error: error.message || 'Apps Script এর সাথে সংযোগ স্থাপন করা সম্ভব হয়নি।'
    };
  }
}

/**
 * Verify certificate memo through Google Apps Script
 */
export async function verifyCertificateFromGas(memoNo: string): Promise<GasApiResponse<CertificateRecord | null>> {
  try {
    const url = `${GAS_APP_URL}?action=verifyCertificate&memo=${encodeURIComponent(memoNo)}`;
    const response = await fetch(url, {
      method: 'GET',
      mode: 'cors'
    });

    if (!response.ok) {
      throw new Error(`GAS verification error: ${response.status}`);
    }

    return await response.json();
  } catch (error: any) {
    console.warn('GAS verification notice:', error);
    return {
      success: false,
      error: error.message || 'ভেরিফিকেশন সার্ভার থেকে ডাটা পাওয়া যায়নি।'
    };
  }
}

/**
 * Fetch notice announcements from GAS / Sheets
 */
export async function fetchNoticesFromGas(): Promise<GasNoticeItem[]> {
  try {
    const url = `${GAS_APP_URL}?action=listNotices`;
    const response = await fetch(url, { method: 'GET', mode: 'cors' });
    if (!response.ok) return [];
    const json = await response.json();
    return json.data || [];
  } catch (err) {
    return [];
  }
}

/**
 * React Hook for Realtime Updates & Polling
 */
export function useRealtimeUpdates(pollIntervalMs: number = 30000) {
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const interval = setInterval(() => {
      if (navigator.onLine) {
        setLastUpdate(new Date());
      }
    }, pollIntervalMs);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, [pollIntervalMs]);

  return { lastUpdate, isOnline };
}
