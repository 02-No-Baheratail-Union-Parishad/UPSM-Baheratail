import { 
  WhatsAppOtpRequest, 
  WhatsAppOtpResponse, 
  WhatsAppVerifyRequest, 
  WhatsAppVerifyResponse, 
  WhatsAppInstantSession 
} from '../types';

export class WhatsAppAuthService {
  /**
   * Convert Bengali numerals to ASCII English numerals
   */
  public convertBanglaToEnglishDigits(str: string): string {
    if (!str) return '';
    const banglaDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return str.replace(/[০-৯]/g, (w) => banglaDigits.indexOf(w).toString());
  }

  /**
   * Normalize and format phone number for International / WhatsApp standard (+8801XXXXXXXXX)
   */
  public formatBangladeshiPhone(rawPhone: string, includePlusPrefix: boolean = true): { formatted: string; isValid: boolean; display: string } {
    if (!rawPhone) return { formatted: '', isValid: false, display: '' };

    const asciiPhone = this.convertBanglaToEnglishDigits(rawPhone).trim();
    // Remove all non-numeric characters except +
    const cleanDigits = asciiPhone.replace(/\D/g, '');

    let normalized = '';

    if (cleanDigits.startsWith('8801') && cleanDigits.length === 13) {
      normalized = cleanDigits;
    } else if (cleanDigits.startsWith('01') && cleanDigits.length === 11) {
      normalized = '88' + cleanDigits;
    } else if (cleanDigits.startsWith('1') && cleanDigits.length === 10) {
      normalized = '880' + cleanDigits;
    } else if (cleanDigits.length >= 10) {
      normalized = cleanDigits.startsWith('88') ? cleanDigits : '88' + cleanDigits;
    }

    const isValid = normalized.startsWith('8801') && normalized.length === 13;
    const finalFormatted = includePlusPrefix ? `+${normalized}` : normalized;
    
    // Nice human display format (e.g., +880 1712-345678)
    let display = finalFormatted;
    if (isValid && normalized.length === 13) {
      display = `+880 ${normalized.substring(3, 7)}-${normalized.substring(7)}`;
    }

    return {
      formatted: finalFormatted,
      isValid,
      display: display || rawPhone
    };
  }

  /**
   * Request a 6-digit WhatsApp OTP
   */
  public async sendOtp(phone: string, roleHint?: 'citizen' | 'staff' | 'auto'): Promise<WhatsAppOtpResponse> {
    try {
      const response = await fetch('/api/auth/whatsapp/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, roleHint: roleHint || 'auto' }),
      });

      const data = await response.json();
      return data;
    } catch (err: any) {
      return {
        success: false,
        message: err.message || 'হোয়াটসঅ্যাপ ওটিপি প্রেরণ করতে সমস্যা হয়েছে।'
      };
    }
  }

  /**
   * Verify the 6-digit WhatsApp OTP
   */
  public async verifyOtp(phone: string, otp: string, token: string): Promise<WhatsAppVerifyResponse> {
    try {
      const response = await fetch('/api/auth/whatsapp/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, otp, token }),
      });

      const data = await response.json();
      if (data.success && data.user) {
        this.saveAuthSession(data.user);
      }
      return data;
    } catch (err: any) {
      return {
        success: false,
        message: err.message || 'ওটিপি যাচাইকরণে ত্রুটি হয়েছে।'
      };
    }
  }

  /**
   * Create an Instant WhatsApp QR / 1-Click Verification Session
   */
  public async createInstantSession(): Promise<{ success: boolean; session?: WhatsAppInstantSession; message?: string }> {
    try {
      const response = await fetch('/api/auth/whatsapp/instant-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      return await response.json();
    } catch (err: any) {
      return {
        success: false,
        message: err.message || 'হোয়াটসঅ্যাপ ইনস্ট্যান্ট সেশন তৈরি ব্যর্থ হয়েছে।'
      };
    }
  }

  /**
   * Check status of Instant WhatsApp Session (Polling)
   */
  public async checkInstantSession(sessionId: string): Promise<{ success: boolean; status: string; user?: WhatsAppVerifyResponse['user']; message?: string }> {
    try {
      const response = await fetch(`/api/auth/whatsapp/instant-check/${sessionId}`);
      const data = await response.json();
      if (data.success && data.status === 'verified' && data.user) {
        this.saveAuthSession(data.user);
      }
      return data;
    } catch (err: any) {
      return {
        success: false,
        status: 'error',
        message: err.message || 'স্ট্যাটাস চেক ব্যর্থ হয়েছে।'
      };
    }
  }

  /**
   * Save user session locally and dispatch auth change event
   */
  public saveAuthSession(user: WhatsAppVerifyResponse['user']): void {
    if (!user) return;
    try {
      localStorage.setItem('upsm_whatsapp_active_user', JSON.stringify(user));

      // If user has admin/staff role, also sync with admin session
      if (user.role !== 'citizen') {
        const adminSession = {
          email: user.email || `${user.phone.replace(/\D/g, '')}@whatsapp.upsm.gov.bd`,
          name: user.name,
          role: user.role,
          designation: user.designation,
          phone: user.phone,
          authenticatedVia: 'whatsapp_otp',
          loginTime: new Date().toISOString()
        };
        localStorage.setItem('bup_active_admin_session', JSON.stringify(adminSession));
        window.dispatchEvent(new CustomEvent('adminAuthChanged', { detail: adminSession }));
      }

      window.dispatchEvent(new CustomEvent('whatsappAuthChanged', { detail: user }));
    } catch (e) {
      console.warn('Failed to save WhatsApp auth session:', e);
    }
  }

  /**
   * Get active logged-in WhatsApp user
   */
  public getActiveUser(): WhatsAppVerifyResponse['user'] | null {
    try {
      const saved = localStorage.getItem('upsm_whatsapp_active_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  }

  /**
   * Log out WhatsApp user
   */
  public logout(): void {
    try {
      localStorage.removeItem('upsm_whatsapp_active_user');
      window.dispatchEvent(new CustomEvent('whatsappAuthChanged', { detail: null }));
    } catch (e) {
      console.warn('Error during WhatsApp logout:', e);
    }
  }
}

export const whatsappAuthService = new WhatsAppAuthService();
