import { CertificateRecord, UnionParishadConfig, WhatsAppMessagePayload, WhatsAppSendResult, WhatsAppLogRecord } from '../types';

export interface WhatsAppServiceStatus {
  isConfigured: boolean;
  senderNumber: string;
  provider: 'twilio' | 'simulation' | 'not_configured';
  accountSidMasked?: string;
  totalSent: number;
}

export class WhatsAppMessagingService {
  /**
   * Convert Bengali numerals to ASCII English numerals
   */
  public convertBanglaToEnglishDigits(str: string): string {
    if (!str) return '';
    const banglaDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return str.replace(/[০-৯]/g, (w) => banglaDigits.indexOf(w).toString());
  }

  /**
   * Normalize and format phone number for International / WhatsApp standard (+8801XXXXXXXXX)
   */
  public formatBangladeshiPhone(rawPhone: string, includePlusPrefix: boolean = true): { formatted: string; isValid: boolean; display: string } {
    if (!rawPhone) return { formatted: '', isValid: false, display: '' };

    const asciiPhone = this.convertBanglaToEnglishDigits(rawPhone).trim();
    // Remove all non-numeric characters except +
    const cleanDigits = asciiPhone.replace(/\D/g, '');

    let normalized = '';

    if (cleanDigits.startsWith('8801') && cleanDigits.length === 13) {
      normalized = cleanDigits;
    } else if (cleanDigits.startsWith('01') && cleanDigits.length === 11) {
      normalized = '88' + cleanDigits;
    } else if (cleanDigits.startsWith('1') && cleanDigits.length === 10) {
      normalized = '880' + cleanDigits;
    } else if (cleanDigits.length >= 10) {
      // General fallback
      normalized = cleanDigits.startsWith('88') ? cleanDigits : '88' + cleanDigits;
    }

    const isValid = normalized.startsWith('8801') && normalized.length === 13;
    const finalFormatted = includePlusPrefix ? `+${normalized}` : normalized;
    
    // Nice human display format (e.g., +880 1712-345678)
    let display = finalFormatted;
    if (isValid && normalized.length === 13) {
      display = `+880 ${normalized.substring(3, 7)}-${normalized.substring(7)}`;
    }

    return {
      formatted: finalFormatted,
      isValid,
      display: display || rawPhone
    };
  }

  /**
   * Build an official, beautifully structured WhatsApp message text
   */
  public buildCertificateMessageText(
    cert: CertificateRecord,
    config: UnionParishadConfig,
    customNote?: string,
    templateType: 'approval' | 'verification' | 'fee_receipt' | 'custom' = 'approval'
  ): string {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'https://baheratailup.gov.bd';
    const verifyUrl = cert.verificationUrl || `${origin}/verify/${cert.memoNo}`;
    const qrUrl = cert.qrCodeUrl || `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(verifyUrl)}`;
    
    const citizenName = cert.citizen?.name || 'নাগরিক';
    const certType = cert.typeLabel || cert.category || 'প্রত্যয়নপত্র';
    const upName = config.upName || '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ';
    const location = `${config.upazila || 'সখিপুর'}, ${config.district || 'টাঙ্গাইল'}`;

    if (templateType === 'fee_receipt') {
      let msg = `🏛️ *${upName} — ডিজিটাল ফি রসিদ*\n`;
      msg += `📍 ${location}\n\n`;
      msg += `সম্মানিত *${citizenName}*,\n`;
      msg += `আপনার প্রত্যয়নপত্র ফি প্রাপ্তি নিশ্চিত করা হইয়াছে।\n\n`;
      msg += `💳 *পেমেন্ট বিবরণী:*\n`;
      msg += `• স্মারক নং: ${cert.memoNo}\n`;
      msg += `• সনদের ধরন: ${certType}\n`;
      msg += `• ফি পরিমাণ: ৳${cert.feeAmount || 0} (${cert.paymentMethod || 'ক্যাশ'})\n`;
      if (cert.trxId) msg += `• ট্রানজেকশন আইডি: ${cert.trxId}\n`;
      msg += `• স্ট্যাটাস: ${cert.paymentStatus === 'paid' ? 'পরিশোধিত (Paid ✅)' : 'অপেক্ষমান'}\n\n`;
      msg += `🔗 *অনলাইন কপি ও সত্যতা যাচাই লিংক:*\n${verifyUrl}\n\n`;
      msg += `ধন্যবাদান্তে,\n${upName}`;
      return msg;
    }

    // Default: Official Approval & Direct QR Verification Template
    let msg = `🏛️ *${upName}*\n`;
    msg += `📍 ${location}\n\n`;
    msg += `সম্মানিত *${citizenName}*,\n`;
    msg += `আপনার আবেদনকৃত *"${certType}"* ইউনিয়ন পরিষদ কর্তৃক অনুমোদিত ও ডিজিটাল ডাটাবেজে অন্তর্ভুক্ত হয়েছে।\n\n`;
    
    msg += `📋 *সনদের বিবরণী (Certificate Summary):*\n`;
    msg += `• স্মারক নং: ${cert.memoNo}\n`;
    msg += `• ইস্যুর তারিখ: ${cert.issueDate}\n`;
    msg += `• আবেদনকারী: ${citizenName}\n`;
    if (cert.citizen?.father) msg += `• পিতা/স্বামী: ${cert.citizen.father}\n`;
    if (cert.citizen?.village) msg += `• গ্রাম/ওয়ার্ড: ${cert.citizen.village}${cert.citizen.wardNo ? ` (ওয়ার্ড নং ${cert.citizen.wardNo})` : ''}\n`;
    if (cert.citizen?.nid || cert.citizen?.birthNo) msg += `• NID/জন্ম নিবন্ধন: ${cert.citizen.nid || cert.citizen.birthNo}\n`;
    
    if (cert.feeAmount) {
      msg += `• সরকারি ফি: ৳${cert.feeAmount} (${cert.paymentStatus === 'paid' ? 'পরিশোধিত ✅' : 'সংগৃহীত'})\n`;
    }

    msg += `\n🔗 *সরাসরি অনলাইন সনদ সত্যতা যাচাই ও মূল পিডিএফ ডাউনলোড লিংক:*\n${verifyUrl}\n`;
    msg += `\n📲 *ডিজিটাল ভেরিফিকেশন QR কোড লিংক:*\n${qrUrl}\n`;

    if (customNote && customNote.trim()) {
      msg += `\n💬 *দাপ্তরিক বিশেষ বার্তা:* ${customNote.trim()}\n`;
    }

    msg += `\nস্বাক্ষরিত:\n${config.chairmanName || 'চেয়ারম্যান'}\n${config.chairmanTitle || 'চেয়ারম্যান'}, ${upName}`;
    return msg;
  }

  /**
   * Send WhatsApp message via Backend Twilio API
   */
  public async sendViaTwilio(payload: WhatsAppMessagePayload): Promise<WhatsAppSendResult> {
    try {
      const response = await fetch('/api/messaging/whatsapp/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || `সার্ভার ত্রুটি: HTTP ${response.status}`);
      }

      // Store in local delivery log cache
      this.saveLocalDeliveryLog({
        id: data.messageId || `wa_${Date.now()}`,
        memoNo: payload.certificate.memoNo,
        citizenName: payload.certificate.citizen.name,
        recipientPhone: payload.to,
        provider: data.provider || 'twilio',
        status: data.status || 'sent',
        sentAt: new Date().toISOString(),
        messageSummary: `Sent ${payload.certificate.typeLabel} to ${payload.to}`,
        verificationUrl: payload.certificate.verificationUrl,
        qrCodeUrl: payload.certificate.qrCodeUrl,
      });

      return data;
    } catch (err: any) {
      console.error('Twilio WhatsApp dispatch failed:', err);
      return {
        success: false,
        provider: 'twilio',
        status: 'failed',
        to: payload.to,
        timestamp: new Date().toISOString(),
        error: err.message || 'মেসেজ প্রেরণে ত্রুটি ঘটেছে।'
      };
    }
  }

  /**
   * Send WhatsApp message via batch dispatch API
   */
  public async sendBulkWhatsApp(certificates: CertificateRecord[], customNote?: string): Promise<{
    total: number;
    successCount: number;
    failedCount: number;
    results: WhatsAppSendResult[];
  }> {
    try {
      const response = await fetch('/api/messaging/whatsapp/bulk-send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          certificates,
          customNote
        }),
      });

      const data = await response.json();
      return data;
    } catch (err: any) {
      console.error('Bulk WhatsApp dispatch error:', err);
      throw err;
    }
  }

  /**
   * Open Direct WhatsApp Web/App chat link in browser
   */
  public openDirectWhatsAppWeb(rawPhone: string, messageText: string): void {
    const { formatted, isValid } = this.formatBangladeshiPhone(rawPhone, false); // format without plus for wa.me
    const cleanNumber = isValid ? formatted : rawPhone.replace(/\D/g, '');
    
    const waUrl = cleanNumber 
      ? `https://wa.me/${cleanNumber}?text=${encodeURIComponent(messageText)}`
      : `https://api.whatsapp.com/send?text=${encodeURIComponent(messageText)}`;
    
    if (typeof window !== 'undefined') {
      window.open(waUrl, '_blank', 'noopener,noreferrer');
    }
  }

  /**
   * Diagnostic Test Ping to Twilio WhatsApp API
   */
  public async testConnection(testPhone: string, note?: string): Promise<{ success: boolean; message: string; details?: any }> {
    try {
      const response = await fetch('/api/messaging/whatsapp/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          to: testPhone,
          note: note || 'ইউনিয়ন পরিষদ ডিজিটাল অটোমেশন সিস্টেম টেস্ট বার্তা।'
        }),
      });

      const data = await response.json();
      return data;
    } catch (err: any) {
      return {
        success: false,
        message: err.message || 'টেস্ট কানেকশন ব্যর্থ হয়েছে।'
      };
    }
  }

  /**
   * Fetch WhatsApp Service Status & Configuration info from Server
   */
  public async getServiceStatus(): Promise<WhatsAppServiceStatus> {
    try {
      const response = await fetch('/api/messaging/whatsapp/status');
      if (response.ok) {
        return await response.json();
      }
    } catch (e) {
      console.warn('Failed to fetch WhatsApp service status:', e);
    }

    return {
      isConfigured: false,
      senderNumber: 'whatsapp:+14155238886',
      provider: 'simulation',
      totalSent: 0
    };
  }

  /**
   * Fetch WhatsApp delivery logs
   */
  public async getDeliveryLogs(): Promise<WhatsAppLogRecord[]> {
    try {
      const response = await fetch('/api/messaging/whatsapp/logs');
      if (response.ok) {
        const data = await response.json();
        if (data.logs && Array.isArray(data.logs)) {
          return data.logs;
        }
      }
    } catch (e) {
      console.warn('Failed to fetch server WhatsApp logs, reading local fallback:', e);
    }

    return this.getLocalDeliveryLogs();
  }

  /**
   * Local storage cache for offline/instant feedback logs
   */
  private getLocalDeliveryLogs(): WhatsAppLogRecord[] {
    try {
      const saved = localStorage.getItem('upsm_whatsapp_logs');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  }

  private saveLocalDeliveryLog(log: WhatsAppLogRecord): void {
    try {
      const current = this.getLocalDeliveryLogs();
      const updated = [log, ...current].slice(0, 100);
      localStorage.setItem('upsm_whatsapp_logs', JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to cache WhatsApp log locally:', e);
    }
  }
}

export const whatsappService = new WhatsAppMessagingService();
