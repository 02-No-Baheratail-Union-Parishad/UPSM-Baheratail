export interface SimpleFieldConfig {
  key: string;
  label: string;
  placeholder?: string;
  type?: 'text' | 'number' | 'date';
  required?: boolean;
}

export interface TableConfig {
  key: string;
  title: string;
  headers: string[];
}

export interface CertificateTypeCustomization {
  declaration?: string;
  footerContact?: string;
  promptInstruction?: string;
  fee?: number;
}

export interface CertificateTypeConfig {
  key: string;
  label: string;
  category: string;
  iconName?: string;
  simpleFields?: SimpleFieldConfig[];
  tables?: TableConfig[];
  promptInstruction?: string;
  customDeclaration?: string;
  customFooter?: string;
}

export interface CitizenData {
  nid?: string;
  birthNo?: string;
  holdingNo?: string;
  name: string;
  father: string;
  spouseName?: string;
  mother: string;
  gender: 'পুরুষ' | 'মহিলা' | 'হিজরা';
  age?: number;
  dateOfBirth?: string;
  occupation?: string;
  mobile?: string;
  village: string;
  postOffice: string;
  postCode?: string;
  wardNo: string;
  upName?: string;
  district?: string;
  upazila?: string;
}

export interface TableRowData {
  [colIndex: number]: string;
}

export interface CertificateExtraData {
  simpleFields: Record<string, string>;
  tables: Record<string, string[][]>;
}

export interface CertificateRecord {
  id: string;
  memoNo: string;
  issueDate: string;
  issueDateEn: string;
  typeKey: string;
  typeLabel: string;
  category: string;
  citizen: CitizenData;
  extra: CertificateExtraData;
  bodyText: string;
  qrCodeUrl?: string;
  verificationUrl: string;
  status: 'pending_approval' | 'approved' | 'issued' | 'revoked' | 'cancelled' | 'draft';
  issuedBy: string;
  approvedBy?: string;
  approvedAt?: string;
  cancelledBy?: string;
  cancelledAt?: string;
  rejectionReason?: string;
  createdAt: string;
  feeAmount?: number;
  paymentMethod?: 'bKash' | 'Nagad' | 'Rocket' | 'Cash' | 'Upay';
  trxId?: string;
  paymentStatus?: 'paid' | 'unpaid' | 'waived';
  biometricVerified?: boolean;
  biometricAuthType?: 'WebAuthn Passkey' | 'Platform Biometrics' | 'Biometric PIN' | 'Security Passkey';
  biometricTimestamp?: string;
  verifiedByBiometrics?: string;
}

export interface WebAuthnPasskeyCredential {
  id: string;
  rawId: string;
  type: string;
  deviceName: string;
  authenticatorAttachment?: 'platform' | 'cross-platform';
  registeredAt: string;
  lastUsedAt?: string;
  userEmail: string;
  transports?: string[];
}

export interface CouncilMember {
  id: string;
  category: 'chairman' | 'reserved_female' | 'general_member' | 'officer' | 'udc' | 'dafadar' | 'gram_police';
  name: string;
  designation: string;
  mobile: string;
  wardNo?: string;
  photoUrl?: string;
  isAutoSynced?: boolean;
}

export interface UnionParishadConfig {
  upName: string;
  upNameEn: string;
  upazila: string;
  district: string;
  address: string;
  phone?: string;
  hotline?: string;
  email?: string;
  website?: string;
  chairmanName: string;
  chairmanTitle: string;
  chairmanPhone?: string;
  chairmanSignatureUrl?: string;
  secretaryName: string;
  secretaryTitle: string;
  secretaryPhone?: string;
  secretarySignatureUrl?: string;
  enableDigitalSignature?: boolean;
  showSecretarySignature?: boolean;
  logoUrl: string;
  watermarkUrl?: string;
  sealText: string;
  defaultPromptPrefix: string;
  enableHeaderInPrint: boolean;
  watermarkOpacity: number;
  certificateFeeDefault?: number;
  categoryFees?: Record<string, number>;
  typeFeeOverrides?: Record<string, number>;
  certificateCustomizations?: Record<string, CertificateTypeCustomization>;
  // MFS Payment Details
  paymentBkashNumber?: string;
  paymentNagadNumber?: string;
  paymentRocketNumber?: string;
  paymentInstructions?: string;
  // Template Customizer Options
  templateHeaderStyle?: 'tri-column' | 'classic' | 'centered';
  bodyFontSize?: number;
  borderStyle?: 'double-green-red' | 'double-green' | 'single-green' | 'none';
  blankSealSize?: number; // Circle diameter in px (0 to hide)
  qrCodePosition?: 'left-bottom' | 'right-bottom';
  // QR Code Advanced Styling Options
  qrColorScheme?: 'classic-black' | 'govt-emerald' | 'emerald-gold' | 'govt-crimson' | 'navy-slate' | 'teal-cyan' | 'custom';
  qrCustomDarkColor?: string;
  qrCustomLightColor?: string;
  qrEmbedLogo?: boolean;
  qrLogoUrl?: string;
  qrLogoShape?: 'circle' | 'rounded';
  qrFrameStyle?: 'clean' | 'badge' | 'double' | 'minimal';
  qrSize?: number;
  templateDocId: string;
  targetFolderId: string;
  sheetId: string;
  appsScriptUrl?: string;
  r2AccountId?: string;
  r2AccessKeyId?: string;
  r2SecretAccessKey?: string;
  r2Endpoint?: string;
  r2BucketName?: string;
  geminiApiKey?: string;
  // Developer & Backup URLs
  developerName?: string;
  developerTitle?: string;
  developerPhotoUrl?: string;
  developerBio?: string;
  developerEmail?: string;
  developerPhone?: string;
  developerWhatsappNumber?: string;
  developerFacebookUrl?: string;
  developerLinkedinUrl?: string;
  developerTiktokUrl?: string;
  developerInstagramUrl?: string;
  developerGithubProfileUrl?: string;
  developerTwitterUrl?: string;
  developerWordpressUrl?: string;
  developerWhatsappUrl?: string;
  developerWhatsappUsername?: string;
  developerTelegramUrl?: string;
  developerTelegramUsername?: string;
  developerMessengerUrl?: string;
  developerMessengerUsername?: string;
  githubRepoUrl?: string;
  githubBranch?: string;
  googleDriveBackupUrl?: string;
  archiveFolderId?: string;
  mcpEndpointUrl?: string;
  webhookUrl?: string;
  webhookSecret?: string;
  lastBackupDate?: string;
  councilMembers?: CouncilMember[];
  pluginsConfig?: {
    smsNotification?: boolean;
    gdriveAutoSync?: boolean;
    geminiOcrVision?: boolean;
    auditTrailLog?: boolean;
    webhookIntegration?: boolean;
    mcpProtocolAgent?: boolean;
  };
  // Biometric & Security Fallback Configuration
  securityRecoverySecret?: string;
  securityOtpFallbackEnabled?: boolean;
  securityOtpFallbackPhone?: string;
  securityOtpFallbackEmail?: string;
  biometricMandatoryRoles?: ('super_admin' | 'chairman' | 'secretary' | 'member' | 'developer')[];
}

export interface ApiKeyRecord {
  id: string;
  name: string;
  key: string;
  permissions: 'read' | 'write' | 'admin';
  createdAt: string;
  lastUsedAt?: string;
  status: 'active' | 'revoked';
}

export interface WebhookConfig {
  id: string;
  name: string;
  url: string;
  secret?: string;
  events: ('certificate.created' | 'certificate.approved' | 'certificate.cancelled' | 'citizen.registered')[];
  enabled: boolean;
  createdAt: string;
}

export interface WebhookLogRecord {
  id: string;
  webhookName: string;
  url: string;
  event: string;
  payloadSummary: string;
  status: 'success' | 'failed';
  httpStatus: number;
  timestamp: string;
  error?: string;
}

export interface CitizenAccountRecord {
  id: string;
  nid?: string;
  birthNo?: string;
  holdingNo?: string;
  name: string;
  father: string;
  mother: string;
  spouseName?: string;
  gender: 'পুরুষ' | 'মহিলা' | 'হিজরা';
  age?: number;
  dateOfBirth?: string;
  occupation?: string;
  mobile?: string;
  village: string;
  wardNo: string;
  postOffice: string;
  postCode?: string;
  totalCertificates: number;
  lastCertificateType?: string;
  lastCertificateDate?: string;
  registeredAt: string;
}

export interface NidScanResult {
  nidNo?: string;
  name?: string;
  fatherName?: string;
  motherName?: string;
  spouseName?: string;
  dob?: string;
  addressText?: string;
  village?: string;
  wardNo?: string;
  rawText?: string;
  error?: string;
}

export interface VerificationResult {
  found: boolean;
  certificate?: CertificateRecord;
  verifiedAt: string;
  message?: string;
}

export interface AuditLogRecord {
  id: string;
  action: 'CERTIFICATE_ISSUED' | 'CERTIFICATE_APPROVED' | 'CERTIFICATE_REJECTED' | 'ADMIN_ADDED' | 'ADMIN_REMOVED' | 'ADMIN_ROLE_UPDATED' | 'CONFIG_UPDATED' | 'TEMPLATE_CHANGED' | 'CITIZEN_RECORD_ADDED' | 'BACKUP_RESTORED' | 'SECURITY_KEY_GENERATED' | 'ADMIN_LOGIN' | 'OTHER';
  actionTitle: string;
  details: string;
  performedByEmail: string;
  performedByName: string;
  performedByRole: string;
  timestamp: string;
  ipAddress?: string;
  docId?: string;
  checksum?: string;
}

export interface BiometricLoginDeviceInfo {
  platform: string; // 'macOS' | 'Windows' | 'iOS' | 'Android' | 'Linux' | 'Other'
  browser: string; // 'Chrome' | 'Safari' | 'Edge' | 'Firefox' | 'Opera' | 'Other'
  deviceType: 'desktop' | 'mobile' | 'tablet';
  deviceName: string; // e.g. "MacBook Pro (Apple Silicon Touch ID)"
  authenticatorType: string; // "Platform Biometric (Touch ID / Face ID / Windows Hello)"
  credentialId?: string;
  userAgent?: string;
  screenResolution?: string;
  ipOrOrigin?: string;
  touchSupport?: boolean;
}

export interface BiometricLoginEventRecord {
  id: string;
  timestamp: string; // ISO 8601 string
  formattedTimestamp: string; // Bengali + English human readable
  adminEmail: string;
  adminName: string;
  adminRole: 'super_admin' | 'chairman' | 'secretary' | 'member' | 'developer' | string;
  adminDesignation?: string;
  authMethod: string;
  status: 'SUCCESS' | 'FAILED' | 'CHALLENGE_ELEVATED';
  deviceInfo: BiometricLoginDeviceInfo;
  sessionId?: string;
  context?: string; // e.g. "Admin Portal Login", "Sensitive Action Approval", "Security Settings Re-auth"
  checksum?: string;
}

export interface AdminPermissions {
  canApproveCertificates: boolean;
  canIssueCertificates: boolean;
  canManageAdmins: boolean;
  canEditConfig: boolean;
  canExportData: boolean;
  canDeleteLogs: boolean;
  canView?: boolean;
  canEdit?: boolean;
  canApprove?: boolean;
  canDelete?: boolean;
}

export interface AdminUserRecord {
  uid?: string;
  email: string;
  name: string;
  role: 'super_admin' | 'chairman' | 'secretary' | 'member' | 'developer';
  designation: string;
  photoUrl?: string;
  addedAt: string;
  lastLoginAt?: string;
  status: 'active' | 'suspended';
  wardNo?: string;
  permissions?: AdminPermissions;
}

export interface BackupSnapshot {
  id: string;
  filename: string;
  timestamp: string;
  archiveFolderId: string;
  sheetId: string;
  recordsCount: number;
  sizeKb?: number;
  status: 'completed' | 'in_progress' | 'failed';
  downloadUrl?: string;
  driveFileId?: string;
  notes?: string;
}

export interface GoogleChatSpace {
  name: string;
  displayName?: string;
  spaceType?: 'SPACE' | 'GROUP_CHAT' | 'DIRECT_MESSAGE' | string;
  singleUserBotDm?: boolean;
  threaded?: boolean;
  spaceDetails?: {
    description?: string;
    guidelines?: string;
  };
  spaceHistoryState?: string;
  createTime?: string;
}

export interface GoogleChatMessage {
  name: string;
  text?: string;
  sender?: {
    name?: string;
    displayName?: string;
    avatarUrl?: string;
    type?: 'HUMAN' | 'BOT' | string;
    email?: string;
  };
  createTime?: string;
  formattedText?: string;
  thread?: {
    name?: string;
  };
}

export interface GoogleChatMembership {
  name: string;
  state?: string;
  role?: 'ROLE_MEMBER' | 'ROLE_MANAGER' | string;
  member?: {
    name?: string;
    displayName?: string;
    avatarUrl?: string;
    type?: string;
  };
}

export type CloudConnectorKey = 
  | 'linear' 
  | 'lovable' 
  | 'make' 
  | 'netlify' 
  | 'notion' 
  | 'replit' 
  | 'send' 
  | 'stripe' 
  | 'supabase' 
  | 'superhuman' 
  | 'twilio' 
  | 'vercel' 
  | 'webflow' 
  | 'wix';

export interface WhatsAppMessagePayload {
  to: string;
  certificate: CertificateRecord;
  customNote?: string;
  templateType?: 'approval' | 'verification' | 'fee_receipt' | 'custom';
  mediaUrl?: string;
  sendMethod?: 'twilio' | 'whatsapp_web' | 'auto';
}

export interface WhatsAppSendResult {
  success: boolean;
  messageId?: string;
  provider: 'twilio' | 'whatsapp_web' | 'simulation';
  status: 'queued' | 'sent' | 'delivered' | 'failed';
  to: string;
  timestamp: string;
  error?: string;
  directWebUrl?: string;
  message?: string;
}

export interface WhatsAppLogRecord {
  id: string;
  memoNo: string;
  citizenName: string;
  recipientPhone: string;
  provider: 'twilio' | 'whatsapp_web' | 'simulation';
  status: 'sent' | 'delivered' | 'failed' | 'queued';
  sentAt: string;
  messageSummary: string;
  verificationUrl: string;
  qrCodeUrl?: string;
  error?: string;
}

export interface CloudConnectorConfig {
  id: string;
  key: CloudConnectorKey;
  name: string;
  nameBn: string;
  tagline: string;
  category: 'Automation & AI' | 'Deployment & Hosting' | 'Database & Storage' | 'Productivity & Docs' | 'Payments & Messaging' | 'Website & CMS';
  status: 'connected' | 'disconnected' | 'configuring';
  apiKey?: string;
  webhookUrl?: string;
  endpointUrl?: string;
  databaseId?: string;
  teamId?: string;
  projectId?: string;
  publicKey?: string;
  secretKey?: string;
  lastSyncAt?: string;
  syncCount?: number;
  settings?: Record<string, any>;
  enabledEvents?: string[];
}

export interface ConnectorSyncLog {
  id: string;
  connectorKey: CloudConnectorKey;
  connectorName: string;
  event: string;
  status: 'success' | 'failed' | 'in_progress';
  payloadSummary: string;
  timestamp: string;
  httpStatus?: number;
  errorMessage?: string;
}

export type DraftSyncStatus = 'pending' | 'syncing' | 'synced' | 'failed';

export interface DraftCertificate {
  id: string;
  memoNo: string;
  certificateType: string;
  typeNameBn: string;
  typeNameEn?: string;
  citizen: {
    name: string;
    father?: string;
    mother?: string;
    spouseName?: string;
    gender?: 'পুরুষ' | 'মহিলা' | 'হিজরা';
    nid?: string;
    birthNo?: string;
    mobile?: string;
    holdingNo?: string;
    wardNo: string;
    village: string;
    postOffice: string;
    postCode?: string;
  };
  formData?: {
    simpleFields?: Record<string, string>;
    tablesData?: Record<string, any[]>;
    customNote?: string;
    highThinking?: boolean;
    feeAmount?: number;
    paymentMethod?: string;
    trxId?: string;
    targetStatus?: 'draft' | 'pending_approval' | 'issued';
  };
  generatedText?: string;
  fullRecord?: CertificateRecord;
  syncStatus: DraftSyncStatus;
  syncError?: string;
  retryCount: number;
  createdAt: string;
  updatedAt: string;
  syncedAt?: string;
}

export interface DraftSyncStats {
  total: number;
  pending: number;
  synced: number;
  failed: number;
}

// WhatsApp Authentication & OTP Types
export interface WhatsAppOtpRequest {
  phone: string;
  roleHint?: 'citizen' | 'staff' | 'auto';
  requestedBy?: string;
}

export interface WhatsAppOtpResponse {
  success: boolean;
  message: string;
  token?: string;
  formattedPhone?: string;
  directWaUrl?: string;
  expiresInSeconds?: number;
  devOtp?: string;
  provider?: 'twilio' | 'simulation' | 'wa_direct';
}

export interface WhatsAppVerifyRequest {
  phone: string;
  otp: string;
  token: string;
}

export interface WhatsAppVerifyResponse {
  success: boolean;
  message: string;
  token?: string;
  user?: {
    phone: string;
    email?: string;
    name: string;
    role: 'citizen' | 'udc' | 'secretary' | 'chairman' | 'super_admin' | 'developer' | 'member';
    designation: string;
    nid?: string;
    village?: string;
    wardNo?: string;
    isAuthenticated: boolean;
    authMethod: 'whatsapp_otp' | 'whatsapp_instant';
  };
}

export interface WhatsAppInstantSession {
  sessionId: string;
  verificationCode: string;
  deepLink: string;
  qrCodeUrl: string;
  expiresAt: string;
  status: 'pending' | 'verified' | 'expired';
  verifiedUser?: WhatsAppVerifyResponse['user'];
}


