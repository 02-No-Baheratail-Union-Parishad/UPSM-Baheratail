/**
 * Faraez & Inheritance Estate Calculator (মুসলিম ফারায়েজ ও হিন্দু উত্তরাধিকার বণ্টন ইঞ্জিন)
 * According to Bangladesh Muslim Personal Law (Shariat) and Hindu Succession Principles
 */

import { toBengaliNumeral } from '../lib/utils';

export type HeirRelationship = 
  | 'husband' // স্বামী
  | 'wife' // স্ত্রী
  | 'father' // পিতা
  | 'mother' // মাতা
  | 'son' // পুত্র
  | 'daughter' // কন্যা
  | 'brother' // সহোদর ভাই
  | 'sister' // সহোদর বোন
  | 'grandfather' // দাদা/পিতামহ
  | 'grandmother' // দাদী/নানী
  | 'grandson' // পৌত্র (পুত্রের পুত্র)
  | 'granddaughter' // পৌত্রী (পুত্রের কন্যা)
  | 'other'; // অন্যান্য

export interface HeirInput {
  id: string;
  name: string;
  relation: HeirRelationship;
  relationLabelBn: string;
  gender: 'পুরুষ' | 'মহিলা';
  nidOrBirthNo?: string;
  customSharePercent?: number;
}

export interface CalculatedHeirShare {
  id: string;
  name: string;
  relationLabelBn: string;
  gender: 'পুরুষ' | 'মহিলা';
  nidOrBirthNo: string;
  fractionText: string; // e.g. "১/৮", "২/৩", "৭/২৪"
  percentage: number; // e.g. 12.5%
  percentageBn: string;
  anaGandaKaraKranti: string; // e.g. "০-২-২-০"
  allocatedLand: number; // in decimals (শতাংশ)
  allocatedLandBn: string;
  allocatedCash: number; // in BDT (টাকা)
  allocatedCashBn: string;
  legalNote: string; // শরিয়াহ / আইনের ব্যাখ্যা
}

export interface FaraezCalculationResult {
  deceasedName: string;
  deceasedGender: 'পুরুষ' | 'মহিলা';
  religion: 'muslim' | 'hindu';
  totalLandDecimals: number;
  totalCashAmount: number;
  heirs: CalculatedHeirShare[];
  totalPercentage: number;
  isBalanced: boolean;
  legalSummaryBn: string;
}

/**
 * Convert a decimal percentage (0 to 1) into traditional Bengali Ana-Ganda-Kara-Kranti
 * 1 Solah Ana = 16 Ana
 * 1 Ana = 20 Ganda
 * 1 Ganda = 4 Kara
 * 1 Kara = 3 Kranti
 * 1 Kranti = 20 Til
 */
export function decimalToAnaGanda(fraction: number): string {
  if (fraction <= 0) return '০-০-০-০';
  if (fraction >= 1) return '১৬-০-০-০';

  const totalAnas = fraction * 16;
  const ana = Math.floor(totalAnas);
  const remainingAfterAna = (totalAnas - ana) * 20;

  const ganda = Math.floor(remainingAfterAna);
  const remainingAfterGanda = (remainingAfterGandaVal(remainingAfterAna, ganda)) * 4;

  const kara = Math.floor(remainingAfterGanda);
  const remainingAfterKara = (remainingAfterGanda - kara) * 3;

  const kranti = Math.floor(remainingAfterKara);

  return `${toBengaliNumeral(ana)} আনা, ${toBengaliNumeral(ganda)} গণ্ডা, ${toBengaliNumeral(kara)} কড়া, ${toBengaliNumeral(kranti)} ক্রান্তি`;
}

function remainingAfterGandaVal(val: number, floorVal: number) {
  return Math.max(0, val - floorVal);
}

/**
 * Islamic Faraez Inheritance Calculator Engine
 */
export function calculateIslamicFaraez(
  deceasedName: string,
  deceasedGender: 'পুরুষ' | 'মহিলা',
  heirList: HeirInput[],
  totalLandDecimals: number = 100,
  totalCashAmount: number = 0
): FaraezCalculationResult {
  const resultHeirs: CalculatedHeirShare[] = [];

  // Count heirs by relation
  const husbands = heirList.filter(h => h.relation === 'husband');
  const wives = heirList.filter(h => h.relation === 'wife');
  const fathers = heirList.filter(h => h.relation === 'father');
  const mothers = heirList.filter(h => h.relation === 'mother');
  const sons = heirList.filter(h => h.relation === 'son');
  const daughters = heirList.filter(h => h.relation === 'daughter');
  const brothers = heirList.filter(h => h.relation === 'brother');
  const sisters = heirList.filter(h => h.relation === 'sister');

  const hasChildren = sons.length > 0 || daughters.length > 0;
  let remainingShare = 1.0; // 100%
  const assignedShares: Map<string, { share: number; fractionText: string; note: string }> = new Map();

  // 1. Spouse Share (যাবিল ফুরুজ)
  if (deceasedGender === 'মহিলা' && husbands.length > 0) {
    const husband = husbands[0];
    const share = hasChildren ? 0.25 : 0.50;
    const frac = hasChildren ? '১/৪' : '১/২';
    const note = hasChildren ? 'সন্তান থাকায় স্বামী ১/৪ অংশ পাবেন।' : 'সন্তান না থাকায় স্বামী ১/২ অংশ পাবেন।';
    assignedShares.set(husband.id, { share, fractionText: frac, note });
    remainingShare -= share;
  } else if (deceasedGender === 'পুরুষ' && wives.length > 0) {
    const totalWifeShare = hasChildren ? 0.125 : 0.25; // 1/8 or 1/4
    const frac = hasChildren ? '১/৮' : '১/৪';
    const note = hasChildren 
      ? `সন্তান থাকায় স্ত্রীগণ সর্বমোট ১/৮ অংশ সমবণ্টন পাবেন (${wives.length} জন)।`
      : `সন্তান না থাকায় স্ত্রীগণ সর্বমোট ১/৪ অংশ সমবণ্টন পাবেন (${wives.length} জন)।`;
    
    const individualShare = totalWifeShare / wives.length;
    wives.forEach(w => {
      assignedShares.set(w.id, { share: individualShare, fractionText: frac, note });
    });
    remainingShare -= totalWifeShare;
  }

  // 2. Mother Share (মাতা)
  if (mothers.length > 0) {
    const mother = mothers[0];
    const hasMultipleSiblings = (brothers.length + sisters.length) >= 2;
    const share = (hasChildren || hasMultipleSiblings) ? (1 / 6) : (1 / 3);
    const frac = (hasChildren || hasMultipleSiblings) ? '১/৬' : '১/৩';
    const note = (hasChildren || hasMultipleSiblings) 
      ? 'সন্তান বা একাধিক ভাইবোন থাকায় মাতা ১/৬ অংশ পাবেন।' 
      : 'সন্তান বা একাধিক ভাইবোন না থাকায় মাতা ১/৩ অংশ পাবেন।';
    assignedShares.set(mother.id, { share, fractionText: frac, note });
    remainingShare -= share;
  }

  // 3. Father Share (পিতা)
  if (fathers.length > 0) {
    const father = fathers[0];
    if (sons.length > 0) {
      // Father gets 1/6 only when sons exist
      const share = 1 / 6;
      assignedShares.set(father.id, { share, fractionText: '১/৬', note: 'পুত্র সন্তান থাকায় পিতা ১/৬ অংশ পাবেন।' });
      remainingShare -= share;
    } else if (daughters.length > 0) {
      // Father gets 1/6 + residual
      const fixedShare = 1 / 6;
      remainingShare -= fixedShare;
      // Residual will be handled after daughters
      assignedShares.set(father.id, { share: fixedShare, fractionText: '১/৬ + অবশিষ্ট', note: 'শুধু কন্যা সন্তান থাকায় পিতা ১/৬ এর সাথে অবশিষ্ট অংশ পাবেন।' });
    } else {
      // No children: father takes remaining as Asaba (অবশিষ্টাংশভোগী)
      assignedShares.set(father.id, { share: 0, fractionText: 'আসাবা (অবশিষ্ট সর্বমোট)', note: 'সন্তান না থাকায় পিতা অবশিষ্টাংশভোগী (আসাবা) হিসেবে সম্পূর্ণ বাকি সম্পত্তি পাবেন।' });
    }
  }

  // 4. Children Share (পুত্র ও কন্যা)
  if (sons.length > 0 && daughters.length > 0) {
    // Both sons and daughters: 2:1 ratio from remaining Asaba
    const totalUnits = (sons.length * 2) + daughters.length;
    const unitShare = Math.max(0, remainingShare) / totalUnits;

    sons.forEach(s => {
      const share = unitShare * 2;
      assignedShares.set(s.id, { 
        share, 
        fractionText: 'আসাবা (পুত্রের দ্বিগুণ অংশ)', 
        note: `কন্যার দ্বিগুণ অনুপাতে অবশিষ্টাংশ হতে বণ্টন (${toBengaliNumeral(Number((share * 100).toFixed(2)))}%)` 
      });
    });

    daughters.forEach(d => {
      const share = unitShare * 1;
      assignedShares.set(d.id, { 
        share, 
        fractionText: 'আসাবা (কন্যার অংশ)', 
        note: `পুত্রের অর্ধেক অনুপাতে অবশিষ্টাংশ হতে বণ্টন (${toBengaliNumeral(Number((share * 100).toFixed(2)))}%)` 
      });
    });
    remainingShare = 0;
  } else if (sons.length > 0 && daughters.length === 0) {
    // Sons only: divide remaining equally
    const sonShare = Math.max(0, remainingShare) / sons.length;
    sons.forEach(s => {
      assignedShares.set(s.id, { 
        share: sonShare, 
        fractionText: 'আসাবা (সমান অংশ)', 
        note: `পুত্রগণ অবশিষ্টাংশভোগী হিসেবে সমান বণ্টন পাবেন (${toBengaliNumeral(Number((sonShare * 100).toFixed(2)))}%)` 
      });
    });
    remainingShare = 0;
  } else if (daughters.length > 0 && sons.length === 0) {
    // Daughters only
    const totalDaughterShare = daughters.length === 1 ? 0.50 : (2 / 3);
    const frac = daughters.length === 1 ? '১/২' : '২/৩';
    const individualDaughterShare = totalDaughterShare / daughters.length;

    daughters.forEach(d => {
      assignedShares.set(d.id, { 
        share: individualDaughterShare, 
        fractionText: frac, 
        note: daughters.length === 1 
          ? 'একক কন্যা হিসেবে ১/২ অংশ প্রাপক।' 
          : `একাধিক কন্যা সর্বমোট ২/৩ অংশ সমবণ্টন পাবেন (${toBengaliNumeral(Number((individualDaughterShare * 100).toFixed(2)))}%)` 
      });
    });
    remainingShare -= totalDaughterShare;

    // If father exists, give rest to father
    if (fathers.length > 0 && remainingShare > 0) {
      const father = fathers[0];
      const prev = assignedShares.get(father.id);
      const updatedShare = (prev ? prev.share : 0) + remainingShare;
      assignedShares.set(father.id, {
        share: updatedShare,
        fractionText: '১/৬ + আসাবা',
        note: `পিতা ১/৬ অংশ এবং কন্যাদের বণ্টনের পর অবশিষ্ট ${toBengaliNumeral(Number((remainingShare * 100).toFixed(2)))}% অংশ পাবেন।`
      });
      remainingShare = 0;
    }
  }

  // 5. No children & Father alive: Father gets all remaining
  if (!hasChildren && fathers.length > 0 && remainingShare > 0) {
    const father = fathers[0];
    const prev = assignedShares.get(father.id);
    const updatedShare = (prev ? prev.share : 0) + remainingShare;
    assignedShares.set(father.id, {
      share: updatedShare,
      fractionText: 'আসাবা (সম্পূর্ণ অবশিষ্ট)',
      note: `সন্তানহীন অবস্থায় পিতা আসাবা হিসেবে অবশিষ্ট ${toBengaliNumeral(Number((updatedShare * 100).toFixed(2)))}% অংশ পাবেন।`
    });
    remainingShare = 0;
  }

  // 6. Fallback / Equal Split for remaining or custom heirs
  heirList.forEach(heir => {
    if (!assignedShares.has(heir.id)) {
      if (heirList.length > 0 && remainingShare > 0) {
        const share = remainingShare / heirList.length;
        assignedShares.set(heir.id, { share, fractionText: 'প্রযোজ্য বণ্টন', note: 'সাধারণ ওয়ারিশান বণ্টন' });
      } else {
        assignedShares.set(heir.id, { share: 0, fractionText: 'বঞ্চিত/হজব', note: 'নিকটবর্তী ওয়ারিশের উপস্থিতিতে বঞ্চিত' });
      }
    }
  });

  // Calculate totals and format result list
  let totalPercent = 0;
  heirList.forEach(heir => {
    const assigned = assignedShares.get(heir.id) || { share: 0, fractionText: '০', note: '' };
    const pct = assigned.share * 100;
    totalPercent += pct;

    const land = (assigned.share * totalLandDecimals);
    const cash = (assigned.share * totalCashAmount);

    resultHeirs.push({
      id: heir.id,
      name: heir.name || 'ওয়ারিশের নাম',
      relationLabelBn: heir.relationLabelBn,
      gender: heir.gender,
      nidOrBirthNo: heir.nidOrBirthNo || 'প্রযোজ্য নয়',
      fractionText: assigned.fractionText,
      percentage: Number(pct.toFixed(2)),
      percentageBn: `${toBengaliNumeral(Number(pct.toFixed(2)))}%`,
      anaGandaKaraKranti: decimalToAnaGanda(assigned.share),
      allocatedLand: Number(land.toFixed(3)),
      allocatedLandBn: `${toBengaliNumeral(Number(land.toFixed(3)))} শতক`,
      allocatedCash: Math.round(cash),
      allocatedCashBn: `${toBengaliNumeral(Math.round(cash))} টাকা`,
      legalNote: assigned.note
    });
  });

  const legalSummary = `মৃত ${deceasedName}-এর ওয়ারিশগণের মধ্যে ইসলামী ফারায়েজ আইন মোতাবেক সম্পত্তির অংশ বণ্টন সম্পন্ন হইয়াছে। মোট ওয়ারিশ সংখ্যা ${toBengaliNumeral(heirList.length)} জন।`;

  return {
    deceasedName,
    deceasedGender,
    religion: 'muslim',
    totalLandDecimals,
    totalCashAmount,
    heirs: resultHeirs,
    totalPercentage: Number(totalPercent.toFixed(2)),
    isBalanced: Math.abs(totalPercent - 100) < 0.5,
    legalSummaryBn: legalSummary
  };
}

/**
 * Hindu Succession / Equal Proportion Estate Calculator
 */
export function calculateHinduSuccession(
  deceasedName: string,
  deceasedGender: 'পুরুষ' | 'মহিলা',
  heirList: HeirInput[],
  totalLandDecimals: number = 100,
  totalCashAmount: number = 0
): FaraezCalculationResult {
  const count = heirList.length;
  const equalShare = count > 0 ? 1 / count : 0;
  const pct = equalShare * 100;

  const resultHeirs: CalculatedHeirShare[] = heirList.map(heir => {
    const land = equalShare * totalLandDecimals;
    const cash = equalShare * totalCashAmount;
    return {
      id: heir.id,
      name: heir.name || 'ওয়ারিশের নাম',
      relationLabelBn: heir.relationLabelBn,
      gender: heir.gender,
      nidOrBirthNo: heir.nidOrBirthNo || 'প্রযোজ্য নয়',
      fractionText: `১/${toBengaliNumeral(count)}`,
      percentage: Number(pct.toFixed(2)),
      percentageBn: `${toBengaliNumeral(Number(pct.toFixed(2)))}%`,
      anaGandaKaraKranti: decimalToAnaGanda(equalShare),
      allocatedLand: Number(land.toFixed(3)),
      allocatedLandBn: `${toBengaliNumeral(Number(land.toFixed(3)))} শতক`,
      allocatedCash: Math.round(cash),
      allocatedCashBn: `${toBengaliNumeral(Math.round(cash))} টাকা`,
      legalNote: 'হিন্দু দায়ভাগ/উত্তরাধিকার আইনানুযায়ী সমবণ্টন'
    };
  });

  return {
    deceasedName,
    deceasedGender,
    religion: 'hindu',
    totalLandDecimals,
    totalCashAmount,
    heirs: resultHeirs,
    totalPercentage: 100,
    isBalanced: true,
    legalSummaryBn: `মৃত ${deceasedName}-এর ওয়ারিশগণের মধ্যে হিন্দু উত্তরাধিকার আইনানুযায়ী সমবণ্টন সম্পন্ন হইয়াছে।`
  };
}
