import { CertificateRecord, UnionParishadConfig } from '../types';
import { formatBanglaDate, generateSecurityChecksum } from '../lib/utils';

/**
 * Generates an HTML-formatted .doc file string that Google Docs and Microsoft Word can open natively.
 */
export function generateCertificateDocHtml(
  certificate: CertificateRecord,
  config: UnionParishadConfig,
  options?: {
    includeHeader?: boolean;
    includeQrCode?: boolean;
    includeSignatures?: boolean;
    includeSeal?: boolean;
  }
): string {
  const includeHeader = options?.includeHeader !== false;
  const includeQrCode = options?.includeQrCode !== false;
  const includeSignatures = options?.includeSignatures !== false;
  const includeSeal = options?.includeSeal !== false;

  const c = certificate.citizen;
  const extraTables = certificate.extra?.tables || {};
  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://baheratailup.gov.bd';
  const verifyUrl = `${origin}/verify/${certificate.memoNo}`;
  const checksum = generateSecurityChecksum(
    certificate.memoNo,
    c?.nid || c?.birthNo,
    certificate.issueDateEn || certificate.issueDate
  );

  // Generate table rows if extra tables exist (e.g. Warishan)
  let extraTablesHtml = '';
  if (Object.keys(extraTables).length > 0) {
    Object.entries(extraTables).forEach(([tableName, rows]) => {
      if (Array.isArray(rows) && rows.length > 0) {
        extraTablesHtml += `
          <div style="margin-top: 18px; margin-bottom: 18px;">
            <p style="font-weight: bold; color: #064e3b; font-size: 14pt; margin-bottom: 6px; border-bottom: 2px solid #064e3b; padding-bottom: 4px;">
              ${tableName === 'warishan' ? 'ওয়ারিশগণের বিবরণী তালিকা' : tableName}
            </p>
            <table border="1" cellpadding="6" cellspacing="0" style="width: 100%; border-collapse: collapse; font-size: 11pt; border: 1px solid #064e3b; text-align: center;">
              <thead>
                <tr style="background-color: #f0fdf4; color: #064e3b; font-weight: bold;">
                  <th style="border: 1px solid #064e3b; padding: 6px;">ক্র. নং</th>
                  <th style="border: 1px solid #064e3b; padding: 6px;">ওয়ারিশের নাম</th>
                  <th style="border: 1px solid #064e3b; padding: 6px;">সম্পর্ক</th>
                  <th style="border: 1px solid #064e3b; padding: 6px;">বয়স</th>
                  <th style="border: 1px solid #064e3b; padding: 6px;">জাতীয় পরিচয়পত্র / জন্ম সনদ নং</th>
                  <th style="border: 1px solid #064e3b; padding: 6px;">মন্তব্য</th>
                </tr>
              </thead>
              <tbody>
                ${rows.map((row: any, idx: number) => `
                  <tr>
                    <td style="border: 1px solid #064e3b; padding: 5px;">${idx + 1}</td>
                    <td style="border: 1px solid #064e3b; padding: 5px; font-weight: bold;">${row.name || row.applicantName || '-'}</td>
                    <td style="border: 1px solid #064e3b; padding: 5px;">${row.relation || '-'}</td>
                    <td style="border: 1px solid #064e3b; padding: 5px;">${row.age || '-'}</td>
                    <td style="border: 1px solid #064e3b; padding: 5px;">${row.nid || row.birthNo || '-'}</td>
                    <td style="border: 1px solid #064e3b; padding: 5px;">${row.remarks || '-'}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        `;
      }
    });
  }

  return `
<!DOCTYPE html>
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
  <meta charset="utf-8">
  <title>${certificate.typeLabel} - ${certificate.memoNo}</title>
  <!--[if gte mso 9]>
  <xml>
    <w:WordDocument>
      <w:View>Print</w:View>
      <w:Zoom>100</w:Zoom>
      <w:DoNotOptimizeForBrowser/>
    </w:WordDocument>
  </xml>
  <![endif]-->
  <style>
    @page Section1 {
      size: 595.3pt 841.9pt; /* A4 size */
      margin: 36.0pt 45.0pt 36.0pt 45.0pt;
      mso-header-margin: 35.4pt;
      mso-footer-margin: 35.4pt;
      mso-paper-source: 0;
    }
    div.Section1 {
      page: Section1;
      font-family: 'Kalpurush', 'SolaimanLipi', 'Nikosh', 'SutonnyMJ', 'Arial', sans-serif;
      color: #0f172a;
      line-height: 1.6;
    }
    body {
      font-family: 'Kalpurush', 'SolaimanLipi', 'Nikosh', 'Arial', sans-serif;
    }
    .header-table {
      width: 100%;
      border-collapse: collapse;
      border-bottom: 2.5pt solid #064e3b;
      margin-bottom: 15px;
    }
    .memo-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 12px;
      font-size: 11pt;
      font-weight: bold;
    }
    .cert-title-container {
      text-align: center;
      margin: 14px 0;
    }
    .cert-title {
      display: inline-block;
      background-color: #064e3b;
      color: #ffffff;
      padding: 6px 24px;
      font-size: 15pt;
      font-weight: bold;
      border-radius: 4px;
    }
    .body-content {
      font-size: 12.5pt;
      text-align: justify;
      line-height: 1.8;
      margin-top: 16px;
      margin-bottom: 24px;
      text-indent: 30px;
    }
    .footer-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 30px;
    }
    .seal-box {
      width: 90px;
      height: 90px;
      border: 1.5pt dashed #94a3b8;
      border-radius: 50%;
      text-align: center;
      vertical-align: middle;
      font-size: 9pt;
      color: #64748b;
      margin: 0 auto;
    }
  </style>
</head>
<body lang="BN">
<div class="Section1" style="border: 2pt solid #064e3b; padding: 20px;">

  ${includeHeader ? `
  <!-- HEADER -->
  <table class="header-table">
    <tr>
      <td style="width: 33%; vertical-align: top; text-align: left; font-size: 10pt; line-height: 1.3;">
        <p style="margin: 0; font-weight: bold; font-size: 11.5pt; color: #022c22;">${config.chairmanName}</p>
        <p style="margin: 2px 0 0 0; color: #064e3b; font-weight: bold;">${config.chairmanTitle}</p>
        <p style="margin: 2px 0 0 0; color: #334155;">${config.upName}</p>
        <p style="margin: 2px 0 0 0; color: #475569;">${config.upazila}, ${config.district}।</p>
        <p style="margin: 2px 0 0 0; color: #475569;">মোবাইল: ${config.phone || '০১৭২২-৬৬৯৭৫৩'}</p>
      </td>
      <td style="width: 34%; vertical-align: middle; text-align: center;">
        <p style="margin: 0; font-size: 10pt; font-weight: bold; color: #064e3b;">গণপ্রজাতন্ত্রী বাংলাদেশ সরকার</p>
        <h2 style="margin: 4px 0; font-size: 16pt; color: #064e3b; font-weight: 900;">${config.upName}</h2>
        <p style="margin: 0; font-size: 10pt; color: #475569;">${config.address}</p>
        <p style="margin: 2px 0 0 0; font-size: 9pt; color: #047857;">ওয়েবসাইট: ${config.website || 'baheratailup.gov.bd'}</p>
      </td>
      <td style="width: 33%; vertical-align: top; text-align: right; font-size: 10pt; line-height: 1.3;">
        <p style="margin: 0; font-weight: bold; font-size: 11.5pt; color: #022c22;">${config.secretaryName}</p>
        <p style="margin: 2px 0 0 0; color: #064e3b; font-weight: bold;">${config.secretaryTitle}</p>
        <p style="margin: 2px 0 0 0; color: #334155;">${config.upName}</p>
        <p style="margin: 2px 0 0 0; color: #475569;">মোবাইল: ${config.secretaryPhone || '০১৭০৯-০৩৪৩৯০'}</p>
      </td>
    </tr>
  </table>
  ` : ''}

  <!-- MEMO & DATE -->
  <table class="memo-table">
    <tr>
      <td style="text-align: left; color: #064e3b;">
        স্মারক নং: <span style="font-weight: 900; color: #0f172a;">${certificate.memoNo}</span>
      </td>
      <td style="text-align: right; color: #064e3b;">
        তারিখ: <span style="font-weight: 900; color: #0f172a;">${certificate.issueDate}</span>
      </td>
    </tr>
  </table>

  <!-- CERTIFICATE TITLE -->
  <div class="cert-title-container">
    <div class="cert-title">
      ${certificate.typeLabel}
    </div>
  </div>

  <!-- CERTIFICATE BODY CONTENT -->
  <div class="body-content">
    ${certificate.bodyText.replace(/\n/g, '<br/>')}
  </div>

  <!-- ATTACHED TABLES IF ANY -->
  ${extraTablesHtml}

  ${(includeSignatures || includeQrCode || includeSeal) ? `
  <!-- FOOTER SIGNATURES & QR SECTION -->
  <table class="footer-table">
    <tr>
      <!-- Left: Secretary & QR -->
      <td style="width: 36%; vertical-align: bottom; text-align: left;">
        ${includeSignatures ? `
        <div style="margin-bottom: 12px;">
          <p style="margin: 0; font-weight: bold; font-size: 11pt; color: #0f172a;">${config.secretaryName}</p>
          <p style="margin: 1px 0; font-size: 10pt; color: #064e3b; font-weight: bold;">${config.secretaryTitle}</p>
          <p style="margin: 1px 0; font-size: 9.5pt; color: #475569;">${config.upName}</p>
        </div>
        ` : ''}

        ${includeQrCode ? `
        <div style="font-size: 9pt; color: #064e3b; border-top: 1px solid #cbd5e1; padding-top: 6px;">
          <p style="margin: 0; font-weight: bold;">🛡️ ডিজিটাল যাচাইকরণ ও নিরাপত্তা:</p>
          <p style="margin: 2px 0; font-size: 8pt; font-family: monospace; color: #334155;">Checksum: ${checksum}</p>
          <p style="margin: 2px 0; font-size: 8.5pt;">লিংক: <a href="${verifyUrl}" style="color: #047857; text-decoration: underline;">${verifyUrl}</a></p>
        </div>
        ` : ''}
      </td>

      <!-- Center: Official Seal -->
      <td style="width: 28%; vertical-align: bottom; text-align: center;">
        ${includeSeal ? `
        <div class="seal-box" style="line-height: 80px;">
          (ম্যানুয়াল সিল)
        </div>
        <p style="margin: 4px 0 0 0; font-size: 9pt; color: #64748b;">অফিশিয়াল গোল সিল</p>
        ` : ''}
      </td>

      <!-- Right: Chairman Signature -->
      <td style="width: 36%; vertical-align: bottom; text-align: right;">
        ${includeSignatures ? `
        <div>
          <p style="margin: 0; font-weight: 900; font-size: 12pt; color: #022c22;">${config.chairmanName}</p>
          <p style="margin: 2px 0; font-size: 10.5pt; color: #064e3b; font-weight: bold;">${config.chairmanTitle}</p>
          <p style="margin: 2px 0; font-size: 10pt; color: #334155;">${config.upName}</p>
          <p style="margin: 2px 0; font-size: 9.5pt; color: #475569;">${config.upazila}, ${config.district}।</p>
        </div>
        ` : ''}
      </td>
    </tr>
  </table>
  ` : ''}

</div>
</body>
</html>
  `.trim();
}

/**
 * Triggers download of the formatted .doc file
 */
export function downloadCertificateAsDoc(
  certificate: CertificateRecord,
  config: UnionParishadConfig,
  options?: {
    includeHeader?: boolean;
    includeQrCode?: boolean;
    includeSignatures?: boolean;
    includeSeal?: boolean;
  }
) {
  const html = generateCertificateDocHtml(certificate, config, options);
  const blob = new Blob(['\ufeff', html], {
    type: 'application/msword;charset=utf-8'
  });
  
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const fileName = `${certificate.typeLabel}_${certificate.memoNo.replace(/[^a-zA-Z0-9-]/g, '_')}.doc`;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Copies formatted HTML to clipboard so the user can paste directly into Google Docs (docs.new)
 */
export async function copyCertificateForGoogleDocs(
  certificate: CertificateRecord,
  config: UnionParishadConfig,
  options?: {
    includeHeader?: boolean;
    includeQrCode?: boolean;
    includeSignatures?: boolean;
    includeSeal?: boolean;
  }
): Promise<boolean> {
  const html = generateCertificateDocHtml(certificate, config, options);
  try {
    if (navigator.clipboard && window.ClipboardItem) {
      const blobHtml = new Blob([html], { type: 'text/html' });
      const blobText = new Blob([certificate.bodyText], { type: 'text/plain' });
      await navigator.clipboard.write([
        new ClipboardItem({
          'text/html': blobHtml,
          'text/plain': blobText,
        })
      ]);
      return true;
    } else {
      await navigator.clipboard.writeText(certificate.bodyText);
      return true;
    }
  } catch (err) {
    console.warn('Clipboard write failed, fallback to plain text', err);
    try {
      await navigator.clipboard.writeText(certificate.bodyText);
      return true;
    } catch {
      return false;
    }
  }
}
