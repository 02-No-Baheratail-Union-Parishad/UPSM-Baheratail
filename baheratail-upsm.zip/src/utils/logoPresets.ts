// Official Vector Logo Styles & Presets for Union Parishad Automation
export type LogoStylePreset = 
  | 'up-seal' 
  | 'govt-seal' 
  | 'digital-shield' 
  | 'smart-emblem' 
  | 'golden-crest';

export interface LogoPresetInfo {
  id: LogoStylePreset;
  label: string;
  labelBn: string;
  description: string;
  icon: string;
  url: string; // Direct URL or base64/SVG Data URL
}

// 1. Govt of Bangladesh National Emblem SVG Data URI
const GOVT_SEAL_SVG = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200"><circle cx="100" cy="100" r="95" fill="%23064e3b" stroke="%23d97706" stroke-width="4"/><circle cx="100" cy="100" r="82" fill="%23ffffff"/><circle cx="100" cy="100" r="76" fill="%23064e3b"/><circle cx="100" cy="100" r="70" fill="%23ffffff"/><circle cx="100" cy="100" r="32" fill="%23dc2626"/><circle cx="100" cy="100" r="14" fill="%23ffffff"/><path d="M100 42 L105 58 L122 58 L108 68 L113 84 L100 74 L87 84 L92 68 L78 58 L95 58 Z" fill="%23064e3b"/><path d="M100 158 L105 142 L122 142 L108 132 L113 116 L100 126 L87 116 L92 132 L78 142 L95 142 Z" fill="%23064e3b"/><text x="100" y="105" font-family="sans-serif" font-size="12" font-weight="bold" fill="%23064e3b" text-anchor="middle">BD GOVT</text></svg>`;

// 2. Digital Security Shield Verification SVG Data URI
const DIGITAL_SHIELD_SVG = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200"><defs><linearGradient id="shieldGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%25" stop-color="%23065f46"/><stop offset="100%25" stop-color="%23022c22"/></linearGradient></defs><path d="M100 15 C145 15 175 40 175 90 C175 145 125 180 100 190 C75 180 25 145 25 90 C25 40 55 15 100 15 Z" fill="url(%23shieldGrad)" stroke="%2334d399" stroke-width="6"/><path d="M100 30 C135 30 160 50 160 90 C160 135 120 165 100 174 C80 165 40 135 40 90 C40 50 65 30 100 30 Z" fill="%23ffffff" opacity="0.95"/><path d="M68 94 L88 114 L134 68" fill="none" stroke="%23059669" stroke-width="14" stroke-linecap="round" stroke-linejoin="round"/><circle cx="100" cy="148" r="8" fill="%23059669"/></svg>`;

// 3. Smart Bangladesh Digital Emblem SVG Data URI
const SMART_EMBLEM_SVG = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200"><circle cx="100" cy="100" r="92" fill="%230f172a" stroke="%2338bdf8" stroke-width="5"/><circle cx="100" cy="100" r="78" fill="%23ffffff"/><circle cx="100" cy="100" r="70" fill="%230284c7" opacity="0.15"/><path d="M70 100 A30 30 0 0 1 130 100 A30 30 0 0 1 70 100" fill="none" stroke="%230284c7" stroke-width="6"/><circle cx="100" cy="100" r="16" fill="%230284c7"/><path d="M100 45 L100 65 M100 135 L100 155 M45 100 L65 100 M135 100 L155 100" stroke="%230284c7" stroke-width="5" stroke-linecap="round"/><circle cx="100" cy="100" r="6" fill="%23ffffff"/></svg>`;

// 4. Golden Royal Crest SVG Data URI
const GOLDEN_CREST_SVG = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200"><defs><linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0%25" stop-color="%23f59e0b"/><stop offset="50%25" stop-color="%23fbbf24"/><stop offset="100%25" stop-color="%23b45309"/></linearGradient></defs><circle cx="100" cy="100" r="92" fill="%2378350f" stroke="url(%23goldGrad)" stroke-width="6"/><circle cx="100" cy="100" r="80" fill="%23fffbeb"/><circle cx="100" cy="100" r="72" fill="url(%23goldGrad)"/><circle cx="100" cy="100" r="64" fill="%23fffbeb"/><polygon points="100,50 112,82 146,82 118,102 128,134 100,114 72,134 82,102 54,82 88,82" fill="url(%23goldGrad)" stroke="%2392400e" stroke-width="2"/><circle cx="100" cy="98" r="12" fill="%2378350f"/></svg>`;

export const LOGO_PRESETS: Record<LogoStylePreset, LogoPresetInfo> = {
  'up-seal': {
    id: 'up-seal',
    label: 'UP Official Seal',
    labelBn: '🏛️ বহেড়াতৈল ইউপি সিল',
    description: '০২নং বহেড়াতৈল ইউনিয়ন পরিষদের অফিশিয়াল বৃত্তাকার মনোগ্রাম ও সিল',
    icon: '🏛️',
    url: '/baheratail_seal.svg'
  },
  'govt-seal': {
    id: 'govt-seal',
    label: 'Bangladesh Govt Seal',
    labelBn: '🇧🇩 বাংলাদেশ সরকার মনোগ্রাম',
    description: 'গণপ্রজাতন্ত্রী বাংলাদেশ সরকারের ক্লাসিকাল জাতীয় প্রতীক ও মনোগ্রাম',
    icon: '🇧🇩',
    url: GOVT_SEAL_SVG
  },
  'digital-shield': {
    id: 'digital-shield',
    label: 'Security Shield',
    labelBn: '🛡️ ডিজিটাল ভেরিফিকেশন শিল্ড',
    description: 'ক্রিপ্টোগ্রাফিক সুরক্ষা ও অনুমোদিত সত্যতা যাচাই শিল্ড',
    icon: '🛡️',
    url: DIGITAL_SHIELD_SVG
  },
  'smart-emblem': {
    id: 'smart-emblem',
    label: 'Smart Digital Emblem',
    labelBn: '🌐 স্মার্ট সেবা প্রতীক',
    description: 'আধুনিক স্মার্ট বাংলাদেশ ও ইউনিয়ন ডিজিটাল সেন্টার সিকিউরিটি আইকন',
    icon: '🌐',
    url: SMART_EMBLEM_SVG
  },
  'golden-crest': {
    id: 'golden-crest',
    label: 'Royal Golden Crest',
    labelBn: '👑 রয়্যাল গোল্ডেন ক্রেস্ট',
    description: 'অভিজাত সোনালী রাজকীয় ফ্রেম ও উচ্চ-মর্যাদার সনদ ভেরিফিকেশন ব্যাজ',
    icon: '👑',
    url: GOLDEN_CREST_SVG
  }
};

export interface WatermarkIntensityPreset {
  id: string;
  labelBn: string;
  value: number;
  description: string;
}

export const WATERMARK_INTENSITY_PRESETS: WatermarkIntensityPreset[] = [
  { id: 'off', labelBn: '🚫 বন্ধ (০%)', value: 0.0, description: 'কোনো ওয়াটারমার্ক নেই' },
  { id: 'subtle', labelBn: '🌿 মৃদু (৫%)', value: 0.05, description: 'অতি হালকা, পড়ার জন্য চমৎকার' },
  { id: 'standard', labelBn: '⚖️ স্ট্যান্ডার্ড (৮%)', value: 0.08, description: 'অফিসিয়াল ডিফল্ট ব্যালান্স' },
  { id: 'medium', labelBn: '👁️ মাঝারি (১৪%)', value: 0.14, description: 'স্পষ্ট দৃশ্যমান জলছাপ' },
  { id: 'prominent', labelBn: '🛡️ গাঢ় (২০%)', value: 0.20, description: 'নিরাপত্তা প্রাধান্য' },
  { id: 'security', labelBn: '🔒 হাই-সিকিউরিটি (২৮%)', value: 0.28, description: 'জালিয়াতি প্রতিরোধী' }
];
