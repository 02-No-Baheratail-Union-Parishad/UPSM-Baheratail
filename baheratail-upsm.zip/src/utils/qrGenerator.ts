import QRCode from 'qrcode';

export interface QrGeneratorOptions {
  width?: number;
  margin?: number;
  colorDark?: string;
  colorLight?: string;
  includeGoldBorder?: boolean;
  headerText?: string;
}

/**
 * Generate a Styled Data URL for QR Code (Emerald Modules with Gold Accents)
 */
export async function generateStyledQrDataUrl(
  text: string,
  options: QrGeneratorOptions = {}
): Promise<string> {
  const {
    width = 320,
    margin = 2,
    colorDark = '#006400',
    colorLight = '#FFFFFF',
    includeGoldBorder = true,
    headerText = '০২নং বহেড়াতৈল ইউপি — ভেরিফাইড'
  } = options;

  try {
    // Generate base QR canvas
    const canvas = document.createElement('canvas');
    await QRCode.toCanvas(canvas, text, {
      width: width,
      margin: margin,
      errorCorrectionLevel: 'H',
      color: {
        dark: colorDark,
        light: colorLight
      }
    });

    if (!includeGoldBorder) {
      return canvas.toDataURL('image/png');
    }

    // Composite with gold frame and header
    const borderPadding = 16;
    const bannerHeight = headerText ? 24 : 0;
    const finalCanvas = document.createElement('canvas');
    finalCanvas.width = canvas.width + borderPadding * 2;
    finalCanvas.height = canvas.height + borderPadding * 2 + bannerHeight;

    const ctx = finalCanvas.getContext('2d');
    if (!ctx) return canvas.toDataURL('image/png');

    // Background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, finalCanvas.width, finalCanvas.height);

    // Gold Outer Border
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#FFD700';
    ctx.strokeRect(4, 4, finalCanvas.width - 8, finalCanvas.height - 8);

    // Inner Emerald Line
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = '#006400';
    ctx.strokeRect(8, 8, finalCanvas.width - 16, finalCanvas.height - 16);

    // Draw Header Text
    if (headerText) {
      ctx.fillStyle = '#006400';
      ctx.font = 'bold 11px "Hind Siliguri", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(headerText, finalCanvas.width / 2, 22);
    }

    // Draw QR image centered
    ctx.drawImage(canvas, borderPadding, borderPadding + bannerHeight - 4);

    return finalCanvas.toDataURL('image/png');
  } catch (error) {
    console.error('Error generating styled QR code:', error);
    // Fallback standard QR
    return await QRCode.toDataURL(text, {
      width,
      margin,
      errorCorrectionLevel: 'M',
      color: { dark: colorDark, light: colorLight }
    });
  }
}

/**
 * Generate Raw SVG string of QR code for vector rendering
 */
export async function generateQrSvg(
  text: string,
  options: { width?: number; colorDark?: string; colorLight?: string } = {}
): Promise<string> {
  const { width = 256, colorDark = '#006400', colorLight = '#FFFFFF' } = options;
  return await QRCode.toString(text, {
    type: 'svg',
    width,
    errorCorrectionLevel: 'H',
    color: {
      dark: colorDark,
      light: colorLight
    }
  });
}
