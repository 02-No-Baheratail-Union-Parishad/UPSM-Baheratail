import jsQR from 'jsqr';

export interface ScanResult {
  rawText: string;
  memoNo?: string;
  isValidUpQr: boolean;
}

export class QrScannerController {
  private videoElement: HTMLVideoElement | null = null;
  private canvasElement: HTMLCanvasElement | null = null;
  private canvasCtx: CanvasRenderingContext2D | null = null;
  private stream: MediaStream | null = null;
  private animationFrameId: number | null = null;
  private isScanning: boolean = false;
  private onScanCallback: ((result: ScanResult) => void) | null = null;

  /**
   * Start camera stream and begin frame scan loop
   */
  async start(
    videoElement: HTMLVideoElement,
    onScan: (result: ScanResult) => void,
    onError?: (err: Error) => void
  ): Promise<void> {
    this.stop();
    this.videoElement = videoElement;
    this.onScanCallback = onScan;

    try {
      this.canvasElement = document.createElement('canvas');
      this.canvasCtx = this.canvasElement.getContext('2d', { willReadFrequently: true });

      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      };

      this.stream = await navigator.mediaDevices.getUserMedia(constraints);
      this.videoElement.srcObject = this.stream;
      this.videoElement.setAttribute('playsinline', 'true'); // Required for iOS and Android WebViews
      await this.videoElement.play();

      this.isScanning = true;
      this.scanLoop();
    } catch (err: any) {
      if (onError) onError(err);
      this.stop();
      throw err;
    }
  }

  private scanLoop = () => {
    if (!this.isScanning || !this.videoElement || !this.canvasCtx || !this.canvasElement) {
      return;
    }

    if (this.videoElement.readyState === this.videoElement.HAVE_ENOUGH_DATA) {
      this.canvasElement.height = this.videoElement.videoHeight;
      this.canvasElement.width = this.videoElement.videoWidth;

      this.canvasCtx.drawImage(
        this.videoElement,
        0,
        0,
        this.canvasElement.width,
        this.canvasElement.height
      );

      const imageData = this.canvasCtx.getImageData(
        0,
        0,
        this.canvasElement.width,
        this.canvasElement.height
      );

      const code = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: 'dontInvert'
      });

      if (code && code.data) {
        const parsed = this.parseQrData(code.data);
        if (this.onScanCallback) {
          this.onScanCallback(parsed);
        }
      }
    }

    this.animationFrameId = requestAnimationFrame(this.scanLoop);
  };

  /**
   * Parse QR code text or URL to extract memo number
   */
  public parseQrData(raw: string): ScanResult {
    const trimmed = raw.trim();
    let memoNo: string | undefined;

    // Check if it's a URL with memo parameter
    try {
      if (trimmed.includes('?')) {
        const urlObj = new URL(trimmed.startsWith('http') ? trimmed : `https://${trimmed}`);
        memoNo = urlObj.searchParams.get('memo') || urlObj.searchParams.get('id') || undefined;
      }
    } catch (_) {
      // Not a standard URL
    }

    // Direct memo format match (e.g. BUP-2026-XXXX or BAU-2026-XXXX)
    if (!memoNo) {
      const match = trimmed.match(/(BUP|BAU|UPMS)-[0-9]{4}-[0-9A-Z]+/i);
      if (match) {
        memoNo = match[0];
      } else if (trimmed.startsWith('BAU-') || trimmed.startsWith('BUP-')) {
        memoNo = trimmed;
      }
    }

    const isValidUpQr = Boolean(
      memoNo ||
      trimmed.includes('baheratail') ||
      trimmed.includes('bup') ||
      trimmed.includes('verify')
    );

    return {
      rawText: trimmed,
      memoNo: memoNo || (isValidUpQr ? trimmed : undefined),
      isValidUpQr
    };
  }

  /**
   * Stop camera stream and cleanup
   */
  stop(): void {
    this.isScanning = false;
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop());
      this.stream = null;
    }
    if (this.videoElement) {
      this.videoElement.srcObject = null;
    }
  }
}
